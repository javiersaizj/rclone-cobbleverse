# v4.8 - Sincronización rápida

La optimización principal está en `scripts/DeltaSync.ps1`.

## Qué cambia

- El escaneo local sigue basándose en metadatos (ruta, tamaño, fecha), pero ahora poda carpetas excluidas antes de recorrerlas.
- Cuando ambos PCs están en la misma generación, el sistema migra automáticamente del overlay antiguo a `bundle-v2`.
- En `bundle-v2`, los cambios de una sesión se empaquetan en un único ZIP **sin compresión** y rclone sube un solo objeto a Drive.
- El otro PC descarga un paquete por generación y lo aplica localmente.
- Cuando ambos PCs alcanzan la misma generación, los bundles antiguos se purgan y esa generación se convierte en la nueva base.
- Se eliminó el `rclone size` automático al final de cada sesión porque añadía una pasada completa por Drive solo para mostrar estadísticas.

## Por qué no se usa solo FileSystemWatcher

Minecraft/mods hacen muchas escrituras, renombrados y guardados asíncronos. FileSystemWatcher puede perder eventos si su buffer se desborda. Por seguridad se mantiene una lectura de metadatos completa (~1-3 s en el servidor actual) al inicio y al cierre; no se leen los ~10 GB de contenido.
