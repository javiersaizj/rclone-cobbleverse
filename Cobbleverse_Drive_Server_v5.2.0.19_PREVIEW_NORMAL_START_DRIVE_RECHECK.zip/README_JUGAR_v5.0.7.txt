BOTÓN JUGAR - v5.0.7 PREVIEW

Ruta de instancia detectada automáticamente:
%USERPROFILE%\curseforge\minecraft\Instances\COBBLEVERSE - Pokemon Adventure [Cobblemon]

IMPORTANTE:
La carpeta de una instancia de CurseForge no contiene por sí sola una orden pública/documentada que permita arrancar de forma fiable el perfil únicamente con la ruta. El manager utiliza el acceso directo de lanzamiento del perfil que genera CurseForge.

CONFIGURACIÓN UNA SOLA VEZ (si el perfil no tiene acceso directo):
1. Abrir CurseForge.
2. Abrir COBBLEVERSE - Pokemon Adventure [Cobblemon].
3. Crear el acceso directo de escritorio del perfil.
4. Cerrar CurseForge si quieres.

A partir de entonces el botón Jugar del Server Manager localiza ese acceso directo y lanza el perfil. No hace falta navegar por CurseForge manualmente cada vez.

v5.0.7 descarta expresamente Cobbleverse Server Manager.lnk para evitar el bucle visto en v5.0.6.

Opcional en config.json:
"MinecraftPlayShortcut": "%USERPROFILE%\Desktop\COBBLEVERSE - Pokemon Adventure [Cobblemon].lnk"
