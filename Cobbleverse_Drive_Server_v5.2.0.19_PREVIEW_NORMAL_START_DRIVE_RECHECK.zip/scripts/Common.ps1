﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$script:Root = Split-Path -Parent $PSScriptRoot
$script:ConfigPath = Join-Path $script:Root "config.json"
$script:DataDir = Join-Path $script:Root "data"
$script:ToolsDir = Join-Path $script:Root "tools"
$script:RcloneDir = Join-Path $script:ToolsDir "rclone"
$script:ResticDir = Join-Path $script:ToolsDir "restic"
$script:RcloneExe = Join-Path $script:RcloneDir "rclone.exe"
$script:ResticExe = Join-Path $script:ResticDir "restic.exe"
$script:RcloneConfig = Join-Path $script:DataDir "rclone.conf"
$script:OldResticPasswordFile = Join-Path $script:DataDir "restic-password.txt"
$script:LocalBackupPasswordFile = Join-Path $script:DataDir "local-backup-password.txt"
$script:DirtyMarkerPath = Join-Path $script:DataDir "local-session-in-progress.json"
$script:DuckDnsTokenFile = Join-Path $script:DataDir "duckdns-token.txt"
$script:CachedPublicIPv4 = $null
$script:PublicIPv4Checked = $false

function Get-DefaultStateExcludePatterns {
    return @(
        "/mods/**",
        "/libraries/**",
        "/.fabric/**",
        "/.cache/**",
        "/.local/**",
        "/.mixin.out/**",
        "/licenses/**",
        "/versions/**",
        "/resourcepacks/**",
        "/shaderpacks/**",
        "/showdown/**",
        "/stackdeobf_mappings/**",
        "/logs/**",
        "/crash-reports/**",
        "/backups/**",
        "/*.jar",
        "/manifest.json",
        "/modlist.html",
        "/COBBLEVERSE - Third-Party Licenses*",
        "/README*"
    )
}

function Load-CobbleverseConfig {
    if (-not (Test-Path $script:ConfigPath)) {
        $template = Join-Path $script:Root "config.template.json"
        if (Test-Path $template) {
            Copy-Item $template $script:ConfigPath -Force
        }
        else {
            throw "No se encuentra config.json ni config.template.json en $script:Root"
        }
    }
    $script:Config = Get-Content $script:ConfigPath -Raw | ConvertFrom-Json
    if (-not ($script:Config.PSObject.Properties.Name -contains 'PublicAccessMode')) { $script:Config | Add-Member -NotePropertyName PublicAccessMode -NotePropertyValue 'none' }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'DuckDnsSubdomain')) { $script:Config | Add-Member -NotePropertyName DuckDnsSubdomain -NotePropertyValue '' }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'ExternalPort')) { $script:Config | Add-Member -NotePropertyName ExternalPort -NotePropertyValue 0 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'AutoUpnp')) { $script:Config | Add-Member -NotePropertyName AutoUpnp -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'LocalBackupFolder')) { $script:Config | Add-Member -NotePropertyName LocalBackupFolder -NotePropertyValue 'local_backups' }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'SyncExcludePatterns')) { $script:Config | Add-Member -NotePropertyName SyncExcludePatterns -NotePropertyValue (Get-DefaultStateExcludePatterns) }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'LocalKeepLast')) { $script:Config | Add-Member -NotePropertyName LocalKeepLast -NotePropertyValue 10 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'LocalKeepDaily')) { $script:Config | Add-Member -NotePropertyName LocalKeepDaily -NotePropertyValue 7 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'LocalKeepWeekly')) { $script:Config | Add-Member -NotePropertyName LocalKeepWeekly -NotePropertyValue 4 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'ServerPath')) { $script:Config | Add-Member -NotePropertyName ServerPath -NotePropertyValue '' }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'SyncProtocol')) { $script:Config | Add-Member -NotePropertyName SyncProtocol -NotePropertyValue 'delta-overlay-v1' }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'AutoRebaseWhenBothClientsSynced')) { $script:Config | Add-Member -NotePropertyName AutoRebaseWhenBothClientsSynced -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'AutoLocalBackupAfterSession')) { $script:Config | Add-Member -NotePropertyName AutoLocalBackupAfterSession -NotePropertyValue $false }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BackgroundChangeTracking')) { $script:Config | Add-Member -NotePropertyName BackgroundChangeTracking -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BackgroundSweepIntervalMs')) { $script:Config | Add-Member -NotePropertyName BackgroundSweepIntervalMs -NotePropertyValue 3000 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BackgroundSweepDirectoriesPerCycle')) { $script:Config | Add-Member -NotePropertyName BackgroundSweepDirectoriesPerCycle -NotePropertyValue 1 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BackgroundDriveMaintenance')) { $script:Config | Add-Member -NotePropertyName BackgroundDriveMaintenance -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BackgroundDriveMaintenanceDelaySeconds')) { $script:Config | Add-Member -NotePropertyName BackgroundDriveMaintenanceDelaySeconds -NotePropertyValue 5 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BackgroundDriveMaintenanceStartupTimeoutSeconds')) { $script:Config | Add-Member -NotePropertyName BackgroundDriveMaintenanceStartupTimeoutSeconds -NotePropertyValue 180 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'AutoRetryPendingSync')) { $script:Config | Add-Member -NotePropertyName AutoRetryPendingSync -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'PendingSyncRetrySeconds')) { $script:Config | Add-Member -NotePropertyName PendingSyncRetrySeconds -NotePropertyValue 30 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'AutoRecoverInterruptedSession')) { $script:Config | Add-Member -NotePropertyName AutoRecoverInterruptedSession -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'PersistentManifestCache')) { $script:Config | Add-Member -NotePropertyName PersistentManifestCache -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BundleCompression')) { $script:Config | Add-Member -NotePropertyName BundleCompression -NotePropertyValue 'fast' }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'DriveChunkSizeMB')) { $script:Config | Add-Member -NotePropertyName DriveChunkSizeMB -NotePropertyValue 64 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'GameplayLockVerifyInitialMs')) { $script:Config | Add-Member -NotePropertyName GameplayLockVerifyInitialMs -NotePropertyValue 1800 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'GameplayLockVerifyConfirmMs')) { $script:Config | Add-Member -NotePropertyName GameplayLockVerifyConfirmMs -NotePropertyValue 700 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'PerformanceMetrics')) { $script:Config | Add-Member -NotePropertyName PerformanceMetrics -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'GenerationHistory')) { $script:Config | Add-Member -NotePropertyName GenerationHistory -NotePropertyValue $true }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'CheckpointThresholdGenerations')) { $script:Config | Add-Member -NotePropertyName CheckpointThresholdGenerations -NotePropertyValue 8 }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'AutoRestartAfterCrash')) { $script:Config | Add-Member -NotePropertyName AutoRestartAfterCrash -NotePropertyValue $false }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'ShutdownAfterSync')) { $script:Config | Add-Member -NotePropertyName ShutdownAfterSync -NotePropertyValue $false }

    if (-not ($script:Config.PSObject.Properties.Name -contains 'DiscordWebhookUrl')) { $script:Config | Add-Member -NotePropertyName DiscordWebhookUrl -NotePropertyValue '' }
    if (-not ($script:Config.PSObject.Properties.Name -contains 'BackupBeforeSession')) { $script:Config | Add-Member -NotePropertyName BackupBeforeSession -NotePropertyValue $false }
    $configuredServerPath = ([string]$script:Config.ServerPath).Trim()
    if (-not [string]::IsNullOrWhiteSpace($configuredServerPath)) {
        $script:ServerDir = [Environment]::ExpandEnvironmentVariables($configuredServerPath.Trim('"'))
    }
    else {
        $script:ServerDir = Join-Path $script:Root $script:Config.ServerFolder
    }
    $script:RemoteRoot = "$($script:Config.DriveRemote):$($script:Config.DriveBasePath)"
    $script:RemoteControl = "$script:RemoteRoot/control"
    $script:RemoteState = "$script:RemoteRoot/state"
    $script:RemoteLock = "$script:RemoteControl/server-lock.json"
    $script:RemoteStateVersion = "$script:RemoteControl/state-version.json"
    $script:RemoteBaseInfo = "$script:RemoteControl/static-base.json"
    $script:OldRemoteResticRepo = "$script:RemoteRoot/restic-repo"

    # Protocolo v4.2: Drive actua como bus de cambios. La base completa vive en ambos PCs.
    $script:RemoteDeltaRoot = "$script:RemoteRoot/delta-v1"
    $script:RemoteDeltaControl = "$script:RemoteDeltaRoot/control"
    $script:RemoteDeltaOverlay = "$script:RemoteDeltaRoot/overlay"
    $script:RemoteDeltaFiles = "$script:RemoteDeltaOverlay/files"
    $script:RemoteDeltaClients = "$script:RemoteDeltaRoot/clients"
    $script:RemoteDeltaCurrent = "$script:RemoteDeltaControl/current.json"
    $script:RemoteDeltaIndex = "$script:RemoteDeltaControl/index.json"
    $script:RemoteDeltaBaseline = "$script:RemoteDeltaControl/baseline.json"
    $script:ClientIdPath = Join-Path $script:DataDir "client-id.txt"
    $script:LocalGenerationPath = Join-Path $script:DataDir "local-generation.json"
    $script:SessionStartManifestPath = Join-Path $script:DataDir "session-start-manifest.json"
    $script:ChangeTrackerCandidatesPath = Join-Path $script:DataDir "change-tracker-candidates.txt"
    $script:ChangeTrackerStatePath = Join-Path $script:DataDir "change-tracker-state.json"
    $script:ChangeTrackerStopPath = Join-Path $script:DataDir "change-tracker-stop.flag"
    $script:ChangeTrackerReadyPath = Join-Path $script:DataDir "change-tracker-ready.flag"
    # v4.9.1: carpetas que no llegaron a revisarse en el ciclo suave actual.
    # Se validan al cerrar para completar el barrido sin volver a recorrer todo el servidor.
    $script:ChangeTrackerFinalDirsPath = Join-Path $script:DataDir "change-tracker-final-dirs.txt"
    $script:ChangeTrackerLogPath = Join-Path $script:DataDir "change-tracker.log"
    # v4.9.2: mantenimiento remoto diferido. Se ejecuta cuando Minecraft ya escucha,
    # para que la limpieza/rebase de generaciones antiguas no bloquee el arranque.
    $script:BackgroundMaintenanceStopPath = Join-Path $script:DataDir "background-drive-maintenance-stop.flag"
    $script:BackgroundMaintenanceStatePath = Join-Path $script:DataDir "background-drive-maintenance-state.json"
    $script:BackgroundMaintenanceLogPath = Join-Path $script:DataDir "background-drive-maintenance.log"
    $script:BackgroundMaintenanceManifestPath = Join-Path $script:DataDir "background-drive-maintenance-manifest.json"
    # v4.9.6: outbox local persistente. Un paquete READY nunca se borra hasta que
    # current.json confirme el commit remoto o se detecte un conflicto.
    $script:PendingSyncRoot = Join-Path $script:DataDir "pending-sync"
    $script:PendingSyncStatusPath = Join-Path $script:DataDir "pending-sync-status.json"
    # v4.9.9 PERFORMANCE: cache local de metadatos validada por generacion.
    $script:PersistentManifestCachePath = Join-Path $script:DataDir "persistent-manifest-cache.json"
    $script:PerformanceLastPath = Join-Path $script:DataDir "performance-last.json"

    $script:LocalBackupRoot = Join-Path $script:Root ([string]$script:Config.LocalBackupFolder)
    $script:LocalResticRepo = Join-Path $script:LocalBackupRoot "restic-repo"
}

function Save-CobbleverseConfig {
    $script:Config | ConvertTo-Json -Depth 10 | Set-Content -Path $script:ConfigPath -Encoding UTF8
}

function Get-StateExcludePatterns {
    if ($null -ne $script:Config -and $script:Config.PSObject.Properties.Name -contains 'SyncExcludePatterns') {
        return @($script:Config.SyncExcludePatterns | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    }
    return @(Get-DefaultStateExcludePatterns)
}

function Get-StateFilterArguments {
    $result = @()
    foreach ($pattern in @(Get-StateExcludePatterns)) {
        $result += @("--exclude", $pattern)
    }
    return $result
}

function Ensure-LocalBackupRepository {
    New-Item -ItemType Directory -Force -Path $script:DataDir, $script:LocalBackupRoot | Out-Null

    if (-not (Test-Path $script:LocalBackupPasswordFile)) {
        if (Test-Path $script:OldResticPasswordFile) {
            Copy-Item $script:OldResticPasswordFile $script:LocalBackupPasswordFile -Force
        }
        else {
            $bytes = New-Object byte[] 32
            [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
            $password = [Convert]::ToBase64String($bytes)
            Set-Content -Path $script:LocalBackupPasswordFile -Value $password -Encoding ASCII -NoNewline
        }
        try { & attrib +h $script:LocalBackupPasswordFile 2>$null } catch {}
    }

    $env:RESTIC_PASSWORD_FILE = $script:LocalBackupPasswordFile
    $env:RESTIC_CACHE_DIR = Join-Path $script:DataDir "restic-cache-local"
    New-Item -ItemType Directory -Force -Path $env:RESTIC_CACHE_DIR | Out-Null

    $repoConfig = Join-Path $script:LocalResticRepo "config"
    if (-not (Test-Path $repoConfig)) {
        New-Item -ItemType Directory -Force -Path $script:LocalResticRepo | Out-Null
        Write-Host "Inicializando backups LOCALES deduplicados en: $script:LocalBackupRoot" -ForegroundColor Cyan
        Invoke-Restic -Arguments @("init") | Out-Null
    }
}

function Initialize-CobbleverseEnvironment {
    Load-CobbleverseConfig
    New-Item -ItemType Directory -Force -Path $script:DataDir, $script:ToolsDir, $script:ServerDir, $script:LocalBackupRoot | Out-Null
    if ($null -ne $script:PendingSyncRoot -and -not [string]::IsNullOrWhiteSpace([string]$script:PendingSyncRoot)) { New-Item -ItemType Directory -Force -Path $script:PendingSyncRoot | Out-Null }

    if (-not (Test-Path $script:RcloneExe)) { throw "Falta rclone. Ejecuta primero 00_INSTALAR_Y_CONFIGURAR.bat" }
    if (-not (Test-Path $script:ResticExe)) { throw "Falta restic. Ejecuta primero 00_INSTALAR_Y_CONFIGURAR.bat" }
    if (-not (Test-Path $script:RcloneConfig)) { throw "Falta la configuracion de Google Drive. Ejecuta primero 00_INSTALAR_Y_CONFIGURAR.bat" }

    $env:RCLONE_CONFIG = $script:RcloneConfig
    Ensure-LocalBackupRepository
}

function Invoke-Rclone {
    param(
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [switch]$IgnoreExitCode
    )
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        & $script:RcloneExe @Arguments 2>&1 | Out-Host
        $code = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    if ((-not $IgnoreExitCode) -and $code -ne 0) { throw "rclone termino con codigo $code" }
    return $code
}

function Invoke-RcloneCapture {
    param(
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [switch]$IgnoreExitCode
    )
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        $output = & $script:RcloneExe @Arguments 2>$null
        $code = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    $global:LASTEXITCODE = $code
    if ((-not $IgnoreExitCode) -and $code -ne 0) { throw "rclone termino con codigo $code" }
    return (($output | Out-String).Trim())
}

function Invoke-Restic {
    param(
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [switch]$IgnoreExitCode
    )
    $base = @("-r", $script:LocalResticRepo)
    $all = $base + $Arguments
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        & $script:ResticExe @all 2>&1 | Out-Host
        $code = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    if ((-not $IgnoreExitCode) -and $code -ne 0) { throw "restic termino con codigo $code" }
    return $code
}

function Invoke-ResticCapture {
    param(
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [switch]$IgnoreExitCode
    )
    $base = @("-r", $script:LocalResticRepo)
    $all = $base + $Arguments
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        $output = & $script:ResticExe @all 2>$null
        $code = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    $global:LASTEXITCODE = $code
    if ((-not $IgnoreExitCode) -and $code -ne 0) { throw "restic termino con codigo $code" }
    return (($output | Out-String).Trim())
}

function Test-DriveRemote {
    $null = Invoke-RcloneCapture -Arguments @("lsd", "$($script:Config.DriveRemote):", "--config", $script:RcloneConfig) -IgnoreExitCode
    return ($LASTEXITCODE -eq 0)
}

function Get-RemoteLock {
    $raw = Invoke-RcloneCapture -Arguments @("cat", $script:RemoteLock, "--config", $script:RcloneConfig) -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) {
        return $null
    }
    try {
        return ($raw | ConvertFrom-Json)
    }
    catch {
        return $null
    }
}

function Get-MinecraftServerPort {
    $defaultPort = 25565
    $prop = Join-Path $script:ServerDir "server.properties"
    if (-not (Test-Path $prop)) { return $defaultPort }

    try {
        $line = Get-Content $prop -ErrorAction Stop |
            Where-Object { $_ -match '^\s*server-port\s*=\s*\d+\s*$' } |
            Select-Object -First 1
        if ($null -ne $line -and $line -match '=\s*(\d+)\s*$') {
            $port = [int]$Matches[1]
            if ($port -ge 1 -and $port -le 65535) { return $port }
        }
    }
    catch { }
    return $defaultPort
}

function Get-LanIPv4Addresses {
    $ips = @()

    try {
        $configs = Get-NetIPConfiguration -ErrorAction Stop |
            Where-Object { $null -ne $_.IPv4DefaultGateway -and $null -ne $_.IPv4Address }
        foreach ($cfg in $configs) {
            foreach ($addr in @($cfg.IPv4Address)) {
                $ip = [string]$addr.IPAddress
                if (-not [string]::IsNullOrWhiteSpace($ip) -and
                    $ip -ne '127.0.0.1' -and
                    -not $ip.StartsWith('169.254.')) {
                    $ips += $ip
                }
            }
        }
    }
    catch { }

    if ($ips.Count -eq 0) {
        try {
            $addresses = [System.Net.Dns]::GetHostAddresses($env:COMPUTERNAME)
            foreach ($addr in $addresses) {
                if ($addr.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork) {
                    $ip = $addr.IPAddressToString
                    if ($ip -ne '127.0.0.1' -and -not $ip.StartsWith('169.254.')) {
                        $ips += $ip
                    }
                }
            }
        }
        catch { }
    }

    return @($ips | Select-Object -Unique)
}

function Get-PublicIPv4 {
    if ($script:PublicIPv4Checked) { return $script:CachedPublicIPv4 }
    $script:PublicIPv4Checked = $true

    $services = @(
        'https://api.ipify.org',
        'https://checkip.amazonaws.com'
    )
    foreach ($uri in $services) {
        try {
            $value = ([string](Invoke-RestMethod -Uri $uri -TimeoutSec 5)).Trim()
            if ($value -match '^\d{1,3}(\.\d{1,3}){3}$') {
                $script:CachedPublicIPv4 = $value
                return $value
            }
        }
        catch { }
    }
    return $null
}

function Get-ConfiguredExternalPort {
    $internal = Get-MinecraftServerPort
    try {
        $configured = [int]$script:Config.ExternalPort
        if ($configured -ge 1 -and $configured -le 65535) { return $configured }
    }
    catch { }
    return $internal
}

function Get-PublicHostname {
    if ([string]$script:Config.PublicAccessMode -ne 'duckdns-upnp') { return $null }
    $sub = ([string]$script:Config.DuckDnsSubdomain).Trim()
    if ([string]::IsNullOrWhiteSpace($sub)) { return $null }
    if ($sub.EndsWith('.duckdns.org')) { return $sub }
    return "$sub.duckdns.org"
}

function Update-DuckDns {
    if ([string]$script:Config.PublicAccessMode -ne 'duckdns-upnp') { return $false }
    if (-not (Test-Path $script:DuckDnsTokenFile)) { throw "Falta data\\duckdns-token.txt. Ejecuta 07_CONFIGURAR_DIRECCION_FIJA.bat" }
    $sub = ([string]$script:Config.DuckDnsSubdomain).Trim() -replace '\.duckdns\.org$',''
    if ($sub -notmatch '^[A-Za-z0-9-]+$') { throw "Subdominio DuckDNS no valido: $sub" }
    $token = (Get-Content $script:DuckDnsTokenFile -Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($token)) { throw "El token DuckDNS esta vacio." }
    $public = Get-PublicIPv4
    if ([string]::IsNullOrWhiteSpace([string]$public)) { throw "No se pudo detectar la IP publica." }
    $uri = "https://www.duckdns.org/update?domains=$sub&token=$token&ip=$public"
    $reply = ([string](Invoke-RestMethod -Uri $uri -TimeoutSec 10)).Trim()
    if ($reply -ne 'OK') { throw "DuckDNS respondio '$reply'." }
    return $true
}

function Get-PreferredLanIPv4 {
    $ips = @(Get-LanIPv4Addresses)
    if ($ips.Count -eq 0) { return $null }
    return [string]$ips[0]
}

function Enable-UpnpPortMapping {
    param([int]$ExternalPort,[int]$InternalPort,[string]$InternalClient)
    try {
        $nat = New-Object -ComObject HNetCfg.NATUPnP
        $mappings = $nat.StaticPortMappingCollection
        if ($null -eq $mappings) { return [pscustomobject]@{success=$false;routerExternalIp=$null;message='UPnP no disponible o desactivado en el router.'} }
        try { $mappings.Remove($ExternalPort, 'TCP') } catch { }
        Start-Sleep -Milliseconds 300
        $mapping = $mappings.Add($ExternalPort, 'TCP', $InternalPort, $InternalClient, $true, 'Cobbleverse Minecraft')
        if ($null -eq $mapping) { return [pscustomobject]@{success=$false;routerExternalIp=$null;message='El router no acepto el port-forward.'} }
        $routerExternal = $null
        try { $routerExternal = [string]$mapping.ExternalIPAddress } catch { }
        return [pscustomobject]@{success=$true;routerExternalIp=$routerExternal;message='OK'}
    }
    catch { return [pscustomobject]@{success=$false;routerExternalIp=$null;message=$_.Exception.Message} }
}

function Disable-UpnpPortMapping {
    param([int]$ExternalPort)
    try {
        $nat = New-Object -ComObject HNetCfg.NATUPnP
        $mappings = $nat.StaticPortMappingCollection
        if ($null -ne $mappings) { $mappings.Remove($ExternalPort, 'TCP') }
    }
    catch { }
}

function Enable-CobbleversePublicAccess {
    if ([string]$script:Config.PublicAccessMode -ne 'duckdns-upnp') {
        return [pscustomobject]@{enabled=$false;hostname=$null;externalPort=(Get-MinecraftServerPort);upnp=$false;warning=$null}
    }
    $hostname = Get-PublicHostname
    $internalPort = Get-MinecraftServerPort
    $externalPort = Get-ConfiguredExternalPort
    $lan = Get-PreferredLanIPv4
    if ([string]::IsNullOrWhiteSpace([string]$lan)) { throw "No se pudo detectar la IP LAN." }
    $null = Update-DuckDns
    $warning = $null
    $upnpOk = $false
    $routerExternal = $null
    if ([bool]$script:Config.AutoUpnp) {
        $map = Enable-UpnpPortMapping -ExternalPort $externalPort -InternalPort $internalPort -InternalClient $lan
        $upnpOk = [bool]$map.success
        $routerExternal = $map.routerExternalIp
        if (-not $upnpOk) { $warning = "No se pudo abrir el puerto automaticamente: $($map.message)" }
        else {
            $internetIp = Get-PublicIPv4
            if (-not [string]::IsNullOrWhiteSpace([string]$routerExternal) -and -not [string]::IsNullOrWhiteSpace([string]$internetIp) -and $routerExternal -ne $internetIp) {
                $warning = "Posible CG-NAT/doble NAT: WAN router $routerExternal, IP publica $internetIp."
            }
        }
    }
    return [pscustomobject]@{enabled=$true;hostname=$hostname;externalPort=$externalPort;upnp=$upnpOk;warning=$warning}
}

function Disable-CobbleversePublicAccess {
    if ([string]$script:Config.PublicAccessMode -eq 'duckdns-upnp' -and [bool]$script:Config.AutoUpnp) {
        Disable-UpnpPortMapping -ExternalPort (Get-ConfiguredExternalPort)
    }
}

function Get-ServerConnectionInfo {
    $lan = @(Get-LanIPv4Addresses)
    $public = Get-PublicIPv4
    $port = Get-MinecraftServerPort
    return [pscustomobject]@{
        lanIPv4 = $lan
        publicIPv4 = $public
        serverPort = $port
        publicHost = (Get-PublicHostname)
        externalPort = (Get-ConfiguredExternalPort)
    }
}

function Get-LockConnectionInfo {
    param($Lock)
    $lan=@(); $public=$null; $port=25565; $publicHost=$null; $externalPort=25565
    if ($null -ne $Lock) {
        if ($Lock.PSObject.Properties.Name -contains 'lanIPv4') { $lan=@($Lock.lanIPv4 | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }) }
        if ($Lock.PSObject.Properties.Name -contains 'publicIPv4') { $public=[string]$Lock.publicIPv4; if ([string]::IsNullOrWhiteSpace($public)) {$public=$null} }
        if ($Lock.PSObject.Properties.Name -contains 'serverPort') { try {$c=[int]$Lock.serverPort; if ($c -ge 1 -and $c -le 65535) {$port=$c}} catch {} }
        if ($Lock.PSObject.Properties.Name -contains 'publicHost') { $publicHost=[string]$Lock.publicHost; if ([string]::IsNullOrWhiteSpace($publicHost)) {$publicHost=$null} }
        if ($Lock.PSObject.Properties.Name -contains 'externalPort') { try {$c=[int]$Lock.externalPort; if ($c -ge 1 -and $c -le 65535) {$externalPort=$c}} catch {} } else {$externalPort=$port}
    }
    return [pscustomobject]@{lanIPv4=$lan;publicIPv4=$public;serverPort=$port;publicHost=$publicHost;externalPort=$externalPort}
}

function Show-ExistingServerInfo {
    param([Parameter(Mandatory=$true)]$Lock)

    $info = Get-LockConnectionInfo -Lock $Lock
    $status = [string]$Lock.status
    $hostName = [string]$Lock.host
    $isRunning = ($status -eq 'server-running')

    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Yellow
    if ($isRunning) {
        Write-Host " EL SERVIDOR COBBLEVERSE YA ESTA EJECUTANDOSE" -ForegroundColor Yellow
    }
    else {
        Write-Host " EL SERVIDOR COBBLEVERSE YA ESTA RESERVADO POR OTRO PC" -ForegroundColor Yellow
    }
    Write-Host "================================================================" -ForegroundColor Yellow
    Write-Host (" PC activo : {0}" -f $hostName) -ForegroundColor Cyan
    Write-Host (" Estado    : {0}" -f $status) -ForegroundColor Cyan
    Write-Host (" Puerto    : {0}" -f $info.serverPort) -ForegroundColor Cyan

    if ($isRunning) {
        Write-Host ""
        Write-Host " DIRECCIONES PARA CONECTARTE:" -ForegroundColor Green

        if ($info.lanIPv4.Count -gt 0) {
            foreach ($ip in $info.lanIPv4) {
                Write-Host ("   Misma red / Wi-Fi : {0}:{1}" -f $ip, $info.serverPort) -ForegroundColor Green
            }
        }
        else {
            Write-Host "   IP local          : no se pudo detectar" -ForegroundColor DarkYellow
        }

        if (-not [string]::IsNullOrWhiteSpace([string]$info.publicHost)) {
            Write-Host ("   DIRECCION FIJA    : {0}:{1}" -f $info.publicHost, $info.externalPort) -ForegroundColor Magenta
        }
        if (-not [string]::IsNullOrWhiteSpace([string]$info.publicIPv4)) {
            Write-Host ("   IP publica actual : {0}:{1}" -f $info.publicIPv4, $info.externalPort) -ForegroundColor Green
        }
        else {
            Write-Host "   IP publica        : no se pudo detectar" -ForegroundColor DarkYellow
        }

        $thisPublic = Get-PublicIPv4
        if (-not [string]::IsNullOrWhiteSpace([string]$thisPublic) -and
            -not [string]::IsNullOrWhiteSpace([string]$info.publicIPv4) -and
            $thisPublic -eq $info.publicIPv4 -and
            $info.lanIPv4.Count -gt 0) {
            Write-Host ""
            Write-Host (" PARECE QUE ESTAS EN LA MISMA RED: usa {0}:{1}" -f $info.lanIPv4[0], $info.serverPort) -ForegroundColor Magenta
        }
    }
    else {
        Write-Host ""
        Write-Host "El otro PC todavia esta preparando/restaurando/cerrando el servidor." -ForegroundColor DarkYellow
        Write-Host "No se inicia una segunda copia para proteger el mundo." -ForegroundColor DarkYellow
    }
    Write-Host "================================================================" -ForegroundColor Yellow
    Write-Host ""
}

function Write-RemoteLock {
    param(
        [Parameter(Mandatory=$true)][string]$SessionId,
        [Parameter(Mandatory=$true)][string]$Status,
        $ConnectionInfo = $null
    )

    $startedUtc = [DateTimeOffset]::UtcNow.ToString("o")
    if ($null -eq $ConnectionInfo) {
        $previous = Get-RemoteLock
        if ($null -ne $previous -and [string]$previous.sessionId -eq $SessionId) {
            $ConnectionInfo = Get-LockConnectionInfo -Lock $previous
            if ($previous.PSObject.Properties.Name -contains 'sessionStartedUtc') {
                $startedUtc = [string]$previous.sessionStartedUtc
            }
        }
        else {
            $ConnectionInfo = Get-ServerConnectionInfo
        }
    }

    $payload = [ordered]@{
        sessionId = $SessionId
        host = $env:COMPUTERNAME
        user = $env:USERNAME
        status = $Status
        sessionStartedUtc = $startedUtc
        heartbeatUtc = [DateTimeOffset]::UtcNow.ToString("o")
        lanIPv4 = @($ConnectionInfo.lanIPv4)
        publicIPv4 = $ConnectionInfo.publicIPv4
        serverPort = [int]$ConnectionInfo.serverPort
        publicHost = $ConnectionInfo.publicHost
        externalPort = [int]$ConnectionInfo.externalPort
    }
    $tmp = Join-Path $script:DataDir ("lock-{0}.json" -f $SessionId)
    $payload | ConvertTo-Json -Depth 5 | Set-Content -Path $tmp -Encoding UTF8
    try {
        Invoke-Rclone -Arguments @("mkdir", $script:RemoteControl, "--config", $script:RcloneConfig) | Out-Null
        Invoke-Rclone -Arguments @("copyto", $tmp, $script:RemoteLock, "--config", $script:RcloneConfig, "--no-traverse") | Out-Null
    }
    finally {
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Acquire-GameplayLock {
    param([string]$RecoverySessionId = "")
    $existing = Get-RemoteLock
    if ($null -ne $existing) {
        $sameRecovery = (-not [string]::IsNullOrWhiteSpace($RecoverySessionId) -and [string]$existing.sessionId -eq $RecoverySessionId -and [string]$existing.host -eq $env:COMPUTERNAME)
        if ($sameRecovery) {
            Write-Host "Se ha detectado el bloqueo de la sesion pendiente de ESTE PC. Se permite la recuperacion local." -ForegroundColor Yellow
            Write-RemoteLock -SessionId $RecoverySessionId -Status "recovering-local-session"
            return $RecoverySessionId
        }

        $stale = $false
        try {
            $hb = [DateTimeOffset]::Parse([string]$existing.heartbeatUtc)
            $age = [DateTimeOffset]::UtcNow - $hb
            $stale = ($age.TotalMinutes -ge [double]$script:Config.GameplayLockTimeoutMinutes)
        }
        catch { $stale = $true }

        if (-not $stale) {
            Show-ExistingServerInfo -Lock $existing
            throw "El servidor ya esta en uso por $($existing.host). Se cancela este arranque."
        }

        Write-Host ""
        Write-Host "ATENCION: existe un bloqueo antiguo de $($existing.host)." -ForegroundColor Yellow
        Write-Host "Puede significar que ese PC se apago o que todavia tiene avances locales sin subir." -ForegroundColor Yellow
        $answer = Read-Host "Escribe FORZAR solo si estas seguro de que el otro servidor NO esta funcionando"
        if ($answer -cne "FORZAR") { throw "Operacion cancelada para proteger el mundo." }
    }

    $session = [guid]::NewGuid().ToString("N")
    $connectionInfo = Get-ServerConnectionInfo
    Write-RemoteLock -SessionId $session -Status "claiming" -ConnectionInfo $connectionInfo
    Write-Host "Verificando bloqueo remoto (modo rapido seguro)..."
    $initialMs = [Math]::Max(800,[int]$script:Config.GameplayLockVerifyInitialMs)
    $confirmMs = [Math]::Max(300,[int]$script:Config.GameplayLockVerifyConfirmMs)
    Start-Sleep -Milliseconds $initialMs
    $verify = Get-RemoteLock
    if ($null -eq $verify -or [string]$verify.sessionId -ne $session) {
        throw "Otro PC ha reclamado el servidor al mismo tiempo. Este arranque se cancela."
    }
    # Segunda lectura corta: evita ganar una lectura intermedia si ambos PCs pulsaron iniciar casi a la vez.
    Start-Sleep -Milliseconds $confirmMs
    $verify2 = Get-RemoteLock
    if ($null -eq $verify2 -or [string]$verify2.sessionId -ne $session) {
        throw "Otro PC ha reclamado el servidor al mismo tiempo. Este arranque se cancela."
    }
    Write-RemoteLock -SessionId $session -Status "preparing"
    return $session
}

function Set-GameplayLockStatus {
    param(
        [string]$SessionId,
        [string]$Status,
        [switch]$RefreshConnectionInfo
    )
    $current = Get-RemoteLock
    if ($null -ne $current -and [string]$current.sessionId -eq $SessionId) {
        if ($RefreshConnectionInfo) {
            Write-RemoteLock -SessionId $SessionId -Status $Status -ConnectionInfo (Get-ServerConnectionInfo)
        }
        else {
            Write-RemoteLock -SessionId $SessionId -Status $Status
        }
    }
}

function Release-GameplayLock {
    param([Parameter(Mandatory=$true)][string]$SessionId)
    # v4.9.6: devuelve TRUE solo cuando podemos confirmar con Drive que nuestro lock
    # ya no existe. Una caida de Internet no se confunde con "lock liberado".
    if (-not (Test-DriveRemote)) { return $false }
    $current = Get-RemoteLock
    if ($null -eq $current) { return $true }
    if ([string]$current.sessionId -ne $SessionId) { return $true }
    $code = Invoke-Rclone -Arguments @("deletefile", $script:RemoteLock, "--config", $script:RcloneConfig, "--drive-use-trash=false") -IgnoreExitCode
    if ($code -ne 0) { return $false }
    $verify = Get-RemoteLock
    if ($null -eq $verify -or [string]$verify.sessionId -ne $SessionId) {
        Write-Host "Bloqueo remoto liberado."
        return $true
    }
    return $false
}

function Start-LockHeartbeat {
    param([Parameter(Mandatory=$true)][string]$SessionId)
    $rclone = $script:RcloneExe
    $rcloneConfig = $script:RcloneConfig
    $remoteLock = $script:RemoteLock
    $hostName = $env:COMPUTERNAME
    $userName = $env:USERNAME

    $job = Start-Job -ScriptBlock {
        param($RcloneExe, $RcloneConfig, $RemoteLock, $SessionId, $HostName, $UserName)
        while ($true) {
            Start-Sleep -Seconds 60
            $raw = & $RcloneExe cat $RemoteLock --config $RcloneConfig 2>$null
            if ($LASTEXITCODE -ne 0) { continue }
            try { $obj = (($raw | Out-String).Trim() | ConvertFrom-Json) } catch { continue }
            if ([string]$obj.sessionId -ne $SessionId) { break }

            $lan = @()
            $public = $null
            $port = 25565
            $publicHost = $null
            $externalPort = 25565
            $startedUtc = [DateTimeOffset]::UtcNow.ToString("o")
            if ($obj.PSObject.Properties.Name -contains 'lanIPv4') { $lan = @($obj.lanIPv4) }
            if ($obj.PSObject.Properties.Name -contains 'publicIPv4') { $public = [string]$obj.publicIPv4 }
            if ($obj.PSObject.Properties.Name -contains 'serverPort') { $port = [int]$obj.serverPort }
            if ($obj.PSObject.Properties.Name -contains 'publicHost') { $publicHost = [string]$obj.publicHost }
            if ($obj.PSObject.Properties.Name -contains 'externalPort') { $externalPort = [int]$obj.externalPort } else { $externalPort = $port }
            if ($obj.PSObject.Properties.Name -contains 'sessionStartedUtc') { $startedUtc = [string]$obj.sessionStartedUtc }

            $payload = [ordered]@{
                sessionId = $SessionId
                host = $HostName
                user = $UserName
                status = [string]$obj.status
                sessionStartedUtc = $startedUtc
                heartbeatUtc = [DateTimeOffset]::UtcNow.ToString("o")
                lanIPv4 = $lan
                publicIPv4 = $public
                serverPort = $port
                publicHost = $publicHost
                externalPort = $externalPort
            }
            $tmp = Join-Path $env:TEMP ("cobbleverse-lock-{0}.json" -f $SessionId)
            $payload | ConvertTo-Json -Depth 5 | Set-Content -Path $tmp -Encoding UTF8
            & $RcloneExe copyto $tmp $RemoteLock --config $RcloneConfig --no-traverse *> $null
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        }
    } -ArgumentList $rclone, $rcloneConfig, $remoteLock, $SessionId, $hostName, $userName
    return $job
}

function Stop-LockHeartbeat {
    param($Job)
    if ($null -ne $Job) {
        Stop-Job $Job -ErrorAction SilentlyContinue | Out-Null
        Remove-Job $Job -Force -ErrorAction SilentlyContinue | Out-Null
    }
}

function Format-ByteSize {
    param([long]$Bytes)
    if ($Bytes -ge 1TB) { return ("{0:N2} TB" -f ($Bytes / 1TB)) }
    if ($Bytes -ge 1GB) { return ("{0:N2} GB" -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ("{0:N2} MB" -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ("{0:N2} KB" -f ($Bytes / 1KB)) }
    return "$Bytes bytes"
}

function Get-RcloneSizeInfo {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [switch]$ApplyStateFilters
    )
    $args = @("size", $Path, "--json", "--config", $script:RcloneConfig)
    if ($ApplyStateFilters) { $args += @(Get-StateFilterArguments) }
    $raw = Invoke-RcloneCapture -Arguments $args
    try { return ($raw | ConvertFrom-Json) } catch { throw "No se pudo interpretar el tamano calculado por rclone." }
}

function Show-StateSizeAnalysis {
    if (-not (Test-Path $script:ServerDir)) { return }
    $total = Get-RcloneSizeInfo -Path $script:ServerDir
    $state = Get-RcloneSizeInfo -Path $script:ServerDir -ApplyStateFilters
    $staticBytes = [long]$total.bytes - [long]$state.bytes
    if ($staticBytes -lt 0) { $staticBytes = 0 }
    Write-Host ""
    Write-Host "=========== ANALISIS DE ESPACIO ===========" -ForegroundColor Cyan
    Write-Host ("Servidor local completo : {0} ({1} archivos)" -f (Format-ByteSize ([long]$total.bytes)), $total.count)
    Write-Host ("Estado que ira a Drive : {0} ({1} archivos)" -f (Format-ByteSize ([long]$state.bytes)), $state.count) -ForegroundColor Green
    Write-Host ("Base estatica solo local: {0}" -f (Format-ByteSize $staticBytes)) -ForegroundColor Yellow
    Write-Host "Drive NO guardara mods, libraries, .fabric, versions, resourcepacks, shaderpacks, showdown, logs ni los JAR del servidor."
    Write-Host "============================================" -ForegroundColor Cyan
    if ([long]$state.bytes -ge 12GB) {
        Write-Host "AVISO: el estado mutable supera 12 GB. Con una cuenta Drive de 15 GB quedara muy poco margen." -ForegroundColor Red
    }
}

function Get-StaticBaseInfo {
    if (-not (Test-Path $script:ServerDir)) { throw "No existe la carpeta local del servidor." }

    # La base estatica no se envia a Drive. Este identificador rapido sirve para
    # comprobar que los dos PCs parten del mismo pack descargado del hosting.
    # Se basa en ruta + tamano de los ficheros estaticos; no lee/hash-ea varios GB.
    $staticRoots = @(
        "mods",
        "libraries",
        ".fabric",
        "versions",
        "resourcepacks",
        "shaderpacks",
        "showdown",
        "stackdeobf_mappings",
        "licenses"
    )

    $records = New-Object System.Collections.Generic.List[string]
    [int64]$bytes = 0
    [int64]$count = 0

    foreach ($name in $staticRoots) {
        $dir = Join-Path $script:ServerDir $name
        if (-not (Test-Path $dir)) { continue }
        Get-ChildItem -Path $dir -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
            $relative = $_.FullName.Substring($script:ServerDir.Length).TrimStart([char]'\',[char]'/').Replace('\','/')
            $records.Add(("{0}|{1}" -f $relative, [int64]$_.Length))
            $bytes += [int64]$_.Length
            $count++
        }
    }

    # JARs y metadatos del pack situados en la raiz.
    Get-ChildItem -Path $script:ServerDir -File -Force -ErrorAction SilentlyContinue | Where-Object {
        $_.Extension -ieq '.jar' -or $_.Name -ieq 'manifest.json' -or $_.Name -ieq 'modlist.html'
    } | ForEach-Object {
        $relative = $_.Name.Replace('\','/')
        $records.Add(("{0}|{1}" -f $relative, [int64]$_.Length))
        $bytes += [int64]$_.Length
        $count++
    }

    $ordered = @($records | Sort-Object)
    $joined = [string]::Join("`n", $ordered)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hashBytes = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($joined))
    }
    finally { $sha.Dispose() }
    $fingerprint = ([BitConverter]::ToString($hashBytes)).Replace('-','').ToLowerInvariant()

    return [pscustomobject][ordered]@{
        format = 'path-size-v1'
        fingerprint = $fingerprint
        files = $count
        bytes = $bytes
        minecraftVersion = [string]$script:Config.MinecraftVersion
        serverJar = [string]$script:Config.ServerJar
        generatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
        host = $env:COMPUTERNAME
    }
}

function Get-RemoteStaticBaseInfo {
    $raw = Invoke-RcloneCapture -Arguments @("cat", $script:RemoteBaseInfo, "--config", $script:RcloneConfig) -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) { return $null }
    try { return ($raw | ConvertFrom-Json) } catch { return $null }
}

function Publish-StaticBaseInfo {
    $info = Get-StaticBaseInfo
    $tmp = Join-Path $script:DataDir ("static-base-{0}.json" -f [guid]::NewGuid().ToString('N'))
    $info | ConvertTo-Json -Depth 4 | Set-Content $tmp -Encoding UTF8
    try {
        Invoke-Rclone -Arguments @("mkdir", $script:RemoteControl, "--config", $script:RcloneConfig) | Out-Null
        Invoke-Rclone -Arguments @("copyto", $tmp, $script:RemoteBaseInfo, "--config", $script:RcloneConfig, "--no-traverse") | Out-Null
    }
    finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
    return $info
}

function Assert-StaticBaseCompatibleWithRemote {
    param([switch]$AllowMissingRemote)
    $remote = Get-RemoteStaticBaseInfo
    if ($null -eq $remote) {
        if ($AllowMissingRemote) { return $true }
        throw "Drive no contiene la huella de la base estatica. Ejecuta primero 01_IMPORTAR_DESDE_HOSTING.bat en el PC principal con la v4.1."
    }

    $local = Get-StaticBaseInfo
    if ([string]$remote.fingerprint -ne [string]$local.fingerprint) {
        Write-Host "" 
        Write-Host "LA BASE DEL SEGUNDO PC NO COINCIDE CON LA DEL PC PRINCIPAL." -ForegroundColor Red
        Write-Host ("PC principal: {0} archivos estaticos, {1}" -f $remote.files, (Format-ByteSize ([int64]$remote.bytes))) -ForegroundColor Yellow
        Write-Host ("Este PC     : {0} archivos estaticos, {1}" -f $local.files, (Format-ByteSize ([int64]$local.bytes))) -ForegroundColor Yellow
        Write-Host "Usa exactamente la misma descarga del hosting/modpack en ambos PCs antes de continuar." -ForegroundColor Yellow
        throw "La huella estatica no coincide. Se cancela para evitar arrancar el mismo mundo con mods/librerias diferentes."
    }

    Write-Host ("Base estatica verificada: {0} archivos, {1}" -f $local.files, (Format-ByteSize ([int64]$local.bytes))) -ForegroundColor Green
    return $true
}

function Get-RemoteStateVersion {
    $raw = Invoke-RcloneCapture -Arguments @("cat", $script:RemoteStateVersion, "--config", $script:RcloneConfig) -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) { return $null }
    try { return ($raw | ConvertFrom-Json) } catch { return $null }
}

function Publish-RemoteStateVersion {
    param(
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$Reason = "session"
    )
    $previous = Get-RemoteStateVersion
    $generation = 1
    if ($null -ne $previous -and $previous.PSObject.Properties.Name -contains 'generation') {
        try { $generation = [int64]$previous.generation + 1 } catch { $generation = 1 }
    }
    $size = Get-RcloneSizeInfo -Path $script:ServerDir -ApplyStateFilters
    $payload = [ordered]@{
        generation = $generation
        updatedUtc = [DateTimeOffset]::UtcNow.ToString("o")
        host = $env:COMPUTERNAME
        sessionId = $SessionId
        reason = $Reason
        files = [int64]$size.count
        bytes = [int64]$size.bytes
    }
    $tmp = Join-Path $script:DataDir ("state-version-{0}.json" -f $SessionId)
    $payload | ConvertTo-Json -Depth 4 | Set-Content $tmp -Encoding UTF8
    try {
        Invoke-Rclone -Arguments @("mkdir", $script:RemoteControl, "--config", $script:RcloneConfig) | Out-Null
        Invoke-Rclone -Arguments @("copyto", $tmp, $script:RemoteStateVersion, "--config", $script:RcloneConfig, "--no-traverse") | Out-Null
    }
    finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
    return $payload
}

function Sync-StateToDrive {
    Write-Host "Sincronizando SOLO el estado mutable hacia Google Drive..." -ForegroundColor Cyan
    Invoke-Rclone -Arguments @("mkdir", $script:RemoteState, "--config", $script:RcloneConfig) | Out-Null
    $args = @(
        "sync", $script:ServerDir, $script:RemoteState,
        "--config", $script:RcloneConfig,
        "--create-empty-src-dirs",
        "--fast-list",
        "--checkers", "16",
        "--transfers", "8",
        "--drive-use-trash=false",
        "--stats", "10s",
        "--stats-one-line"
    )
    $args += @(Get-StateFilterArguments)
    Invoke-Rclone -Arguments $args | Out-Null
}

function Sync-StateFromDrive {
    $version = Get-RemoteStateVersion
    if ($null -eq $version) {
        throw "No existe estado inicial en Drive. Ejecuta primero 01_IMPORTAR_DESDE_HOSTING.bat en el primer PC."
    }
    Write-Host ("Estado remoto: generacion {0}, guardado por {1} el {2}" -f $version.generation, $version.host, $version.updatedUtc) -ForegroundColor DarkGray
    Write-Host "Aplicando los cambios de Drive sobre la instalacion local..." -ForegroundColor Cyan
    $args = @(
        "sync", $script:RemoteState, $script:ServerDir,
        "--config", $script:RcloneConfig,
        "--create-empty-src-dirs",
        "--fast-list",
        "--checkers", "16",
        "--transfers", "8",
        "--stats", "10s",
        "--stats-one-line"
    )
    $args += @(Get-StateFilterArguments)
    Invoke-Rclone -Arguments $args | Out-Null
}

function Get-LatestSnapshotId {
    $json = Invoke-ResticCapture -Arguments @("snapshots", "--host", $env:COMPUTERNAME, "--latest", "1", "--json") -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($json)) { return $null }
    try {
        $arr = $json | ConvertFrom-Json
        if ($null -eq $arr) { return $null }
        if ($arr -is [System.Array]) {
            if ($arr.Count -eq 0) { return $null }
            return [string]$arr[0].id
        }
        return [string]$arr.id
    }
    catch { return $null }
}

function Backup-Server {
    param([string[]]$ExtraTags = @())
    if (-not (Test-Path $script:ServerDir)) { throw "No existe la carpeta del servidor." }

    $args = @(
        "backup", ".",
        "--host", $env:COMPUTERNAME,
        "--tag", "cobbleverse-state",
        "--ignore-inode",
        "--ignore-ctime"
    )
    foreach ($pattern in @(Get-StateExcludePatterns)) { $args += @("--exclude", $pattern) }
    foreach ($tag in $ExtraTags) { $args += @("--tag", $tag) }

    Push-Location $script:ServerDir
    try { Invoke-Restic -Arguments $args | Out-Null }
    finally { Pop-Location }
}

function Restore-LocalSnapshotToServer {
    param([Parameter(Mandatory=$true)][string]$SnapshotId)
    $temp = Join-Path $env:TEMP ("CobbleverseRollback-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    try {
        Invoke-Restic -Arguments @("restore", "${SnapshotId}:/", "--target", $temp) | Out-Null
        $args = @("sync", $temp, $script:ServerDir, "--config", $script:RcloneConfig, "--create-empty-src-dirs")
        $args += @(Get-StateFilterArguments)
        Invoke-Rclone -Arguments $args | Out-Null
    }
    finally { Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue }
}

function Find-ServerJar {
    if (-not [string]::IsNullOrWhiteSpace([string]$script:Config.ServerJar)) {
        $configured = Join-Path $script:ServerDir ([string]$script:Config.ServerJar)
        if (Test-Path $configured) { return [string]$script:Config.ServerJar }
    }

    $patterns = @(
        "fabric-server-mc.*-launcher.*.jar",
        "fabric-server-launch.jar",
        "fabric-server-launcher.jar",
        "server.jar"
    )
    foreach ($p in $patterns) {
        $f = Get-ChildItem -Path $script:ServerDir -File -Filter $p -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($null -ne $f) { return $f.Name }
    }

    $fabric = Get-ChildItem -Path $script:ServerDir -File -Filter "*.jar" -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match "fabric" -and $_.Name -notmatch "installer" } |
        Select-Object -First 1
    if ($null -ne $fabric) { return $fabric.Name }
    return $null
}

function Install-OfficialFabricLauncher {
    Write-Host "No se ha encontrado un launcher Fabric en la copia del hosting." -ForegroundColor Yellow
    Write-Host "Descargando un launcher oficial de Fabric para Minecraft $($script:Config.MinecraftVersion)..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $mc = [string]$script:Config.MinecraftVersion
    $loaders = Invoke-RestMethod -Uri "https://meta.fabricmc.net/v2/versions/loader/$mc"
    $loaderObj = $loaders | Where-Object { $_.loader.stable -eq $true } | Select-Object -First 1
    if ($null -eq $loaderObj) { $loaderObj = $loaders | Select-Object -First 1 }
    if ($null -eq $loaderObj) { throw "Fabric Meta no devolvio un loader para $mc" }

    $installers = Invoke-RestMethod -Uri "https://meta.fabricmc.net/v2/versions/installer"
    $installerObj = $installers | Where-Object { $_.stable -eq $true } | Select-Object -First 1
    if ($null -eq $installerObj) { $installerObj = $installers | Select-Object -First 1 }
    if ($null -eq $installerObj) { throw "Fabric Meta no devolvio un installer." }

    $loader = [string]$loaderObj.loader.version
    $installer = [string]$installerObj.version
    $name = "fabric-server-mc.$mc-loader.$loader-launcher.$installer.jar"
    $url = "https://meta.fabricmc.net/v2/versions/loader/$mc/$loader/$installer/server/jar"
    $dest = Join-Path $script:ServerDir $name
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $dest
    Write-Host "Launcher Fabric instalado: $name"
    return $name
}

function Normalize-ServerProperties {
    $prop = Join-Path $script:ServerDir "server.properties"
    if (-not (Test-Path $prop)) { return }
    $lines = Get-Content $prop
    $changed = $false
    $newLines = foreach ($line in $lines) {
        if ($line -match '^server-ip=.+$') {
            $changed = $true
            'server-ip='
        }
        else { $line }
    }
    if ($changed) {
        $newLines | Set-Content -Path $prop -Encoding ASCII
        Write-Host "Se ha vaciado server-ip= para que el servidor pueda enlazar con la red del PC local."
    }
}

function Ensure-EulaAccepted {
    $eula = Join-Path $script:ServerDir "eula.txt"
    $accepted = $false
    if (Test-Path $eula) {
        $accepted = ((Get-Content $eula -Raw) -match '(?m)^eula=true\s*$')
    }
    if (-not $accepted) {
        Write-Host ""
        Write-Host "Para ejecutar un servidor Minecraft debes aceptar la EULA de Mojang/Microsoft." -ForegroundColor Yellow
        $answer = Read-Host "Si la aceptas, escribe ACEPTO"
        if ($answer -cne "ACEPTO") { throw "EULA no aceptada." }
        "eula=true" | Set-Content -Path $eula -Encoding ASCII
    }
}

function Resolve-JavaExecutable {
    $configured = [string]$script:Config.JavaPath
    if (-not [string]::IsNullOrWhiteSpace($configured)) {
        if (Test-Path $configured) { return (Resolve-Path $configured).Path }
        $cmd = Get-Command $configured -ErrorAction SilentlyContinue
        if ($null -ne $cmd) { return $cmd.Source }
    }
    $java = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($null -ne $java) { return $java.Source }
    return $null
}

function Get-JavaMajorVersion {
    param([Parameter(Mandatory=$true)][string]$JavaExe)

    # java -version escribe normalmente en STDERR. En Windows PowerShell 5.1,
    # con ErrorActionPreference=Stop, invocarlo con 2>&1 puede convertirse en
    # NativeCommandError aunque Java funcione perfectamente. Usamos ProcessStartInfo
    # para capturar stdout/stderr sin que PowerShell interprete STDERR como un fallo.
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $JavaExe
    $psi.Arguments = '-version'
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    try {
        if (-not $p.Start()) { return 0 }
        $stdout = $p.StandardOutput.ReadToEnd()
        $stderr = $p.StandardError.ReadToEnd()
        $p.WaitForExit()
        $text = (($stderr + "`n" + $stdout).Trim())
    }
    finally {
        $p.Dispose()
    }

    if ($text -match '"(\d+)(?:\.(\d+))?') {
        $major = [int]$Matches[1]
        if ($major -eq 1 -and $Matches.Count -gt 2) { return [int]$Matches[2] }
        return $major
    }
    return 0
}

function Write-DirtyMarker {
    param([string]$SessionId)
    [ordered]@{
        sessionId = $SessionId
        host = $env:COMPUTERNAME
        startedUtc = [DateTimeOffset]::UtcNow.ToString("o")
    } | ConvertTo-Json | Set-Content -Path $script:DirtyMarkerPath -Encoding UTF8
}

function Get-DirtyMarker {
    if (-not (Test-Path $script:DirtyMarkerPath)) { return $null }
    try { return (Get-Content $script:DirtyMarkerPath -Raw | ConvertFrom-Json) } catch { return $null }
}

function Clear-DirtyMarker {
    Remove-Item $script:DirtyMarkerPath -Force -ErrorAction SilentlyContinue
}

Load-CobbleverseConfig


# ==================== ADVANCED / 5.0 FOUNDATION ====================
function Get-CobbleverseAppVersionText {
    $vp = Join-Path $script:Root 'VERSION.txt'
    if (-not (Test-Path -LiteralPath $vp)) { return '0.0.0' }
    try { return ([IO.File]::ReadAllText($vp)).Trim() } catch { return '0.0.0' }
}

function Get-CobbleverseFeatureStage {
    $v = Get-CobbleverseAppVersionText
    if ($v -match '^5\.') { return 100 }
    if ($v -match '^4\.9\.(\d+)') { return [int]$Matches[1] }
    return 0
}

function Write-GenerationHistoryEvent {
    param(
        [Parameter(Mandatory=$true)][string]$Event,
        [Parameter(Mandatory=$true)][int64]$Generation,
        [string]$SourceHost='',
        [int64]$Changed=0,
        [int64]$Deleted=0,
        [int64]$Bytes=0,
        [string]$Reason=''
    )
    try {
        $path = Join-Path $script:DataDir 'generation-history.jsonl'
        $obj = [ordered]@{
            utc=[DateTimeOffset]::UtcNow.ToString('o'); event=$Event; generation=$Generation
            host=$env:COMPUTERNAME; sourceHost=$SourceHost; changed=$Changed; deleted=$Deleted
            bytes=$Bytes; reason=$Reason
        }
        $line = (ConvertTo-Json -InputObject $obj -Depth 4 -Compress)
        [IO.File]::AppendAllText($path, $line + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
    } catch { }
}

function Get-RemoteMaintenancePath { return "$script:RemoteControl/maintenance.json" }

function Get-RemoteMaintenanceInfo {
    try {
        $raw = Invoke-RcloneCapture -Arguments @('cat',(Get-RemoteMaintenancePath),'--config',$script:RcloneConfig) -IgnoreExitCode
        if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) { return $null }
        return ($raw | ConvertFrom-Json)
    } catch { return $null }
}

function Set-RemoteMaintenanceInfo {
    param([Parameter(Mandatory=$true)]$Object)
    $tmp = Join-Path $script:DataDir ('maintenance-' + [guid]::NewGuid().ToString('N') + '.json')
    try {
        [IO.File]::WriteAllText($tmp,(ConvertTo-Json -InputObject $Object -Depth 6 -Compress),(New-Object Text.UTF8Encoding($false)))
        Invoke-Rclone -Arguments @('mkdir',$script:RemoteControl,'--config',$script:RcloneConfig) | Out-Null
        Invoke-Rclone -Arguments @('copyto',$tmp,(Get-RemoteMaintenancePath),'--config',$script:RcloneConfig,'--no-traverse') | Out-Null
    } finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
}

function Clear-RemoteMaintenanceInfo {
    Invoke-Rclone -Arguments @('deletefile',(Get-RemoteMaintenancePath),'--config',$script:RcloneConfig,'--drive-use-trash=false') -IgnoreExitCode | Out-Null
}

function Write-CrashMarker {
    param([int]$ExitCode,[string]$Message='')
    try {
        $obj=[ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');host=$env:COMPUTERNAME;exitCode=$ExitCode;message=$Message}
        $path=Join-Path $script:DataDir 'last-crash.json'
        [IO.File]::WriteAllText($path,(ConvertTo-Json $obj -Compress),(New-Object Text.UTF8Encoding($false)))
    } catch { }
}

function Clear-CrashMarker {
    Remove-Item -LiteralPath (Join-Path $script:DataDir 'last-crash.json') -Force -ErrorAction SilentlyContinue
}


function Send-CobbleverseNotification {
    param([Parameter(Mandatory=$true)][string]$Message)
    try {
        if ($null -eq $script:Config -or -not ($script:Config.PSObject.Properties.Name -contains 'DiscordWebhookUrl')) { return }
        $url=[string]$script:Config.DiscordWebhookUrl
        if ([string]::IsNullOrWhiteSpace($url)) { return }
        $body=ConvertTo-Json -InputObject @{content=$Message} -Compress
        Invoke-RestMethod -Method Post -Uri $url -ContentType 'application/json' -Body $body -TimeoutSec 6 | Out-Null
    } catch { }
}
