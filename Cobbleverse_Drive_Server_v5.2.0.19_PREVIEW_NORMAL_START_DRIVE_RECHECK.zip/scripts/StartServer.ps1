﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
. (Join-Path $PSScriptRoot "DeltaSync.ps1")

$session = $null
$heartbeat = $null
$serverWasStarted = $false
$syncSucceeded = $false
$publicAccessEnabled = $false
$changeTrackerProcess = $null
$changeTrackerReady = $false
$changeTrackerEnabled = $false
$backgroundMaintenanceProcess = $null
$backgroundMaintenanceStarted = $false
$perf = [ordered]@{ utc=[DateTimeOffset]::UtcNow.ToString('o'); host=$env:COMPUTERNAME }
$startupPipelineWatch = [Diagnostics.Stopwatch]::StartNew()
$closePipelineWatch = $null

try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== COBBLEVERSE COMPARTIDO - v4.9.9 PERFORMANCE ===" -ForegroundColor Green
    Write-Host "Carpeta real del servidor: $script:ServerDir" -ForegroundColor DarkGray

    if ([string]::IsNullOrWhiteSpace([string]$script:Config.ServerPath)) {
        throw "Este PC aun no tiene configurada su carpeta CobbleverseShared. Ejecuta 01_IMPORTAR_DESDE_HOSTING.bat (PC1) u 08_PREPARAR_SEGUNDO_PC.bat (PC2)."
    }
    if (-not (Test-Path -LiteralPath $script:ServerDir -PathType Container)) { throw "No existe la carpeta configurada del servidor: $script:ServerDir" }

    $java = Resolve-JavaExecutable
    if ($null -eq $java) { throw "No se encuentra Java. Ejecuta 00_INSTALAR_Y_CONFIGURAR.bat" }
    $major = Get-JavaMajorVersion -JavaExe $java
    if ($major -lt 21) { throw "Se necesita Java 21 o superior. Detectado: Java $major" }

    $wControl = [Diagnostics.Stopwatch]::StartNew()
    $controlSnapshot = Get-RemoteDeltaSnapshot
    $wControl.Stop()
    $perf.DriveControlSeconds = [double]$wControl.Elapsed.TotalSeconds
    $deltaCurrent = $controlSnapshot.Current
    $deltaBaseline = $controlSnapshot.Baseline
    if ($null -eq $deltaCurrent -or $null -eq $deltaBaseline) { throw "No existe la base delta v4.2 en Drive. Configura primero PC1." }

    $dirty = Get-DirtyMarker
    $recoverySessionId = ""
    if ($null -ne $dirty -and $dirty.PSObject.Properties.Name -contains 'sessionId') { $recoverySessionId = [string]$dirty.sessionId }

    $wLock = [Diagnostics.Stopwatch]::StartNew()
    $session = Acquire-GameplayLock -RecoverySessionId $recoverySessionId
    $wLock.Stop()
    $perf.LockSeconds = [double]$wLock.Elapsed.TotalSeconds
    $heartbeat = Start-LockHeartbeat -SessionId $session

    if ($null -ne $dirty) {
        Write-Host ""
        Write-Host "Sesion anterior interrumpida detectada. v4.9.6 la protege automaticamente antes de descargar nada." -ForegroundColor Yellow
        Set-GameplayLockStatus -SessionId $session -Status "recovering-local-delta"
        $pendingExisting = @(Get-PendingSyncItems)
        if ($pendingExisting.Count -eq 0) {
            $manifestPath = [string]$dirty.manifestPath
            if ([string]::IsNullOrWhiteSpace($manifestPath) -or -not (Test-Path -LiteralPath $manifestPath)) { throw 'Falta el manifiesto inicial de la sesion interrumpida.' }
            $beforeRecovery = Load-FastManifestData -Path $manifestPath
            $afterRecovery = Get-FastManifestData
            $localRecovery = Get-LocalDeltaState
            $queuedRecovery = Queue-DeltaChangesForSafePublish -BeforeManifest $beforeRecovery -AfterManifest $afterRecovery -SessionId ([string]$dirty.sessionId) -Reason 'recovery-after-crash' -BaseGeneration ([int64]$dirty.startGeneration) -BaselineId ([string]$localRecovery.baselineId)
        }
        if (@(Get-PendingSyncItems).Count -gt 0) {
            $recoveredQueue = Publish-PendingSyncQueue
            Write-Host ("Recuperacion publicada hasta G{0}." -f $recoveredQueue.generation) -ForegroundColor Green
        }
        # No se borra dirty hasta confirmar que Drive responde y el lock puede liberarse al final.
        $controlSnapshot = Get-RemoteDeltaSnapshot
        $deltaCurrent = $controlSnapshot.Current
        $deltaBaseline = $controlSnapshot.Baseline
    }

    Set-GameplayLockStatus -SessionId $session -Status "checking-remote-generation"
    Write-Host ""
    Write-Host "Comprobando si el otro PC ha dejado cambios..." -ForegroundColor Cyan
    $wApply = [Diagnostics.Stopwatch]::StartNew()
    $applied = Apply-RemoteDeltaChanges -Baseline $deltaBaseline -Current $deltaCurrent
    $wApply.Stop()
    $perf.RemoteApplySeconds = [double]$wApply.Elapsed.TotalSeconds

    # v4.9.2: la compactacion/limpieza de generaciones antiguas ya NO bloquea el arranque.
    # Se programa despues y solo empieza cuando Minecraft ya esta escuchando.

    Normalize-ServerProperties
    Ensure-EulaAccepted

    $jar = Find-ServerJar
    if ($null -eq $jar) { throw "No se encuentra server.jar/launcher Fabric en $script:ServerDir" }
    if ([string]$script:Config.ServerJar -ne $jar) {
        $script:Config.ServerJar = $jar
        Save-CobbleverseConfig
    }
    $jarPath = Join-Path $script:ServerDir $jar
    if (-not (Test-Path -LiteralPath $jarPath)) { throw "No existe el launcher: $jarPath" }

    Write-Host ""
    Write-Host "Preparando control de cambios local..." -ForegroundColor DarkCyan
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $stateForManifest = Get-LocalDeltaState
    $beforeManifest = $null
    if ($null -ne $stateForManifest) {
        $beforeManifest = Load-PersistentManifestCache -ExpectedGeneration ([int64]$stateForManifest.generation) -ExpectedBaselineId ([string]$stateForManifest.baselineId)
    }
    if ($null -ne $beforeManifest) {
        Write-Host ("Cache persistente valida para G{0}: {1} archivos. Se evita el escaneo completo de inicio." -f [int64]$stateForManifest.generation,$beforeManifest.Count) -ForegroundColor DarkGreen
    }
    else {
        $beforeManifest = Get-FastManifestData
        if ($null -ne $stateForManifest) { Save-PersistentManifestCache -Manifest $beforeManifest -Generation ([int64]$stateForManifest.generation) -BaselineId ([string]$stateForManifest.baselineId) }
        Write-Host ("Cache no disponible: se ha creado una base nueva con {0} archivos." -f $beforeManifest.Count) -ForegroundColor DarkGray
    }
    Save-FastManifestData -Manifest $beforeManifest -Path $script:SessionStartManifestPath
    Save-FastManifestData -Manifest $beforeManifest -Path $script:BackgroundMaintenanceManifestPath
    $sw.Stop()
    $perf.ManifestPrepareSeconds = [double]$sw.Elapsed.TotalSeconds
    Write-Host ("Control local preparado en {0:N2}s; referencia {1}." -f $sw.Elapsed.TotalSeconds,(Format-ByteSize ([int64]$beforeManifest.Bytes))) -ForegroundColor DarkGray

    # v4.9.1: seguimiento de cambios en segundo plano. FileSystemWatcher casi no hace I/O;
    # un barrido MUY suave de metadatos recorre pocas carpetas por ciclo como red de seguridad.
    $changeTrackerEnabled = [bool]$script:Config.BackgroundChangeTracking
    if ($changeTrackerEnabled) {
        Remove-Item -LiteralPath $script:ChangeTrackerCandidatesPath,$script:ChangeTrackerStatePath,$script:ChangeTrackerStopPath,$script:ChangeTrackerReadyPath,$script:ChangeTrackerFinalDirsPath,$script:ChangeTrackerLogPath -Force -ErrorAction SilentlyContinue
        $trackerScript = Join-Path $PSScriptRoot "ChangeTracker.ps1"
        try {
            $psExe = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
            $argLine = ('-NoProfile -ExecutionPolicy Bypass -File "{0}" -ServerDir "{1}" -BaselineManifestPath "{2}" -CandidatesPath "{3}" -StatePath "{4}" -StopPath "{5}" -ReadyPath "{6}" -FinalDirsPath "{7}" -LogPath "{8}" -SweepIntervalMs {9} -DirectoriesPerSweep {10}' -f `
                $trackerScript,$script:ServerDir,$script:SessionStartManifestPath,$script:ChangeTrackerCandidatesPath,$script:ChangeTrackerStatePath,$script:ChangeTrackerStopPath,$script:ChangeTrackerReadyPath,$script:ChangeTrackerFinalDirsPath,$script:ChangeTrackerLogPath,`
                [int]$script:Config.BackgroundSweepIntervalMs,[int]$script:Config.BackgroundSweepDirectoriesPerCycle)
            $psi = New-Object Diagnostics.ProcessStartInfo
            $psi.FileName = $psExe
            $psi.Arguments = $argLine
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow = $true
            $changeTrackerProcess = New-Object Diagnostics.Process
            $changeTrackerProcess.StartInfo = $psi
            if (-not $changeTrackerProcess.Start()) { throw "No se pudo iniciar el proceso de preescaneo." }

            $deadline = [DateTime]::UtcNow.AddMilliseconds(1200)
            while ([DateTime]::UtcNow -lt $deadline -and -not (Test-Path -LiteralPath $script:ChangeTrackerReadyPath)) {
                if ($changeTrackerProcess.HasExited) { break }
                Start-Sleep -Milliseconds 100
            }
            $changeTrackerReady = (Test-Path -LiteralPath $script:ChangeTrackerReadyPath) -and (-not $changeTrackerProcess.HasExited)
            if ($changeTrackerReady) {
                Write-Host "Preescaneo suave ACTIVO en segundo plano (prioridad baja)." -ForegroundColor DarkGreen
            }
            elseif (-not $changeTrackerProcess.HasExited) {
                Write-Host "Preescaneo iniciandose en segundo plano; Minecraft no esperara a que termine." -ForegroundColor DarkCyan
            }
            else {
                $trackerReason = 'el proceso termino antes de quedar listo'
                if (Test-Path -LiteralPath $script:ChangeTrackerStatePath) {
                    try {
                        $failedState = [IO.File]::ReadAllText($script:ChangeTrackerStatePath) | ConvertFrom-Json
                        if ($failedState.PSObject.Properties.Name -contains 'error' -and -not [string]::IsNullOrWhiteSpace([string]$failedState.error)) { $trackerReason = [string]$failedState.error }
                    } catch {}
                }
                Write-Host ("AVISO: el preescaneo fallo al iniciar: {0}" -f $trackerReason) -ForegroundColor Yellow
                Write-Host ("Diagnostico: {0}" -f $script:ChangeTrackerLogPath) -ForegroundColor DarkGray
            }
        }
        catch {
            $changeTrackerReady = $false
            Write-Host ("AVISO: preescaneo desactivado para esta sesion: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        }
    }

    if ((Get-CobbleverseFeatureStage) -ge 100 -and [bool]$script:Config.BackupBeforeSession) {
        Write-Host '5.0: creando backup local previo a la sesión...' -ForegroundColor DarkCyan
        try { Backup-Server -ExtraTags @('pre-session-v5') } catch { Write-Host ("AVISO: backup previo falló: {0}" -f $_.Exception.Message) -ForegroundColor Yellow }
    }

    $localState = Get-LocalDeltaState
    if ($null -eq $localState) { throw "Falta la generacion local del PC." }
    Write-DeltaDirtyMarker -SessionId $session -StartGeneration ([int64]$localState.generation)

    $publicAccess = Enable-CobbleversePublicAccess
    $publicAccessEnabled = [bool]$publicAccess.enabled
    if ($publicAccessEnabled) {
        if ([bool]$publicAccess.upnp) { Write-Host ("Puerto publico TCP {0} redirigido automaticamente a este PC." -f $publicAccess.externalPort) -ForegroundColor Green }
        if (-not [string]::IsNullOrWhiteSpace([string]$publicAccess.warning)) { Write-Host ("AVISO DE RED: {0}" -f $publicAccess.warning) -ForegroundColor Yellow }
    }
    Set-GameplayLockStatus -SessionId $session -Status "server-running" -RefreshConnectionInfo
    $serverWasStarted = $true
    if ((Get-CobbleverseFeatureStage) -ge 100) { Send-CobbleverseNotification -Message ("Cobbleverse: servidor iniciado en {0}." -f $env:COMPUTERNAME) }

    Write-Host ""
    Write-Host "===============================================================" -ForegroundColor Green
    Write-Host " SERVIDOR ARRANCANDO EN ESTE PC: $env:COMPUTERNAME" -ForegroundColor Green
    $connectionInfo = Get-ServerConnectionInfo
    foreach ($ip in @($connectionInfo.lanIPv4)) { Write-Host ((" IP LOCAL PARA CONECTARSE: {0}:{1}" -f $ip, $connectionInfo.serverPort)) -ForegroundColor Cyan }
    if (-not [string]::IsNullOrWhiteSpace([string]$connectionInfo.publicHost)) { Write-Host ((" DIRECCION FIJA INTERNET: {0}:{1}" -f $connectionInfo.publicHost, $connectionInfo.externalPort)) -ForegroundColor Magenta }
    if (-not [string]::IsNullOrWhiteSpace([string]$connectionInfo.publicIPv4)) { Write-Host ((" IP PUBLICA ACTUAL: {0}:{1}" -f $connectionInfo.publicIPv4, $connectionInfo.externalPort)) -ForegroundColor Cyan }
    Write-Host " Para cerrar BIEN, escribe: stop" -ForegroundColor Yellow
    Write-Host " Al cerrar SOLO se subiran los archivos que hayan cambiado." -ForegroundColor Yellow
    Write-Host "===============================================================" -ForegroundColor Green
    Write-Host ""

    # v4.9.2: lanzar el mantenimiento remoto como proceso separado. Se queda esperando
    # hasta que el puerto de Minecraft este LISTENING, por lo que no retrasa el arranque.
    if ([bool]$script:Config.BackgroundDriveMaintenance) {
        Remove-Item -LiteralPath $script:BackgroundMaintenanceStopPath,$script:BackgroundMaintenanceStatePath -Force -ErrorAction SilentlyContinue
        try {
            $maintenanceScript = Join-Path $PSScriptRoot 'BackgroundDriveMaintenance.ps1'
            $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $serverPortForMaintenance = Get-MinecraftServerPort
            $maintenanceGeneration = [int64]$localState.generation
            $argLine = ('-NoProfile -ExecutionPolicy Bypass -File "{0}" -SessionId "{1}" -ExpectedGeneration {2} -SnapshotManifestPath "{3}" -ServerPort {4} -StopPath "{5}" -StatePath "{6}" -LogPath "{7}" -DelaySeconds {8} -StartupTimeoutSeconds {9}' -f `
                $maintenanceScript,$session,$maintenanceGeneration,$script:BackgroundMaintenanceManifestPath,$serverPortForMaintenance,$script:BackgroundMaintenanceStopPath,$script:BackgroundMaintenanceStatePath,$script:BackgroundMaintenanceLogPath,`
                [int]$script:Config.BackgroundDriveMaintenanceDelaySeconds,[int]$script:Config.BackgroundDriveMaintenanceStartupTimeoutSeconds)
            $psiMaint = New-Object Diagnostics.ProcessStartInfo
            $psiMaint.FileName = $psExe
            $psiMaint.Arguments = $argLine
            $psiMaint.UseShellExecute = $false
            $psiMaint.CreateNoWindow = $true
            $backgroundMaintenanceProcess = New-Object Diagnostics.Process
            $backgroundMaintenanceProcess.StartInfo = $psiMaint
            if ($backgroundMaintenanceProcess.Start()) {
                $backgroundMaintenanceStarted = $true
                Write-Host 'Limpieza de Drive programada en segundo plano; Minecraft no esperara a que termine.' -ForegroundColor DarkGreen
            }
        }
        catch {
            Write-Host ("AVISO: no se pudo programar la limpieza en segundo plano: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
            $backgroundMaintenanceProcess = $null
        }
    }

    $startupPipelineWatch.Stop()
    $perf.StartupPipelineSeconds = [double]$startupPipelineWatch.Elapsed.TotalSeconds
    Write-Host ("Preparacion total antes de Java: {0:N2}s." -f $perf.StartupPipelineSeconds) -ForegroundColor DarkGray

    $javaArgs = @("-Xms$($script:Config.MinRamGB)G", "-Xmx$($script:Config.MaxRamGB)G", "-jar", $jarPath, "nogui")
    Push-Location $script:ServerDir
    try { & $java @javaArgs; $serverExitCode = $LASTEXITCODE }
    finally { Pop-Location }

    # Si el servidor se cierra mientras el mantenimiento aun espera, lo cancelamos.
    # Si ya estaba compactando, esperamos a que termine ANTES de publicar la siguiente
    # generacion; asi nunca puede purgar un bundle nuevo por una carrera de procesos.
    if ($backgroundMaintenanceStarted -and $null -ne $backgroundMaintenanceProcess) {
        try { [IO.File]::WriteAllText($script:BackgroundMaintenanceStopPath, 'stop', (New-Object Text.UTF8Encoding($false))) } catch {}
        if (-not $backgroundMaintenanceProcess.HasExited) {
            Write-Host 'Esperando a que termine el mantenimiento remoto que ya estaba en curso...' -ForegroundColor DarkGray
            $null = $backgroundMaintenanceProcess.WaitForExit(120000)
        }
        if (-not $backgroundMaintenanceProcess.HasExited) {
            throw 'El mantenimiento remoto no termino en 120 s. Se conserva la sesion pendiente y NO se publica para evitar una carrera con Drive.'
        }
    }

    if ($publicAccessEnabled) {
        Disable-CobbleversePublicAccess
        $publicAccessEnabled = $false
    }

    $closePipelineWatch = [Diagnostics.Stopwatch]::StartNew()
    Write-Host ""
    Write-Host "Java se ha cerrado (codigo $serverExitCode). Finalizando control de cambios..." -ForegroundColor Cyan
    if ((Get-CobbleverseFeatureStage) -ge 16 -and $serverExitCode -ne 0) {
        Write-CrashMarker -ExitCode $serverExitCode -Message 'Java terminó de forma no limpia. La sincronización segura continuará antes de liberar el mundo.'
        Write-Host "WATCHDOG: salida no limpia detectada. Se ha registrado el crash y se protegerán los cambios antes de liberar el servidor." -ForegroundColor Yellow
    }
    Set-GameplayLockStatus -SessionId $session -Status "detecting-local-changes"

    $trackerCanBeTrusted = $false
    $trackerState = $null
    [string[]]$candidatePaths = @()
    [string[]]$finalDirectoryPaths = @()
    [int64]$remainingDirsExpected = 0
    if ($changeTrackerEnabled -and $null -ne $changeTrackerProcess) {
        # v4.9.7: no dependemos del resultado de los primeros 1,2 s. El tracker puede
        # haber terminado de inicializarse mientras Minecraft estaba arrancando/jugando.
        $changeTrackerReady = (Test-Path -LiteralPath $script:ChangeTrackerReadyPath) -and (-not $changeTrackerProcess.HasExited)
        $trackerWasAlive = -not $changeTrackerProcess.HasExited
        if ($changeTrackerReady) { Write-Host "Preescaneo confirmado activo al cerrar. Validando cambios acumulados..." -ForegroundColor DarkGreen }
        elseif ($trackerWasAlive) { Write-Host "El tracker seguia vivo pero nunca marco READY; se usara escaneo completo de seguridad." -ForegroundColor Yellow }
        else {
            Write-Host "El tracker termino antes del cierre; se usara escaneo completo de seguridad." -ForegroundColor Yellow
            if (Test-Path -LiteralPath $script:ChangeTrackerLogPath) { Write-Host ("Revisa diagnostico: {0}" -f $script:ChangeTrackerLogPath) -ForegroundColor DarkGray }
        }
        try { [IO.File]::WriteAllText($script:ChangeTrackerStopPath, "stop", (New-Object Text.UTF8Encoding($false))) } catch {}
        try {
            if (-not $changeTrackerProcess.HasExited) { $null = $changeTrackerProcess.WaitForExit(8000) }
            if (-not $changeTrackerProcess.HasExited) { try { $changeTrackerProcess.Kill() } catch {} }
        } catch {}
        if ($changeTrackerReady -and $trackerWasAlive -and (Test-Path -LiteralPath $script:ChangeTrackerStatePath)) {
            try { $trackerState = [IO.File]::ReadAllText($script:ChangeTrackerStatePath) | ConvertFrom-Json } catch { $trackerState = $null }
            if ($null -ne $trackerState -and [string]$trackerState.status -eq 'stopped-cleanly' -and -not [bool]$trackerState.requiresFullScan) {
                if (Test-Path -LiteralPath $script:ChangeTrackerCandidatesPath) {
                    $candidatePaths = [string[]]@(Get-Content -LiteralPath $script:ChangeTrackerCandidatesPath -ErrorAction SilentlyContinue | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
                }
                if ($trackerState.PSObject.Properties.Name -contains 'remainingDirectoriesInSweep') {
                    $remainingDirsExpected = [int64]$trackerState.remainingDirectoriesInSweep
                }
                if (Test-Path -LiteralPath $script:ChangeTrackerFinalDirsPath) {
                    $finalDirectoryPaths = [string[]]@(Get-Content -LiteralPath $script:ChangeTrackerFinalDirsPath -ErrorAction SilentlyContinue)
                }

                # Para fiarnos del modo hibrido, la lista final de carpetas debe cuadrar exactamente
                # con el estado que dejo el tracker. Si no cuadra, volvemos al escaneo completo.
                if ([int64]$finalDirectoryPaths.Count -eq $remainingDirsExpected) { $trackerCanBeTrusted = $true }
            }
        }
    }

    $sw2 = [Diagnostics.Stopwatch]::StartNew()
    if ($trackerCanBeTrusted) {
        try {
            # v4.9.1: validacion hibrida. Los candidatos se confirman individualmente y ademas
            # se terminan las carpetas que faltaban del ciclo suave actual. De esta forma no
            # dependemos solo de FileSystemWatcher y tampoco releemos siempre todo el servidor.
            $afterManifest = Get-FastManifestDataHybridFinal -BeforeManifest $beforeManifest -CandidatePaths $candidatePaths -DirectoryPaths $finalDirectoryPaths
            $sw2.Stop()
            $sweeps = 0
            if ($null -ne $trackerState -and $trackerState.PSObject.Properties.Name -contains 'sweepsCompleted') { $sweeps = [int64]$trackerState.sweepsCompleted }
            Write-Host ("Preescaneo v4.9.2: {0} candidatos; {1} barridos suaves completos; {2} carpetas pendientes del ciclo." -f $candidatePaths.Count,$sweeps,$finalDirectoryPaths.Count) -ForegroundColor DarkCyan
            Write-Host ("Validacion conservadora: {0} carpetas verificadas al cerrar (incluye carpetas de candidatos)." -f $afterManifest.FinalDirectoriesScanned) -ForegroundColor DarkCyan
            Write-Host ("Validacion hibrida final terminada en {0:N2}s. Solo se ha tocado lo necesario; no se han leido los GB de contenido." -f $sw2.Elapsed.TotalSeconds) -ForegroundColor DarkGray
        }
        catch {
            Write-Host ("AVISO: la validacion hibrida encontro una inconsistencia: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
            Write-Host "Ejecutando escaneo completo de seguridad..." -ForegroundColor Yellow
            $sw2.Restart()
            $afterManifest = Get-FastManifestData
            $sw2.Stop()
            Write-Host ("Revision completa de respaldo terminada en {0:N1}s." -f $sw2.Elapsed.TotalSeconds) -ForegroundColor DarkGray
        }
    }
    else {
        Write-Host "El seguimiento en segundo plano no es 100% fiable para esta sesion. Ejecutando escaneo completo de seguridad..." -ForegroundColor Yellow
        $afterManifest = Get-FastManifestData
        $sw2.Stop()
        Write-Host ("Revision completa terminada en {0:N1}s; no se ha comparado el contenido completo con Drive." -f $sw2.Elapsed.TotalSeconds) -ForegroundColor DarkGray
    }

    $perf.CloseValidationSeconds = [double]$sw2.Elapsed.TotalSeconds

    # v4.9.6: PRIMERO se materializa un outbox local READY. A partir de aqui un corte
    # de Internet, cierre de la GUI o reinicio del PC no obliga a volver a leer el mundo.
    Set-GameplayLockStatus -SessionId $session -Status "creating-local-outbox"
    $localBeforePublish = Get-LocalDeltaState
    $wOutbox = [Diagnostics.Stopwatch]::StartNew()
    $queued = Queue-DeltaChangesForSafePublish -BeforeManifest $beforeManifest -AfterManifest $afterManifest -SessionId $session -Reason 'session' -BaseGeneration ([int64]$localBeforePublish.generation) -BaselineId ([string]$localBeforePublish.baselineId)
    $wOutbox.Stop()
    $perf.OutboxBuildSeconds = [double]$wOutbox.Elapsed.TotalSeconds

    $published = [pscustomobject]@{generation=[int64]$localBeforePublish.generation;changed=0;deleted=0;bytes=0}
    $wUpload = [Diagnostics.Stopwatch]::StartNew()
    if ($queued.queued) {
        Write-Host 'Paquete local protegido. Intentando enviarlo a Drive...' -ForegroundColor Cyan
        while ($true) {
            try {
                Set-GameplayLockStatus -SessionId $session -Status "uploading-pending-outbox"
                $qResult = Publish-PendingSyncQueue
                $published = [pscustomobject]@{generation=[int64]$qResult.generation;changed=[int64]$queued.changed;deleted=[int64]$queued.deleted;bytes=[int64]$queued.bytes}
                break
            }
            catch {
                Write-Host ("SIN INTERNET / DRIVE NO DISPONIBLE: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
                Write-Host ("El ZIP READY se conserva en data\\pending-sync. Reintento automatico en {0}s..." -f [int]$script:Config.PendingSyncRetrySeconds) -ForegroundColor Yellow
                Start-Sleep -Seconds ([Math]::Max(5,[int]$script:Config.PendingSyncRetrySeconds))
            }
        }
    }

    $wUpload.Stop()
    $perf.UploadAndCommitSeconds = [double]$wUpload.Elapsed.TotalSeconds

    # Incluso si no habia cambios, no consideramos terminada la sesion hasta poder
    # confirmar Drive y retirar nuestro lock. Si la red cae aqui, seguimos reintentando.
    while (-not (Test-DriveRemote)) {
        Write-Host ("Esperando conexion para confirmar el cierre seguro... reintento en {0}s." -f [int]$script:Config.PendingSyncRetrySeconds) -ForegroundColor Yellow
        Start-Sleep -Seconds ([Math]::Max(5,[int]$script:Config.PendingSyncRetrySeconds))
    }
    $released = Release-GameplayLock -SessionId $session
    while (-not $released) {
        Write-Host 'Drive responde, pero aun no se pudo confirmar la liberacion del bloqueo. Reintentando...' -ForegroundColor Yellow
        Start-Sleep -Seconds ([Math]::Max(5,[int]$script:Config.PendingSyncRetrySeconds))
        $released = Release-GameplayLock -SessionId $session
    }

    $syncSucceeded = $true
    Clear-DirtyMarker
    Remove-Item $script:SessionStartManifestPath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $script:ChangeTrackerCandidatesPath,$script:ChangeTrackerStatePath,$script:ChangeTrackerStopPath,$script:ChangeTrackerReadyPath,$script:ChangeTrackerFinalDirsPath,$script:ChangeTrackerLogPath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $script:BackgroundMaintenanceStopPath,$script:BackgroundMaintenanceStatePath,$script:BackgroundMaintenanceManifestPath -Force -ErrorAction SilentlyContinue

    # La cache se hace oficial solo DESPUES del commit remoto y de liberar el lock.
    $stateAfterSync = Get-LocalDeltaState
    if ($null -ne $stateAfterSync) { Save-PersistentManifestCache -Manifest $afterManifest -Generation ([int64]$stateAfterSync.generation) -BaselineId ([string]$stateAfterSync.baselineId) }

    if ($null -ne $closePipelineWatch) { $closePipelineWatch.Stop(); $perf.ClosePipelineSeconds = [double]$closePipelineWatch.Elapsed.TotalSeconds }
    Write-Host ""
    Write-Host ("SINCRONIZACION COMPLETADA: generacion {0}; {1} archivos protegidos/subidos ({2}); {3} borrados." -f $published.generation,$published.changed,(Format-ByteSize ([int64]$published.bytes)),$published.deleted) -ForegroundColor Green
    if ([bool]$script:Config.PerformanceMetrics) {
        Write-Host "===== RENDIMIENTO v4.9.9 PERFORMANCE =====" -ForegroundColor DarkCyan
        Write-Host ("Control Drive inicial : {0:N2}s" -f [double]$perf.DriveControlSeconds) -ForegroundColor DarkGray
        Write-Host ("Reserva/bloqueo       : {0:N2}s" -f [double]$perf.LockSeconds) -ForegroundColor DarkGray
        Write-Host ("Actualizar generaciones: {0:N2}s" -f [double]$perf.RemoteApplySeconds) -ForegroundColor DarkGray
        Write-Host ("Preparar manifiesto   : {0:N2}s" -f [double]$perf.ManifestPrepareSeconds) -ForegroundColor DarkGray
        Write-Host ("Total antes de Java   : {0:N2}s" -f [double]$perf.StartupPipelineSeconds) -ForegroundColor DarkGray
        Write-Host ("Validacion al cerrar  : {0:N2}s" -f [double]$perf.CloseValidationSeconds) -ForegroundColor DarkGray
        Write-Host ("Crear ZIP/outbox      : {0:N2}s" -f [double]$perf.OutboxBuildSeconds) -ForegroundColor DarkGray
        Write-Host ("Subida + commit       : {0:N2}s" -f [double]$perf.UploadAndCommitSeconds) -ForegroundColor DarkGray
        Write-Host ("Total cierre/sync     : {0:N2}s" -f [double]$perf.ClosePipelineSeconds) -ForegroundColor DarkGray
        try { Write-LocalJsonAtomic -Path $script:PerformanceLastPath -Object $perf } catch { }
        try { [IO.File]::AppendAllText((Join-Path $script:DataDir 'performance-history.jsonl'),((ConvertTo-Json $perf -Depth 6 -Compress)+[Environment]::NewLine),(New-Object Text.UTF8Encoding($false))) } catch { }
    }
    if ((Get-CobbleverseFeatureStage) -ge 100) { Send-CobbleverseNotification -Message ("Cobbleverse: sincronización completada en {0}, G{1}." -f $env:COMPUTERNAME,$published.generation) }
    $session = $null
    Write-Host "El otro PC ya puede arrancar el servidor." -ForegroundColor Green

    # Backup local opcional DESPUES de liberar el bloqueo. No retrasa al otro PC.
    if ([bool]$script:Config.AutoLocalBackupAfterSession) {
        Write-Host "Creando backup LOCAL deduplicado (el otro PC ya puede arrancar)..." -ForegroundColor DarkCyan
        try {
            $tags = @('session-v42')
            if ($serverExitCode -ne 0) { $tags += "java-exit-$serverExitCode" }
            Backup-Server -ExtraTags $tags
            Write-Host "Backup local terminado." -ForegroundColor Green
        }
        catch { Write-Host "AVISO: fallo el backup local, pero Drive ya esta sincronizado: $($_.Exception.Message)" -ForegroundColor Yellow }
    }
}
catch {
    if ($publicAccessEnabled) { try { Disable-CobbleversePublicAccess } catch { }; $publicAccessEnabled = $false }
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    if ($serverWasStarted -and -not $syncSucceeded) {
        Write-Host "IMPORTANTE: se conserva el marcador local/outbox y NO se anuncia la sesion como terminada." -ForegroundColor Yellow
        Write-Host "Al volver a abrir la app, v4.9.6 reintentara automaticamente antes de permitir una nueva rama." -ForegroundColor Yellow
    }
    exit 1
}
finally {
    if ($null -ne $backgroundMaintenanceProcess) {
        try {
            if (-not $backgroundMaintenanceProcess.HasExited) {
                try { [IO.File]::WriteAllText($script:BackgroundMaintenanceStopPath, 'stop', (New-Object Text.UTF8Encoding($false))) } catch {}
                $null = $backgroundMaintenanceProcess.WaitForExit(3000)
            }
        } catch {}
    }
    if ($null -ne $changeTrackerProcess) {
        try {
            if (-not $changeTrackerProcess.HasExited) {
                try { [IO.File]::WriteAllText($script:ChangeTrackerStopPath, "stop", (New-Object Text.UTF8Encoding($false))) } catch {}
                $null = $changeTrackerProcess.WaitForExit(1500)
                if (-not $changeTrackerProcess.HasExited) { $changeTrackerProcess.Kill() }
            }
        } catch {}
    }
    Stop-LockHeartbeat -Job $heartbeat
    if ($null -ne $session -and -not $serverWasStarted) { Release-GameplayLock -SessionId $session }
}
