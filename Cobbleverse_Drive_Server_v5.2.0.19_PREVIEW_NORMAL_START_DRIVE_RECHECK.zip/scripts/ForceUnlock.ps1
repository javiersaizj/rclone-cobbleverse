﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
try {
    Initialize-CobbleverseEnvironment
    $lock = Get-RemoteLock
    if ($null -eq $lock) {
        Write-Host "No existe ningun bloqueo remoto."
        exit 0
    }
    Write-Host "Bloqueo actual:" -ForegroundColor Yellow
    $lock | Format-List | Out-Host
    Write-Host "Solo debes quitarlo si estas 100% seguro de que ningun PC esta ejecutando el servidor." -ForegroundColor Red
    $answer = Read-Host "Escribe DESBLOQUEAR para eliminarlo"
    if ($answer -cne "DESBLOQUEAR") { throw "Cancelado." }
    Invoke-Rclone -Arguments @("deletefile", $script:RemoteLock, "--config", $script:RcloneConfig, "--drive-use-trash=false") -IgnoreExitCode | Out-Null
    Write-Host "Bloqueo eliminado." -ForegroundColor Green
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
