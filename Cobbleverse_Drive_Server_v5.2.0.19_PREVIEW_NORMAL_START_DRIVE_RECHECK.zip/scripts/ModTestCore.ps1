﻿# Cobbleverse v5.2.0.18 - Entorno TEST de actualización masiva de mods.
# Todo el entorno de prueba es LOCAL: no toca el mundo real ni publica nada en Drive
# hasta que el usuario pulsa expresamente "Promover TEST a normal".
Set-StrictMode -Version 2.0

function Initialize-ModTestPaths {
    Initialize-ModManagerPaths
    $script:ModTestRoot = Join-Path $script:ModManagerDir 'test-environment'
    $script:ModTestDownloadsDir = Join-Path $script:ModTestRoot 'downloads'
    $script:ModTestClientModsDir = Join-Path $script:ModTestRoot 'client-mods'
    $script:ModTestClientConfigDir = Join-Path $script:ModTestRoot 'client-config'
    $script:ModTestClientDefaultConfigsDir = Join-Path $script:ModTestRoot 'client-defaultconfigs'
    $script:ModTestStatePath = Join-Path $script:ModTestRoot 'test-state.json'
    $script:ModTestPlanPath = Join-Path $script:ModTestRoot 'test-plan.json'
    $script:ModTestRiskPath = Join-Path $script:ModTestRoot 'addons-a-vigilar.json'
    $script:ModTestRiskTextPath = Join-Path $script:ModTestRoot 'ADDONS_A_VIGILAR.txt'
    $script:ModTestServerRunningPath = Join-Path $script:ModTestRoot 'test-server-running.json'
    $script:ModTestReadyPath = Join-Path $script:ModTestRoot 'test-ready.json'
    $script:ModTestBuildMarkerPath = Join-Path $script:ModTestRoot 'BUILD_IN_PROGRESS.txt'
    $script:ModPromotionRoot = Join-Path $script:ModManagerDir 'promotion-backups'
    New-Item -ItemType Directory -Force -Path $script:ModTestRoot,$script:ModPromotionRoot | Out-Null
}

function Get-ModTestServerDir {
    $custom=''
    if($script:Config.PSObject.Properties.Name -contains 'ModTestServerPath'){$custom=[string]$script:Config.ModTestServerPath}
    if(-not[string]::IsNullOrWhiteSpace($custom)){return [Environment]::ExpandEnvironmentVariables($custom.Trim('"'))}
    return ([string]$script:ServerDir + '__MOD_TEST')
}

function Get-ModTestClientInstancePath {
    $p=''
    if($script:Config.PSObject.Properties.Name -contains 'ModTestClientInstancePath'){$p=[string]$script:Config.ModTestClientInstancePath}
    if([string]::IsNullOrWhiteSpace($p)){$p='%USERPROFILE%\curseforge\minecraft\Instances\New Cobbleverse'}
    return [Environment]::ExpandEnvironmentVariables($p.Trim('"'))
}

function Get-ModTestFabricLoaderVersion {
    $v=''
    if($script:Config.PSObject.Properties.Name -contains 'ModTestFabricLoaderVersion'){$v=[string]$script:Config.ModTestFabricLoaderVersion}
    if([string]::IsNullOrWhiteSpace($v)){$v='0.19.5'}
    return $v.Trim()
}

function Get-ModTestClientProfileInfo {
    $instance=Get-ModTestClientInstancePath
    if(-not(Test-Path -LiteralPath $instance -PathType Container)){
        throw ("No existe el perfil CurseForge TEST: {0}. Crea un perfil llamado 'New Cobbleverse' con Minecraft 1.21.1 y Fabric Loader 0.19.5 o configura ModTestClientInstancePath." -f $instance)
    }
    $info=[ordered]@{path=$instance;gameVersion='';loaderName='';loaderVersion=''}
    $metaPath=Join-Path $instance 'minecraftinstance.json'
    if(Test-Path -LiteralPath $metaPath){
        try{
            $j=([IO.File]::ReadAllText($metaPath)|ConvertFrom-Json)
            if($j.PSObject.Properties.Name -contains 'gameVersion'){$info.gameVersion=[string]$j.gameVersion}
            if(($j.PSObject.Properties.Name -contains 'baseModLoader') -and $null-ne$j.baseModLoader){
                if($j.baseModLoader.PSObject.Properties.Name -contains 'name'){$info.loaderName=[string]$j.baseModLoader.name}
                if($j.baseModLoader.PSObject.Properties.Name -contains 'mavenVersionString'){
                    $mv=[string]$j.baseModLoader.mavenVersionString
                    if($mv -match 'fabric-loader:([^:]+)$'){$info.loaderVersion=$Matches[1]}
                }
                if([string]::IsNullOrWhiteSpace([string]$info.loaderVersion) -and ([string]$info.loaderName) -match 'fabric[- ]([0-9][0-9.]+)'){$info.loaderVersion=$Matches[1]}
            }
        }catch{}
    }
    return [pscustomobject]$info
}

function Get-ModTestCurseForgeLoaderVersion {
    param([string]$InstancePath)
    if([string]::IsNullOrWhiteSpace($InstancePath)){return ''}
    $metaPath=Join-Path $InstancePath 'minecraftinstance.json'
    if(-not(Test-Path -LiteralPath $metaPath)){return ''}
    try{
        $j=([IO.File]::ReadAllText($metaPath)|ConvertFrom-Json)
        if(($j.PSObject.Properties.Name -contains 'baseModLoader') -and $null-ne$j.baseModLoader){
            if($j.baseModLoader.PSObject.Properties.Name -contains 'mavenVersionString'){
                $mv=[string]$j.baseModLoader.mavenVersionString
                if($mv -match 'fabric-loader:([^:]+)$'){return [string]$Matches[1]}
            }
            if($j.baseModLoader.PSObject.Properties.Name -contains 'name'){
                $n=[string]$j.baseModLoader.name
                if($n -match 'fabric[- ]([0-9][0-9.]+)'){return [string]$Matches[1]}
            }
        }
    }catch{}
    return ''
}

function Get-ModTestServerFabricLoaderDetectedVersion {
    param([string]$ServerPath)
    $best=$null
    $libRoot=Join-Path $ServerPath 'libraries\net\fabricmc\fabric-loader'
    if(Test-Path -LiteralPath $libRoot -PathType Container){
        foreach($d in @(Get-ChildItem -LiteralPath $libRoot -Directory -ErrorAction SilentlyContinue)){
            try{$v=[version]$d.Name;if($null-eq$best -or $v -gt $best){$best=$v}}catch{}
        }
    }
    foreach($f in @(Get-ChildItem -LiteralPath $ServerPath -File -Filter 'fabric-server-mc.*-loader.*-launcher.*.jar' -ErrorAction SilentlyContinue)){
        if($f.Name -match '-loader\.([0-9.]+)-launcher\.'){
            try{$v=[version]$Matches[1];if($null-eq$best -or $v -gt $best){$best=$v}}catch{}
        }
    }
    if($null-eq$best){return ''}
    return $best.ToString()
}

function Assert-ModTestNormalLoadersReadyForPromotion {
    $required=[version](Get-ModTestFabricLoaderVersion)
    $normalClient=Get-ModManagerClientInstancePath
    $clientV=Get-ModTestCurseForgeLoaderVersion -InstancePath $normalClient
    if(-not[string]::IsNullOrWhiteSpace($clientV)){
        try{
            if(([version]$clientV) -lt $required){
                throw ("No se puede promover todavía: el perfil NORMAL usa Fabric Loader {0} y el pack probado necesita {1} o posterior. Actualiza primero el loader del perfil NORMAL; sus mods todavía no se tocarán." -f $clientV,$required)
            }
        }catch{
            if($_.Exception.Message -like 'No se puede promover todavía:*'){throw}
        }
    }
    $serverV=Get-ModTestServerFabricLoaderDetectedVersion -ServerPath $script:ServerDir
    if(-not[string]::IsNullOrWhiteSpace($serverV)){
        try{
            if(([version]$serverV) -lt $required){
                throw ("No se puede promover todavía: el servidor NORMAL parece usar Fabric Loader {0} y el pack probado necesita {1} o posterior. Actualiza primero el loader NORMAL o pide al gestor que lo haga durante la promoción." -f $serverV,$required)
            }
        }catch{
            if($_.Exception.Message -like 'No se puede promover todavía:*'){throw}
        }
    }
}

function Assert-ModTestClientProfileCompatible {
    param([string]$MinecraftVersion)
    $info=Get-ModTestClientProfileInfo
    if(-not[string]::IsNullOrWhiteSpace([string]$info.gameVersion) -and [string]$info.gameVersion -ne $MinecraftVersion){
        throw ("El perfil TEST '{0}' usa Minecraft {1}; el TEST se está construyendo para {2}." -f [string]$info.path,[string]$info.gameVersion,$MinecraftVersion)
    }
    if(-not[string]::IsNullOrWhiteSpace([string]$info.loaderName) -and ([string]$info.loaderName).ToLowerInvariant() -notlike 'fabric*'){
        throw ("El perfil TEST no usa Fabric: {0}" -f [string]$info.loaderName)
    }
    $required=[version](Get-ModTestFabricLoaderVersion)
    if(-not[string]::IsNullOrWhiteSpace([string]$info.loaderVersion)){
        try{
            $actual=[version][string]$info.loaderVersion
            if($actual -lt $required){throw ("El perfil TEST usa Fabric Loader {0}; se necesita {1} o posterior." -f $actual,$required)}
        }catch{
            if($_.Exception.Message -like 'El perfil TEST usa Fabric Loader*'){throw}
        }
    }
    return $info
}

function Install-ModTestFabricServerLauncher {
    param([string]$TestServer,[string]$MinecraftVersion)
    $loader=Get-ModTestFabricLoaderVersion
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
    $installers=Invoke-RestMethod -Uri 'https://meta.fabricmc.net/v2/versions/installer'
    $installerObj=$installers|Where-Object{$_.stable -eq $true}|Select-Object -First 1
    if($null-eq$installerObj){$installerObj=$installers|Select-Object -First 1}
    if($null-eq$installerObj){throw 'Fabric Meta no devolvió una versión de installer para el servidor TEST.'}
    $installer=[string]$installerObj.version
    $name=("fabric-server-mc.{0}-loader.{1}-launcher.{2}.jar" -f $MinecraftVersion,$loader,$installer)
    $url=("https://meta.fabricmc.net/v2/versions/loader/{0}/{1}/{2}/server/jar" -f $MinecraftVersion,$loader,$installer)
    foreach($pattern in @('fabric-server-mc.*-launcher.*.jar','fabric-server-launch.jar','fabric-server-launcher.jar')){
        foreach($old in @(Get-ChildItem -LiteralPath $TestServer -File -Filter $pattern -ErrorAction SilentlyContinue)){
            Remove-Item -LiteralPath $old.FullName -Force -ErrorAction SilentlyContinue
        }
    }
    $fabricCache=Join-Path $TestServer '.fabric'
    if(Test-Path -LiteralPath $fabricCache){Remove-Item -LiteralPath $fabricCache -Recurse -Force -ErrorAction SilentlyContinue}
    $dest=Join-Path $TestServer $name
    Write-Host ("  Instalando Fabric Loader {0} SOLO en el servidor TEST..." -f $loader) -ForegroundColor Cyan
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $dest
    if(-not(Test-Path -LiteralPath $dest)){throw 'No se pudo crear el launcher Fabric del servidor TEST.'}
    return $name
}

function Assert-ModTestServerPathSafe {
    param([string]$TestServerPath)
    if([string]::IsNullOrWhiteSpace($TestServerPath)){throw 'Ruta del servidor TEST vacía.'}
    $normal=[IO.Path]::GetFullPath([string]$script:ServerDir).TrimEnd('\')
    $test=[IO.Path]::GetFullPath($TestServerPath).TrimEnd('\')
    if($normal.Equals($test,[StringComparison]::OrdinalIgnoreCase)){throw 'La ruta TEST coincide con la ruta NORMAL. Operación cancelada por seguridad.'}
    if($test.StartsWith($normal+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'La ruta TEST no puede estar dentro del servidor NORMAL porque podría entrar en la sincronización del mundo.'}
}

function Get-ModTestState {
    Initialize-ModTestPaths
    return (Read-ModManagerJson $script:ModTestStatePath)
}

function Save-ModTestState {
    param($State)
    Initialize-ModTestPaths
    Write-ModManagerJson $script:ModTestStatePath $State 30
}


function Get-ModTestReady {
    Initialize-ModTestPaths
    return (Read-ModManagerJson $script:ModTestReadyPath)
}

function Start-ModTestBuildMarker {
    param([string]$BuildId,[string]$MinecraftVersion,[string]$Loader)
    Initialize-ModTestPaths
    Remove-Item -LiteralPath $script:ModTestReadyPath -Force -ErrorAction SilentlyContinue
    $txt = @(
        'COBBLEVERSE TEST BUILD EN PROGRESO',
        ('BuildId: '+$BuildId),
        ('Minecraft: '+$MinecraftVersion),
        ('Loader: '+$Loader),
        ('Inicio UTC: '+[DateTimeOffset]::UtcNow.ToString('o')),
        '',
        'Si este archivo sigue presente, la construcción TEST no terminó correctamente.',
        'No actives el cliente TEST: vuelve a Crear / reconstruir TEST y espera a 7/7 ENTORNO TEST LISTO.'
    )
    [IO.File]::WriteAllLines($script:ModTestBuildMarkerPath,$txt,(New-Object Text.UTF8Encoding($false)))
}

function Assert-ModTestReadyDirectory {
    param($Ready,[string]$Directory,[string]$SideLabel)
    if($null-eq$Ready){throw 'El TEST no tiene sello de construcción válida. Vuelve a Crear / reconstruir TEST y espera a 7/7 ENTORNO TEST LISTO.'}
    if(-not(Test-Path -LiteralPath $Directory -PathType Container)){throw "No existe la carpeta de mods TEST '$Directory'. Vuelve a reconstruir el TEST."}
    $idMap=Get-ModTestDirectoryIdMap -Directory $Directory
    foreach($entry in @($Ready.items)){
        $side=([string]$entry.side).ToLowerInvariant()
        if($SideLabel -eq 'client' -and $side -notin @('client','both')){continue}
        if($SideLabel -eq 'server' -and $side -notin @('server','both')){continue}
        $expectedSha1=([string]$entry.sha1).ToLowerInvariant()
        foreach($ridRaw in @($entry.ids)){
            $rid=([string]$ridRaw).ToLowerInvariant()
            if([string]::IsNullOrWhiteSpace($rid)){continue}
            if(-not$idMap.ContainsKey($rid)){throw "TEST incompleto: falta '$rid' en $SideLabel. Vuelve a Crear / reconstruir TEST."}
            if(-not[string]::IsNullOrWhiteSpace($expectedSha1)){
                $jar=Join-Path $Directory ([string]$idMap[$rid])
                $h=Get-ModFileHashes $jar
                if(([string]$h.sha1).ToLowerInvariant() -ne $expectedSha1){
                    throw ("TEST obsoleto/incompleto: '{0}' en {1} no coincide con la versión construida {2} ({3}). Vuelve a Crear / reconstruir TEST." -f $rid,$SideLabel,[string]$entry.versionNumber,[string]$entry.fileName)
                }
            }
        }
    }
}

function Assert-ModTestReadyForActivation {
    Initialize-ModTestPaths
    if(Test-Path -LiteralPath $script:ModTestBuildMarkerPath){
        throw 'La última construcción TEST quedó interrumpida o todavía está en curso. No se puede activar un TEST antiguo. Pulsa Crear / reconstruir TEST y espera a 7/7 ENTORNO TEST LISTO.'
    }
    $ready=Get-ModTestReady
    if($null-eq$ready){throw 'No hay un TEST terminado y validado. Pulsa Crear / reconstruir TEST y espera a 7/7 ENTORNO TEST LISTO.'}
    $readyBuilder=''
    if($ready.PSObject.Properties.Name -contains 'builderVersion'){$readyBuilder=[string]$ready.builderVersion}
    $builderOk=$false
    try{$builderOk=([version]$readyBuilder -ge [version]'5.2.0.13')}catch{$builderOk=$false}
    if(-not$builderOk){
        throw ("El TEST actual fue construido con {0} y puede contener JAR antiguos. Pulsa Crear / reconstruir TEST con v5.2.0.13 o posterior y espera a 7/7 antes de activarlo." -f $(if([string]::IsNullOrWhiteSpace($readyBuilder)){'una versión anterior'}else{$readyBuilder}))
    }
    $state=Get-ModTestState
    if($null-eq$state){throw 'Falta el estado del TEST. Reconstrúyelo.'}

    # v5.2.0.12: el sello READY y los JAR físicos son la fuente de verdad.
    # Antes se abortaba por un buildId de test-state.json desfasado ANTES de
    # comprobar los archivos, aunque el TEST terminado fuera perfectamente válido.
    if($ready.PSObject.Properties.Name -contains 'clientMods'){
        $expectedClientMods=[int]$ready.clientMods
        $actualClientMods=@(Get-ChildItem -LiteralPath $script:ModTestClientModsDir -File -Filter '*.jar' -ErrorAction SilentlyContinue).Count
        if($expectedClientMods -ne $actualClientMods){
            throw ("TEST incompleto: el sello validado esperaba {0} JAR(s) de cliente y hay {1}. Vuelve a Crear / reconstruir TEST." -f $expectedClientMods,$actualClientMods)
        }
    }

    # Comprueba primero los SHA-1/IDs reales de todos los roots seleccionados.
    # Si Cobblemon fue construido como 1.8.1, aquí tiene que estar físicamente
    # ese JAR exacto; un 1.7.3 antiguo no puede pasar esta comprobación.
    Assert-ModTestReadyDirectory -Ready $ready -Directory $script:ModTestClientModsDir -SideLabel 'client'

    $stateBuildId=''
    if($state.PSObject.Properties.Name -contains 'buildId'){$stateBuildId=[string]$state.buildId}
    $readyBuildId=[string]$ready.buildId
    if([string]::IsNullOrWhiteSpace($readyBuildId)){throw 'El sello TEST validado no contiene buildId. Reconstruye el TEST.'}

    if([string]::IsNullOrWhiteSpace($stateBuildId) -or $stateBuildId -ne $readyBuildId){
        Write-Host 'Aviso: test-state.json estaba desfasado respecto al TEST físico validado. Reparando estado automáticamente...' -ForegroundColor Yellow
        if($state.PSObject.Properties.Name -contains 'buildId'){$state.buildId=$readyBuildId}else{$state|Add-Member -NotePropertyName buildId -NotePropertyValue $readyBuildId}
        if($state.PSObject.Properties.Name -contains 'buildComplete'){$state.buildComplete=$true}else{$state|Add-Member -NotePropertyName buildComplete -NotePropertyValue $true}
        if($ready.PSObject.Properties.Name -contains 'builderVersion'){
            $bv=[string]$ready.builderVersion
            if($state.PSObject.Properties.Name -contains 'builderVersion'){$state.builderVersion=$bv}else{$state|Add-Member -NotePropertyName builderVersion -NotePropertyValue $bv}
        }
        if($ready.PSObject.Properties.Name -contains 'minecraftVersion'){
            $mv=[string]$ready.minecraftVersion
            if($state.PSObject.Properties.Name -contains 'minecraftVersion'){$state.minecraftVersion=$mv}else{$state|Add-Member -NotePropertyName minecraftVersion -NotePropertyValue $mv}
        }
        if($ready.PSObject.Properties.Name -contains 'loader'){
            $ld=[string]$ready.loader
            if($state.PSObject.Properties.Name -contains 'loader'){$state.loader=$ld}else{$state|Add-Member -NotePropertyName loader -NotePropertyValue $ld}
        }
        Save-ModTestState $state
        Write-Host 'Estado TEST reparado. El sello y los JAR físicos coinciden.' -ForegroundColor Green
    }
    return $ready
}

function Get-ModTestRiskReport {
    Initialize-ModTestPaths
    return (Read-ModManagerJson $script:ModTestRiskPath)
}

function Save-ModTestRiskReport {
    param([object[]]$Items,[string]$MinecraftVersion,[string]$Loader)
    Initialize-ModTestPaths
    $safe=@($Items)
    $obj=[ordered]@{format='cobbleverse-mod-test-addon-risk-v1';createdUtc=[DateTimeOffset]::UtcNow.ToString('o');minecraftVersion=$MinecraftVersion;loader=$Loader;count=$safe.Count;items=$safe}
    Write-ModManagerJson $script:ModTestRiskPath $obj 30
    $lines=New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('COBBLEVERSE - ADDONS / MODS A VIGILAR EN EL TEST')
    $lines.Add(('Minecraft {0} · Loader {1}' -f $MinecraftVersion,$Loader))
    $lines.Add('')
    $lines.Add('Esta lista contiene addons/mods que requieren atención especial. Algunos se mantienen para probarlos y otros pueden excluirse SOLO del TEST por una incompatibilidad confirmada.')
    $lines.Add('El pack NORMAL no se modifica durante la construcción del TEST.')
    $lines.Add('')
    if($safe.Count -eq 0){$lines.Add('No se han detectado addons que requieran vigilancia especial.')}
    foreach($r in $safe){
        $lines.Add(('[{0}] {1}  (ID: {2})' -f [string]$r.status,[string]$r.addon,[string]$r.addonModId))
        if(-not[string]::IsNullOrWhiteSpace([string]$r.clientFile)){$lines.Add(('  Cliente: {0}' -f [string]$r.clientFile))}
        if(-not[string]::IsNullOrWhiteSpace([string]$r.serverFile)){$lines.Add(('  Servidor: {0}' -f [string]$r.serverFile))}
        $lines.Add(('  Dependencia: {0}' -f [string]$r.dependency))
        if(-not[string]::IsNullOrWhiteSpace([string]$r.normalDependencyVersion) -or -not[string]::IsNullOrWhiteSpace([string]$r.testDependencyVersion)){$lines.Add(('  Dependencia NORMAL -> TEST: {0} -> {1}' -f [string]$r.normalDependencyVersion,[string]$r.testDependencyVersion))}
        $lines.Add(('  Motivo: {0}' -f [string]$r.reason))
        $lines.Add('')
    }
    [IO.File]::WriteAllLines($script:ModTestRiskTextPath,$lines.ToArray(),(New-Object Text.UTF8Encoding($false)))
    return $obj
}

function Get-ModTestClientBackupPaths {
    $instance=Get-ModManagerClientInstancePath
    return [pscustomobject]@{
        mods=(Join-Path $instance 'mods.__COBBLEVERSE_NORMAL_BACKUP')
        config=(Join-Path $instance 'config.__COBBLEVERSE_NORMAL_BACKUP')
        defaultconfigs=(Join-Path $instance 'defaultconfigs.__COBBLEVERSE_NORMAL_BACKUP')
    }
}

function Invoke-ModTestRoboCopy {
    param([string]$Source,[string]$Destination,[switch]$Mirror,[string[]]$ExcludeDirs=@())
    if(-not(Test-Path -LiteralPath $Source -PathType Container)){return}
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    $copyArgs=@($Source,$Destination)
    if($Mirror){$copyArgs += '/MIR'}else{$copyArgs += '/E'}
    $copyArgs += @('/COPY:DAT','/DCOPY:DAT','/R:1','/W:1','/XJ','/NP','/NFL','/NDL')
    if($ExcludeDirs.Count -gt 0){$copyArgs += '/XD';$copyArgs += $ExcludeDirs}
    & robocopy.exe @copyArgs | Out-Host
    $code=$LASTEXITCODE
    if($code -gt 7){throw "Robocopy falló copiando '$Source' a '$Destination' (código $code)."}
}

function Copy-ModTestDirectoryClean {
    param([string]$Source,[string]$Destination)
    if(Test-Path -LiteralPath $Destination){Remove-Item -LiteralPath $Destination -Recurse -Force}
    if(Test-Path -LiteralPath $Source -PathType Container){Invoke-ModTestRoboCopy -Source $Source -Destination $Destination}
    else{New-Item -ItemType Directory -Force -Path $Destination | Out-Null}
}

function Sync-ModTestDirectory {
    param([string]$Source,[string]$Destination)
    if(-not(Test-Path -LiteralPath $Source -PathType Container)){throw "No existe la carpeta origen: $Source"}
    Invoke-ModTestRoboCopy -Source $Source -Destination $Destination -Mirror
}

# Devuelve únicamente el ID principal del JAR sin calcular hashes. Se usa para
# validar que una actualización TEST no haya eliminado accidentalmente un mod
# que existía en el pack NORMAL.
function Get-ModTestJarPrimaryId {
    param([string]$Path)
    $fallback=[IO.Path]::GetFileNameWithoutExtension($Path)
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $zip=$null
    try{
        $zip=[IO.Compression.ZipFile]::OpenRead($Path)
        $fabric=$zip.Entries|Where-Object{$_.FullName -eq 'fabric.mod.json'}|Select-Object -First 1
        if($null-ne$fabric){
            $sr=New-Object IO.StreamReader($fabric.Open())
            try{$j=$sr.ReadToEnd()|ConvertFrom-Json}finally{$sr.Dispose()}
            if(($j.PSObject.Properties.Name -contains 'id') -and -not[string]::IsNullOrWhiteSpace([string]$j.id)){return ([string]$j.id).ToLowerInvariant()}
        }
        $quilt=$zip.Entries|Where-Object{$_.FullName -eq 'quilt.mod.json'}|Select-Object -First 1
        if($null-ne$quilt){
            $sr=New-Object IO.StreamReader($quilt.Open())
            try{$j=$sr.ReadToEnd()|ConvertFrom-Json}finally{$sr.Dispose()}
            try{
                $qid=[string]$j.quilt_loader.id
                if(-not[string]::IsNullOrWhiteSpace($qid)){return $qid.ToLowerInvariant()}
            }catch{}
        }
        $toml=$zip.Entries|Where-Object{$_.FullName -in @('META-INF/mods.toml','META-INF/neoforge.mods.toml')}|Select-Object -First 1
        if($null-ne$toml){
            $sr=New-Object IO.StreamReader($toml.Open())
            try{$t=$sr.ReadToEnd()}finally{$sr.Dispose()}
            if($t -match '(?im)^\s*modId\s*=\s*["'']([^"'']+)["'']'){return ([string]$Matches[1]).ToLowerInvariant()}
        }
    }catch{}finally{if($null-ne$zip){$zip.Dispose()}}
    return $fallback.ToLowerInvariant()
}

function Get-ModTestDirectoryIdMap {
    param([string]$Directory)
    $map=@{}
    if(-not(Test-Path -LiteralPath $Directory -PathType Container)){return $map}
    foreach($f in @(Get-ChildItem -LiteralPath $Directory -File -Filter '*.jar' -ErrorAction SilentlyContinue)){
        $id=Get-ModTestJarPrimaryId -Path $f.FullName
        if(-not[string]::IsNullOrWhiteSpace($id)){$map[$id]=[string]$f.Name}
    }
    return $map
}

# Índice ID -> lista de JAR. Se construye una sola vez para que reemplazar 100+
# mods no implique volver a abrir todos los ZIP/JAR en cada iteración.
function Get-ModTestDirectoryIdMultiMap {
    param([string]$Directory)
    $map=@{}
    if(-not(Test-Path -LiteralPath $Directory -PathType Container)){return $map}
    foreach($f in @(Get-ChildItem -LiteralPath $Directory -File -Filter '*.jar' -ErrorAction SilentlyContinue)){
        $id=Get-ModTestJarPrimaryId -Path $f.FullName
        if([string]::IsNullOrWhiteSpace($id)){continue}
        $key=$id.ToLowerInvariant()
        if(-not$map.ContainsKey($key)){$map[$key]=New-Object 'System.Collections.Generic.List[string]'}
        $map[$key].Add($f.FullName)
    }
    return $map
}

# Elimina TODOS los JAR cuyo ID interno coincida. Usa un índice precalculado
# para que la sustitución sea rápida incluso con 136+ mods.
function Remove-ModTestJarsByIds {
    param([string]$Directory,[string[]]$Ids,[hashtable]$PathMap=$null)
    if(-not(Test-Path -LiteralPath $Directory -PathType Container)){return}
    if($null-eq$PathMap){$PathMap=Get-ModTestDirectoryIdMultiMap -Directory $Directory}
    foreach($rawId in @($Ids)){
        $id=([string]$rawId).Trim().ToLowerInvariant()
        if([string]::IsNullOrWhiteSpace($id) -or -not$PathMap.ContainsKey($id)){continue}
        foreach($path in @($PathMap[$id])){
            if(Test-Path -LiteralPath $path){
                Write-Host ("    Quitando JAR anterior de {0}: {1}" -f $id,[IO.Path]::GetFileName($path)) -ForegroundColor DarkYellow
                Remove-Item -LiteralPath $path -Force
            }
        }
        [void]$PathMap.Remove($id)
    }
}

# Regla de seguridad v5.2.0.2:
# El TEST siempre parte de una copia completa del NORMAL. Tras aplicar las
# actualizaciones de Modrinth, todo mod principal que existía en un lado debe
# seguir presente en ese mismo lado. Si falta, se restaura el JAR NORMAL exacto.
function Repair-ModTestMissingBaselineMods {
    param($Inventory,[string]$ClientStage,[string]$ServerStage,[hashtable]$ProtectedRootIds=$null)
    $restored=New-Object 'System.Collections.Generic.List[object]'
    $clientIds=Get-ModTestDirectoryIdMap -Directory $ClientStage
    $serverIds=Get-ModTestDirectoryIdMap -Directory $ServerStage
    $normalClient=Get-ModManagerClientModsDir
    $normalServer=Get-ModManagerServerModsDir

    foreach($m in @($Inventory.mods)){
        $id=([string]$m.id).ToLowerInvariant()
        if([string]::IsNullOrWhiteSpace($id)){continue}

        if(-not[string]::IsNullOrWhiteSpace([string]$m.clientFile) -and -not $clientIds.ContainsKey($id)){
            $protectedSide=''
            if($null-ne$ProtectedRootIds -and $ProtectedRootIds.ContainsKey($id)){$protectedSide=[string]$ProtectedRootIds[$id]}
            if(-not[string]::IsNullOrWhiteSpace($protectedSide)){
                if($protectedSide -in @('client','both')){
                    throw "El mod actualizado '$id' debería existir en TEST cliente ($protectedSide), pero ha desaparecido. Por seguridad NO se restaura la versión NORMAL antigua."
                }
                Write-Host ("  LADO ACTUALIZADO: {0} ya no se instala en cliente (Modrinth={1}); no se restaura el JAR NORMAL." -f [string]$m.name,$protectedSide) -ForegroundColor DarkYellow
            } else {
                $src=Join-Path $normalClient ([string]$m.clientFile)
                if(Test-Path -LiteralPath $src){
                    Copy-Item -LiteralPath $src -Destination (Join-Path $ClientStage ([string]$m.clientFile)) -Force
                    $clientIds[$id]=[string]$m.clientFile
                    $restored.Add([pscustomobject]@{id=$id;side='client';file=[string]$m.clientFile})
                    Write-Host ("  SEGURIDAD: {0} faltaba en TEST cliente; se conserva el JAR NORMAL." -f [string]$m.name) -ForegroundColor Yellow
                }
            }
        }

        if(-not[string]::IsNullOrWhiteSpace([string]$m.serverFile) -and -not $serverIds.ContainsKey($id)){
            $protectedSide=''
            if($null-ne$ProtectedRootIds -and $ProtectedRootIds.ContainsKey($id)){$protectedSide=[string]$ProtectedRootIds[$id]}
            if(-not[string]::IsNullOrWhiteSpace($protectedSide)){
                if($protectedSide -in @('server','both')){
                    throw "El mod actualizado '$id' debería existir en TEST servidor ($protectedSide), pero ha desaparecido. Por seguridad NO se restaura la versión NORMAL antigua."
                }
                Write-Host ("  LADO ACTUALIZADO: {0} ya no se instala en servidor (Modrinth={1}); no se restaura el JAR NORMAL." -f [string]$m.name,$protectedSide) -ForegroundColor DarkYellow
            } else {
                $src=Join-Path $normalServer ([string]$m.serverFile)
                if(Test-Path -LiteralPath $src){
                    Copy-Item -LiteralPath $src -Destination (Join-Path $ServerStage ([string]$m.serverFile)) -Force
                    $serverIds[$id]=[string]$m.serverFile
                    $restored.Add([pscustomobject]@{id=$id;side='server';file=[string]$m.serverFile})
                    Write-Host ("  SEGURIDAD: {0} faltaba en TEST servidor; se conserva el JAR NORMAL." -f [string]$m.name) -ForegroundColor Yellow
                }
            }
        }
    }
    return $restored.ToArray()
}

function Assert-ModTestSelectedRootsExact {
    param([hashtable]$Selected,[string]$ClientStage,[string]$ServerStage)
    $clientIds=Get-ModTestDirectoryIdMap -Directory $ClientStage
    $serverIds=Get-ModTestDirectoryIdMap -Directory $ServerStage
    foreach($entry in @($Selected.Values)){
        if(-not[bool]$entry.root){continue}
        $expectedSha1=''
        if(($entry.file.PSObject.Properties.Name -contains 'hashes') -and $null-ne$entry.file.hashes -and ($entry.file.hashes.PSObject.Properties.Name -contains 'sha1')){$expectedSha1=([string]$entry.file.hashes.sha1).ToLowerInvariant()}
        foreach($ridRaw in @($entry.replaceModIds)){
            $rid=([string]$ridRaw).ToLowerInvariant()
            if([string]::IsNullOrWhiteSpace($rid)){continue}
            if([string]$entry.side -in @('client','both')){
                if(-not$clientIds.ContainsKey($rid)){throw "VALIDACIÓN FINAL: falta '$rid' en TEST cliente después de descargar $($entry.displayName) $($entry.version.version_number)."}
                $p=Join-Path $ClientStage ([string]$clientIds[$rid])
                if(-not[string]::IsNullOrWhiteSpace($expectedSha1)){$h=Get-ModFileHashes $p;if(([string]$h.sha1).ToLowerInvariant() -ne $expectedSha1){throw "VALIDACIÓN FINAL: '$rid' en TEST cliente NO es el JAR seleccionado de Modrinth ($($entry.version.version_number)). Se cancela antes de restaurar una versión antigua."}}
            }
            if([string]$entry.side -in @('server','both')){
                if(-not$serverIds.ContainsKey($rid)){throw "VALIDACIÓN FINAL: falta '$rid' en TEST servidor después de descargar $($entry.displayName) $($entry.version.version_number)."}
                $p=Join-Path $ServerStage ([string]$serverIds[$rid])
                if(-not[string]::IsNullOrWhiteSpace($expectedSha1)){$h=Get-ModFileHashes $p;if(([string]$h.sha1).ToLowerInvariant() -ne $expectedSha1){throw "VALIDACIÓN FINAL: '$rid' en TEST servidor NO es el JAR seleccionado de Modrinth ($($entry.version.version_number)). Se cancela antes de restaurar una versión antigua."}}
            }
        }
    }
}

function Get-ModrinthCompatibleVersionForTarget {
    param([string]$ProjectId,[string]$MinecraftVersion,[string]$Loader)

    # v5.2.0.16: el selector SIEMPRE devuelve UN único objeto de versión.
    # En Windows PowerShell 5.1 ConvertFrom-Json puede conservar/emitir arrays
    # de forma distinta según el contexto; por eso aplanamos explícitamente la
    # respuesta de Modrinth antes de elegir el candidato más reciente.
    $targetGame=([string]$MinecraftVersion).Trim()
    $targetLoader=([string]$Loader).Trim().ToLowerInvariant()
    $cacheKey=(([string]$ProjectId).Trim().ToLowerInvariant()+'|'+$targetGame.ToLowerInvariant()+'|'+$targetLoader)
    if($script:ModTestVersionCache.ContainsKey($cacheKey)){
        $cached=$script:ModTestVersionCache[$cacheKey]
        if($cached -is [DBNull]){return $null}
        $cached=@($cached)[0]
        return $cached
    }

    function Get-VersionObjectsFromModrinthUrl {
        param([string]$Url)
        $headers=@{'User-Agent'='CobbleverseServerManager/5.2.0.18 (local mod manager)';'Accept'='application/json'}
        $lastError=''
        for($attempt=1;$attempt -le 4;$attempt++){
            try{
                $response=Invoke-WebRequest -Method Get -Uri $Url -Headers $headers -UseBasicParsing
                if($null-eq$response -or [string]::IsNullOrWhiteSpace([string]$response.Content)){throw 'Modrinth devolvió una respuesta vacía.'}
                $parsed=ConvertFrom-Json -InputObject ([string]$response.Content)
                $out=New-Object 'System.Collections.Generic.List[object]'
                $queue=New-Object 'System.Collections.Queue'
                $queue.Enqueue($parsed)
                while($queue.Count -gt 0){
                    $cur=$queue.Dequeue()
                    if($null-eq$cur){continue}
                    $isVersion=$false
                    try{
                        $props=@($cur.PSObject.Properties.Name)
                        $isVersion=($props -contains 'id') -and ($props -contains 'project_id') -and ($props -contains 'version_number')
                    }catch{}
                    if($isVersion){
                        $out.Add($cur)
                        continue
                    }
                    if(($cur -is [System.Collections.IEnumerable]) -and -not($cur -is [string])){
                        foreach($child in $cur){if($null-ne$child){$queue.Enqueue($child)}}
                    }
                }
                return $out.ToArray()
            }catch{
                $lastError=[string]$_.Exception.Message
                $statusCode=0
                try{if($null-ne$_.Exception.Response){$statusCode=[int]$_.Exception.Response.StatusCode}}catch{}
                if($attempt -lt 4 -and ($statusCode -eq 429 -or $statusCode -ge 500)){
                    Start-Sleep -Seconds ([Math]::Min(8,2*$attempt))
                    continue
                }
                throw
            }
        }
        throw ('No se pudo leer la lista de versiones de Modrinth. '+$lastError)
    }

    function Test-VersionTargetExplicit {
        param($Version)
        if($null-eq$Version){return $false}
        $Version=@($Version)[0]
        $props=@($Version.PSObject.Properties.Name)
        if(-not($props -contains 'game_versions') -or -not($props -contains 'loaders')){return $false}
        $gameOk=$false
        foreach($g in @($Version.game_versions)){
            if(([string]$g).Trim() -eq $targetGame){$gameOk=$true;break}
        }
        if(-not$gameOk){return $false}
        $loaderOk=$false
        foreach($l in @($Version.loaders)){
            if(([string]$l).Trim().ToLowerInvariant() -eq $targetLoader){$loaderOk=$true;break}
        }
        return $loaderOk
    }

    function Select-NewestVersionSingle {
        param([object[]]$Versions,[bool]$FilterLocally)
        $flat=New-Object 'System.Collections.Generic.List[object]'
        $queue=New-Object 'System.Collections.Queue'
        foreach($seed in @($Versions)){if($null-ne$seed){$queue.Enqueue($seed)}}
        while($queue.Count -gt 0){
            $cur=$queue.Dequeue()
            if($null-eq$cur){continue}
            $props=@()
            try{$props=@($cur.PSObject.Properties.Name)}catch{}
            if(($props -contains 'id') -and ($props -contains 'project_id') -and ($props -contains 'version_number')){
                $flat.Add($cur)
                continue
            }
            if(($cur -is [System.Collections.IEnumerable]) -and -not($cur -is [string])){
                foreach($child in $cur){if($null-ne$child){$queue.Enqueue($child)}}
            }
        }

        $bestRelease=$null;$bestReleaseDate=[DateTimeOffset]::MinValue
        $bestAny=$null;$bestAnyDate=[DateTimeOffset]::MinValue
        foreach($v in $flat){
            if($FilterLocally -and -not(Test-VersionTargetExplicit -Version $v)){continue}
            $published=[DateTimeOffset]::MinValue
            try{$published=[DateTimeOffset]::Parse([string]$v.date_published,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)}catch{}
            if($null-eq$bestAny -or $published -gt $bestAnyDate){$bestAny=$v;$bestAnyDate=$published}
            $vType=''
            if(@($v.PSObject.Properties.Name) -contains 'version_type'){$vType=([string]$v.version_type).Trim().ToLowerInvariant()}
            if($vType -eq 'release' -and ($null-eq$bestRelease -or $published -gt $bestReleaseDate)){
                $bestRelease=$v;$bestReleaseDate=$published
            }
        }
        $best=$bestRelease
        if($null-eq$best){$best=$bestAny}
        if($null-eq$best){return $null}
        # @(...)[0] impide que PowerShell propague accidentalmente una colección.
        $best=@($best)[0]
        return $best
    }

    $loadersJson='["'+$targetLoader.Replace('"','\\"')+'"]'
    $gamesJson='["'+$targetGame.Replace('"','\\"')+'"]'
    $base='https://api.modrinth.com/v2/project/'+[uri]::EscapeDataString($ProjectId)+'/version'
    $filteredUrl=$base+'?loaders='+[uri]::EscapeDataString($loadersJson)+'&game_versions='+[uri]::EscapeDataString($gamesJson)+'&include_changelog=false'

    $filteredVersions=@(Get-VersionObjectsFromModrinthUrl -Url $filteredUrl)
    $chosen=Select-NewestVersionSingle -Versions $filteredVersions -FilterLocally $false
    if($null-ne$chosen){$chosen=@($chosen)[0]}
    if($null-ne$chosen -and -not(Test-VersionTargetExplicit -Version $chosen)){$chosen=$null}

    if($null-eq$chosen){
        Write-Host ("    Modrinth fallback para {0}: la consulta filtrada no devolvió una versión utilizable; revisando catálogo completo..." -f $ProjectId) -ForegroundColor DarkYellow
        $allVersions=@(Get-VersionObjectsFromModrinthUrl -Url ($base+'?include_changelog=false'))
        $chosen=Select-NewestVersionSingle -Versions $allVersions -FilterLocally $true
        if($null-ne$chosen){$chosen=@($chosen)[0]}
    }

    if($null-eq$chosen){
        try{
            $project=Get-ModrinthProject $ProjectId
            $slug=([string]$project.slug).Trim()
            if(-not[string]::IsNullOrWhiteSpace($slug) -and $slug -ine $ProjectId){
                $slugBase='https://api.modrinth.com/v2/project/'+[uri]::EscapeDataString($slug)+'/version'
                $slugFiltered=$slugBase+'?loaders='+[uri]::EscapeDataString($loadersJson)+'&game_versions='+[uri]::EscapeDataString($gamesJson)+'&include_changelog=false'
                $slugVersions=@(Get-VersionObjectsFromModrinthUrl -Url $slugFiltered)
                $chosen=Select-NewestVersionSingle -Versions $slugVersions -FilterLocally $false
                if($null-ne$chosen){$chosen=@($chosen)[0]}
                if($null-ne$chosen -and -not(Test-VersionTargetExplicit -Version $chosen)){$chosen=$null}
                if($null-eq$chosen){
                    $slugAll=@(Get-VersionObjectsFromModrinthUrl -Url ($slugBase+'?include_changelog=false'))
                    $chosen=Select-NewestVersionSingle -Versions $slugAll -FilterLocally $true
                    if($null-ne$chosen){$chosen=@($chosen)[0]}
                }
            }
        }catch{}
    }

    # Cobblemon 1.8.1 es una salvaguarda mínima conocida para 1.21.1/Fabric.
    # Una release posterior compatible sigue teniendo prioridad por fecha.
    if(($ProjectId -ieq 'MdwFAVRL' -or $ProjectId -ieq 'cobblemon') -and $targetGame -eq '1.21.1' -and $targetLoader -eq 'fabric'){
        try{
            $floor=Get-ModrinthVersionById 'gBW3vLC7'
            if($null-ne$floor){$floor=@($floor)[0]}
            if($null-ne$floor -and (Test-VersionTargetExplicit -Version $floor)){
                $floorDate=[DateTimeOffset]::MinValue
                try{$floorDate=[DateTimeOffset]::Parse([string]$floor.date_published,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)}catch{}
                $chosenDate=[DateTimeOffset]::MinValue
                if($null-ne$chosen){try{$chosenDate=[DateTimeOffset]::Parse([string]$chosen.date_published,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)}catch{}}
                if($null-eq$chosen -or $floorDate -gt $chosenDate){$chosen=$floor}
            }
        }catch{}
    }

    if($null-eq$chosen){$script:ModTestVersionCache[$cacheKey]=[DBNull]::Value;return $null}
    $chosen=@($chosen)[0]
    $chosenProps=@($chosen.PSObject.Properties.Name)
    if(-not($chosenProps -contains 'id') -or -not($chosenProps -contains 'version_number')){
        throw "ERROR INTERNO: el selector de Modrinth para $ProjectId no devolvió un objeto de versión único."
    }
    # Algunas respuestas antiguas/cachés pueden omitir dependencies; para el
    # planificador equivale a una lista vacía, no a un error de StrictMode.
    if(-not($chosenProps -contains 'dependencies')){$chosen|Add-Member -NotePropertyName dependencies -NotePropertyValue @()}
    $script:ModTestVersionCache[$cacheKey]=$chosen
    return $chosen
}

function Resolve-ModrinthRootProject {
    param($Mod,$HashMap,[string]$MinecraftVersion,[string]$Loader)

    $modId=([string]$Mod.id).Trim()
    $modName=([string]$Mod.name).Trim()
    $targetLoader=([string]$Loader).Trim().ToLowerInvariant()

    # 1) La fuente más fuerte para muchos mods Fabric es su propio mod id como slug.
    # Ejemplo: fabric.mod.json id=cobblemon -> modrinth.com/mod/cobblemon.
    if(-not[string]::IsNullOrWhiteSpace($modId)){
        try{
            $project=Get-ModrinthProject $modId
            if($null-ne$project -and ([string]$project.project_type).ToLowerInvariant() -eq 'mod'){
                $slug=([string]$project.slug).Trim().ToLowerInvariant()
                $idNorm=($modId.ToLowerInvariant() -replace '[^a-z0-9]','')
                $slugNorm=($slug -replace '[^a-z0-9]','')
                $games=@($project.game_versions|ForEach-Object{([string]$_).Trim()})
                $loaders=@($project.loaders|ForEach-Object{([string]$_).Trim().ToLowerInvariant()})
                if($slugNorm -eq $idNorm -and ($games -contains $MinecraftVersion) -and ($loaders -contains $targetLoader)){
                    return [pscustomobject]@{projectId=[string]$project.id;method='slug';project=$project}
                }
            }
        }catch{}
    }

    # 2) Identificación exacta por SHA1 del JAR instalado.
    $sha1=([string]$Mod.sha1).Trim().ToLowerInvariant()
    if(-not[string]::IsNullOrWhiteSpace($sha1) -and $HashMap.ContainsKey($sha1)){
        $v=$HashMap[$sha1]
        $resolvedProjectId=[string]$v.project_id
        if(-not[string]::IsNullOrWhiteSpace($resolvedProjectId)){
            try{$project=Get-ModrinthProject $resolvedProjectId;return [pscustomobject]@{projectId=$resolvedProjectId;method='sha1';project=$project}}catch{return [pscustomobject]@{projectId=$resolvedProjectId;method='sha1';project=$null}}
        }
    }

    # 3) Mapeo conocido de nuestro inventario/source-map, pero validado contra Modrinth.
    if(-not[string]::IsNullOrWhiteSpace([string]$Mod.projectId)){
        $resolvedProjectId=[string]$Mod.projectId
        try{
            $project=Get-ModrinthProject $resolvedProjectId
            if($null-ne$project -and ([string]$project.project_type).ToLowerInvariant() -eq 'mod'){
                return [pscustomobject]@{projectId=[string]$project.id;method='source-map';project=$project}
            }
        }catch{}
    }

    # 4) Último recurso: búsqueda estricta por nombre/ID. Solo aceptamos coincidencia
    # exacta de slug con mod id o título con nombre para no actualizar el mod equivocado.
    foreach($query in @($modId,$modName)){
        if([string]::IsNullOrWhiteSpace($query)){continue}
        try{
            $facets='[["project_type:mod"],["versions:'+([string]$MinecraftVersion)+'"],["categories:'+([string]$Loader).ToLowerInvariant()+'"]]'
            $url='https://api.modrinth.com/v2/search?limit=20&index=relevance&query='+[uri]::EscapeDataString($query)+'&facets='+[uri]::EscapeDataString($facets)
            $r=Invoke-ModrinthJson -Url $url
            $idNorm=($modId.ToLowerInvariant() -replace '[^a-z0-9]','')
            $nameNorm=($modName.ToLowerInvariant() -replace '[^a-z0-9]','')
            foreach($h in @($r.hits)){
                $slugNorm=(([string]$h.slug).ToLowerInvariant() -replace '[^a-z0-9]','')
                $titleNorm=(([string]$h.title).ToLowerInvariant() -replace '[^a-z0-9]','')
                if(((-not[string]::IsNullOrWhiteSpace($idNorm)) -and $slugNorm -eq $idNorm) -or ((-not[string]::IsNullOrWhiteSpace($nameNorm)) -and $titleNorm -eq $nameNorm)){
                    $project=Get-ModrinthProject ([string]$h.project_id)
                    return [pscustomobject]@{projectId=[string]$h.project_id;method='search';project=$project}
                }
            }
        }catch{}
    }
    return $null
}

function Test-ModrinthVersionForTarget {
    param($Version,[string]$MinecraftVersion,[string]$Loader)
    if($null-eq$Version){return $false}
    $Version=@($Version)[0]
    $props=@($Version.PSObject.Properties.Name)
    if(-not($props -contains 'game_versions') -or -not($props -contains 'loaders')){return $false}
    if(-not(@($Version.game_versions) -contains $MinecraftVersion)){return $false}
    if(-not(@($Version.loaders) -contains $Loader)){return $false}
    return $true
}

function Get-ModrinthVersionDependenciesSafe {
    param($Version)
    if($null-eq$Version){return @()}
    $Version=@($Version)[0]
    if(-not(@($Version.PSObject.Properties.Name) -contains 'dependencies')){return @()}
    return @($Version.dependencies)
}

function Get-ModTestVersionEnvironment {
    param($Version)
    if($null-eq$Version){return ''}
    if($Version.PSObject.Properties.Name -contains 'environment'){return [string]$Version.environment}
    return ''
}

function Convert-ModTestEnvironmentToSide {
    param([string]$Environment,[string]$RequestedSide='both')
    $e=([string]$Environment).Trim().ToLowerInvariant()
    if($e -in @('client_only','singleplayer_only','client_only_server_optional')){return 'client'}
    if($e -in @('server_only','dedicated_server_only','server_only_client_optional')){return 'server'}
    if($RequestedSide -in @('client','server','both')){return $RequestedSide}
    return 'both'
}

function Merge-ModTestSides {
    param([string]$A,[string]$B)
    if([string]::IsNullOrWhiteSpace($A)){return $B}
    if([string]::IsNullOrWhiteSpace($B)){return $A}
    if($A -eq $B){return $A}
    return 'both'
}

function Get-ModrinthInventoryHashMap {
    param($Inventory)
    $hashes=@($Inventory.mods|Where-Object{-not[string]::IsNullOrWhiteSpace([string]$_.sha1)}|ForEach-Object{([string]$_.sha1).ToLowerInvariant()}|Sort-Object -Unique)
    $map=@{}
    if($hashes.Count -eq 0){return $map}
    Write-Host ("Identificando {0} hashes instalados en Modrinth..." -f $hashes.Count) -ForegroundColor Cyan
    $result=Invoke-ModrinthJson -Method POST -Url 'https://api.modrinth.com/v2/version_files' -Body @{hashes=$hashes;algorithm='sha1'}
    if($null-ne$result){foreach($p in $result.PSObject.Properties){$map[([string]$p.Name).ToLowerInvariant()]=$p.Value}}
    return $map
}

function Get-ModTestFreePort {
    param([int]$PreferredPort)
    $start=$PreferredPort;if($start -lt 1 -or $start -gt 65535){$start=25566}
    for($offset=0;$offset -lt 30;$offset++){
        $candidate=$start+$offset;if($candidate -gt 65535){$candidate=25000+$offset}
        $listener=$null
        try{
            $listener=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Any,$candidate)
            $listener.Start();$listener.Stop();return $candidate
        }catch{if($null-ne$listener){try{$listener.Stop()}catch{}}}
    }
    throw 'No se ha encontrado un puerto libre para el servidor TEST.'
}

function Set-ModTestServerPort {
    param([string]$ServerDir,[int]$Port)
    $path=Join-Path $ServerDir 'server.properties'
    $lines=@()
    if(Test-Path -LiteralPath $path){$lines=@(Get-Content -LiteralPath $path)}
    $foundPort=$false;$foundIp=$false
    $out=New-Object 'System.Collections.Generic.List[string]'
    foreach($line in $lines){
        if($line -match '^server-port='){$out.Add('server-port='+$Port);$foundPort=$true;continue}
        if($line -match '^server-ip='){$out.Add('server-ip=');$foundIp=$true;continue}
        $out.Add([string]$line)
    }
    if(-not$foundPort){$out.Add('server-port='+$Port)}
    if(-not$foundIp){$out.Add('server-ip=')}
    [IO.File]::WriteAllLines($path,$out.ToArray(),[Text.Encoding]::ASCII)
}

function Get-ModTestServerRunningInfo {
    Initialize-ModTestPaths
    $o=Read-ModManagerJson $script:ModTestServerRunningPath
    if($null-eq$o){return $null}
    $processIdValue=0
    try{$processIdValue=[int]$o.processId}catch{}
    if($processIdValue -le 0){Remove-Item $script:ModTestServerRunningPath -Force -ErrorAction SilentlyContinue;return $null}
    $p=Get-Process -Id $processIdValue -ErrorAction SilentlyContinue
    if($null-eq$p){Remove-Item $script:ModTestServerRunningPath -Force -ErrorAction SilentlyContinue;return $null}
    return $o
}

function New-ModTestBulkEnvironment {
    param([string]$MinecraftVersion,[string]$Loader='fabric')
    Initialize-ModTestPaths
    $script:ModTestVersionCache=@{}
    if([string]::IsNullOrWhiteSpace($MinecraftVersion)){throw 'Indica la versión de Minecraft para el entorno TEST.'}
    if([string]::IsNullOrWhiteSpace($Loader)){$Loader=Get-ModManagerLoader}
    if($null-ne(Get-ModTestServerRunningInfo)){throw 'El servidor TEST está en ejecución. Ciérralo escribiendo stop antes de reconstruir el entorno.'}
    $existingState=Get-ModTestState
    # Compatibilidad con instalaciones anteriores: si quedó un backup del antiguo
    # sistema de intercambio de perfil, se restaura una sola vez.
    $clientBackups=Get-ModTestClientBackupPaths
    if(Test-Path -LiteralPath $clientBackups.mods){
        Write-Host 'Se ha detectado un backup NORMAL del sistema TEST antiguo. Restaurándolo antes de continuar...' -ForegroundColor Yellow
        Restore-ModTestClientNormal | Out-Null
        $existingState=Get-ModTestState
    }
    if($null-ne$existingState -and [bool]$existingState.clientActive){
        # Desde v5.2.0.18 el TEST vive en otro perfil; volver a NORMAL solo captura
        # los configs del perfil TEST y cambia el estado, sin tocar el perfil NORMAL.
        Restore-ModTestClientNormal | Out-Null
        $existingState=Get-ModTestState
    }
    $testProfileInfo=Assert-ModTestClientProfileCompatible -MinecraftVersion $MinecraftVersion

    # v5.2.0.13: reconstrucción realmente limpia. Borramos TODO el staging TEST
    # anterior antes de consultar/descargar nada. Los backups de promoción viven
    # fuera de esta carpeta y no se tocan.
    if(Test-Path -LiteralPath $script:ModTestRoot){
        Write-Host 'Limpieza total del TEST anterior: eliminando staging, sellos y JAR antiguos...' -ForegroundColor Yellow
        Remove-Item -LiteralPath $script:ModTestRoot -Recurse -Force
    }
    Initialize-ModTestPaths

    $buildId=[guid]::NewGuid().ToString('N')
    Start-ModTestBuildMarker -BuildId $buildId -MinecraftVersion $MinecraftVersion -Loader $Loader

    Write-Host '1/7 Escaneando el pack NORMAL actual (cliente + servidor)...' -ForegroundColor Cyan
    $inventory=Get-ModManagerInventory
    $hashMap=Get-ModrinthInventoryHashMap $inventory

    $selected=@{}
    $visiting=@{}
    $rootProjects=@{}
    $currentVersionIdByProject=@{}
    $currentVersionNumberByProject=@{}
    $rootModByProject=@{}
    $reportRows=New-Object 'System.Collections.Generic.List[object]'
    $unresolved=New-Object 'System.Collections.Generic.List[object]'
    $riskRows=New-Object 'System.Collections.Generic.List[object]'
    $riskKeys=@{}
    $resolvedProjectByModId=@{}
    $excludedTestRootIds=@{}
    $excludedTestProjectIds=@{}

    # Primero descubrimos TODOS los proyectos que ya forman parte del pack NORMAL.
    # Esto da prioridad a la versión más reciente del mod principal frente a una
    # dependencia antigua declarada por un addon procesado antes.
    foreach($m in @($inventory.mods)){
        $resolved=Resolve-ModrinthRootProject -Mod $m -HashMap $hashMap -MinecraftVersion $MinecraftVersion -Loader $Loader
        if($null-eq$resolved){continue}
        $rootProjectId=[string]$resolved.projectId
        if([string]::IsNullOrWhiteSpace($rootProjectId)){continue}
        $resolvedProjectByModId[([string]$m.id).ToLowerInvariant()]=$resolved
        $rootKey=$rootProjectId.ToLowerInvariant();$rootProjects[$rootKey]=$true;$rootModByProject[$rootKey]=$m
        $sha1Value=([string]$m.sha1).ToLowerInvariant();$currentObj=$null
        if(-not[string]::IsNullOrWhiteSpace($sha1Value) -and $hashMap.ContainsKey($sha1Value)){$currentObj=$hashMap[$sha1Value]}
        $curId='';$curNumber=''
        if($null-ne$currentObj){$curId=[string]$currentObj.id;$curNumber=[string]$currentObj.version_number}
        if([string]::IsNullOrWhiteSpace($curId) -and -not[string]::IsNullOrWhiteSpace([string]$m.sourceVersionId)){$curId=[string]$m.sourceVersionId}
        if([string]::IsNullOrWhiteSpace($curNumber)){$curNumber=if($m.versionClient){[string]$m.versionClient}else{[string]$m.versionServer}}
        $currentVersionIdByProject[$rootKey]=$curId;$currentVersionNumberByProject[$rootKey]=$curNumber
        $projectTitle='';$projectSlug='';if($null-ne$resolved.project){$projectTitle=[string]$resolved.project.title;$projectSlug=[string]$resolved.project.slug}
        Write-Host ("  Identificado {0} -> {1} ({2}) por {3}" -f [string]$m.name,$projectTitle,$projectSlug,[string]$resolved.method) -ForegroundColor DarkGray
    }

    # Incompatibilidades confirmadas por Fabric Loader durante la prueba 1.8.1.
    # Se excluyen SOLO del TEST; el perfil/servidor NORMAL permanecen intactos.
    foreach($excludeId in @('better_pokedex_scanner','reeses-sodium-options')){
        $ek=$excludeId.ToLowerInvariant()
        if($resolvedProjectByModId.ContainsKey($ek)){
            $r=$resolvedProjectByModId[$ek]
            $pk=([string]$r.projectId).ToLowerInvariant()
            if(-not[string]::IsNullOrWhiteSpace($pk)){$excludedTestProjectIds[$pk]=$true}
            $excludedTestRootIds[$ek]=$true
        }
    }

    function Add-ModTestRisk {
        param([string]$ParentProjectId,[string]$ParentName,[string]$DependencyProjectId,[string]$DependencyName,[string]$NormalDependencyVersion,[string]$TestDependencyVersion,[string]$Reason)
        if([string]::IsNullOrWhiteSpace($ParentProjectId)){return}
        $pk=$ParentProjectId.ToLowerInvariant();$dk=([string]$DependencyProjectId).ToLowerInvariant();$key=$pk+'|'+$dk+'|'+$Reason
        if($riskKeys.ContainsKey($key)){return};$riskKeys[$key]=$true
        $parentMod=$null;if($rootModByProject.ContainsKey($pk)){$parentMod=$rootModByProject[$pk]}
        $riskRows.Add([pscustomobject]@{
            status='VIGILAR';addon=[string]$ParentName;addonProjectId=$ParentProjectId;addonModId=if($null-ne$parentMod){[string]$parentMod.id}else{''};
            clientFile=if($null-ne$parentMod){[string]$parentMod.clientFile}else{''};serverFile=if($null-ne$parentMod){[string]$parentMod.serverFile}else{''};
            dependency=[string]$DependencyName;dependencyProjectId=$DependencyProjectId;normalDependencyVersion=$NormalDependencyVersion;testDependencyVersion=$TestDependencyVersion;reason=$Reason
        })
    }

    function AddTestProject {
        param([string]$ProjectId,[string]$ForcedVersionId,[string]$RequestedSide,[string]$ReplaceModId,[string]$DisplayName,[bool]$IsRoot,[string]$ParentProjectId='',[string]$ParentDisplayName='')
        if([string]::IsNullOrWhiteSpace($ProjectId)){return}
        $key=$ProjectId.ToLowerInvariant()
        if($excludedTestProjectIds.ContainsKey($key)){return}
        if($visiting.ContainsKey($key)){return}

        $version=$null
        $isInstalledRoot=$rootProjects.ContainsKey($key)
        if($isInstalledRoot){
            # Un mod que ya existe en el pack NORMAL manda sobre las restricciones
            # antiguas de un addon: siempre probamos su versión más reciente para
            # Minecraft/loader objetivo. El addon se conserva y se marca para revisar.
            $version=Get-ModrinthCompatibleVersionForTarget -ProjectId $ProjectId -MinecraftVersion $MinecraftVersion -Loader $Loader
            if($null-eq$version){throw "No existe una versión de $DisplayName ($ProjectId) compatible con Minecraft $MinecraftVersion / $Loader."}
            if(-not[string]::IsNullOrWhiteSpace($ForcedVersionId) -and [string]$version.id -ne $ForcedVersionId){
                $normalDep='';if($currentVersionNumberByProject.ContainsKey($key)){$normalDep=[string]$currentVersionNumberByProject[$key]}
                Add-ModTestRisk -ParentProjectId $ParentProjectId -ParentName $ParentDisplayName -DependencyProjectId $ProjectId -DependencyName $DisplayName -NormalDependencyVersion $normalDep -TestDependencyVersion ([string]$version.version_number) -Reason ('El addon referenciaba una versión concreta de esta dependencia, pero el TEST prioriza la versión más reciente compatible. El addon se mantiene para probarlo.')
            }
            $ForcedVersionId=''
        } elseif(-not[string]::IsNullOrWhiteSpace($ForcedVersionId)){
            $version=Get-ModrinthVersionById $ForcedVersionId
            if(-not(Test-ModrinthVersionForTarget -Version $version -MinecraftVersion $MinecraftVersion -Loader $Loader)){
                throw "La dependencia $ProjectId exige la versión $ForcedVersionId, pero esa versión no es compatible con Minecraft $MinecraftVersion / $Loader."
            }
        } else {
            $version=Get-ModrinthCompatibleVersionForTarget -ProjectId $ProjectId -MinecraftVersion $MinecraftVersion -Loader $Loader
            if($null-eq$version){throw "No existe una versión de $DisplayName ($ProjectId) compatible con Minecraft $MinecraftVersion / $Loader."}
        }

        # Iris 1.8.8 para MC 1.21.1 necesita Sodium 0.6.x. La versión 0.8.13
        # seleccionada por "más reciente" es incompatible con esa rama de Iris.
        # Mientras usemos este stack, fijamos Sodium 0.6.13 (Modrinth u1OEbNKx).
        if($IsRoot -and ([string]$ReplaceModId).ToLowerInvariant() -eq 'sodium' -and $MinecraftVersion -eq '1.21.1' -and $Loader -eq 'fabric'){
            $compatSodium=Get-ModrinthVersionById 'u1OEbNKx'
            if($null-eq$compatSodium -or -not(Test-ModrinthVersionForTarget -Version $compatSodium -MinecraftVersion $MinecraftVersion -Loader $Loader)){
                throw 'No se pudo cargar Sodium 0.6.13 compatible con Iris 1.8.8.'
            }
            $version=@($compatSodium)[0]
        }

        if($null-ne$version){$version=@($version)[0]}
        if($null-eq$version -or -not(@($version.PSObject.Properties.Name) -contains 'id')){throw "ERROR INTERNO: $ProjectId no produjo una versión Modrinth única antes de añadirla al plan."}

        if($selected.ContainsKey($key)){
            $existing=$selected[$key]
            $incomingSide=if($IsRoot){Convert-ModTestEnvironmentToSide (Get-ModTestVersionEnvironment $version) $RequestedSide}else{if($RequestedSide -in @('client','server','both')){$RequestedSide}else{'both'}}
            $existing.side=Merge-ModTestSides ([string]$existing.side) $incomingSide
            if($IsRoot){$existing.root=$true}
            if(-not[string]::IsNullOrWhiteSpace($ReplaceModId) -and -not(@($existing.replaceModIds) -contains $ReplaceModId)){$existing.replaceModIds=@($existing.replaceModIds)+@($ReplaceModId)}
            # Solo una dependencia NO instalada como raíz puede fijar versión.
            # Los mods principales del pack nunca se rebajan para satisfacer un addon.
            if(-not$rootProjects.ContainsKey($key) -and -not[string]::IsNullOrWhiteSpace($ForcedVersionId) -and [string]$existing.version.id -ne [string]$version.id){
                if(-not[string]::IsNullOrWhiteSpace([string]$existing.forcedVersionId) -and [string]$existing.forcedVersionId -ne $ForcedVersionId){throw "Conflicto de dependencias para ${ProjectId}: se exigen dos versiones distintas."}
                $existing.version=$version;$existing.file=Get-ModrinthPrimaryFile $version;$existing.forcedVersionId=$ForcedVersionId
                $visiting[$key]=$true
                foreach($dep in @(Get-ModrinthVersionDependenciesSafe -Version $version)){
                    if([string]$dep.dependency_type -ne 'required'){continue}
                    $depProject=[string]$dep.project_id;$depVersion=[string]$dep.version_id
                    if([string]::IsNullOrWhiteSpace($depProject) -and -not[string]::IsNullOrWhiteSpace($depVersion)){$depObj=Get-ModrinthVersionById $depVersion;$depProject=[string]$depObj.project_id}
                    if(-not[string]::IsNullOrWhiteSpace($depProject)){AddTestProject -ProjectId $depProject -ForcedVersionId $depVersion -RequestedSide ([string]$existing.side) -ReplaceModId '' -DisplayName $depProject -IsRoot $false -ParentProjectId ([string]$existing.projectId) -ParentDisplayName ([string]$existing.displayName)}
                }
                [void]$visiting.Remove($key)
            }
            return
        }

        $file=Get-ModrinthPrimaryFile $version
        if($null-eq$file){throw "La versión $($version.version_number) de $DisplayName no contiene un JAR instalable."}
        # Una dependencia requerida debe existir en todos los lados donde se carga
        # su padre, aunque Modrinth etiquete la librería como server-only. Fabric
        # necesita ver su metadata para satisfacer el depends del mod padre.
        $side=if($IsRoot){Convert-ModTestEnvironmentToSide (Get-ModTestVersionEnvironment $version) $RequestedSide}else{if($RequestedSide -in @('client','server','both')){$RequestedSide}else{'both'}}
        $entry=[pscustomobject]@{
            projectId=$ProjectId
            displayName=$DisplayName
            version=$version
            file=$file
            side=$side
            replaceModIds=if([string]::IsNullOrWhiteSpace($ReplaceModId)){@()}else{@($ReplaceModId)}
            root=$IsRoot
            forcedVersionId=$ForcedVersionId
        }
        $selected[$key]=$entry
        $visiting[$key]=$true
        foreach($dep in @(Get-ModrinthVersionDependenciesSafe -Version $version)){
            if([string]$dep.dependency_type -ne 'required'){continue}
            $depProject=[string]$dep.project_id;$depVersion=[string]$dep.version_id
            if([string]::IsNullOrWhiteSpace($depProject) -and -not[string]::IsNullOrWhiteSpace($depVersion)){$depObj=Get-ModrinthVersionById $depVersion;$depProject=[string]$depObj.project_id}
            if([string]::IsNullOrWhiteSpace($depProject)){continue}
            AddTestProject -ProjectId $depProject -ForcedVersionId $depVersion -RequestedSide $side -ReplaceModId '' -DisplayName $depProject -IsRoot $false -ParentProjectId $ProjectId -ParentDisplayName $DisplayName
        }
        [void]$visiting.Remove($key)
    }

    Write-Host '2/7 Buscando la última versión compatible de TODOS los mods identificables...' -ForegroundColor Cyan
    $index=0
    foreach($m in @($inventory.mods)){
        $index++
        $sha1=([string]$m.sha1).ToLowerInvariant();$currentVersionObj=$null;$projectIdValue='';$resolveMethod=''
        if(-not[string]::IsNullOrWhiteSpace($sha1) -and $hashMap.ContainsKey($sha1)){$currentVersionObj=$hashMap[$sha1]}
        $mid=([string]$m.id).ToLowerInvariant()
        if($resolvedProjectByModId.ContainsKey($mid)){$resolved=$resolvedProjectByModId[$mid];$projectIdValue=[string]$resolved.projectId;$resolveMethod=[string]$resolved.method}
        else{$resolved=Resolve-ModrinthRootProject -Mod $m -HashMap $hashMap -MinecraftVersion $MinecraftVersion -Loader $Loader;if($null-ne$resolved){$projectIdValue=[string]$resolved.projectId;$resolveMethod=[string]$resolved.method;$resolvedProjectByModId[$mid]=$resolved}}
        Write-Host ("  [{0}/{1}] {2}" -f $index,@($inventory.mods).Count,[string]$m.name) -ForegroundColor DarkGray
        if($excludedTestRootIds.ContainsKey($mid)){
            $reason=if($mid -eq 'better_pokedex_scanner'){'EXCLUIDO SOLO DEL TEST: Better Pokédex Scanner 1.0.0 declara Cobblemon <1.8.0 y bloquea Cobblemon 1.8.1.'}else{'EXCLUIDO SOLO DEL TEST: Reese''s Sodium Options se aparta temporalmente para estabilizar la combinación Iris 1.8.8 + Sodium 0.6.13.'}
            Write-Host ("    {0}" -f $reason) -ForegroundColor Yellow
            $reportRows.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;status='EXCLUIDO TEST';current=if($m.versionClient){[string]$m.versionClient}else{[string]$m.versionServer};target='';detail=$reason})
            $riskRows.Add([pscustomobject]@{status='EXCLUIDO TEST';addon=[string]$m.name;addonProjectId=$projectIdValue;addonModId=[string]$m.id;clientFile=[string]$m.clientFile;serverFile=[string]$m.serverFile;dependency=if($mid -eq 'better_pokedex_scanner'){'Cobblemon'}else{'Iris / Sodium'};dependencyProjectId='';normalDependencyVersion='';testDependencyVersion=if($mid -eq 'better_pokedex_scanner'){'Cobblemon 1.8.1'}else{'Iris 1.8.8 + Sodium 0.6.13'};reason=$reason})
            continue
        }
        if([string]::IsNullOrWhiteSpace($projectIdValue)){
            $unresolved.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;reason='No encontrado por hash en Modrinth; se conserva el JAR actual.'})
            $reportRows.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;status='CONSERVADO';current=if($m.versionClient){[string]$m.versionClient}else{[string]$m.versionServer};target='';detail='No identificado en Modrinth'})
            continue
        }
        try{
            $latest=Get-ModrinthCompatibleVersionForTarget -ProjectId $projectIdValue -MinecraftVersion $MinecraftVersion -Loader $Loader
            if($null-ne$latest){
                $latestCount=@($latest).Count
                if($latestCount -ne 1){throw "ERROR INTERNO: el selector devolvió $latestCount versiones para $projectIdValue; se esperaba exactamente 1."}
                $latest=@($latest)[0]
                Write-Host ("    Modrinth: {0} ({1}) -> {2} [{3}] · {4}" -f $projectIdValue,$resolveMethod,[string]$latest.version_number,[string]$latest.id,[string]$latest.date_published) -ForegroundColor DarkCyan
            }
            if($null-eq$latest){
                $unresolved.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;reason="Sin versión compatible para $MinecraftVersion/$Loader; se conserva el JAR actual."})
                $reportRows.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;status='CONSERVADO';current=if($m.versionClient){[string]$m.versionClient}else{[string]$m.versionServer};target='';detail='Sin versión compatible'})
                continue
            }
            AddTestProject -ProjectId $projectIdValue -ForcedVersionId '' -RequestedSide ([string]$m.side) -ReplaceModId ([string]$m.id) -DisplayName ([string]$m.name) -IsRoot $true
            $chosen=$selected[$projectIdValue.ToLowerInvariant()].version
            if(([string]$m.id).ToLowerInvariant() -eq 'cobblemon'){
                $chosenFileForLog=Get-ModrinthPrimaryFile $chosen
                $chosenFileNameForLog=if($null-ne$chosenFileForLog){[string]$chosenFileForLog.filename}else{'(sin archivo)'}
                Write-Host ("    COBBLEMON SELECCIONADO DE FORMA DEFINITIVA: {0} [{1}] · archivo={2}" -f [string]$chosen.version_number,[string]$chosen.id,$chosenFileNameForLog) -ForegroundColor Magenta
            }
            $currentId='';if($null-ne$currentVersionObj){$currentId=[string]$currentVersionObj.id}elseif(-not[string]::IsNullOrWhiteSpace([string]$m.sourceVersionId)){$currentId=[string]$m.sourceVersionId}
            $status=if($currentId -eq [string]$chosen.id){'YA ACTUAL'}else{'ACTUALIZAR'}
            $detail=$projectIdValue;if([string]$chosen.id -ne [string]$latest.id){$detail += ' · versión ajustada por dependencia'}
            $reportRows.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;status=$status;current=if($m.versionClient){[string]$m.versionClient}else{[string]$m.versionServer};target=[string]$chosen.version_number;detail=$detail})
        }catch{
            $msg=[string]$_.Exception.Message
            Write-Host ("    ERROR MODRINTH en {0}: {1}" -f [string]$m.name,$msg) -ForegroundColor Red
            throw ("No se puede construir un TEST fiable porque falló la consulta/planificación de '{0}'. {1}" -f [string]$m.name,$msg)
        }
    }

    # Addons/dependientes que se mantienen mientras una dependencia instalada cambia
    # de versión quedan señalados para prueba manual. No se eliminan ni fuerzan downgrade.
    foreach($entry in @($selected.Values)){
        if(-not[bool]$entry.root){continue}
        foreach($dep in @(Get-ModrinthVersionDependenciesSafe -Version $entry.version)){
            if([string]$dep.dependency_type -ne 'required'){continue}
            $depProject=[string]$dep.project_id;$depVersion=[string]$dep.version_id
            if([string]::IsNullOrWhiteSpace($depProject) -and -not[string]::IsNullOrWhiteSpace($depVersion)){$depObj=Get-ModrinthVersionById $depVersion;$depProject=[string]$depObj.project_id}
            if([string]::IsNullOrWhiteSpace($depProject)){continue}
            $dk=$depProject.ToLowerInvariant()
            if(-not$rootProjects.ContainsKey($dk) -or -not$selected.ContainsKey($dk)){continue}
            $normalId='';$normalNumber='';if($currentVersionIdByProject.ContainsKey($dk)){$normalId=[string]$currentVersionIdByProject[$dk]};if($currentVersionNumberByProject.ContainsKey($dk)){$normalNumber=[string]$currentVersionNumberByProject[$dk]}
            $testDep=$selected[$dk].version
            if(-not[string]::IsNullOrWhiteSpace($normalId) -and $normalId -ne [string]$testDep.id){
                $depName=[string]$selected[$dk].displayName
                Add-ModTestRisk -ParentProjectId ([string]$entry.projectId) -ParentName ([string]$entry.displayName) -DependencyProjectId $depProject -DependencyName $depName -NormalDependencyVersion $normalNumber -TestDependencyVersion ([string]$testDep.version_number) -Reason 'Este mod depende de otro mod del pack que cambia de versión en el TEST. Se conserva instalado para comprobar si sigue funcionando; no se rebaja la dependencia nueva.'
            }
        }
    }

    Write-Host ("Plan: {0} proyectos Modrinth, {1} mods conservados sin actualizar, {2} addon(s)/dependiente(s) a vigilar." -f $selected.Count,$unresolved.Count,$riskRows.Count) -ForegroundColor Green
    if($rootProjects.Count -gt 0 -and $selected.Count -eq 0){throw 'ERROR INTERNO: se identificaron proyectos en Modrinth pero el plan terminó con 0 proyectos. Se cancela para no reconstruir el TEST con todos los JAR antiguos.'}
    Write-Host '3/7 Construyendo carpetas de mods TEST sin tocar las actuales...' -ForegroundColor Cyan
    if(Test-Path -LiteralPath $script:ModTestDownloadsDir){Remove-Item $script:ModTestDownloadsDir -Recurse -Force}
    if(Test-Path -LiteralPath $script:ModTestClientModsDir){Remove-Item $script:ModTestClientModsDir -Recurse -Force}
    $serverStage=Join-Path $script:ModTestRoot 'server-mods'
    if(Test-Path -LiteralPath $serverStage){Remove-Item $serverStage -Recurse -Force}
    New-Item -ItemType Directory -Force -Path $script:ModTestDownloadsDir,$script:ModTestClientModsDir,$serverStage | Out-Null
    foreach($f in @(Get-ChildItem -LiteralPath (Get-ModManagerClientModsDir) -File -Filter '*.jar' -ErrorAction SilentlyContinue)){Copy-Item $f.FullName (Join-Path $script:ModTestClientModsDir $f.Name) -Force}
    foreach($f in @(Get-ChildItem -LiteralPath (Get-ModManagerServerModsDir) -File -Filter '*.jar' -ErrorAction SilentlyContinue)){Copy-Item $f.FullName (Join-Path $serverStage $f.Name) -Force}
    $clientStageIdPaths=Get-ModTestDirectoryIdMultiMap -Directory $script:ModTestClientModsDir
    $serverStageIdPaths=Get-ModTestDirectoryIdMultiMap -Directory $serverStage

    if($excludedTestRootIds.Count -gt 0){
        $excludedIds=[string[]]@($excludedTestRootIds.Keys)
        Remove-ModTestJarsByIds -Directory $script:ModTestClientModsDir -Ids $excludedIds -PathMap $clientStageIdPaths
        Remove-ModTestJarsByIds -Directory $serverStage -Ids $excludedIds -PathMap $serverStageIdPaths
        foreach($xid in $excludedIds){Write-Host ("  EXCLUIDO DEL TEST: {0}" -f $xid) -ForegroundColor Yellow}
    }

    $sourceMap=Get-ModManagerSourceMap;$downloadIndex=0
    foreach($entry in @($selected.Values)){
        $downloadIndex++
        Write-Host ("  Descargando [{0}/{1}] {2} {3}" -f $downloadIndex,$selected.Count,[string]$entry.displayName,[string]$entry.version.version_number) -ForegroundColor DarkCyan
        $safeProject=([string]$entry.projectId) -replace '[^A-Za-z0-9._-]','_'
        $dest=Join-Path $script:ModTestDownloadsDir ($safeProject+'--'+[string]$entry.file.filename)
        Invoke-WebRequest -Uri ([string]$entry.file.url) -OutFile $dest -UseBasicParsing -Headers @{'User-Agent'='CobbleverseServerManager/5.2.0.18'}
        $hash=Get-ModFileHashes $dest
        $expectedSha1='';if(($entry.file.PSObject.Properties.Name -contains 'hashes') -and $null-ne$entry.file.hashes -and ($entry.file.hashes.PSObject.Properties.Name -contains 'sha1')){$expectedSha1=([string]$entry.file.hashes.sha1).ToLowerInvariant()}
        if(-not[string]::IsNullOrWhiteSpace($expectedSha1) -and $hash.sha1 -ne $expectedSha1){throw "Hash SHA1 incorrecto al descargar $($entry.displayName)."}
        $meta=Get-JarModMetadata -Path $dest -Presence ([string]$entry.side) -SourceMap $sourceMap
        $replaceIds=@($entry.replaceModIds)
        $actualId=([string]$meta.id).ToLowerInvariant()
        $rootReplacementOk=$true
        if($replaceIds.Count -gt 0){
            $rootReplacementOk=$false
            foreach($rid in $replaceIds){if(([string]$rid).ToLowerInvariant() -eq $actualId){$rootReplacementOk=$true;break}}
        }
        if(-not$rootReplacementOk){
            throw ("Modrinth seleccionó '{0}' {1} para {2}, pero el JAR descargado declara ID '{3}' en vez del ID instalado. Se cancela el TEST para no conservar silenciosamente una versión antigua." -f [string]$entry.file.filename,[string]$entry.version.version_number,[string]$entry.displayName,[string]$meta.id)
        }

        $idsToRemove=@($replaceIds)+@([string]$meta.id)
        # Quitar por ID interno, no por nombre de fichero. Esto elimina cualquier
        # copia vieja/renombrada/duplicada del mismo mod antes de poner la nueva.
        Remove-ModTestJarsByIds -Directory $script:ModTestClientModsDir -Ids $idsToRemove -PathMap $clientStageIdPaths
        Remove-ModTestJarsByIds -Directory $serverStage -Ids $idsToRemove -PathMap $serverStageIdPaths

        $finalName=[string]$entry.file.filename
        if([string]$entry.side -in @('client','both')){
            $clientDest=Join-Path $script:ModTestClientModsDir $finalName
            Copy-Item -LiteralPath $dest -Destination $clientDest -Force
            $newId=([string]$meta.id).ToLowerInvariant();if(-not$clientStageIdPaths.ContainsKey($newId)){$clientStageIdPaths[$newId]=New-Object 'System.Collections.Generic.List[string]'};$clientStageIdPaths[$newId].Add($clientDest)
            Write-Host ("    INSTALADO CLIENTE: {0} -> {1}" -f [string]$meta.id,$finalName) -ForegroundColor Green
        }
        if([string]$entry.side -in @('server','both')){
            $serverDest=Join-Path $serverStage $finalName
            Copy-Item -LiteralPath $dest -Destination $serverDest -Force
            $newId=([string]$meta.id).ToLowerInvariant();if(-not$serverStageIdPaths.ContainsKey($newId)){$serverStageIdPaths[$newId]=New-Object 'System.Collections.Generic.List[string]'};$serverStageIdPaths[$newId].Add($serverDest)
            Write-Host ("    INSTALADO SERVIDOR: {0} -> {1}" -f [string]$meta.id,$finalName) -ForegroundColor Green
        }
        $environmentValue=''
        if($entry.version.PSObject.Properties.Name -contains 'environment'){$environmentValue=[string]$entry.version.environment}
        $sourceMap[$hash.sha256]=[pscustomobject]@{source='modrinth';projectId=[string]$entry.projectId;versionId=[string]$entry.version.id;environment=$environmentValue;url=[string]$entry.file.url;versionNumber=[string]$entry.version.version_number;title=[string]$entry.displayName}
    }
    Save-ModManagerSourceMap $sourceMap

    # Primero verificamos físicamente que cada mod raíz actualizado es EXACTAMENTE
    # el JAR elegido por Modrinth. Si no lo es, abortamos: nunca restauramos el viejo.
    Assert-ModTestSelectedRootsExact -Selected $selected -ClientStage $script:ModTestClientModsDir -ServerStage $serverStage
    # Para cada root actualizado guardamos el lado REAL elegido para la nueva versión.
    # No basta con un booleano: un mod que estaba en ambos lados en NORMAL puede pasar
    # a ser server-only/client-only en Modrinth. En ese caso NO debemos restaurar el JAR
    # antiguo en el lado que ya no corresponde.
    $protectedRootIds=@{}
    foreach($xid in @($excludedTestRootIds.Keys)){$protectedRootIds[([string]$xid).ToLowerInvariant()]='excluded'}
    foreach($entry in @($selected.Values)){
        if(-not[bool]$entry.root){continue}
        foreach($rid in @($entry.replaceModIds)){
            if([string]::IsNullOrWhiteSpace([string]$rid)){continue}
            $rk=([string]$rid).ToLowerInvariant()
            $newSide=[string]$entry.side
            if($protectedRootIds.ContainsKey($rk)){$protectedRootIds[$rk]=Merge-ModTestSides ([string]$protectedRootIds[$rk]) $newSide}
            else{$protectedRootIds[$rk]=$newSide}
        }
    }

    Write-Host '  Validando que ninguna actualización haya eliminado mods base del pack NORMAL...' -ForegroundColor Cyan
    $baselineRestored=@(Repair-ModTestMissingBaselineMods -Inventory $inventory -ClientStage $script:ModTestClientModsDir -ServerStage $serverStage -ProtectedRootIds $protectedRootIds)
    if($baselineRestored.Count -gt 0){
        Write-Host ("  Se han restaurado {0} JAR(s) del NORMAL porque su reemplazo no quedó presente en el TEST." -f $baselineRestored.Count) -ForegroundColor Yellow
    }
    # La reparación de baseline tampoco puede reintroducir un root antiguo.
    Assert-ModTestSelectedRootsExact -Selected $selected -ClientStage $script:ModTestClientModsDir -ServerStage $serverStage

    # Diagnóstico explícito del JAR físico de Cobblemon ANTES de sellar el TEST.
    $clientIdMapFinal=Get-ModTestDirectoryIdMap -Directory $script:ModTestClientModsDir
    if($clientIdMapFinal.ContainsKey('cobblemon')){
        $cobbleJar=Join-Path $script:ModTestClientModsDir ([string]$clientIdMapFinal['cobblemon'])
        $cobbleMeta=Get-JarModMetadata -Path $cobbleJar -Presence 'client' -SourceMap $sourceMap
        $cobbleHash=Get-ModFileHashes $cobbleJar
        Write-Host ("  COBBLEMON FÍSICO EN TEST CLIENTE: versión={0} archivo={1} sha1={2}" -f [string]$cobbleMeta.version,[IO.Path]::GetFileName($cobbleJar),[string]$cobbleHash.sha1) -ForegroundColor Magenta
    }
    $riskReport=Save-ModTestRiskReport -Items $riskRows.ToArray() -MinecraftVersion $MinecraftVersion -Loader $Loader
    if($riskRows.Count -gt 0){Write-Host ("  AVISO: {0} addon(s)/mod(s) quedan instalados pero marcados A VIGILAR. Informe: {1}" -f $riskRows.Count,$script:ModTestRiskTextPath) -ForegroundColor Yellow}

    Write-Host '4/7 Copiando configuración del cliente para aislarla del modo NORMAL...' -ForegroundColor Cyan
    $clientInstance=Get-ModManagerClientInstancePath
    Copy-ModTestDirectoryClean -Source (Join-Path $clientInstance 'config') -Destination $script:ModTestClientConfigDir
    Copy-ModTestDirectoryClean -Source (Join-Path $clientInstance 'defaultconfigs') -Destination $script:ModTestClientDefaultConfigsDir

    Write-Host '5/7 Creando copia COMPLETA y aislada del servidor/mundo...' -ForegroundColor Cyan
    $testServer=Get-ModTestServerDir
    Assert-ModTestServerPathSafe -TestServerPath $testServer
    if(Test-Path -LiteralPath $testServer){Remove-Item -LiteralPath $testServer -Recurse -Force}
    New-Item -ItemType Directory -Force -Path $testServer | Out-Null
    $exclude=@((Join-Path $script:ServerDir 'mods'),(Join-Path $script:ServerDir 'logs'),(Join-Path $script:ServerDir 'crash-reports'),(Join-Path $script:ServerDir 'backups'))
    Invoke-ModTestRoboCopy -Source $script:ServerDir -Destination $testServer -ExcludeDirs $exclude
    $testServerMods=Join-Path $testServer 'mods';Sync-ModTestDirectory -Source $serverStage -Destination $testServerMods

    $normalPort=Get-MinecraftServerPort;$preferredTestPort=$normalPort+1;if($preferredTestPort -gt 65535){$preferredTestPort=25566};$testPort=Get-ModTestFreePort -PreferredPort $preferredTestPort
    Set-ModTestServerPort -ServerDir $testServer -Port $testPort
    $testServerJar=''
    if($Loader -eq 'fabric'){$testServerJar=Install-ModTestFabricServerLauncher -TestServer $testServer -MinecraftVersion $MinecraftVersion}
    [IO.File]::WriteAllText((Join-Path $testServer 'COBBLEVERSE_MOD_TEST.txt'),("ENTORNO TEST. Mundo copiado del NORMAL el {0}. No sincronizar con Drive.`r`n" -f [DateTimeOffset]::Now.ToString('o')),(New-Object Text.UTF8Encoding($false)))
    if(Test-Path -LiteralPath $script:ModTestRiskTextPath){Copy-Item -LiteralPath $script:ModTestRiskTextPath -Destination (Join-Path $testServer 'ADDONS_A_VIGILAR.txt') -Force}

    Write-Host '6/7 Guardando informe y estado del entorno TEST...' -ForegroundColor Cyan
    $dependencyCount=0;foreach($entry in @($selected.Values)){if(-not[bool]$entry.root){$dependencyCount++}}
    $updatedCount=@($reportRows.ToArray()|Where-Object{$_.status -eq 'ACTUALIZAR'}).Count
    $sameCount=@($reportRows.ToArray()|Where-Object{$_.status -eq 'YA ACTUAL'}).Count
    $plan=[ordered]@{format='cobbleverse-mod-test-plan-v1';createdUtc=[DateTimeOffset]::UtcNow.ToString('o');minecraftVersion=$MinecraftVersion;loader=$Loader;roots=@($inventory.mods).Count;identifiedRoots=$rootProjects.Count;selectedProjects=$selected.Count;dependencies=$dependencyCount;updates=$updatedCount;alreadyLatest=$sameCount;keptCurrent=$unresolved.Count;baselineRestored=$baselineRestored.Count;riskyAddons=$riskRows.Count;items=$reportRows.ToArray();unresolved=$unresolved.ToArray();risks=$riskRows.ToArray()}
    Write-ModManagerJson $script:ModTestPlanPath $plan 30
    $state=[ordered]@{format='cobbleverse-mod-test-state-v1';createdUtc=[DateTimeOffset]::UtcNow.ToString('o');minecraftVersion=$MinecraftVersion;loader=$Loader;normalServerPath=$script:ServerDir;testServerPath=$testServer;normalClientPath=$clientInstance;testClientProfilePath=[string]$testProfileInfo.path;testClientProfileName='New Cobbleverse';requiredFabricLoader=(Get-ModTestFabricLoaderVersion);testServerJar=$testServerJar;testClientModsPath=$script:ModTestClientModsDir;normalPort=$normalPort;testPort=$testPort;clientActive=$false;promoted=$false;latestPromotionBackup='';updated=$updatedCount;alreadyLatest=$sameCount;keptCurrent=$unresolved.Count;excludedTest=$excludedTestRootIds.Count;dependencies=$dependencyCount;baselineRestored=$baselineRestored.Count;riskyAddons=$riskRows.Count;testClientMods=@(Get-ChildItem $script:ModTestClientModsDir -File -Filter '*.jar' -ErrorAction SilentlyContinue).Count;testServerMods=@(Get-ChildItem $testServerMods -File -Filter '*.jar' -ErrorAction SilentlyContinue).Count;buildId=$buildId;buildComplete=$true;builderVersion='5.2.0.18'}
    Save-ModTestState $state

    $readyItems=New-Object 'System.Collections.Generic.List[object]'
    foreach($entry in @($selected.Values)){
        if(-not[bool]$entry.root){continue}
        $sha1=''
        if(($entry.file.PSObject.Properties.Name -contains 'hashes') -and $null-ne$entry.file.hashes -and ($entry.file.hashes.PSObject.Properties.Name -contains 'sha1')){$sha1=([string]$entry.file.hashes.sha1).ToLowerInvariant()}
        $readyItems.Add([pscustomobject]@{projectId=[string]$entry.projectId;ids=[string[]]@($entry.replaceModIds);versionId=[string]$entry.version.id;versionNumber=[string]$entry.version.version_number;fileName=[string]$entry.file.filename;sha1=$sha1;side=[string]$entry.side})
    }
    $ready=[ordered]@{format='cobbleverse-mod-test-ready-v1';buildId=$buildId;builtUtc=[DateTimeOffset]::UtcNow.ToString('o');builderVersion='5.2.0.18';minecraftVersion=$MinecraftVersion;loader=$Loader;clientMods=[int]$state.testClientMods;serverMods=[int]$state.testServerMods;items=$readyItems.ToArray()}
    Write-ModManagerJson $script:ModTestReadyPath $ready 40
    Remove-Item -LiteralPath $script:ModTestBuildMarkerPath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $serverStage -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host '7/7 ENTORNO TEST LISTO Y VALIDADO.' -ForegroundColor Green
    Write-Host ("Servidor TEST: {0}" -f $testServer) -ForegroundColor Green
    Write-Host ("Puerto TEST: {0} (NORMAL: {1})" -f $testPort,$normalPort) -ForegroundColor Green
    Write-Host ("Mods: {0} actualizables, {1} ya actuales, {2} conservados, {3} dependencias resueltas, {4} addon(s) a vigilar." -f $updatedCount,$sameCount,$unresolved.Count,$dependencyCount,$riskRows.Count) -ForegroundColor Green
    Write-Host 'El mundo REAL no se ha modificado. Drive tampoco se ha modificado.' -ForegroundColor Yellow
    return $state
}

function Activate-ModTestClient {
    Initialize-ModTestPaths
    $ready=Assert-ModTestReadyForActivation
    $state=Get-ModTestState;if($null-eq$state){throw 'Primero crea el entorno TEST.'}
    $profile=Assert-ModTestClientProfileCompatible -MinecraftVersion ([string]$state.minecraftVersion)
    $instance=[string]$profile.path
    $mods=Join-Path $instance 'mods';$cfg=Join-Path $instance 'config';$defs=Join-Path $instance 'defaultconfigs'
    Write-Host ("Activando TEST en el perfil CurseForge separado: {0}" -f $instance) -ForegroundColor Cyan
    Sync-ModTestDirectory -Source $script:ModTestClientModsDir -Destination $mods
    Assert-ModTestReadyDirectory -Ready $ready -Directory $mods -SideLabel 'client'
    if(Test-Path -LiteralPath $script:ModTestClientConfigDir){Sync-ModTestDirectory -Source $script:ModTestClientConfigDir -Destination $cfg}
    if(Test-Path -LiteralPath $script:ModTestClientDefaultConfigsDir){Sync-ModTestDirectory -Source $script:ModTestClientDefaultConfigsDir -Destination $defs}
    $state.clientActive=$true
    if($state.PSObject.Properties.Name -contains 'testClientProfilePath'){$state.testClientProfilePath=$instance}else{$state|Add-Member -NotePropertyName testClientProfilePath -NotePropertyValue $instance}
    Save-ModTestState $state
    Write-Host "Perfil NORMAL intacto. En CurseForge abre: New Cobbleverse" -ForegroundColor Green
    return $state
}

function Restore-ModTestClientNormal {
    Initialize-ModTestPaths
    $state=Get-ModTestState

    # Recuperación única del mecanismo antiguo (v5.2.0.17 y anteriores).
    $normalInstance=Get-ModManagerClientInstancePath
    $back=Get-ModTestClientBackupPaths
    $normalMods=Join-Path $normalInstance 'mods';$normalCfg=Join-Path $normalInstance 'config';$normalDefs=Join-Path $normalInstance 'defaultconfigs'
    if(Test-Path -LiteralPath $back.mods){
        if(Test-Path -LiteralPath $normalMods){Remove-Item -LiteralPath $normalMods -Recurse -Force}
        Move-Item -LiteralPath $back.mods -Destination $normalMods
    }
    if(Test-Path -LiteralPath $back.config){
        if(Test-Path -LiteralPath $normalCfg){Remove-Item -LiteralPath $normalCfg -Recurse -Force}
        Move-Item -LiteralPath $back.config -Destination $normalCfg
    }
    if(Test-Path -LiteralPath $back.defaultconfigs){
        if(Test-Path -LiteralPath $normalDefs){Remove-Item -LiteralPath $normalDefs -Recurse -Force}
        Move-Item -LiteralPath $back.defaultconfigs -Destination $normalDefs
    }

    # Nuevo sistema: NORMAL nunca se sustituye. Solo guardamos posibles cambios de
    # config hechos durante la prueba para que una promoción pueda conservarlos.
    $testInstance=Get-ModTestClientInstancePath
    if(Test-Path -LiteralPath $testInstance -PathType Container){
        $testCfg=Join-Path $testInstance 'config'
        $testDefs=Join-Path $testInstance 'defaultconfigs'
        if(Test-Path -LiteralPath $testCfg){Copy-ModTestDirectoryClean -Source $testCfg -Destination $script:ModTestClientConfigDir}
        if(Test-Path -LiteralPath $testDefs){Copy-ModTestDirectoryClean -Source $testDefs -Destination $script:ModTestClientDefaultConfigsDir}
    }
    if($null-ne$state){$state.clientActive=$false;Save-ModTestState $state}
    Write-Host 'Modo TEST desactivado en el gestor. El perfil NORMAL no se ha tocado; selecciónalo en CurseForge para jugar NORMAL.' -ForegroundColor Green
    return $state
}

function Start-ModTestServerConsole {
    Initialize-ModTestPaths
    $state=Get-ModTestState;if($null-eq$state){throw 'Primero crea el entorno TEST.'}
    if($null-ne(Get-ModTestServerRunningInfo)){throw 'El servidor TEST ya está en ejecución.'}
    $launcher=Join-Path $PSScriptRoot 'StartTestServer.ps1'
    if(-not(Test-Path -LiteralPath $launcher)){throw 'Falta StartTestServer.ps1.'}
    $ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $arg='-NoProfile -ExecutionPolicy Bypass -File "'+$launcher+'"'
    Start-Process -FilePath $ps -ArgumentList $arg -WorkingDirectory ([string]$state.testServerPath) -WindowStyle Normal | Out-Null
    return $state
}

function New-ModPromotionBackup {
    Initialize-ModTestPaths
    $id=(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6)
    $root=Join-Path $script:ModPromotionRoot $id
    New-Item -ItemType Directory -Force -Path $root | Out-Null
    $client=Join-Path $root 'client';$server=Join-Path $root 'server';New-Item -ItemType Directory -Force -Path $client,$server|Out-Null
    Copy-ModTestDirectoryClean -Source (Get-ModManagerClientModsDir) -Destination (Join-Path $client 'mods')
    Copy-ModTestDirectoryClean -Source (Join-Path (Get-ModManagerClientInstancePath) 'config') -Destination (Join-Path $client 'config')
    Copy-ModTestDirectoryClean -Source (Join-Path (Get-ModManagerClientInstancePath) 'defaultconfigs') -Destination (Join-Path $client 'defaultconfigs')
    Copy-ModTestDirectoryClean -Source (Get-ModManagerServerModsDir) -Destination (Join-Path $server 'mods')
    Copy-ModTestDirectoryClean -Source (Join-Path $script:ServerDir 'config') -Destination (Join-Path $server 'config')
    Copy-ModTestDirectoryClean -Source (Join-Path $script:ServerDir 'defaultconfigs') -Destination (Join-Path $server 'defaultconfigs')
    Write-ModManagerJson (Join-Path $root 'backup.json') ([ordered]@{id=$id;utc=[DateTimeOffset]::UtcNow.ToString('o');note='Copia anterior de mods/config. El mundo NORMAL nunca se copia ni sustituye durante la promoción.'}) 10
    return $root
}

function Restore-ModPromotionBackup {
    param([string]$BackupRoot)
    if([string]::IsNullOrWhiteSpace($BackupRoot) -or -not(Test-Path -LiteralPath $BackupRoot)){return}
    Sync-ModTestDirectory -Source (Join-Path $BackupRoot 'client\mods') -Destination (Get-ModManagerClientModsDir)
    if(Test-Path (Join-Path $BackupRoot 'client\config')){Sync-ModTestDirectory -Source (Join-Path $BackupRoot 'client\config') -Destination (Join-Path (Get-ModManagerClientInstancePath) 'config')}
    if(Test-Path (Join-Path $BackupRoot 'client\defaultconfigs')){Sync-ModTestDirectory -Source (Join-Path $BackupRoot 'client\defaultconfigs') -Destination (Join-Path (Get-ModManagerClientInstancePath) 'defaultconfigs')}
    Sync-ModTestDirectory -Source (Join-Path $BackupRoot 'server\mods') -Destination (Get-ModManagerServerModsDir)
    if(Test-Path (Join-Path $BackupRoot 'server\config')){Sync-ModTestDirectory -Source (Join-Path $BackupRoot 'server\config') -Destination (Join-Path $script:ServerDir 'config')}
    if(Test-Path (Join-Path $BackupRoot 'server\defaultconfigs')){Sync-ModTestDirectory -Source (Join-Path $BackupRoot 'server\defaultconfigs') -Destination (Join-Path $script:ServerDir 'defaultconfigs')}
}

function Promote-ModTestToNormal {
    Initialize-ModTestPaths
    $state=Get-ModTestState;if($null-eq$state){throw 'No existe un entorno TEST para promover.'}
    Assert-ModTestNormalLoadersReadyForPromotion
    if($null-ne(Get-ModTestServerRunningInfo)){throw 'Cierra primero el servidor TEST escribiendo stop en su consola.'}
    if([bool]$state.clientActive){Restore-ModTestClientNormal|Out-Null;$state=Get-ModTestState}
    $testServer=[string]$state.testServerPath
    if(-not(Test-Path -LiteralPath $testServer)){throw 'No existe la copia del servidor TEST.'}
    $backup=New-ModPromotionBackup
    try{
        Write-Host 'Aplicando mods/config TEST sobre NORMAL. El mundo REAL NO se sustituye.' -ForegroundColor Yellow
        Sync-ModTestDirectory -Source $script:ModTestClientModsDir -Destination (Get-ModManagerClientModsDir)
        Sync-ModTestDirectory -Source (Join-Path $testServer 'mods') -Destination (Get-ModManagerServerModsDir)
        if(Test-Path $script:ModTestClientConfigDir){Sync-ModTestDirectory -Source $script:ModTestClientConfigDir -Destination (Join-Path (Get-ModManagerClientInstancePath) 'config')}
        if(Test-Path $script:ModTestClientDefaultConfigsDir){Sync-ModTestDirectory -Source $script:ModTestClientDefaultConfigsDir -Destination (Join-Path (Get-ModManagerClientInstancePath) 'defaultconfigs')}
        if(Test-Path (Join-Path $testServer 'config')){Sync-ModTestDirectory -Source (Join-Path $testServer 'config') -Destination (Join-Path $script:ServerDir 'config')}
        if(Test-Path (Join-Path $testServer 'defaultconfigs')){Sync-ModTestDirectory -Source (Join-Path $testServer 'defaultconfigs') -Destination (Join-Path $script:ServerDir 'defaultconfigs')}
        $manifest=Publish-CurrentModSet -Reason 'promote-tested-modpack'
        $state=Get-ModTestState;$state.promoted=$true;$state.promotedUtc=[DateTimeOffset]::UtcNow.ToString('o');$state.latestPromotionBackup=$backup;$state.publishedGeneration=[int64]$manifest.generation;Save-ModTestState $state
        return $state
    }catch{
        Write-Warning 'La promoción falló. Restaurando automáticamente los mods/config anteriores...'
        Restore-ModPromotionBackup -BackupRoot $backup
        throw
    }
}

function Remove-ModTestEnvironment {
    Initialize-ModTestPaths
    $state=Get-ModTestState
    if($null-ne$state -and [bool]$state.clientActive){throw 'El cliente está en modo TEST. Pulsa primero Volver cliente a NORMAL.'}
    if($null-ne(Get-ModTestServerRunningInfo)){throw 'El servidor TEST sigue abierto. Escribe stop antes de borrar la prueba.'}
    $testServer=Get-ModTestServerDir;if($null-ne$state -and -not[string]::IsNullOrWhiteSpace([string]$state.testServerPath)){$testServer=[string]$state.testServerPath}
    Assert-ModTestServerPathSafe -TestServerPath $testServer
    if(Test-Path -LiteralPath $testServer){Remove-Item -LiteralPath $testServer -Recurse -Force}
    if(Test-Path -LiteralPath $script:ModTestRoot){Remove-Item -LiteralPath $script:ModTestRoot -Recurse -Force}
    Initialize-ModTestPaths
}

function Remove-LatestModPromotionBackup {
    Initialize-ModTestPaths
    $state=Get-ModTestState
    if($null-eq$state -or -not($state.PSObject.Properties.Name -contains 'latestPromotionBackup') -or [string]::IsNullOrWhiteSpace([string]$state.latestPromotionBackup)){throw 'No hay una copia anterior registrada para borrar.'}
    $path=[string]$state.latestPromotionBackup
    if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Recurse -Force}
    $state.latestPromotionBackup='';Save-ModTestState $state
}
