﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

# v4.2 - Sincronizacion por DELTAS sobre una base comun local.
# Drive NO contiene el servidor completo. Solo contiene:
#   - bloqueo/estado de control
#   - un indice pequeno de archivos cambiados
#   - la ultima version de los archivos que han cambiado desde la ultima rebase
# Ambos PCs deben partir de la misma descarga completa del hosting.

function Get-DeltaExcludedTopLevelNames {
    return @(
        'logs',
        'crash-reports',
        'backups',
        '.cache',
        '.mixin.out'
    )
}

function Test-DeltaPathExcluded {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    $p = $RelativePath.Replace('\','/').TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($p)) { return $true }
    $first = ($p -split '/', 2)[0]
    foreach ($name in @(Get-DeltaExcludedTopLevelNames)) {
        if ($first -ieq $name) { return $true }
    }
    if ($p -ieq 'world/session.lock') { return $true }
    $leaf = [IO.Path]::GetFileName($p)
    if ($leaf -like 'hs_err_pid*.log') { return $true }
    if ($leaf -ieq 'debug.log') { return $true }
    return $false
}

function Get-NormalizedServerRoot {
    if ([string]::IsNullOrWhiteSpace([string]$script:ServerDir)) { throw "No hay carpeta de servidor configurada." }
    $full = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables([string]$script:ServerDir))
    return $full.TrimEnd([char[]]@([char]'\',[char]'/'))
}

function Get-RelativeServerPath {
    param([Parameter(Mandatory=$true)][string]$FullName)
    $root = Get-NormalizedServerRoot
    $full = [IO.Path]::GetFullPath($FullName)
    if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Ruta fuera del servidor: $full"
    }
    $rel = $full.Substring($root.Length).TrimStart([char[]]@([char]'\',[char]'/'))
    return $rel.Replace('\','/')
}


# v4.9.9 PERFORMANCE: cache persistente del manifiesto local. Permite reutilizar la
# fotografia validada de la ultima generacion y evitar recorrer miles de archivos en
# cada arranque. Si la generacion/base no coincide, se ignora automaticamente.
function Save-PersistentManifestCache {
    param(
        [Parameter(Mandatory=$true)]$Manifest,
        [Parameter(Mandatory=$true)][int64]$Generation,
        [Parameter(Mandatory=$true)][string]$BaselineId
    )
    if (-not [bool]$script:Config.PersistentManifestCache) { return }
    try {
        $obj = [ordered]@{
            format = 'cobbleverse-manifest-cache-v1'
            generation = [int64]$Generation
            baselineId = [string]$BaselineId
            savedUtc = [DateTimeOffset]::UtcNow.ToString('o')
            count = [int64]$Manifest.Count
            bytes = [int64]$Manifest.Bytes
            records = @($Manifest.Records)
        }
        Write-LocalJsonAtomic -Path $script:PersistentManifestCachePath -Object $obj
    }
    catch {
        Write-Host ("AVISO: no se pudo guardar la cache persistente de metadatos: {0}" -f $_.Exception.Message) -ForegroundColor DarkYellow
    }
}

function Load-PersistentManifestCache {
    param([int64]$ExpectedGeneration,[string]$ExpectedBaselineId)
    if (-not [bool]$script:Config.PersistentManifestCache) { return $null }
    if (-not (Test-Path -LiteralPath $script:PersistentManifestCachePath -PathType Leaf)) { return $null }
    try {
        $obj = [IO.File]::ReadAllText($script:PersistentManifestCachePath) | ConvertFrom-Json
        if ([string]$obj.format -ne 'cobbleverse-manifest-cache-v1') { return $null }
        if ([int64]$obj.generation -ne [int64]$ExpectedGeneration) { return $null }
        if ([string]$obj.baselineId -ne [string]$ExpectedBaselineId) { return $null }
        $records = New-Object 'System.Collections.Generic.List[object]'
        $map = @{}
        [int64]$bytes = 0
        foreach ($item in @($obj.records)) {
            if ($null -eq $item) { continue }
            $rec = [pscustomobject]@{p=[string]$item.p;s=[int64]$item.s;t=[int64]$item.t}
            $records.Add($rec)
            $map[[string]$rec.p] = $rec
            $bytes += [int64]$rec.s
        }
        return [pscustomobject]@{Records=$records.ToArray();Map=$map;Count=[int64]$records.Count;Bytes=$bytes}
    }
    catch {
        try { Remove-Item -LiteralPath $script:PersistentManifestCachePath -Force -ErrorAction SilentlyContinue } catch { }
        return $null
    }
}

function Update-PersistentManifestCacheAfterRemoteApply {
    param(
        [Parameter(Mandatory=$true)]$OldManifest,
        [Parameter(Mandatory=$true)][AllowEmptyCollection()][string[]]$ChangedPaths,
        [Parameter(Mandatory=$true)][AllowEmptyCollection()][string[]]$DeletedPaths,
        [Parameter(Mandatory=$true)][int64]$Generation,
        [Parameter(Mandatory=$true)][string]$BaselineId
    )
    try {
        $all = @($ChangedPaths) + @($DeletedPaths)
        if ($all.Count -gt 0) { $updated = Get-FastManifestDataFromCandidates -BeforeManifest $OldManifest -CandidatePaths ([string[]]$all) }
        else { $updated = $OldManifest }
        Save-PersistentManifestCache -Manifest $updated -Generation $Generation -BaselineId $BaselineId
        return $updated
    }
    catch {
        try { Remove-Item -LiteralPath $script:PersistentManifestCachePath -Force -ErrorAction SilentlyContinue } catch { }
        return $null
    }
}

# current.json y baseline.json viven en la misma carpeta remota. Los descargamos en una
# sola ejecucion de rclone para reducir procesos y round-trips contra Google Drive.
function Get-RemoteDeltaSnapshot {
    $tmpDir = Join-Path $script:DataDir ('control-snapshot-' + [guid]::NewGuid().ToString('N'))
    $list = Join-Path $script:DataDir ('control-snapshot-' + [guid]::NewGuid().ToString('N') + '.txt')
    New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
    try {
        Write-Utf8NoBomLines -Path $list -Lines ([string[]]@('current.json','baseline.json'))
        Invoke-Rclone -Arguments @('copy',$script:RemoteDeltaControl,$tmpDir,'--config',$script:RcloneConfig,'--files-from-raw',$list,'--no-traverse','--transfers','2','--checkers','2') | Out-Null
        $currentPath = Join-Path $tmpDir 'current.json'
        $baselinePath = Join-Path $tmpDir 'baseline.json'
        $current = $null
        $baseline = $null
        if (Test-Path -LiteralPath $currentPath) { $current = [IO.File]::ReadAllText($currentPath) | ConvertFrom-Json }
        if (Test-Path -LiteralPath $baselinePath) { $baseline = [IO.File]::ReadAllText($baselinePath) | ConvertFrom-Json }
        return [pscustomobject]@{Current=$current;Baseline=$baseline}
    }
    finally {
        Remove-Item -LiteralPath $list -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Get-FastManifestData {
    param([string]$Root = $script:ServerDir)
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) { throw "No existe la carpeta del servidor: $Root" }
    $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd([char[]]@([char]'\',[char]'/'))
    $records = New-Object 'System.Collections.Generic.List[object]'
    $map = @{}
    [int64]$bytes = 0

    # v4.8: recorrido podado. No entramos siquiera en logs/backups/cache en vez de
    # recorrerlos para descartarlos archivo por archivo.
    $excludedTop = @{}
    foreach ($name in @(Get-DeltaExcludedTopLevelNames)) { $excludedTop[[string]$name.ToLowerInvariant()] = $true }
    $stack = New-Object 'System.Collections.Generic.Stack[System.IO.DirectoryInfo]'
    $stack.Push((New-Object IO.DirectoryInfo($rootFull)))

    while ($stack.Count -gt 0) {
        $dir = $stack.Pop()
        try {
            foreach ($sub in $dir.EnumerateDirectories()) {
                if (($sub.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                if ($dir.FullName -ieq $rootFull -and $excludedTop.ContainsKey($sub.Name.ToLowerInvariant())) { continue }
                $stack.Push($sub)
            }
            foreach ($fi in $dir.EnumerateFiles()) {
                $rel = $fi.FullName.Substring($rootFull.Length).TrimStart([char[]]@([char]'\',[char]'/')).Replace('\','/')
                if (Test-DeltaPathExcluded -RelativePath $rel) { continue }
                $rec = [pscustomobject]@{
                    p = $rel
                    s = [int64]$fi.Length
                    t = [int64]$fi.LastWriteTimeUtc.Ticks
                }
                $records.Add($rec)
                $map[$rel] = $rec
                $bytes += [int64]$fi.Length
            }
        }
        catch {
            throw "No se pudieron leer metadatos en '$($dir.FullName)': $($_.Exception.Message)"
        }
    }

    return [pscustomobject]@{
        Records = $records.ToArray()
        Map = $map
        Count = [int64]$records.Count
        Bytes = $bytes
    }
}

function Save-FastManifestData {
    param(
        [Parameter(Mandatory=$true)]$Manifest,
        [Parameter(Mandatory=$true)][string]$Path
    )
    $parent = Split-Path -Parent $Path
    if (-not [string]::IsNullOrWhiteSpace($parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    $json = ConvertTo-Json -InputObject @($Manifest.Records) -Depth 4 -Compress
    [IO.File]::WriteAllText($Path, $json, (New-Object Text.UTF8Encoding($false)))
}

function Load-FastManifestData {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { throw "No existe el manifiesto local: $Path" }
    $raw = [IO.File]::ReadAllText($Path)
    if ([string]::IsNullOrWhiteSpace($raw)) { $items = @() }
    else { $items = @($raw | ConvertFrom-Json) }
    $records = New-Object 'System.Collections.Generic.List[object]'
    $map = @{}
    [int64]$bytes = 0
    foreach ($item in $items) {
        if ($null -eq $item) { continue }
        $rec = [pscustomobject]@{ p=[string]$item.p; s=[int64]$item.s; t=[int64]$item.t }
        $records.Add($rec)
        $map[[string]$rec.p] = $rec
        $bytes += [int64]$rec.s
    }
    return [pscustomobject]@{ Records=$records.ToArray(); Map=$map; Count=[int64]$records.Count; Bytes=$bytes }
}

function Get-FastManifestDataFromCandidates {
    param(
        [Parameter(Mandatory=$true)]$BeforeManifest,
        [Parameter(Mandatory=$true)][AllowEmptyCollection()][string[]]$CandidatePaths,
        [string]$Root = $script:ServerDir
    )
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) { throw "No existe la carpeta del servidor: $Root" }
    $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd([char[]]@([char]'\',[char]'/'))
    $map = @{}
    [int64]$bytes = [int64]$BeforeManifest.Bytes

    # Copiar el manifiesto inicial SOLO en memoria. No toca disco para los ~8800 archivos.
    foreach ($entry in $BeforeManifest.Map.GetEnumerator()) { $map[[string]$entry.Key] = $entry.Value }

    $unique = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($raw in @($CandidatePaths)) {
        $p = ([string]$raw).Replace('\','/').TrimStart('/')
        if ([string]::IsNullOrWhiteSpace($p) -or (Test-DeltaPathExcluded -RelativePath $p)) { continue }
        $null = $unique.Add($p)
    }

    foreach ($p in $unique) {
        $oldSize = [int64]0
        if ($map.ContainsKey($p)) { $oldSize = [int64]$map[$p].s }
        $full = Join-Path $rootFull ($p.Replace('/','\'))
        if (Test-Path -LiteralPath $full -PathType Leaf) {
            $fi = New-Object IO.FileInfo($full)
            $rec = [pscustomobject]@{ p=$p; s=[int64]$fi.Length; t=[int64]$fi.LastWriteTimeUtc.Ticks }
            if ($map.ContainsKey($p)) { $bytes -= $oldSize }
            $bytes += [int64]$rec.s
            $map[$p] = $rec
        }
        else {
            if ($map.ContainsKey($p)) {
                $bytes -= $oldSize
                $null = $map.Remove($p)
            }
        }
    }

    $records = @($map.GetEnumerator() | ForEach-Object { $_.Value })
    return [pscustomobject]@{
        Records = $records
        Map = $map
        Count = [int64]$map.Count
        Bytes = $bytes
        CandidateCount = [int64]$unique.Count
    }
}

function Get-FastManifestDataHybridFinal {
    param(
        [Parameter(Mandatory=$true)]$BeforeManifest,
        [Parameter(Mandatory=$true)][AllowEmptyCollection()][string[]]$CandidatePaths,
        [Parameter(Mandatory=$true)][AllowEmptyCollection()][string[]]$DirectoryPaths,
        [string]$Root = $script:ServerDir
    )
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) { throw "No existe la carpeta del servidor: $Root" }

    # 1) Aplicar primero los candidatos acumulados por FileSystemWatcher/barrido suave.
    $result = Get-FastManifestDataFromCandidates -BeforeManifest $BeforeManifest -CandidatePaths $CandidatePaths -Root $Root
    $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd([char[]]@([char]'\',[char]'/'))
    $map = @{}
    foreach ($entry in $result.Map.GetEnumerator()) { $map[[string]$entry.Key] = $entry.Value }
    [int64]$bytes = [int64]$result.Bytes

    # 2) Completar SOLO las carpetas que no llegaron a revisarse en el ciclo suave actual.
    # Esto consulta archivos directos de esas carpetas (nombre/tamano/fecha), no su contenido.
    $targetDirs = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($rawDir in @($DirectoryPaths)) {
        $d = ([string]$rawDir).Replace('\','/').Trim('/')
        if ($d -eq '.') { $d = '' }
        if ($d -eq '..' -or $d.StartsWith('../') -or $d.Contains('/../')) { throw "Carpeta de validacion no valida: $rawDir" }
        $null = $targetDirs.Add($d)
    }

    # Seguridad extra v4.9.1: si un archivo fue candidato, revisar tambien todos los
    # archivos hermanos de su carpeta. Asi, si Windows hubiera omitido un segundo evento
    # dentro de esa misma carpeta, la validacion final todavia lo detectaria.
    foreach ($rawCandidate in @($CandidatePaths)) {
        $p = ([string]$rawCandidate).Replace('\','/').TrimStart('/')
        if ([string]::IsNullOrWhiteSpace($p) -or (Test-DeltaPathExcluded -RelativePath $p)) { continue }
        $slash = $p.LastIndexOf('/')
        $candidateDir = ''
        if ($slash -ge 0) { $candidateDir = $p.Substring(0,$slash) }
        $null = $targetDirs.Add($candidateDir)
    }

    if ($targetDirs.Count -gt 0) {
        # Agrupar en memoria las rutas que el manifiesto espera en cada carpeta objetivo.
        # Recorrer ~8800 entradas en RAM es muy barato y evita tocar el resto del disco.
        $expectedByDir = @{}
        foreach ($d in $targetDirs) { $expectedByDir[$d] = New-Object 'System.Collections.Generic.List[string]' }
        foreach ($entry in $map.GetEnumerator()) {
            $p = [string]$entry.Key
            $slash = $p.LastIndexOf('/')
            $dirRel = ''
            if ($slash -ge 0) { $dirRel = $p.Substring(0,$slash) }
            if ($targetDirs.Contains($dirRel)) { $expectedByDir[$dirRel].Add($p) }
        }

        foreach ($dirRel in $targetDirs) {
            $dirFull = $rootFull
            if (-not [string]::IsNullOrWhiteSpace($dirRel)) { $dirFull = Join-Path $rootFull ($dirRel.Replace('/','\')) }
            $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)

            if (Test-Path -LiteralPath $dirFull -PathType Container) {
                try {
                    $di = New-Object IO.DirectoryInfo($dirFull)
                    foreach ($fi in $di.EnumerateFiles()) {
                        $rel = $fi.FullName.Substring($rootFull.Length).TrimStart([char[]]@([char]'\',[char]'/')).Replace('\','/')
                        if (Test-DeltaPathExcluded -RelativePath $rel) { continue }
                        $null = $seen.Add($rel)
                        $oldSize = [int64]0
                        if ($map.ContainsKey($rel)) { $oldSize = [int64]$map[$rel].s; $bytes -= $oldSize }
                        $rec = [pscustomobject]@{ p=$rel; s=[int64]$fi.Length; t=[int64]$fi.LastWriteTimeUtc.Ticks }
                        $map[$rel] = $rec
                        $bytes += [int64]$rec.s
                    }
                }
                catch { throw "No se pudieron validar metadatos en '$dirFull': $($_.Exception.Message)" }
            }

            # Lo que existia en esta carpeta al inicio y ya no se ve ahora se considera borrado.
            foreach ($oldPath in @($expectedByDir[$dirRel])) {
                if (-not $seen.Contains([string]$oldPath) -and $map.ContainsKey([string]$oldPath)) {
                    $bytes -= [int64]$map[[string]$oldPath].s
                    $null = $map.Remove([string]$oldPath)
                }
            }
        }
    }

    $records = @($map.GetEnumerator() | ForEach-Object { $_.Value })
    return [pscustomobject]@{
        Records = $records
        Map = $map
        Count = [int64]$map.Count
        Bytes = $bytes
        CandidateCount = [int64]$result.CandidateCount
        FinalDirectoriesScanned = [int64]$targetDirs.Count
    }
}

function Compare-FastManifestData {
    param(
        [Parameter(Mandatory=$true)]$Before,
        [Parameter(Mandatory=$true)]$After
    )
    $changed = New-Object 'System.Collections.Generic.List[string]'
    $deleted = New-Object 'System.Collections.Generic.List[string]'
    [int64]$changedBytes = 0

    foreach ($entry in $After.Map.GetEnumerator()) {
        $path = [string]$entry.Key
        $now = $entry.Value
        if (-not $Before.Map.ContainsKey($path)) {
            $changed.Add($path)
            $changedBytes += [int64]$now.s
            continue
        }
        $old = $Before.Map[$path]
        if ([int64]$old.s -ne [int64]$now.s -or [int64]$old.t -ne [int64]$now.t) {
            $changed.Add($path)
            $changedBytes += [int64]$now.s
        }
    }

    foreach ($entry in $Before.Map.GetEnumerator()) {
        $path = [string]$entry.Key
        if (-not $After.Map.ContainsKey($path)) { $deleted.Add($path) }
    }

    return [pscustomobject]@{
        Changed = @($changed.ToArray() | Sort-Object)
        Deleted = @($deleted.ToArray() | Sort-Object)
        ChangedBytes = $changedBytes
    }
}

function Get-FastBaselineFingerprint {
    param([string]$Root = $script:ServerDir)
    $manifest = Get-FastManifestData -Root $Root
    $sb = New-Object Text.StringBuilder
    foreach ($rec in @($manifest.Records | Sort-Object p)) {
        $null = $sb.Append([string]$rec.p)
        $null = $sb.Append('|')
        $null = $sb.Append([string][int64]$rec.s)
        $null = $sb.Append("`n")
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $data = [Text.Encoding]::UTF8.GetBytes($sb.ToString())
        $hash = $sha.ComputeHash($data)
        $hex = -join ($hash | ForEach-Object { $_.ToString('x2') })
    }
    finally { $sha.Dispose() }
    return [pscustomobject]@{ fingerprint=$hex; files=$manifest.Count; bytes=$manifest.Bytes; manifest=$manifest }
}

function Get-FastBaselineFingerprintFromManifest {
    param([Parameter(Mandatory=$true)]$Manifest)
    $sb = New-Object Text.StringBuilder
    foreach ($rec in @($Manifest.Records | Sort-Object p)) {
        $null = $sb.Append([string]$rec.p)
        $null = $sb.Append('|')
        $null = $sb.Append([string][int64]$rec.s)
        $null = $sb.Append("`n")
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $data = [Text.Encoding]::UTF8.GetBytes($sb.ToString())
        $hash = $sha.ComputeHash($data)
        $hex = -join ($hash | ForEach-Object { $_.ToString('x2') })
    }
    finally { $sha.Dispose() }
    return [pscustomobject]@{ fingerprint=$hex; files=[int64]$Manifest.Count; bytes=[int64]$Manifest.Bytes; manifest=$Manifest }
}

function Write-Utf8NoBomLines {
    param([Parameter(Mandatory=$true)][string]$Path,[string[]]$Lines=@())
    $parent = Split-Path -Parent $Path
    if (-not [string]::IsNullOrWhiteSpace($parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    [IO.File]::WriteAllLines($Path, [string[]]$Lines, (New-Object Text.UTF8Encoding($false)))
}

function Get-RemoteJsonObject {
    param([Parameter(Mandatory=$true)][string]$RemotePath)
    $raw = Invoke-RcloneCapture -Arguments @('cat', $RemotePath, '--config', $script:RcloneConfig) -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) { return $null }
    try { return ($raw | ConvertFrom-Json) } catch { return $null }
}

function Set-RemoteJsonObject {
    param(
        [Parameter(Mandatory=$true)][string]$RemotePath,
        [Parameter(Mandatory=$true)]$Object,
        [string]$TempPrefix='delta-json'
    )
    $tmp = Join-Path $script:DataDir ("{0}-{1}.json" -f $TempPrefix, [guid]::NewGuid().ToString('N'))
    $json = ConvertTo-Json -InputObject $Object -Depth 8 -Compress
    [IO.File]::WriteAllText($tmp, $json, (New-Object Text.UTF8Encoding($false)))
    try { Invoke-Rclone -Arguments @('copyto', $tmp, $RemotePath, '--config', $script:RcloneConfig, '--no-traverse') | Out-Null }
    finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
}

function Get-OrCreateClientId {
    if (Test-Path $script:ClientIdPath) {
        $id = ([IO.File]::ReadAllText($script:ClientIdPath)).Trim()
        if ($id -match '^[a-fA-F0-9]{32}$') { return $id }
    }
    $id = [guid]::NewGuid().ToString('N')
    [IO.File]::WriteAllText($script:ClientIdPath, $id, (New-Object Text.UTF8Encoding($false)))
    return $id
}

function Get-LocalDeltaState {
    if (-not (Test-Path $script:LocalGenerationPath)) { return $null }
    try { return ([IO.File]::ReadAllText($script:LocalGenerationPath) | ConvertFrom-Json) } catch { return $null }
}

function Set-LocalDeltaState {
    param([Parameter(Mandatory=$true)][int64]$Generation,[Parameter(Mandatory=$true)][string]$BaselineId)
    $obj = [ordered]@{
        protocol = 'delta-overlay-v1'
        generation = $Generation
        baselineId = $BaselineId
        host = $env:COMPUTERNAME
        updatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
    }
    $json = ConvertTo-Json -InputObject $obj -Depth 4 -Compress
    [IO.File]::WriteAllText($script:LocalGenerationPath, $json, (New-Object Text.UTF8Encoding($false)))
}

function Get-RemoteDeltaCurrent { return (Get-RemoteJsonObject -RemotePath $script:RemoteDeltaCurrent) }
function Get-RemoteDeltaBaseline { return (Get-RemoteJsonObject -RemotePath $script:RemoteDeltaBaseline) }

function Get-RemoteDeltaIndexMap {
    $obj = Get-RemoteJsonObject -RemotePath $script:RemoteDeltaIndex
    $map = @{}
    if ($null -eq $obj) { return $map }
    $records = @($obj)
    if ($obj.PSObject.Properties.Name -contains 'entries') { $records = @($obj.entries) }
    foreach ($rec in $records) {
        if ($null -eq $rec) { continue }
        $p = [string]$rec.p
        if ([string]::IsNullOrWhiteSpace($p)) { continue }
        [int64]$recordSize = 0
        if ($rec.PSObject.Properties.Name -contains 's') { $recordSize = [int64]$rec.s }
        $map[$p] = [pscustomobject]@{
            p = $p
            g = [int64]$rec.g
            d = [bool]$rec.d
            s = $recordSize
        }
    }
    return $map
}

function Set-RemoteDeltaIndexMap {
    param([Parameter(Mandatory=$true)][hashtable]$Map)
    $items = @($Map.GetEnumerator() | ForEach-Object { $_.Value } | Sort-Object p)
    $wrapper = [ordered]@{ entries = $items }
    Set-RemoteJsonObject -RemotePath $script:RemoteDeltaIndex -Object $wrapper -TempPrefix 'delta-index'
}

function Publish-DeltaClientState {
    param([Parameter(Mandatory=$true)][int64]$Generation,[string]$Status='ready')
    $id = Get-OrCreateClientId
    $obj = [ordered]@{
        clientId = $id
        host = $env:COMPUTERNAME
        user = $env:USERNAME
        generation = $Generation
        status = $Status
        updatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
    }
    Invoke-Rclone -Arguments @('mkdir', $script:RemoteDeltaClients, '--config', $script:RcloneConfig) | Out-Null
    Set-RemoteJsonObject -RemotePath ("$script:RemoteDeltaClients/$id.json") -Object $obj -TempPrefix 'delta-client'
}

function Get-RemoteDeltaClients {
    $raw = Invoke-RcloneCapture -Arguments @('lsf', $script:RemoteDeltaClients, '--files-only', '--config', $script:RcloneConfig) -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) { return @() }
    $results = New-Object 'System.Collections.Generic.List[object]'
    foreach ($name in @($raw -split '\r?\n')) {
        $n = ([string]$name).Trim()
        if ([string]::IsNullOrWhiteSpace($n) -or -not $n.EndsWith('.json')) { continue }
        $obj = Get-RemoteJsonObject -RemotePath ("$script:RemoteDeltaClients/$n")
        if ($null -ne $obj) { $results.Add($obj) }
    }
    return $results.ToArray()
}

function Initialize-DeltaRemoteFolders {
    Invoke-Rclone -Arguments @('mkdir', $script:RemoteDeltaControl, '--config', $script:RcloneConfig) | Out-Null
    Invoke-Rclone -Arguments @('mkdir', $script:RemoteDeltaFiles, '--config', $script:RcloneConfig) | Out-Null
    Invoke-Rclone -Arguments @('mkdir', $script:RemoteDeltaClients, '--config', $script:RcloneConfig) | Out-Null
    Invoke-Rclone -Arguments @('mkdir', (Get-RemoteDeltaBundlesPath), '--config', $script:RcloneConfig) | Out-Null
    Invoke-Rclone -Arguments @('mkdir', (Get-RemoteDeltaGenerationsPath), '--config', $script:RcloneConfig) | Out-Null
}

function Reset-DeltaProtocolFromLocalBase {
    param([switch]$ForceReset)
    $existing = Get-RemoteDeltaCurrent
    if ($null -ne $existing -and -not $ForceReset) {
        throw "Ya existe una sincronizacion delta v4.2 en Drive. No se reinicia automaticamente para no perder cambios."
    }
    if ($null -ne $existing -or $ForceReset) {
        Invoke-Rclone -Arguments @('purge', $script:RemoteDeltaRoot, '--config', $script:RcloneConfig, '--drive-use-trash=false') -IgnoreExitCode | Out-Null
    }
    Initialize-DeltaRemoteFolders

    Write-Host "Creando huella RAPIDA de la base local (ruta + tamano; no lee los 10 GB de contenido)..." -ForegroundColor Cyan
    $base = Get-FastBaselineFingerprint
    $baselineId = [guid]::NewGuid().ToString('N')
    $baseline = [ordered]@{
        protocol = 'delta-overlay-v1'
        transferMode = 'bundle-v2'
        baselineId = $baselineId
        baselineGeneration = [int64]0
        fingerprint = [string]$base.fingerprint
        files = [int64]$base.files
        bytes = [int64]$base.bytes
        createdUtc = [DateTimeOffset]::UtcNow.ToString('o')
        createdBy = $env:COMPUTERNAME
    }
    $current = [ordered]@{
        protocol = 'delta-overlay-v1'
        transferMode = 'bundle-v2'
        baselineId = $baselineId
        generation = [int64]0
        baselineGeneration = [int64]0
        updatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
        host = $env:COMPUTERNAME
        changedFiles = [int64]0
        deletedFiles = [int64]0
        transferredBytes = [int64]0
    }
    Set-RemoteJsonObject -RemotePath $script:RemoteDeltaBaseline -Object $baseline -TempPrefix 'baseline'
    Set-RemoteDeltaIndexMap -Map @{}
    Set-RemoteJsonObject -RemotePath $script:RemoteDeltaCurrent -Object $current -TempPrefix 'current'
    Set-LocalDeltaState -Generation 0 -BaselineId $baselineId
    Publish-DeltaClientState -Generation 0 -Status 'base-ready'
    return [pscustomobject]@{ baseline=$baseline; manifest=$base.manifest }
}

function Assert-LocalBaseMatchesRemoteDelta {
    $baseline = Get-RemoteDeltaBaseline
    if ($null -eq $baseline) { throw "No existe la base v4.2 en Drive. Configura primero el PC principal con 01_IMPORTAR_DESDE_HOSTING.bat." }
    if ([int64]$baseline.baselineGeneration -ne 0) {
        throw "La base remota ya fue rebasada en la generacion $($baseline.baselineGeneration). Este PC no puede vincularse desde la descarga ORIGINAL del hosting. Usa una copia actual de uno de los PCs ya vinculados."
    }
    Write-Host "Comprobando huella rapida de esta copia local..." -ForegroundColor Cyan
    $local = Get-FastBaselineFingerprint
    if ([string]$local.fingerprint -ne [string]$baseline.fingerprint -or [int64]$local.files -ne [int64]$baseline.files -or [int64]$local.bytes -ne [int64]$baseline.bytes) {
        throw ("La copia local NO coincide con la base del PC principal. Local: {0} archivos / {1}. Base: {2} archivos / {3}. Usa exactamente la misma descarga del hosting." -f $local.files,(Format-ByteSize $local.bytes),$baseline.files,(Format-ByteSize ([int64]$baseline.bytes)))
    }
    return [pscustomobject]@{ baseline=$baseline; manifest=$local.manifest }
}

function Set-ConfiguredServerPath {
    param([Parameter(Mandatory=$true)][string]$Path)
    $expanded = [Environment]::ExpandEnvironmentVariables($Path.Trim('"'))
    if (-not (Test-Path -LiteralPath $expanded -PathType Container)) { throw "No existe la carpeta: $expanded" }
    $full = [IO.Path]::GetFullPath($expanded).TrimEnd([char[]]@([char]'\',[char]'/'))
    $script:Config.ServerPath = $full
    Save-CobbleverseConfig
    Load-CobbleverseConfig
    return $full
}


# v4.8: transporte rapido. En vez de subir decenas/cientos de archivos a Google Drive
# uno por uno, cada generacion se empaqueta en UN solo ZIP sin compresion. Minecraft ya
# comprime muchos de sus formatos; el objetivo aqui es reducir llamadas/API y latencia.
function Get-RemoteDeltaBundlesPath { return "$script:RemoteDeltaRoot/bundles" }
function Get-RemoteDeltaGenerationsPath { return "$script:RemoteDeltaRoot/generations" }

function Get-DeltaTransferMode {
    param($Baseline=$null,$Current=$null)
    if ($null -ne $Current -and $Current.PSObject.Properties.Name -contains 'transferMode') {
        $m = [string]$Current.transferMode
        if (-not [string]::IsNullOrWhiteSpace($m)) { return $m }
    }
    if ($null -ne $Baseline -and $Baseline.PSObject.Properties.Name -contains 'transferMode') {
        $m = [string]$Baseline.transferMode
        if (-not [string]::IsNullOrWhiteSpace($m)) { return $m }
    }
    return 'overlay-v1'
}

function Get-DeltaGenerationToken {
    param([Parameter(Mandatory=$true)][int64]$Generation)
    return ('g{0:D12}' -f $Generation)
}

function Get-RemoteGenerationMetaPath {
    param([Parameter(Mandatory=$true)][int64]$Generation)
    return ((Get-RemoteDeltaGenerationsPath) + '/' + (Get-DeltaGenerationToken -Generation $Generation) + '.json')
}

function Get-RemoteGenerationBundlePath {
    param([Parameter(Mandatory=$true)][int64]$Generation)
    return ((Get-RemoteDeltaBundlesPath) + '/' + (Get-DeltaGenerationToken -Generation $Generation) + '.zip')
}

function Get-BundleCompressionLevel {
    $mode = 'fast'
    try { $mode = ([string]$script:Config.BundleCompression).Trim().ToLowerInvariant() } catch { }
    switch ($mode) {
        'none'    { return [IO.Compression.CompressionLevel]::NoCompression }
        'optimal' { return [IO.Compression.CompressionLevel]::Optimal }
        default   { return [IO.Compression.CompressionLevel]::Fastest }
    }
}

function Get-DriveChunkSizeArgument {
    $mb = 64
    try { $mb = [int]$script:Config.DriveChunkSizeMB } catch { $mb = 64 }
    if ($mb -lt 8) { $mb = 8 }
    if ($mb -gt 256) { $mb = 256 }
    return ('{0}M' -f $mb)
}

function New-DeltaBundleZip {
    param(
        [Parameter(Mandatory=$true)][string[]]$RelativePaths,
        [Parameter(Mandatory=$true)][string]$ZipPath
    )
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue
    $root = Get-NormalizedServerRoot
    $compressionLevel = Get-BundleCompressionLevel
    $fs = [IO.File]::Open($ZipPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $zip = $null
    try {
        $zip = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create, $false)
        foreach ($relRaw in @($RelativePaths)) {
            $rel = ([string]$relRaw).Replace('\','/').TrimStart('/')
            if ([string]::IsNullOrWhiteSpace($rel) -or [IO.Path]::IsPathRooted($rel) -or $rel -match '(^|/)\.\.(/|$)') {
                throw "Ruta insegura al crear bundle: $rel"
            }
            $src = Join-Path $root ($rel.Replace('/','\'))
            if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { throw "Falta archivo cambiado al crear bundle: $rel" }
            $entry = $zip.CreateEntry($rel, $compressionLevel)
            $fi = New-Object IO.FileInfo($src)
            try { $entry.LastWriteTime = New-Object DateTimeOffset($fi.LastWriteTime) } catch { }
            $input = [IO.File]::Open($src, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
            $output = $entry.Open()
            try { $input.CopyTo($output, 1048576) }
            finally { $output.Dispose(); $input.Dispose() }
        }
    }
    finally {
        if ($null -ne $zip) { $zip.Dispose() }
        $fs.Dispose()
    }
    return (New-Object IO.FileInfo($ZipPath))
}

function Expand-DeltaBundleZip {
    param(
        [Parameter(Mandatory=$true)][string]$ZipPath,
        [string]$DestinationRoot = $script:ServerDir
    )
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $root = [IO.Path]::GetFullPath($DestinationRoot).TrimEnd([char[]]@([char]'\',[char]'/'))
    $rootPrefix = $root + [IO.Path]::DirectorySeparatorChar
    $fs = [IO.File]::OpenRead($ZipPath)
    $zip = $null
    try {
        $zip = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Read, $false)
        foreach ($entry in $zip.Entries) {
            $rel = ([string]$entry.FullName).Replace('\','/').TrimStart('/')
            if ([string]::IsNullOrWhiteSpace($rel)) { continue }
            if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|/)\.\.(/|$)') { throw "Ruta insegura dentro del bundle: $rel" }
            $dest = [IO.Path]::GetFullPath((Join-Path $root ($rel.Replace('/','\'))))
            if (-not $dest.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Ruta fuera del servidor dentro del bundle: $rel" }
            if ([string]::IsNullOrEmpty($entry.Name)) {
                New-Item -ItemType Directory -Force -Path $dest | Out-Null
                continue
            }
            $parent = Split-Path -Parent $dest
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
            # v4.9.6: nunca se escribe directamente sobre el archivo definitivo.
            # Primero se completa un temporal en la MISMA carpeta y luego se sustituye.
            # Si Windows/PC se apaga durante la descarga/extraccion, el archivo bueno anterior
            # permanece intacto y esta generacion se volvera a aplicar en el siguiente intento.
            $tmpDest = Join-Path $parent (([IO.Path]::GetFileName($dest)) + '.cobbleverse-new-' + [guid]::NewGuid().ToString('N'))
            $input = $entry.Open()
            $output = [IO.File]::Open($tmpDest, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
            try {
                $input.CopyTo($output, 1048576)
                $output.Flush($true)
            }
            finally { $output.Dispose(); $input.Dispose() }
            try { [IO.File]::SetLastWriteTime($tmpDest, $entry.LastWriteTime.LocalDateTime) } catch { }
            try {
                if (Test-Path -LiteralPath $dest -PathType Leaf) {
                    try { [IO.File]::Replace($tmpDest, $dest, $null, $true) }
                    catch { Move-Item -LiteralPath $tmpDest -Destination $dest -Force }
                }
                else { [IO.File]::Move($tmpDest, $dest) }
            }
            finally { Remove-Item -LiteralPath $tmpDest -Force -ErrorAction SilentlyContinue }
        }
    }
    finally {
        if ($null -ne $zip) { $zip.Dispose() }
        $fs.Dispose()
    }
}


function Get-RemoteCheckpointRoot { return "$script:RemoteDeltaRoot/checkpoints" }
function Get-RemoteCheckpointMetaPath {
    param([int64]$FromGeneration,[int64]$ToGeneration)
    return ((Get-RemoteCheckpointRoot) + ('/cp-{0:D12}-to-{1:D12}.json' -f $FromGeneration,$ToGeneration))
}
function Get-RemoteCheckpointZipPath {
    param([int64]$FromGeneration,[int64]$ToGeneration)
    return ((Get-RemoteCheckpointRoot) + ('/cp-{0:D12}-to-{1:D12}.zip' -f $FromGeneration,$ToGeneration))
}

function Try-ApplyCatchupCheckpoint {
    param([int64]$LocalGeneration,[int64]$RemoteGeneration,$Baseline)
    if ($RemoteGeneration -le $LocalGeneration) { return $false }
    $metaPath=Get-RemoteCheckpointMetaPath -FromGeneration $LocalGeneration -ToGeneration $RemoteGeneration
    $meta=Get-RemoteJsonObject -RemotePath $metaPath
    if ($null -eq $meta) { return $false }
    if ([string]$meta.baselineId -ne [string]$Baseline.baselineId) { return $false }
    if ([int64]$meta.fromGeneration -ne $LocalGeneration -or [int64]$meta.toGeneration -ne $RemoteGeneration) { return $false }
    Write-Host ("Checkpoint catch-up disponible: G{0} -> G{1}. Descargando un único paquete acumulado..." -f $LocalGeneration,$RemoteGeneration) -ForegroundColor Cyan
    $tmpZip=Join-Path $script:DataDir ('checkpoint-download-' + [guid]::NewGuid().ToString('N') + '.zip')
    try {
        Invoke-Rclone -Arguments @('copyto',(Get-RemoteCheckpointZipPath -FromGeneration $LocalGeneration -ToGeneration $RemoteGeneration),$tmpZip,'--config',$script:RcloneConfig,'--no-traverse','--stats','2s','--stats-one-line') | Out-Null
        Expand-DeltaBundleZip -ZipPath $tmpZip -DestinationRoot $script:ServerDir
        $root=Get-NormalizedServerRoot
        foreach($relRaw in @($meta.deleted)) {
            $rel=([string]$relRaw).Replace('\\','/').TrimStart('/')
            if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|/)\.\.(/|$)') { throw "Ruta insegura en checkpoint: $rel" }
            $lp=[IO.Path]::GetFullPath((Join-Path $root ($rel.Replace('/','\\'))))
            if (Test-Path -LiteralPath $lp -PathType Leaf) { Remove-Item -LiteralPath $lp -Force }
        }
        Set-LocalDeltaState -Generation $RemoteGeneration -BaselineId ([string]$Baseline.baselineId)
        Publish-DeltaClientState -Generation $RemoteGeneration -Status 'up-to-date-checkpoint'
        Write-GenerationHistoryEvent -Event 'checkpoint-applied' -Generation $RemoteGeneration -SourceHost ([string]$meta.createdBy) -Changed @($meta.changed).Count -Deleted @($meta.deleted).Count -Bytes ([int64]$meta.sourceBytes) -Reason 'catchup-checkpoint'
        Write-Host "Checkpoint aplicado correctamente." -ForegroundColor Green
        return $true
    }
    finally { Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue }
}

function Apply-RemoteBundleChanges {
    param($Baseline=$null,$Current=$null)
    $baseline = $Baseline
    $current = $Current
    if ($null -eq $baseline -or $null -eq $current) {
        $snapshot = Get-RemoteDeltaSnapshot
        if ($null -eq $baseline) { $baseline = $snapshot.Baseline }
        if ($null -eq $current) { $current = $snapshot.Current }
    }
    if ($null -eq $baseline -or $null -eq $current) { throw "Drive no tiene inicializado el protocolo delta." }
    $local = Get-LocalDeltaState
    if ($null -eq $local) { throw "Este PC aun no esta vinculado. Usa 01_IMPORTAR... (PC1) u 08_PREPARAR_SEGUNDO_PC.bat (PC2)." }
    if ([string]$local.baselineId -ne [string]$baseline.baselineId) { throw "Este PC pertenece a otra base de sincronizacion." }

    $localGen = [int64]$local.generation
    $remoteGen = [int64]$current.generation
    $baselineGen = [int64]$baseline.baselineGeneration
    if ($localGen -lt $baselineGen) { throw "Este PC esta en generacion $localGen, anterior a la base compactada $baselineGen; necesita una copia actual." }
    if ($localGen -gt $remoteGen) { throw "La generacion local ($localGen) es superior a Drive ($remoteGen)." }
    if ($localGen -eq $remoteGen) {
        Write-Host "Este PC ya esta en la generacion $remoteGen. No hay nada que descargar." -ForegroundColor Green
        Publish-DeltaClientState -Generation $remoteGen -Status 'up-to-date'
        return [pscustomobject]@{generation=$remoteGen;downloaded=0;deleted=0;changedPaths=[string[]]@();deletedPaths=[string[]]@();batchSeconds=0.0}
    }

    if ((Get-CobbleverseFeatureStage) -ge 17) {
        try { if (Try-ApplyCatchupCheckpoint -LocalGeneration $localGen -RemoteGeneration $remoteGen -Baseline $baseline) { return [pscustomobject]@{generation=$remoteGen;downloaded=0;deleted=0;checkpoint=$true} } } catch { Write-Host ("Checkpoint no utilizable; se vuelve al método normal: {0}" -f $_.Exception.Message) -ForegroundColor Yellow }
    }

    $cacheAtStart = Load-PersistentManifestCache -ExpectedGeneration $localGen -ExpectedBaselineId ([string]$baseline.baselineId)
    $tmpRoot = Join-Path $script:DataDir ('batch-download-' + [guid]::NewGuid().ToString('N'))
    $metaDir = Join-Path $tmpRoot 'meta'
    $bundleDir = Join-Path $tmpRoot 'bundles'
    New-Item -ItemType Directory -Force -Path $metaDir,$bundleDir | Out-Null
    $batchWatch = [Diagnostics.Stopwatch]::StartNew()

    [int64]$downloadedCount = 0
    [int64]$deletedCount = 0
    $allChanged = New-Object 'System.Collections.Generic.List[string]'
    $allDeleted = New-Object 'System.Collections.Generic.List[string]'
    try {
        # 1) Todos los manifiestos pendientes en UNA sola ejecucion de rclone.
        $metaNames = New-Object 'System.Collections.Generic.List[string]'
        for ([int64]$g = $localGen + 1; $g -le $remoteGen; $g++) { $metaNames.Add((Get-DeltaGenerationToken -Generation $g) + '.json') }
        $metaList = Join-Path $tmpRoot 'meta-list.txt'
        Write-Utf8NoBomLines -Path $metaList -Lines $metaNames.ToArray()
        Invoke-Rclone -Arguments @('copy',(Get-RemoteDeltaGenerationsPath),$metaDir,'--config',$script:RcloneConfig,'--files-from-raw',$metaList,'--no-traverse','--transfers','4','--checkers','8','--stats','2s','--stats-one-line') | Out-Null

        $metas = @{}
        $bundleNames = New-Object 'System.Collections.Generic.List[string]'
        for ([int64]$g = $localGen + 1; $g -le $remoteGen; $g++) {
            $token = Get-DeltaGenerationToken -Generation $g
            $p = Join-Path $metaDir ($token + '.json')
            if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw "Falta el manifiesto remoto de la generacion $g." }
            $meta = [IO.File]::ReadAllText($p) | ConvertFrom-Json
            if ([string]$meta.baselineId -ne [string]$baseline.baselineId) { throw "La generacion $g pertenece a otra base." }
            $metas[[string]$g] = $meta
            if (@($meta.changed).Count -gt 0) { $bundleNames.Add($token + '.zip') }
        }

        # 2) Todos los ZIP pendientes en una unica ejecucion de rclone; si hay varios,
        # rclone puede descargarlos en paralelo. Luego se aplican SIEMPRE en orden.
        if ($bundleNames.Count -gt 0) {
            $bundleList = Join-Path $tmpRoot 'bundle-list.txt'
            Write-Utf8NoBomLines -Path $bundleList -Lines $bundleNames.ToArray()
            Invoke-Rclone -Arguments @('copy',(Get-RemoteDeltaBundlesPath),$bundleDir,'--config',$script:RcloneConfig,'--files-from-raw',$bundleList,'--no-traverse','--transfers','4','--checkers','8','--stats','2s','--stats-one-line') | Out-Null
        }

        $root = Get-NormalizedServerRoot
        for ([int64]$g = $localGen + 1; $g -le $remoteGen; $g++) {
            $meta = $metas[[string]$g]
            $changed = @($meta.changed)
            $deleted = @($meta.deleted)
            Write-Host ("Aplicando generacion {0}: {1} archivos; {2} borrados." -f $g,$changed.Count,$deleted.Count) -ForegroundColor Cyan

            if ($changed.Count -gt 0) {
                $zipPath = Join-Path $bundleDir ((Get-DeltaGenerationToken -Generation $g) + '.zip')
                if (-not (Test-Path -LiteralPath $zipPath -PathType Leaf)) { throw "Falta el ZIP remoto de la generacion $g." }
                Expand-DeltaBundleZip -ZipPath $zipPath -DestinationRoot $script:ServerDir
                $downloadedCount += [int64]$changed.Count
                foreach ($p in $changed) { $allChanged.Add([string]$p) }
            }

            foreach ($relRaw in $deleted) {
                $rel = ([string]$relRaw).Replace('\','/').TrimStart('/')
                if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|/)\.\.(/|$)') { throw "Ruta de borrado insegura: $rel" }
                $localPath = [IO.Path]::GetFullPath((Join-Path $root ($rel.Replace('/','\'))))
                if (Test-Path -LiteralPath $localPath -PathType Leaf) { Remove-Item -LiteralPath $localPath -Force }
                $deletedCount++
                $allDeleted.Add($rel)
            }
            # Commit local por generacion: una interrupcion nunca obliga a repetir una generacion ya aplicada.
            Set-LocalDeltaState -Generation $g -BaselineId ([string]$baseline.baselineId)
            $histBytes=0; if($meta.PSObject.Properties.Name -contains 'sourceBytes'){$histBytes=[int64]$meta.sourceBytes}
            Write-GenerationHistoryEvent -Event 'applied' -Generation $g -SourceHost ([string]$meta.host) -Changed $changed.Count -Deleted $deleted.Count -Bytes $histBytes -Reason ([string]$meta.reason)
        }
        Publish-DeltaClientState -Generation $remoteGen -Status 'up-to-date'
    }
    finally {
        $batchWatch.Stop()
        Remove-Item -LiteralPath $tmpRoot -Recurse -Force -ErrorAction SilentlyContinue
    }

    if ($null -ne $cacheAtStart) {
        $null = Update-PersistentManifestCacheAfterRemoteApply -OldManifest $cacheAtStart -ChangedPaths ([string[]]$allChanged.ToArray()) -DeletedPaths ([string[]]$allDeleted.ToArray()) -Generation $remoteGen -BaselineId ([string]$baseline.baselineId)
    }

    Write-Host ("Descarga/aplicacion por lotes terminada en {0:N2}s para {1} generaciones." -f $batchWatch.Elapsed.TotalSeconds,($remoteGen-$localGen)) -ForegroundColor DarkGray
    return [pscustomobject]@{generation=$remoteGen;downloaded=$downloadedCount;deleted=$deletedCount;changedPaths=[string[]]$allChanged.ToArray();deletedPaths=[string[]]$allDeleted.ToArray();batchSeconds=[double]$batchWatch.Elapsed.TotalSeconds}
}

function Apply-RemoteOverlayChanges {
    param($Baseline=$null,$Current=$null)
    $baseline = $Baseline
    $current = $Current
    if ($null -eq $baseline) { $baseline = Get-RemoteDeltaBaseline }
    if ($null -eq $current) { $current = Get-RemoteDeltaCurrent }
    if ($null -eq $baseline -or $null -eq $current) { throw "Drive no tiene inicializado el protocolo delta v4.2." }
    $local = Get-LocalDeltaState
    if ($null -eq $local) { throw "Este PC aun no esta vinculado a la base v4.2. Usa 01_IMPORTAR... (PC1) u 08_PREPARAR_SEGUNDO_PC.bat (PC2)." }
    if ([string]$local.baselineId -ne [string]$baseline.baselineId) { throw "Este PC pertenece a otra base de sincronizacion. Vuelve a vincularlo." }

    $localGen = [int64]$local.generation
    $remoteGen = [int64]$current.generation
    $baselineGen = [int64]$baseline.baselineGeneration
    if ($localGen -lt $baselineGen) {
        throw "Este PC esta en generacion $localGen, anterior a la rebase $baselineGen. Ya no puede reconstruirse solo con Drive; necesita una copia actual del otro PC o un backup local."
    }
    if ($localGen -gt $remoteGen) { throw "La generacion local ($localGen) es superior a Drive ($remoteGen). Se cancela para evitar perdida de datos." }
    if ($localGen -eq $remoteGen) {
        Write-Host "Este PC ya esta en la generacion $remoteGen. No hay nada que descargar." -ForegroundColor Green
        Publish-DeltaClientState -Generation $remoteGen -Status 'up-to-date'
        return [pscustomobject]@{generation=$remoteGen;downloaded=0;deleted=0}
    }

    $index = Get-RemoteDeltaIndexMap
    $download = New-Object 'System.Collections.Generic.List[string]'
    $delete = New-Object 'System.Collections.Generic.List[string]'
    foreach ($entry in $index.GetEnumerator()) {
        $rec = $entry.Value
        if ([int64]$rec.g -le $localGen -or [int64]$rec.g -gt $remoteGen) { continue }
        if ([bool]$rec.d) { $delete.Add([string]$rec.p) }
        else { $download.Add([string]$rec.p) }
    }

    Write-Host ("Actualizando PC desde generacion {0} -> {1}: {2} archivos a descargar, {3} a borrar." -f $localGen,$remoteGen,$download.Count,$delete.Count) -ForegroundColor Cyan
    if ($download.Count -gt 0) {
        $list = Join-Path $script:DataDir ("download-{0}.txt" -f [guid]::NewGuid().ToString('N'))
        Write-Utf8NoBomLines -Path $list -Lines $download.ToArray()
        try {
            Invoke-Rclone -Arguments @('copy', $script:RemoteDeltaFiles, $script:ServerDir, '--config', $script:RcloneConfig, '--files-from-raw', $list, '--no-traverse', '--transfers', '8', '--checkers', '8', '--stats', '5s', '--stats-one-line') | Out-Null
        }
        finally { Remove-Item $list -Force -ErrorAction SilentlyContinue }
    }

    $root = Get-NormalizedServerRoot
    foreach ($rel in $delete.ToArray()) {
        if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|/)\.\.(/|$)') { throw "Ruta de borrado insegura recibida desde Drive: $rel" }
        $localPath = Join-Path $root ($rel.Replace('/','\'))
        if (Test-Path -LiteralPath $localPath -PathType Leaf) { Remove-Item -LiteralPath $localPath -Force }
    }

    Set-LocalDeltaState -Generation $remoteGen -BaselineId ([string]$baseline.baselineId)
    Publish-DeltaClientState -Generation $remoteGen -Status 'up-to-date'
    return [pscustomobject]@{generation=$remoteGen;downloaded=$download.Count;deleted=$delete.Count}
}

function Publish-RemoteOverlayChanges {
    param(
        [Parameter(Mandatory=$true)]$BeforeManifest,
        [Parameter(Mandatory=$true)]$AfterManifest,
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$Reason='session'
    )
    $baseline = Get-RemoteDeltaBaseline
    $current = Get-RemoteDeltaCurrent
    $local = Get-LocalDeltaState
    if ($null -eq $baseline -or $null -eq $current -or $null -eq $local) { throw "Sincronizacion delta no inicializada." }
    $localGen = [int64]$local.generation
    $remoteGen = [int64]$current.generation
    if ($localGen -ne $remoteGen) { throw "Antes de publicar, local=$localGen y Drive=$remoteGen. Aplica primero los cambios remotos." }

    $diff = Compare-FastManifestData -Before $BeforeManifest -After $AfterManifest
    if ($diff.Changed.Count -eq 0 -and $diff.Deleted.Count -eq 0) {
        Write-Host "No ha cambiado ningun archivo relevante. No se sube ningun dato de partida." -ForegroundColor Green
        Publish-DeltaClientState -Generation $remoteGen -Status 'up-to-date'
        return [pscustomobject]@{generation=$remoteGen;changed=0;deleted=0;bytes=0}
    }

    $nextGen = $remoteGen + 1
    Write-Host ("Cambios detectados: {0} archivos modificados/nuevos ({1}) y {2} eliminados." -f $diff.Changed.Count,(Format-ByteSize ([int64]$diff.ChangedBytes)),$diff.Deleted.Count) -ForegroundColor Cyan
    Write-Host "Subiendo SOLO esos archivos a Drive..." -ForegroundColor Cyan

    if ($diff.Changed.Count -gt 0) {
        $list = Join-Path $script:DataDir ("upload-{0}.txt" -f [guid]::NewGuid().ToString('N'))
        Write-Utf8NoBomLines -Path $list -Lines @($diff.Changed)
        try {
            Invoke-Rclone -Arguments @('copy', $script:ServerDir, $script:RemoteDeltaFiles, '--config', $script:RcloneConfig, '--files-from-raw', $list, '--no-traverse', '--transfers', '8', '--checkers', '8', '--stats', '5s', '--stats-one-line') | Out-Null
        }
        finally { Remove-Item $list -Force -ErrorAction SilentlyContinue }
    }

    $index = Get-RemoteDeltaIndexMap
    foreach ($p in @($diff.Changed)) {
        $rec = $AfterManifest.Map[$p]
        $index[$p] = [pscustomobject]@{ p=$p; g=[int64]$nextGen; d=$false; s=[int64]$rec.s }
    }
    foreach ($p in @($diff.Deleted)) {
        $index[$p] = [pscustomobject]@{ p=$p; g=[int64]$nextGen; d=$true; s=[int64]0 }
    }

    # Primero se publica el indice y SOLO al final current.json. current.json es el commit.
    Set-RemoteDeltaIndexMap -Map $index
    $next = [ordered]@{
        protocol = 'delta-overlay-v1'
        baselineId = [string]$baseline.baselineId
        generation = [int64]$nextGen
        baselineGeneration = [int64]$baseline.baselineGeneration
        updatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
        host = $env:COMPUTERNAME
        sessionId = $SessionId
        reason = $Reason
        changedFiles = [int64]$diff.Changed.Count
        deletedFiles = [int64]$diff.Deleted.Count
        transferredBytes = [int64]$diff.ChangedBytes
    }
    Set-RemoteJsonObject -RemotePath $script:RemoteDeltaCurrent -Object $next -TempPrefix 'current-commit'
    Set-LocalDeltaState -Generation $nextGen -BaselineId ([string]$baseline.baselineId)
    Publish-DeltaClientState -Generation $nextGen -Status 'published'
    return [pscustomobject]@{generation=$nextGen;changed=$diff.Changed.Count;deleted=$diff.Deleted.Count;bytes=[int64]$diff.ChangedBytes}
}



function Write-LocalJsonAtomic {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)]$Object)
    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    $tmp = $Path + '.tmp-' + [guid]::NewGuid().ToString('N')
    $json = ConvertTo-Json -InputObject $Object -Depth 10 -Compress
    [IO.File]::WriteAllText($tmp,$json,(New-Object Text.UTF8Encoding($false)))
    try {
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            try { [IO.File]::Replace($tmp,$Path,$null,$true) }
            catch { Move-Item -LiteralPath $tmp -Destination $Path -Force }
        }
        else { [IO.File]::Move($tmp,$Path) }
    }
    finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
}

function Get-PendingSyncItems {
    if ([string]::IsNullOrWhiteSpace([string]$script:PendingSyncRoot) -or -not (Test-Path -LiteralPath $script:PendingSyncRoot -PathType Container)) { return @() }
    $items = New-Object 'System.Collections.Generic.List[object]'
    foreach ($dir in @(Get-ChildItem -LiteralPath $script:PendingSyncRoot -Directory -ErrorAction SilentlyContinue | Where-Object { -not $_.Name.StartsWith('.building-') })) {
        $metaPath = Join-Path $dir.FullName 'pending.json'
        if (-not (Test-Path -LiteralPath $metaPath -PathType Leaf)) { continue }
        try {
            $meta = [IO.File]::ReadAllText($metaPath) | ConvertFrom-Json
            if ([string]$meta.status -ne 'ready') { continue }
            $items.Add([pscustomobject]@{Dir=$dir.FullName;Meta=$meta})
        } catch { }
    }
    return @($items.ToArray() | Sort-Object { [int64]$_.Meta.baseGeneration }, { [string]$_.Meta.createdUtc })
}

function Get-PendingSyncSummary {
    $items = @(Get-PendingSyncItems)
    [int64]$bytes = 0
    foreach ($item in $items) { try { $bytes += [int64]$item.Meta.bundleBytes } catch { } }
    return [pscustomobject]@{count=$items.Count;bytes=$bytes;items=$items}
}

function Set-PendingSyncAttemptState {
    param([Parameter(Mandatory=$true)][string]$PendingDir,[string]$Message='',[switch]$Success)
    $metaPath = Join-Path $PendingDir 'pending.json'
    if (-not (Test-Path -LiteralPath $metaPath)) { return }
    try {
        $m = [IO.File]::ReadAllText($metaPath) | ConvertFrom-Json
        $attempts = 0
        if ($m.PSObject.Properties.Name -contains 'attempts') { $attempts = [int]$m.attempts }
        if (-not $Success) { $attempts++ }
        $m.attempts = $attempts
        $m.lastAttemptUtc = [DateTimeOffset]::UtcNow.ToString('o')
        $m.lastError = $Message
        Write-LocalJsonAtomic -Path $metaPath -Object $m
    } catch { }
}

function New-PendingBundleSync {
    param(
        [Parameter(Mandatory=$true)]$BeforeManifest,
        [Parameter(Mandatory=$true)]$AfterManifest,
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$Reason='session',
        [int64]$BaseGeneration=-1,
        [string]$BaselineId=''
    )
    $local = Get-LocalDeltaState
    if ($BaseGeneration -lt 0) {
        if ($null -eq $local) { throw 'Falta la generacion local para crear el paquete pendiente.' }
        $BaseGeneration = [int64]$local.generation
    }
    if ([string]::IsNullOrWhiteSpace($BaselineId)) {
        if ($null -eq $local) { throw 'Falta baselineId local para crear el paquete pendiente.' }
        $BaselineId = [string]$local.baselineId
    }

    $diff = Compare-FastManifestData -Before $BeforeManifest -After $AfterManifest
    if ($diff.Changed.Count -eq 0 -and $diff.Deleted.Count -eq 0) {
        return [pscustomobject]@{queued=$false;generation=$BaseGeneration;changed=0;deleted=0;bytes=0;dir=$null}
    }

    $targetGeneration = [int64]$BaseGeneration + 1
    New-Item -ItemType Directory -Force -Path $script:PendingSyncRoot | Out-Null
    $building = Join-Path $script:PendingSyncRoot ('.building-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $building | Out-Null
    $finalName = ('g{0:D12}-{1}' -f $targetGeneration,$SessionId)
    $finalDir = Join-Path $script:PendingSyncRoot $finalName
    if (Test-Path -LiteralPath $finalDir) {
        # Idempotencia: una sesion ya empaquetada nunca se vuelve a construir encima.
        Remove-Item -LiteralPath $building -Recurse -Force -ErrorAction SilentlyContinue
        $existing = [IO.File]::ReadAllText((Join-Path $finalDir 'pending.json')) | ConvertFrom-Json
        return [pscustomobject]@{queued=$true;generation=[int64]$existing.targetGeneration;changed=@($existing.changed).Count;deleted=@($existing.deleted).Count;bytes=[int64]$existing.sourceBytes;dir=$finalDir}
    }

    [int64]$bundleBytes = 0
    try {
        $bundleLocal = Join-Path $building 'bundle.zip'
        [double]$packSeconds = 0.0
        if ($diff.Changed.Count -gt 0) {
            $packWatch = [Diagnostics.Stopwatch]::StartNew()
            $zipInfo = New-DeltaBundleZip -RelativePaths ([string[]]@($diff.Changed)) -ZipPath $bundleLocal
            $packWatch.Stop()
            $packSeconds = [double]$packWatch.Elapsed.TotalSeconds
            $bundleBytes = [int64]$zipInfo.Length
            $ratio = 100.0
            if ([int64]$diff.ChangedBytes -gt 0) { $ratio = (100.0 * [double]$bundleBytes / [double]$diff.ChangedBytes) }
            Write-Host ("ZIP {0}: {1} -> {2} ({3:N1}%); empaquetado {4:N2}s." -f [string]$script:Config.BundleCompression,(Format-ByteSize ([int64]$diff.ChangedBytes)),(Format-ByteSize $bundleBytes),$ratio,$packSeconds) -ForegroundColor DarkCyan
        }
        $meta = [ordered]@{
            protocol='delta-overlay-v1'
            transferMode='bundle-v2'
            status='ready'
            baselineId=$BaselineId
            baseGeneration=[int64]$BaseGeneration
            targetGeneration=[int64]$targetGeneration
            createdUtc=[DateTimeOffset]::UtcNow.ToString('o')
            host=$env:COMPUTERNAME
            sessionId=$SessionId
            reason=$Reason
            changed=[string[]]@($diff.Changed)
            deleted=[string[]]@($diff.Deleted)
            sourceBytes=[int64]$diff.ChangedBytes
            bundleBytes=[int64]$bundleBytes
            compression=[string]$script:Config.BundleCompression
            packSeconds=[double]$packSeconds
            attempts=0
            lastAttemptUtc=$null
            lastError=''
        }
        Write-LocalJsonAtomic -Path (Join-Path $building 'pending.json') -Object $meta
        Move-Item -LiteralPath $building -Destination $finalDir
    }
    catch {
        # Los .building incompletos nunca cuentan como READY y se pueden eliminar con seguridad.
        throw
    }
    finally { Remove-Item -LiteralPath $building -Recurse -Force -ErrorAction SilentlyContinue }

    Write-Host ("Outbox local READY: G{0} -> G{1}; {2} archivos ({3}); {4} borrados." -f $BaseGeneration,$targetGeneration,$diff.Changed.Count,(Format-ByteSize ([int64]$diff.ChangedBytes)),$diff.Deleted.Count) -ForegroundColor DarkCyan
    return [pscustomobject]@{queued=$true;generation=$targetGeneration;changed=$diff.Changed.Count;deleted=$diff.Deleted.Count;bytes=[int64]$diff.ChangedBytes;dir=$finalDir}
}

function Publish-PendingBundleSync {
    param([Parameter(Mandatory=$true)][string]$PendingDir)
    $metaPath = Join-Path $PendingDir 'pending.json'
    if (-not (Test-Path -LiteralPath $metaPath)) { throw "Paquete pendiente sin pending.json: $PendingDir" }
    $m = [IO.File]::ReadAllText($metaPath) | ConvertFrom-Json
    $baseGen = [int64]$m.baseGeneration
    $targetGen = [int64]$m.targetGeneration

    $snapshot = Get-RemoteDeltaSnapshot
    $baseline = $snapshot.Baseline
    $current = $snapshot.Current
    if ($null -eq $baseline -or $null -eq $current) { throw 'Drive no esta disponible o no se puede leer current/baseline.' }
    if ([string]$baseline.baselineId -ne [string]$m.baselineId) { throw 'CONFLICTO: Drive pertenece a otra base de sincronizacion.' }
    $mode = Get-DeltaTransferMode -Baseline $baseline -Current $current
    if ($mode -ne 'bundle-v2') { throw 'El outbox seguro v4.9.6 requiere bundle-v2.' }

    $remoteGen = [int64]$current.generation
    if ($remoteGen -eq $targetGen -and $current.PSObject.Properties.Name -contains 'sessionId' -and [string]$current.sessionId -eq [string]$m.sessionId) {
        # El commit remoto termino antes de una caida local. Solo faltaba reconocerlo.
        Set-LocalDeltaState -Generation $targetGen -BaselineId ([string]$m.baselineId)
        try { Publish-DeltaClientState -Generation $targetGen -Status 'recovered-after-commit' } catch { }
        Remove-Item -LiteralPath $PendingDir -Recurse -Force -ErrorAction SilentlyContinue
        return [pscustomobject]@{generation=$targetGen;changed=@($m.changed).Count;deleted=@($m.deleted).Count;bytes=[int64]$m.sourceBytes;alreadyCommitted=$true}
    }
    if ($remoteGen -ne $baseGen) {
        throw ("CONFLICTO SEGURO: el paquete pendiente parte de G{0}, pero Drive esta en G{1}. No se sobrescribe nada automaticamente." -f $baseGen,$remoteGen)
    }

    Initialize-DeltaRemoteFolders
    $changed = @($m.changed)
    $deleted = @($m.deleted)
    if ($changed.Count -gt 0) {
        $localZip = Join-Path $PendingDir 'bundle.zip'
        if (-not (Test-Path -LiteralPath $localZip -PathType Leaf)) { throw 'Falta bundle.zip del outbox local.' }
        Write-Host ("Subiendo outbox G{0} en UN solo ZIP..." -f $targetGen) -ForegroundColor Cyan
        Invoke-Rclone -Arguments @('copyto',$localZip,(Get-RemoteGenerationBundlePath -Generation $targetGen),'--config',$script:RcloneConfig,'--no-traverse','--drive-chunk-size',(Get-DriveChunkSizeArgument),'--retries','3','--low-level-retries','10','--contimeout','10s','--timeout','30s','--stats','2s','--stats-one-line') | Out-Null
    }

    $bundleName = (Get-DeltaGenerationToken -Generation $targetGen) + '.zip'
    $genMeta = [ordered]@{
        protocol='delta-overlay-v1'; transferMode='bundle-v2'; baselineId=[string]$m.baselineId
        generation=$targetGen; previousGeneration=$baseGen; createdUtc=[string]$m.createdUtc
        host=[string]$m.host; sessionId=[string]$m.sessionId; reason=[string]$m.reason
        changed=[string[]]$changed; deleted=[string[]]$deleted; sourceBytes=[int64]$m.sourceBytes
        bundleBytes=[int64]$m.bundleBytes; bundle=$bundleName
    }
    Set-RemoteJsonObject -RemotePath (Get-RemoteGenerationMetaPath -Generation $targetGen) -Object $genMeta -TempPrefix 'generation-pending'

    # COMMIT REMOTO: SIEMPRE AL FINAL. Si se cae Internet antes, Drive sigue anunciando G(base).
    $next = [ordered]@{
        protocol='delta-overlay-v1'; transferMode='bundle-v2'; baselineId=[string]$m.baselineId
        generation=$targetGen; baselineGeneration=[int64]$baseline.baselineGeneration
        updatedUtc=[DateTimeOffset]::UtcNow.ToString('o'); host=$env:COMPUTERNAME
        sessionId=[string]$m.sessionId; reason=[string]$m.reason
        changedFiles=$changed.Count; deletedFiles=$deleted.Count
        transferredBytes=[int64]$m.bundleBytes; sourceBytes=[int64]$m.sourceBytes
    }
    Set-RemoteJsonObject -RemotePath $script:RemoteDeltaCurrent -Object $next -TempPrefix 'current-commit-pending'
    Set-LocalDeltaState -Generation $targetGen -BaselineId ([string]$m.baselineId)
    Publish-DeltaClientState -Generation $targetGen -Status 'published'
    Write-GenerationHistoryEvent -Event 'published' -Generation $targetGen -SourceHost $env:COMPUTERNAME -Changed $changed.Count -Deleted $deleted.Count -Bytes ([int64]$m.sourceBytes) -Reason ([string]$m.reason)
    Remove-Item -LiteralPath $PendingDir -Recurse -Force -ErrorAction SilentlyContinue
    return [pscustomobject]@{generation=$targetGen;changed=$changed.Count;deleted=$deleted.Count;bytes=[int64]$m.sourceBytes;alreadyCommitted=$false}
}

function Publish-PendingSyncQueue {
    $items = @(Get-PendingSyncItems)
    if ($items.Count -eq 0) { return [pscustomobject]@{completed=$true;count=0;generation=$null} }
    [int64]$lastGen = -1
    foreach ($item in $items) {
        try {
            $r = Publish-PendingBundleSync -PendingDir ([string]$item.Dir)
            $lastGen = [int64]$r.generation
        }
        catch {
            Set-PendingSyncAttemptState -PendingDir ([string]$item.Dir) -Message $_.Exception.Message
            throw
        }
    }
    return [pscustomobject]@{completed=$true;count=$items.Count;generation=$lastGen}
}

function Queue-DeltaChangesForSafePublish {
    param(
        [Parameter(Mandatory=$true)]$BeforeManifest,
        [Parameter(Mandatory=$true)]$AfterManifest,
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$Reason='session',
        [int64]$BaseGeneration=-1,
        [string]$BaselineId=''
    )
    return (New-PendingBundleSync -BeforeManifest $BeforeManifest -AfterManifest $AfterManifest -SessionId $SessionId -Reason $Reason -BaseGeneration $BaseGeneration -BaselineId $BaselineId)
}

function Publish-RemoteBundleChanges {
    param(
        [Parameter(Mandatory=$true)]$BeforeManifest,
        [Parameter(Mandatory=$true)]$AfterManifest,
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$Reason='session'
    )
    $baseline = Get-RemoteDeltaBaseline
    $current = Get-RemoteDeltaCurrent
    $local = Get-LocalDeltaState
    if ($null -eq $baseline -or $null -eq $current -or $null -eq $local) { throw "Sincronizacion delta no inicializada." }
    $localGen = [int64]$local.generation
    $remoteGen = [int64]$current.generation
    if ($localGen -ne $remoteGen) { throw "Antes de publicar, local=$localGen y Drive=$remoteGen. Aplica primero los cambios remotos." }

    $diff = Compare-FastManifestData -Before $BeforeManifest -After $AfterManifest
    if ($diff.Changed.Count -eq 0 -and $diff.Deleted.Count -eq 0) {
        Write-Host "No ha cambiado ningun archivo relevante. No se sube ningun dato de partida." -ForegroundColor Green
        Publish-DeltaClientState -Generation $remoteGen -Status 'up-to-date'
        return [pscustomobject]@{generation=$remoteGen;changed=0;deleted=0;bytes=0}
    }

    $nextGen = $remoteGen + 1
    Write-Host ("Cambios detectados: {0} archivos ({1}) y {2} eliminados." -f $diff.Changed.Count,(Format-ByteSize ([int64]$diff.ChangedBytes)),$diff.Deleted.Count) -ForegroundColor Cyan
    Initialize-DeltaRemoteFolders

    $bundleName = (Get-DeltaGenerationToken -Generation $nextGen) + '.zip'
    $bundlePath = Get-RemoteGenerationBundlePath -Generation $nextGen
    $localZip = Join-Path $script:DataDir ($bundleName + '.tmp')
    [int64]$bundleBytes = 0
    try {
        if ($diff.Changed.Count -gt 0) {
            $packWatch = [Diagnostics.Stopwatch]::StartNew()
            $zipInfo = New-DeltaBundleZip -RelativePaths ([string[]]@($diff.Changed)) -ZipPath $localZip
            $packWatch.Stop()
            $bundleBytes = [int64]$zipInfo.Length
            Write-Host ("Paquete creado en {0:N1}s: {1}. Subiendo UN solo archivo a Drive..." -f $packWatch.Elapsed.TotalSeconds,(Format-ByteSize $bundleBytes)) -ForegroundColor DarkCyan
            Invoke-Rclone -Arguments @('copyto', $localZip, $bundlePath, '--config', $script:RcloneConfig, '--no-traverse', '--drive-chunk-size', (Get-DriveChunkSizeArgument), '--stats', '2s', '--stats-one-line') | Out-Null
        }

        $genMeta = [ordered]@{
            protocol = 'delta-overlay-v1'
            transferMode = 'bundle-v2'
            baselineId = [string]$baseline.baselineId
            generation = [int64]$nextGen
            previousGeneration = [int64]$remoteGen
            createdUtc = [DateTimeOffset]::UtcNow.ToString('o')
            host = $env:COMPUTERNAME
            sessionId = $SessionId
            reason = $Reason
            changed = [string[]]@($diff.Changed)
            deleted = [string[]]@($diff.Deleted)
            sourceBytes = [int64]$diff.ChangedBytes
            bundleBytes = [int64]$bundleBytes
            bundle = $bundleName
        }
        Set-RemoteJsonObject -RemotePath (Get-RemoteGenerationMetaPath -Generation $nextGen) -Object $genMeta -TempPrefix 'generation'

        # current.json es el COMMIT. Se escribe siempre al final.
        $next = [ordered]@{
            protocol = 'delta-overlay-v1'
            transferMode = 'bundle-v2'
            baselineId = [string]$baseline.baselineId
            generation = [int64]$nextGen
            baselineGeneration = [int64]$baseline.baselineGeneration
            updatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
            host = $env:COMPUTERNAME
            sessionId = $SessionId
            reason = $Reason
            changedFiles = [int64]$diff.Changed.Count
            deletedFiles = [int64]$diff.Deleted.Count
            transferredBytes = [int64]$bundleBytes
            sourceBytes = [int64]$diff.ChangedBytes
        }
        Set-RemoteJsonObject -RemotePath $script:RemoteDeltaCurrent -Object $next -TempPrefix 'current-commit'
        Set-LocalDeltaState -Generation $nextGen -BaselineId ([string]$baseline.baselineId)
        Publish-DeltaClientState -Generation $nextGen -Status 'published'
        Write-GenerationHistoryEvent -Event 'published' -Generation $nextGen -SourceHost $env:COMPUTERNAME -Changed $diff.Changed.Count -Deleted $diff.Deleted.Count -Bytes ([int64]$diff.ChangedBytes) -Reason $Reason
    }
    finally { Remove-Item -LiteralPath $localZip -Force -ErrorAction SilentlyContinue }

    return [pscustomobject]@{generation=$nextGen;changed=$diff.Changed.Count;deleted=$diff.Deleted.Count;bytes=[int64]$diff.ChangedBytes;uploadedBytes=$bundleBytes}
}

function Apply-RemoteDeltaChanges {
    param($Baseline=$null,$Current=$null)
    $baseline = $Baseline
    $current = $Current
    if ($null -eq $baseline) { $baseline = Get-RemoteDeltaBaseline }
    if ($null -eq $current) { $current = Get-RemoteDeltaCurrent }
    $mode = Get-DeltaTransferMode -Baseline $baseline -Current $current
    if ($mode -eq 'bundle-v2') { return (Apply-RemoteBundleChanges -Baseline $baseline -Current $current) }
    return (Apply-RemoteOverlayChanges -Baseline $baseline -Current $current)
}

function Publish-DeltaChanges {
    param(
        [Parameter(Mandatory=$true)]$BeforeManifest,
        [Parameter(Mandatory=$true)]$AfterManifest,
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$Reason='session'
    )
    $baseline = Get-RemoteDeltaBaseline
    $current = Get-RemoteDeltaCurrent
    $mode = Get-DeltaTransferMode -Baseline $baseline -Current $current
    if ($mode -eq 'bundle-v2') {
        return (Publish-RemoteBundleChanges -BeforeManifest $BeforeManifest -AfterManifest $AfterManifest -SessionId $SessionId -Reason $Reason)
    }
    return (Publish-RemoteOverlayChanges -BeforeManifest $BeforeManifest -AfterManifest $AfterManifest -SessionId $SessionId -Reason $Reason)
}

function Write-DeltaDirtyMarker {
    param([Parameter(Mandatory=$true)][string]$SessionId,[Parameter(Mandatory=$true)][int64]$StartGeneration)
    $obj = [ordered]@{
        protocol = 'delta-overlay-v1'
        sessionId = $SessionId
        host = $env:COMPUTERNAME
        startGeneration = $StartGeneration
        manifestPath = $script:SessionStartManifestPath
        startedUtc = [DateTimeOffset]::UtcNow.ToString('o')
    }
    $json = ConvertTo-Json -InputObject $obj -Depth 4 -Compress
    [IO.File]::WriteAllText($script:DirtyMarkerPath, $json, (New-Object Text.UTF8Encoding($false)))
}

function Recover-DeltaDirtySession {
    param([Parameter(Mandatory=$true)]$Dirty,[Parameter(Mandatory=$true)][string]$SessionId)
    if (-not ($Dirty.PSObject.Properties.Name -contains 'protocol') -or [string]$Dirty.protocol -ne 'delta-overlay-v1') {
        throw "Existe un marcador pendiente de una version anterior. No se publica automaticamente con v4.2. Conserva la carpeta local y revisalo antes de usar el otro PC."
    }
    $manifestPath = [string]$Dirty.manifestPath
    if ([string]::IsNullOrWhiteSpace($manifestPath) -or -not (Test-Path $manifestPath)) { throw "Falta el manifiesto de inicio de la sesion pendiente; no se puede calcular un delta seguro." }
    $current = Get-RemoteDeltaCurrent
    if ($null -eq $current) { throw "Drive no tiene current.json de v4.2." }
    $startGen = [int64]$Dirty.startGeneration
    $remoteGen = [int64]$current.generation

    # Si el commit remoto llego a completarse pero el proceso murio justo antes de
    # guardar la generacion local/liberar el lock, reconocemos nuestro propio commit.
    $sameCommittedSession = $false
    if ($remoteGen -eq ($startGen + 1) -and $current.PSObject.Properties.Name -contains 'sessionId') {
        $sameCommittedSession = ([string]$current.sessionId -eq [string]$Dirty.sessionId)
    }
    if ($sameCommittedSession) {
        $baseline = Get-RemoteDeltaBaseline
        Set-LocalDeltaState -Generation $remoteGen -BaselineId ([string]$baseline.baselineId)
        Publish-DeltaClientState -Generation $remoteGen -Status 'recovered-after-commit'
        Clear-DirtyMarker
        Remove-Item $script:SessionStartManifestPath -Force -ErrorAction SilentlyContinue
        Write-Host "El cambio ya estaba confirmado en Drive; solo faltaba cerrar la sesion local." -ForegroundColor Green
        return [pscustomobject]@{generation=$remoteGen;changed=0;deleted=0;bytes=0}
    }

    if ($remoteGen -ne $startGen) {
        throw "Drive avanzo desde la generacion de la sesion pendiente. No se publica automaticamente para evitar mezclar ramas."
    }
    Write-Host "Calculando cambios de la sesion interrumpida mediante METADATOS locales..." -ForegroundColor Cyan
    $before = Load-FastManifestData -Path $manifestPath
    $after = Get-FastManifestData
    $result = Publish-DeltaChanges -BeforeManifest $before -AfterManifest $after -SessionId $SessionId -Reason 'recovery'
    Clear-DirtyMarker
    Remove-Item $script:SessionStartManifestPath -Force -ErrorAction SilentlyContinue
    return $result
}

function Try-AutoRebaseDelta {
    param(
        [int64]$ExpectedGeneration = -1,
        [string]$ExpectedSessionId = '',
        $SnapshotManifest = $null
    )
    if (-not [bool]$script:Config.AutoRebaseWhenBothClientsSynced) { return $false }

    # Cuando se ejecuta como mantenimiento v4.9.2, solo puede compactar mientras
    # la misma sesion conserva el lock remoto. Si la sesion ya termino, se cancela.
    if (-not [string]::IsNullOrWhiteSpace($ExpectedSessionId)) {
        $lock = Get-RemoteLock
        if ($null -eq $lock -or [string]$lock.sessionId -ne $ExpectedSessionId) { return $false }
    }

    $current = Get-RemoteDeltaCurrent
    $baseline = Get-RemoteDeltaBaseline
    if ($null -eq $current -or $null -eq $baseline) { return $false }
    $gen = [int64]$current.generation
    $baseGen = [int64]$baseline.baselineGeneration
    $mode = Get-DeltaTransferMode -Baseline $baseline -Current $current

    if ($ExpectedGeneration -ge 0 -and $gen -ne $ExpectedGeneration) { return $false }

    $clients = @(Get-RemoteDeltaClients)
    if ($clients.Count -lt 2) { return $false }
    foreach ($client in $clients) {
        if ([int64]$client.generation -ne $gen) { return $false }
    }

    if ($gen -le $baseGen -and $mode -eq 'bundle-v2') { return $false }

    if ($mode -ne 'bundle-v2') {
        Write-Host "Ambos PCs estan sincronizados. Activando MODO RAPIDO v4.8 (1 paquete por sesion)..." -ForegroundColor DarkCyan
    }
    else {
        Write-Host "Los dos PCs ya tienen la generacion $gen. Compactando paquetes antiguos de Drive..." -ForegroundColor DarkCyan
    }

    # MUY IMPORTANTE v4.9.2: si Minecraft ya esta en marcha, NO se escanea el servidor
    # vivo para crear la huella de la base. Se usa el manifiesto capturado justo antes
    # de arrancar Java, que representa exactamente la generacion que se compacta.
    if ($null -ne $SnapshotManifest) { $fp = Get-FastBaselineFingerprintFromManifest -Manifest $SnapshotManifest }
    else { $fp = Get-FastBaselineFingerprint }

    $createdUtc = [DateTimeOffset]::UtcNow.ToString('o')
    $createdBy = $env:COMPUTERNAME
    if ($baseline.PSObject.Properties.Name -contains 'createdUtc') { $createdUtc = [string]$baseline.createdUtc }
    if ($baseline.PSObject.Properties.Name -contains 'createdBy') { $createdBy = [string]$baseline.createdBy }
    $newBase = [ordered]@{
        protocol = 'delta-overlay-v1'
        transferMode = 'bundle-v2'
        baselineId = [string]$baseline.baselineId
        baselineGeneration = $gen
        fingerprint = [string]$fp.fingerprint
        files = [int64]$fp.files
        bytes = [int64]$fp.bytes
        createdUtc = $createdUtc
        createdBy = $createdBy
        rebasedUtc = [DateTimeOffset]::UtcNow.ToString('o')
        rebasedBy = $env:COMPUTERNAME
    }
    $newCurrent = [ordered]@{
        protocol = 'delta-overlay-v1'
        transferMode = 'bundle-v2'
        baselineId = [string]$baseline.baselineId
        generation = $gen
        baselineGeneration = $gen
        updatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
        host = $env:COMPUTERNAME
        reason = 'automatic-rebase-background-v492'
        changedFiles = [int64]0
        deletedFiles = [int64]0
        transferredBytes = [int64]0
    }

    # Primero hacemos oficial la nueva base. A partir de aqui un cliente antiguo sabe
    # que ya no puede reconstruirse desde generaciones previas. La purga posterior es
    # solo limpieza; si falla, quedan archivos sobrantes pero no se pierde coherencia.
    Set-RemoteJsonObject -RemotePath $script:RemoteDeltaBaseline -Object $newBase -TempPrefix 'baseline-rebase'
    Set-RemoteJsonObject -RemotePath $script:RemoteDeltaCurrent -Object $newCurrent -TempPrefix 'current-rebase'

    Invoke-Rclone -Arguments @('purge', $script:RemoteDeltaOverlay, '--config', $script:RcloneConfig, '--drive-use-trash=false') -IgnoreExitCode | Out-Null
    Invoke-Rclone -Arguments @('purge', (Get-RemoteDeltaBundlesPath), '--config', $script:RcloneConfig, '--drive-use-trash=false') -IgnoreExitCode | Out-Null
    Invoke-Rclone -Arguments @('purge', (Get-RemoteDeltaGenerationsPath), '--config', $script:RcloneConfig, '--drive-use-trash=false') -IgnoreExitCode | Out-Null
    Initialize-DeltaRemoteFolders
    Set-RemoteDeltaIndexMap -Map @{}

    Write-Host "Mantenimiento Drive terminado: generaciones antiguas compactadas sin bloquear el arranque." -ForegroundColor Green
    return $true
}
function Show-DeltaRemoteUsage {
    $raw = Invoke-RcloneCapture -Arguments @('size', $script:RemoteDeltaRoot, '--json', '--config', $script:RcloneConfig) -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) { return }
    try {
        $obj = $raw | ConvertFrom-Json
        Write-Host ("Uso actual del protocolo v4.2 en Drive: {0} ({1} archivos)." -f (Format-ByteSize ([int64]$obj.bytes)), $obj.count) -ForegroundColor DarkGray
    }
    catch { }
}
