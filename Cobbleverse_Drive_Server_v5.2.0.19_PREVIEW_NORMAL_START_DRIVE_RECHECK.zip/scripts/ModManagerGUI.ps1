﻿Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'DeltaSync.ps1')
. (Join-Path $PSScriptRoot 'ModManagerCore.ps1')
. (Join-Path $PSScriptRoot 'ModTestCore.ps1')
Initialize-ModManagerEnvironment

$dark=[System.Drawing.Color]::FromArgb(18,20,26);$panel=[System.Drawing.Color]::FromArgb(29,32,40);$panel2=[System.Drawing.Color]::FromArgb(38,41,51);$text=[System.Drawing.Color]::FromArgb(235,238,245);$muted=[System.Drawing.Color]::FromArgb(165,172,188);$orange=[System.Drawing.Color]::FromArgb(255,139,34);$green=[System.Drawing.Color]::FromArgb(70,180,90);$red=[System.Drawing.Color]::FromArgb(195,55,62)
$script:mmProcess=$null;$script:mmLogPath=Join-Path $script:ModManagerDir 'worker.log';$script:mmErrPath=Join-Path $script:ModManagerDir 'worker.err.log';$script:mmLastLog=''

function New-MMButton([string]$Caption,[int]$X,[int]$Y,[int]$W=150,[int]$H=32){$b=New-Object System.Windows.Forms.Button;$b.Text=$Caption;$b.Location=New-Object System.Drawing.Point($X,$Y);$b.Size=New-Object System.Drawing.Size($W,$H);$b.FlatStyle='Flat';$b.BackColor=$panel2;$b.ForeColor=$text;$b.FlatAppearance.BorderColor=[System.Drawing.Color]::FromArgb(70,74,88);return $b}
function New-MMLabel([string]$Caption,[int]$X,[int]$Y,[int]$W=300,[int]$H=22,[bool]$Bold=$false){$l=New-Object System.Windows.Forms.Label;$l.Text=$Caption;$l.Location=New-Object System.Drawing.Point($X,$Y);$l.Size=New-Object System.Drawing.Size($W,$H);$l.ForeColor=$text;if($Bold){$l.Font=New-Object System.Drawing.Font('Segoe UI Semibold',9.5)};return $l}

function Select-ModSide {
    $d=New-Object System.Windows.Forms.Form;$d.Text='Ámbito del mod';$d.Size=New-Object System.Drawing.Size(430,220);$d.StartPosition='CenterParent';$d.FormBorderStyle='FixedDialog';$d.MaximizeBox=$false;$d.MinimizeBox=$false;$d.BackColor=$dark;$d.ForeColor=$text
    $l=New-MMLabel '¿Dónde debe instalarse este JAR?' 18 18 360 24 $true;$d.Controls.Add($l)
    $combo=New-Object System.Windows.Forms.ComboBox;$combo.DropDownStyle='DropDownList';$combo.Location=New-Object System.Drawing.Point(18,58);$combo.Size=New-Object System.Drawing.Size(370,28);[void]$combo.Items.Add('Cliente + servidor (both)');[void]$combo.Items.Add('Solo cliente (client)');[void]$combo.Items.Add('Solo servidor (server)');$combo.SelectedIndex=0;$d.Controls.Add($combo)
    $ok=New-MMButton 'Aceptar' 118 112 120 32;$cancel=New-MMButton 'Cancelar' 248 112 120 32;$d.Controls.Add($ok);$d.Controls.Add($cancel);$result=$null
    $ok.Add_Click({$script:mmSideChoice=if($combo.SelectedIndex-eq1){'client'}elseif($combo.SelectedIndex-eq2){'server'}else{'both'};$d.DialogResult=[System.Windows.Forms.DialogResult]::OK;$d.Close()});$cancel.Add_Click({$d.DialogResult=[System.Windows.Forms.DialogResult]::Cancel;$d.Close()})
    $script:mmSideChoice=$null;if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){return [string]$script:mmSideChoice};return $null
}

function Write-MMRequest($Object){Write-ModManagerJson (Join-Path $script:ModManagerDir 'action.json') $Object 15}
function Start-MMAction([string]$Label,$Request){
    if($null-ne$script:mmProcess -and -not$script:mmProcess.HasExited){[System.Windows.Forms.MessageBox]::Show('Ya hay una operación de mods en curso.','Gestor de mods')|Out-Null;return}
    Write-MMRequest $Request;Remove-Item $script:mmLogPath,$script:mmErrPath -Force -ErrorAction SilentlyContinue
    $ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe';$act=Join-Path $PSScriptRoot 'ModManagerAction.ps1'
    $arg='-NoProfile -ExecutionPolicy Bypass -File "'+$act+'"'
    try{$script:mmProcess=Start-Process -FilePath $ps -ArgumentList $arg -PassThru -WindowStyle Hidden -RedirectStandardOutput $script:mmLogPath -RedirectStandardError $script:mmErrPath;$lblOperation.Text='Operación: '+$Label;$lblOperation.ForeColor=$orange;$progress.Style='Marquee';$progress.Visible=$true;$tabs.Enabled=$false;$timer.Start()}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Gestor de mods','OK','Error')|Out-Null}
}
function Load-MMStatus {
    try{$s=Get-ModManagerStatus -SkipRemote;$lblPaths.Text=('Cliente: '+$s.clientPath+"`r`nServidor: "+$s.serverPath);$lblVersion.Text=('Minecraft '+$s.minecraftVersion+' · '+$s.loader+' · Cliente '+$s.clientMods+' mods · Servidor '+$s.serverMods+' mods');$lblGeneration.Text=('Mods PC G'+$s.localGeneration+' / Drive G'+$s.remoteGeneration+' (estado guardado)');if($s.problems -gt 0){$lblGeneration.ForeColor=$red}else{$lblGeneration.ForeColor=$green}}catch{$lblGeneration.Text='Estado mods: '+$_.Exception.Message;$lblGeneration.ForeColor=$red}
}
function Load-MMInventory {
    $o=Read-ModManagerJson $script:ModManagerInventoryPath
    $gridMods.Rows.Clear()
    if($null-eq$o){$lblInstalled.Text='Instalados: inventario pendiente · Pulsa Escanear';return}
    $updates=Read-ModManagerJson $script:ModManagerUpdatesPath;$up=@{};if($null-ne$updates){foreach($u in @($updates.updates)){$up[[string]$u.id]=[string]$u.latest}}
    foreach($m in @($o.mods)){$ver=if($m.versionClient){[string]$m.versionClient}else{[string]$m.versionServer};$latest=if($up.ContainsKey([string]$m.id)){$up[[string]$m.id]}else{''};$src=if([string]$m.source -eq 'modrinth'){'Modrinth'}else{'Pack/local'};[void]$gridMods.Rows.Add($m.name,$m.id,$ver,$m.side,$src,$latest,$m.status,$m.projectId)}
    $lblInstalled.Text=('Instalados: '+@($o.mods).Count+' · Problemas: '+@($o.problems).Count+' · caché local')
}
function Load-MMSearch {
    $o=Read-ModManagerJson $script:ModManagerSearchPath;$gridSearch.Rows.Clear();if($null-eq$o){return};foreach($r in @($o.results)){[void]$gridSearch.Rows.Add($r.title,$r.author,$r.environment,$r.downloads,$r.description,$r.projectId)}
}
function Load-MMValidation {
    $v=Read-ModManagerJson (Join-Path $script:ModManagerDir 'validation.json');$c=Read-ModManagerJson $script:ModManagerCrashPath;$lines=New-Object 'Collections.Generic.List[string]'
    if($null-ne$v){$lines.Add(('VALIDACIÓN: '+$(if($v.ok){'OK'}else{'CON ERRORES'})));foreach($i in @($v.issues)){$lines.Add(('ERROR · '+$i.mod+' · '+$i.issue))};foreach($w in @($v.warnings)){$lines.Add(('AVISO · '+$w.mod+' · '+$w.issue))}}
    if($null-ne$c){$lines.Add('');$lines.Add('ANÁLISIS DEL ÚLTIMO CRASH:');foreach($x in @($c.candidates|Select-Object -First 15)){$lines.Add(('{0} · score {1} · {2}' -f $x.name,$x.score,$x.reason))};$lines.Add([string]$c.note)}
    if($lines.Count-eq0){$lines.Add('Aún no hay resultados. Usa Validar compatibilidad o Analizar último crash.')};$txtSafety.Text=$lines -join "`r`n"
}
function Load-MMLog {
    $raw='';if(Test-Path $script:mmLogPath){$raw+=(Get-Content $script:mmLogPath -Raw -ErrorAction SilentlyContinue)};if(Test-Path $script:mmErrPath){$e=Get-Content $script:mmErrPath -Raw -ErrorAction SilentlyContinue;if($e){$raw+="`r`n"+$e}};if($raw -ne $script:mmLastLog){$script:mmLastLog=$raw;$txtLog.Text=$raw;$txtLog.SelectionStart=$txtLog.TextLength;$txtLog.ScrollToCaret()}
}
function Load-MMTestStatus {
    try{
        $state=Get-ModTestState;$lines=New-Object 'System.Collections.Generic.List[string]'
        if($null-eq$state){
            $lines.Add('No existe todavía un entorno TEST.')
            $lines.Add('Pulsa Crear / reconstruir TEST para buscar todos los mods en Modrinth, resolver dependencias y copiar el mundo.')
            $lblTestMode.Text='TEST: no creado';$lblTestMode.ForeColor=$muted
        } else {
            $running=Get-ModTestServerRunningInfo
            $effectiveClientActive=[bool]$state.clientActive
            $clientMode=if($effectiveClientActive){'TEST preparado en New Cobbleverse'}else{'NORMAL intacto / TEST separado'}
            $serverMode=if($null-ne$running){'TEST EN EJECUCIÓN'}else{'TEST parado'}
            $lines.Add(('Minecraft TEST: {0} · Loader de mods: {1}' -f $state.minecraftVersion,$state.loader))
            if($state.PSObject.Properties.Name -contains 'requiredFabricLoader'){$lines.Add(('Fabric Loader TEST requerido: {0}+' -f [string]$state.requiredFabricLoader))}
            if($state.PSObject.Properties.Name -contains 'testClientProfilePath'){$lines.Add(('Perfil CurseForge TEST: {0}' -f [string]$state.testClientProfilePath))}
            $lines.Add(('Cliente: {0} · Servidor: {1}' -f $clientMode,$serverMode))
            $lines.Add(('Actualizaciones: {0} · Ya actuales: {1} · Conservados: {2} · Dependencias: {3}' -f $state.updated,$state.alreadyLatest,$state.keptCurrent,$state.dependencies))
            if($state.PSObject.Properties.Name -contains 'baselineRestored' -and [int]$state.baselineRestored -gt 0){$lines.Add(('Seguridad: {0} JAR(s) NORMAL restaurados porque faltaban tras actualizar.' -f $state.baselineRestored))}
            if($state.PSObject.Properties.Name -contains 'riskyAddons' -and [int]$state.riskyAddons -gt 0){$lines.Add(('Addons/mods a vigilar: {0} · se mantienen instalados; consulta ADDONS_A_VIGILAR.txt.' -f $state.riskyAddons))}
            $lines.Add(('Mods TEST cliente: {0} · servidor: {1}' -f $state.testClientMods,$state.testServerMods))
            $lines.Add(('Servidor NORMAL: {0}' -f $state.normalServerPath))
            $lines.Add(('Servidor TEST (mundo copia): {0}' -f $state.testServerPath))
            $lines.Add(('Puerto NORMAL: {0} · Puerto TEST: {1}' -f $state.normalPort,$state.testPort))
            $lines.Add('')
            $lines.Add('El servidor TEST usa una COPIA del mundo. No usa lock/deltas y no sincroniza ese mundo con Drive.')
            $lines.Add('Promover TEST cambia únicamente mods/config del NORMAL; el mundo NORMAL se conserva.')
            if($state.PSObject.Properties.Name -contains 'latestPromotionBackup' -and -not[string]::IsNullOrWhiteSpace([string]$state.latestPromotionBackup)){$lines.Add(('Copia anterior de mods/config guardada: {0}' -f $state.latestPromotionBackup))}
            $lblTestMode.Text=('TEST: cliente '+$clientMode+' · '+$serverMode);$lblTestMode.ForeColor=if($effectiveClientActive -or $null-ne$running){$orange}else{$green}
        }
        $txtTestStatus.Text=$lines -join "`r`n"
    }catch{$lblTestMode.Text='TEST: error de estado';$lblTestMode.ForeColor=$red;$txtTestStatus.Text=$_.Exception.Message}
}
function Refresh-MMAll {Load-MMStatus;Load-MMInventory;Load-MMSearch;Load-MMValidation;Load-MMTestStatus;Load-MMLog}

$form=New-Object System.Windows.Forms.Form;$form.Text='Cobbleverse - Gestor de Mods';$form.Size=New-Object System.Drawing.Size(1360,850);$form.MinimumSize=New-Object System.Drawing.Size(1100,700);$form.StartPosition='CenterScreen';$form.BackColor=$dark;$form.ForeColor=$text;$form.Font=New-Object System.Drawing.Font('Segoe UI',9)
$top=New-Object System.Windows.Forms.Panel;$top.Dock='Top';$top.Height=112;$top.BackColor=[System.Drawing.Color]::FromArgb(27,29,36);$form.Controls.Add($top)
$title=New-MMLabel 'Gestor de Mods Cobbleverse' 20 14 480 32 $true;$title.Font=New-Object System.Drawing.Font('Segoe UI Semibold',16);$top.Controls.Add($title)
$lblVersion=New-MMLabel '' 22 54 650 22 $false;$lblVersion.ForeColor=$muted;$top.Controls.Add($lblVersion)
$lblGeneration=New-MMLabel '' 700 20 430 24 $true;$top.Controls.Add($lblGeneration)
$lblPaths=New-MMLabel '' 700 50 620 54 $false;$lblPaths.ForeColor=$muted;$top.Controls.Add($lblPaths)

$tabs=New-Object System.Windows.Forms.TabControl;$tabs.Dock='Fill';$form.Controls.Add($tabs);$tabs.BringToFront()

# Instalados
$tInstalled=New-Object System.Windows.Forms.TabPage;$tInstalled.Text='Instalados';$tInstalled.BackColor=$dark;$tabs.TabPages.Add($tInstalled)|Out-Null
$lblInstalled=New-MMLabel 'Instalados' 14 14 320 24 $true;$tInstalled.Controls.Add($lblInstalled)
$bScan=New-MMButton 'Escanear' 14 46 95 32;$bIdentify=New-MMButton 'Identificar online' 117 46 132 32;$bUpdates=New-MMButton 'Buscar actualizaciones' 257 46 155 32;$bUpdate=New-MMButton 'Actualizar online' 420 46 140 32;$bUpdateJar=New-MMButton 'Actualizar desde .jar' 568 46 158 32;$bUpdateAll=New-MMButton 'Actualizar compatibles' 734 46 155 32;$bRemove=New-MMButton 'Desinstalar' 897 46 100 32;$bImport=New-MMButton 'Importar JAR nuevo' 1005 46 125 32;$bFolders=New-MMButton 'Abrir carpetas' 1138 46 125 32
foreach($b in @($bScan,$bIdentify,$bUpdates,$bUpdate,$bUpdateJar,$bUpdateAll,$bRemove,$bImport,$bFolders)){$tInstalled.Controls.Add($b)}
$gridMods=New-Object System.Windows.Forms.DataGridView;$gridMods.Location=New-Object System.Drawing.Point(14,90);$gridMods.Size=New-Object System.Drawing.Size(1295,470);$gridMods.Anchor='Top,Bottom,Left,Right';$gridMods.ReadOnly=$true;$gridMods.AllowUserToAddRows=$false;$gridMods.SelectionMode='FullRowSelect';$gridMods.MultiSelect=$false;$gridMods.AutoSizeColumnsMode='Fill';$gridMods.BackgroundColor=$panel;$gridMods.ForeColor=[System.Drawing.Color]::Black
foreach($c in @('Nombre','ID','Versión','Ámbito','Origen','Actualización','Estado','ProjectId')){[void]$gridMods.Columns.Add($c,$c)};$gridMods.Columns[7].Visible=$false;$tInstalled.Controls.Add($gridMods)
$hint=New-MMLabel 'Ámbito: both = cliente+servidor; client = solo PCs; server = solo servidor. Para sustituir una versión manualmente, selecciona el mod y usa Actualizar desde .jar.' 14 570 1250 42 $false;$hint.Anchor='Bottom,Left,Right';$hint.ForeColor=$muted;$tInstalled.Controls.Add($hint)

# Buscar
$tSearch=New-Object System.Windows.Forms.TabPage;$tSearch.Text='Buscar / añadir';$tSearch.BackColor=$dark;$tabs.TabPages.Add($tSearch)|Out-Null
$txtQuery=New-Object System.Windows.Forms.TextBox;$txtQuery.Location=New-Object System.Drawing.Point(16,18);$txtQuery.Size=New-Object System.Drawing.Size(500,27);$txtQuery.BackColor=$panel2;$txtQuery.ForeColor=$text;$tSearch.Controls.Add($txtQuery)
$bSearch=New-MMButton 'Buscar compatible' 530 16 160 32;$bAdd=New-MMButton 'Añadir seleccionado' 700 16 170 32;$tSearch.Controls.Add($bSearch);$tSearch.Controls.Add($bAdd)
$searchNote=New-MMLabel ('Busca en Modrinth filtrando automáticamente Minecraft '+[string]$script:Config.MinecraftVersion+' y '+(Get-ModManagerLoader)+'. Las dependencias obligatorias se resuelven solas.') 16 56 1100 42 $false;$searchNote.ForeColor=$muted;$tSearch.Controls.Add($searchNote)
$gridSearch=New-Object System.Windows.Forms.DataGridView;$gridSearch.Location=New-Object System.Drawing.Point(16,105);$gridSearch.Size=New-Object System.Drawing.Size(1290,500);$gridSearch.Anchor='Top,Bottom,Left,Right';$gridSearch.ReadOnly=$true;$gridSearch.AllowUserToAddRows=$false;$gridSearch.SelectionMode='FullRowSelect';$gridSearch.MultiSelect=$false;$gridSearch.AutoSizeColumnsMode='Fill';$gridSearch.BackgroundColor=$panel;$gridSearch.ForeColor=[System.Drawing.Color]::Black
foreach($c in @('Mod','Autor','Entorno','Descargas','Descripción','ProjectId')){[void]$gridSearch.Columns.Add($c,$c)};$gridSearch.Columns[5].Visible=$false;$tSearch.Controls.Add($gridSearch)

# Distribución
$tDist=New-Object System.Windows.Forms.TabPage;$tDist.Text='PCs / servidor';$tDist.BackColor=$dark;$tabs.TabPages.Add($tDist)|Out-Null
$tDist.Controls.Add((New-MMLabel 'Distribución del mismo modset a todos los PCs y copias del servidor' 18 18 760 28 $true))
$bAdopt=New-MMButton 'Adoptar pack actual' 18 62 180 34;$bSync=New-MMButton 'Sincronizar desde Drive' 208 62 190 34;$bPublish=New-MMButton 'Publicar estado local' 408 62 180 34;$tDist.Controls.Add($bAdopt);$tDist.Controls.Add($bSync);$tDist.Controls.Add($bPublish)
$distText=New-Object System.Windows.Forms.TextBox;$distText.Multiline=$true;$distText.ReadOnly=$true;$distText.Location=New-Object System.Drawing.Point(18,116);$distText.Size=New-Object System.Drawing.Size(1180,340);$distText.Anchor='Top,Left,Right';$distText.BackColor=$panel2;$distText.ForeColor=$text;$distText.Font=New-Object System.Drawing.Font('Consolas',10);$distText.Text="Adoptar pack actual:`r`n  Convierte los mods que ya tienes en CurseForge + servidor en el modset gestionado.`r`n`r`nSincronizar desde Drive:`r`n  Deja ESTE PC exactamente con las versiones publicadas: cliente y servidor.`r`n`r`nPublicar estado local:`r`n  Publica manualmente lo que haya actualmente instalado. Úsalo después de un rollback si decides conservarlo.`r`n`r`nLos JAR se guardan aparte en Drive bajo mod-manager-v1. El sistema normal del mundo sigue excluyendo /mods/**, así que no se mezcla con las generaciones del mundo.";$tDist.Controls.Add($distText)

# Entorno TEST masivo
$tTest=New-Object System.Windows.Forms.TabPage;$tTest.Text='TEST masivo';$tTest.BackColor=$dark;$tabs.TabPages.Add($tTest)|Out-Null
$tTest.Controls.Add((New-MMLabel 'Actualizar TODO desde Modrinth en una copia aislada antes de tocar el pack normal' 18 16 950 28 $true))
$tTest.Controls.Add((New-MMLabel 'Minecraft objetivo:' 18 54 145 24 $false))
$txtTestMc=New-Object System.Windows.Forms.TextBox;$txtTestMc.Location=New-Object System.Drawing.Point(160,52);$txtTestMc.Size=New-Object System.Drawing.Size(100,26);$txtTestMc.Text=[string]$script:Config.MinecraftVersion;$tTest.Controls.Add($txtTestMc)
$lblTestMode=New-MMLabel 'TEST: no creado' 282 54 620 24 $true;$lblTestMode.ForeColor=$muted;$tTest.Controls.Add($lblTestMode)
$bBuildTest=New-MMButton 'Crear / reconstruir TEST' 18 92 190 34
$bActivateTest=New-MMButton 'Activar cliente TEST' 218 92 165 34
$bRestoreNormal=New-MMButton 'Volver cliente a NORMAL' 393 92 185 34
$bStartTest=New-MMButton 'Iniciar servidor TEST' 588 92 170 34
$bPromoteTest=New-MMButton 'Promover TEST a NORMAL' 768 92 190 34
$bOpenTest=New-MMButton 'Abrir carpetas TEST' 968 92 160 34
foreach($b in @($bBuildTest,$bActivateTest,$bRestoreNormal,$bStartTest,$bPromoteTest,$bOpenTest)){$tTest.Controls.Add($b)}
$bDeleteTest=New-MMButton 'Borrar entorno TEST' 18 136 170 34
$bDeleteOld=New-MMButton 'Borrar copia anterior' 198 136 170 34
$bRiskReport=New-MMButton 'Ver addons a vigilar' 378 136 170 34
$tTest.Controls.Add($bDeleteTest);$tTest.Controls.Add($bDeleteOld);$tTest.Controls.Add($bRiskReport)
$testHint=New-MMLabel 'Flujo: 1) crear TEST → 2) copiarlo al perfil CurseForge New Cobbleverse → 3) iniciar servidor TEST → 4) jugar con ese perfil → 5) volver al perfil NORMAL o promover. El NORMAL no se sustituye.' 560 136 730 52 $false;$testHint.ForeColor=$muted;$tTest.Controls.Add($testHint)
$txtTestStatus=New-Object System.Windows.Forms.TextBox;$txtTestStatus.Multiline=$true;$txtTestStatus.ReadOnly=$true;$txtTestStatus.ScrollBars='Vertical';$txtTestStatus.Location=New-Object System.Drawing.Point(18,204);$txtTestStatus.Size=New-Object System.Drawing.Size(1288,385);$txtTestStatus.Anchor='Top,Bottom,Left,Right';$txtTestStatus.BackColor=$panel2;$txtTestStatus.ForeColor=$text;$txtTestStatus.Font=New-Object System.Drawing.Font('Consolas',9);$tTest.Controls.Add($txtTestStatus)

# Seguridad
$tSafe=New-Object System.Windows.Forms.TabPage;$tSafe.Text='Compatibilidad / errores';$tSafe.BackColor=$dark;$tabs.TabPages.Add($tSafe)|Out-Null
$bValidate=New-MMButton 'Validar compatibilidad' 16 16 190 34;$bCrash=New-MMButton 'Analizar último crash' 216 16 180 34;$bRollback=New-MMButton 'Deshacer última actualización' 406 16 220 34;$tSafe.Controls.Add($bValidate);$tSafe.Controls.Add($bCrash);$tSafe.Controls.Add($bRollback)
$txtSafety=New-Object System.Windows.Forms.TextBox;$txtSafety.Multiline=$true;$txtSafety.ReadOnly=$true;$txtSafety.ScrollBars='Vertical';$txtSafety.Location=New-Object System.Drawing.Point(16,68);$txtSafety.Size=New-Object System.Drawing.Size(1290,520);$txtSafety.Anchor='Top,Bottom,Left,Right';$txtSafety.BackColor=$panel2;$txtSafety.ForeColor=$text;$txtSafety.Font=New-Object System.Drawing.Font('Consolas',9);$tSafe.Controls.Add($txtSafety)

# Bottom status/log
$bottom=New-Object System.Windows.Forms.Panel;$bottom.Dock='Bottom';$bottom.Height=145;$bottom.BackColor=$panel;$form.Controls.Add($bottom);$bottom.BringToFront()
$lblOperation=New-MMLabel 'Preparado' 12 8 850 22 $true;$bottom.Controls.Add($lblOperation)
$progress=New-Object System.Windows.Forms.ProgressBar;$progress.Location=New-Object System.Drawing.Point(880,9);$progress.Size=New-Object System.Drawing.Size(420,18);$progress.Visible=$false;$bottom.Controls.Add($progress)
$txtLog=New-Object System.Windows.Forms.TextBox;$txtLog.Multiline=$true;$txtLog.ReadOnly=$true;$txtLog.ScrollBars='Vertical';$txtLog.Location=New-Object System.Drawing.Point(12,36);$txtLog.Size=New-Object System.Drawing.Size(1290,98);$txtLog.Anchor='Top,Bottom,Left,Right';$txtLog.BackColor=[System.Drawing.Color]::Black;$txtLog.ForeColor=[System.Drawing.Color]::Gainsboro;$txtLog.Font=New-Object System.Drawing.Font('Consolas',8.5);$bottom.Controls.Add($txtLog)

$bScan.Add_Click({Start-MMAction 'Escanear mods' @{action='scan'}})
$bIdentify.Add_Click({Start-MMAction 'Identificar mods en Modrinth' @{action='resolve-online'}})
$bUpdates.Add_Click({Start-MMAction 'Buscar actualizaciones' @{action='check-updates'}})
$bUpdate.Add_Click({if($gridMods.SelectedRows.Count-eq0){return};$projectIdValue=[string]$gridMods.SelectedRows[0].Cells[7].Value;if([string]::IsNullOrWhiteSpace($projectIdValue)){[System.Windows.Forms.MessageBox]::Show('Este mod todavía no está identificado en Modrinth. Pulsa Identificar online. Si no existe allí, actualízalo importando manualmente el JAR.','Gestor de mods')|Out-Null;return};Start-MMAction 'Actualizar mod' @{action='update-project';projectId=$projectIdValue}})
$bUpdateJar.Add_Click({if($gridMods.SelectedRows.Count-eq0){[System.Windows.Forms.MessageBox]::Show('Selecciona primero el mod que quieres actualizar.','Gestor de mods')|Out-Null;return};$modIdValue=[string]$gridMods.SelectedRows[0].Cells[1].Value;$modName=[string]$gridMods.SelectedRows[0].Cells[0].Value;$modSide=[string]$gridMods.SelectedRows[0].Cells[3].Value;$dlg=New-Object System.Windows.Forms.OpenFileDialog;$dlg.Filter='Minecraft mod (*.jar)|*.jar';$dlg.Title=('Selecciona la nueva versión de '+$modName);if($dlg.ShowDialog() -ne 'OK'){return};$msg=("Se actualizará '{0}' desde el JAR seleccionado.`r`n`r`nÁmbito actual: {1}`r`nEl JAR anterior se quitará automáticamente y se conservará en la transacción de rollback.`r`nEl nuevo modset se publicará para el otro PC.`r`n`r`n¿Continuar?" -f $modName,$modSide);if([System.Windows.Forms.MessageBox]::Show($msg,'Actualizar desde .jar','YesNo','Question') -eq 'Yes'){Start-MMAction 'Actualizar desde JAR' @{action='update-local-jar';jarPath=$dlg.FileName;modId=$modIdValue}}})
$bUpdateAll.Add_Click({if([System.Windows.Forms.MessageBox]::Show('Se actualizarán solo los mods identificados con una versión compatible para este Minecraft/loader, incluyendo dependencias. ¿Continuar?','Gestor de mods','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Actualizar todos los compatibles' @{action='update-all'}}})
$bRemove.Add_Click({if($gridMods.SelectedRows.Count-eq0){return};$id=[string]$gridMods.SelectedRows[0].Cells[1].Value;$name=[string]$gridMods.SelectedRows[0].Cells[0].Value;if([System.Windows.Forms.MessageBox]::Show(('¿Desinstalar '+$name+'? Se quitará de cliente/servidor según su ámbito y se publicará el nuevo modset.'),'Gestor de mods','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Desinstalar mod' @{action='remove';modId=$id}}})
$bImport.Add_Click({$dlg=New-Object System.Windows.Forms.OpenFileDialog;$dlg.Filter='Minecraft mod (*.jar)|*.jar';if($dlg.ShowDialog() -ne 'OK'){return};$side=Select-ModSide;if([string]::IsNullOrWhiteSpace($side)){return};Start-MMAction 'Importar JAR' @{action='import-jar';jarPath=$dlg.FileName;side=$side}})
$bFolders.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+(Get-ModManagerClientModsDir)+'"');Start-Process explorer.exe -ArgumentList ('"'+(Get-ModManagerServerModsDir)+'"')})
$bSearch.Add_Click({Start-MMAction 'Buscar mods' @{action='search';query=$txtQuery.Text}})
$txtQuery.Add_KeyDown({if($_.KeyCode -eq 'Enter'){$_.SuppressKeyPress=$true;$bSearch.PerformClick()}})
$bAdd.Add_Click({if($gridSearch.SelectedRows.Count-eq0){return};$projectIdValue=[string]$gridSearch.SelectedRows[0].Cells[5].Value;$name=[string]$gridSearch.SelectedRows[0].Cells[0].Value;if([System.Windows.Forms.MessageBox]::Show(('Añadir '+$name+' y sus dependencias obligatorias?'),'Gestor de mods','YesNo','Question') -eq 'Yes'){Start-MMAction 'Añadir mod' @{action='add-modrinth';projectId=$projectIdValue}}})
$bAdopt.Add_Click({if([System.Windows.Forms.MessageBox]::Show('Esto publicará el pack actual de ESTE PC como referencia compartida. Hazlo primero en el PC cuya instalación cliente+servidor consideras correcta. ¿Continuar?','Adoptar pack','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Adoptar pack actual' @{action='adopt'}}})
$bSync.Add_Click({if([System.Windows.Forms.MessageBox]::Show('Se ajustarán las carpetas mods del cliente y del servidor de ESTE PC para coincidir exactamente con Drive. Se crea rollback antes de tocar nada. ¿Continuar?','Sincronizar mods','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Sincronizar mods desde Drive' @{action='sync'}}})
$bPublish.Add_Click({if([System.Windows.Forms.MessageBox]::Show('Publicar el estado actual como nueva referencia compartida?','Publicar mods','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Publicar mods' @{action='publish'}}})
$bBuildTest.Add_Click({$mc=[string]$txtTestMc.Text;if([string]::IsNullOrWhiteSpace($mc)){[System.Windows.Forms.MessageBox]::Show('Indica la versión de Minecraft para la prueba.','TEST masivo')|Out-Null;return};$msg="Se creará/recreará un entorno TEST COMPLETAMENTE LOCAL.`r`n`r`n- Cliente TEST separado: New Cobbleverse (Minecraft 1.21.1 + Fabric Loader 0.19.5+).`r`n- El perfil NORMAL NO se sustituye.`r`n- Cobblemon se actualizará a 1.8.1 si sigue siendo la versión objetivo seleccionada.`r`n- Better Pokédex Scanner y Reese's Sodium Options se excluirán SOLO del TEST por las incompatibilidades confirmadas.`r`n- Iris 1.8.8 usará Sodium 0.6.13 para mantener una pareja compatible.`r`n- Las dependencias obligatorias se propagarán al cliente/servidor donde las necesite el mod padre.`r`n- El servidor TEST usará Fabric Loader 0.19.5 sin modificar el servidor NORMAL.`r`n- Se copiará el mundo a una carpeta TEST independiente y NO se subirá a Drive.`r`n`r`nEl servidor normal debe estar apagado. ¿Continuar?";if([System.Windows.Forms.MessageBox]::Show($msg,'Crear entorno TEST','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Crear entorno TEST completo' @{action='build-test-pack';minecraftVersion=$mc}}})
$bActivateTest.Add_Click({if([System.Windows.Forms.MessageBox]::Show("Se copiarán los mods/config TEST al perfil CurseForge separado:`r`n`r`nNew Cobbleverse`r`n`r`nEl perfil NORMAL no se tocará. Después abre 'New Cobbleverse' en CurseForge y conecta al servidor TEST.",'Activar cliente TEST','YesNo','Question') -eq 'Yes'){Start-MMAction 'Activar cliente TEST' @{action='activate-test-client'}}})
$bRestoreNormal.Add_Click({Start-MMAction 'Restaurar cliente NORMAL' @{action='restore-normal-client'}})
$bStartTest.Add_Click({if([System.Windows.Forms.MessageBox]::Show("Se abrirá una consola con el servidor TEST y el MUNDO COPIA.`r`nNo usa la sincronización normal de Drive.`r`n`r`nPara cerrarlo correctamente escribe stop en esa consola.",'Servidor TEST','YesNo','Question') -eq 'Yes'){Start-MMAction 'Iniciar servidor TEST' @{action='start-test-server'}}})
$bPromoteTest.Add_Click({$msg="PROMOVER hará que los mods/config probados pasen a ser los NORMALES y publicará ese modset para el otro PC.`r`n`r`nIMPORTANTE: el mundo NORMAL NO se sustituye por el mundo de prueba. Se conserva el mundo real actual.`r`n`r`nAntes se guardará una copia de los mods/config anteriores y NO se borrará hasta que tú pulses 'Borrar copia anterior'.`r`n`r`n¿Promover el TEST?";if([System.Windows.Forms.MessageBox]::Show($msg,'Promover TEST a NORMAL','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Promover TEST a NORMAL' @{action='promote-test'}}})
$bOpenTest.Add_Click({$st=Get-ModTestState;if($null-eq$st){return};if(Test-Path ([string]$st.testServerPath)){Start-Process explorer.exe -ArgumentList ('"'+[string]$st.testServerPath+'"')};if(Test-Path $script:ModTestClientModsDir){Start-Process explorer.exe -ArgumentList ('"'+$script:ModTestClientModsDir+'"')};$tp=Get-ModTestClientInstancePath;if(Test-Path -LiteralPath $tp){Start-Process explorer.exe -ArgumentList ('"'+$tp+'"')}})
$bRiskReport.Add_Click({Initialize-ModTestPaths;if(Test-Path -LiteralPath $script:ModTestRiskTextPath){Start-Process notepad.exe -ArgumentList ('"'+$script:ModTestRiskTextPath+'"')}else{[System.Windows.Forms.MessageBox]::Show('Todavía no existe informe. Crea/reconstruye el TEST primero.','Addons a vigilar')|Out-Null}})
$bDeleteTest.Add_Click({if([System.Windows.Forms.MessageBox]::Show('¿Borrar el entorno TEST, incluida la COPIA DEL MUNDO de prueba? El mundo NORMAL no se tocará.','Borrar TEST','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Borrar entorno TEST' @{action='delete-test'}}})
$bDeleteOld.Add_Click({if([System.Windows.Forms.MessageBox]::Show('¿Borrar definitivamente la copia anterior de mods/config guardada tras la promoción? Hazlo solo cuando estés seguro de que el pack nuevo funciona.','Borrar copia anterior','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Borrar copia anterior' @{action='delete-promotion-backup'}}})

$bValidate.Add_Click({Start-MMAction 'Validar compatibilidad' @{action='validate'}})
$bCrash.Add_Click({Start-MMAction 'Analizar crash' @{action='analyze-crash'}})
$bRollback.Add_Click({if([System.Windows.Forms.MessageBox]::Show('Deshacer localmente la última modificación de mods? No se publicará automáticamente en Drive.','Rollback mods','YesNo','Warning') -eq 'Yes'){Start-MMAction 'Deshacer mods' @{action='rollback'}}})

$timer=New-Object System.Windows.Forms.Timer;$timer.Interval=650;$timer.Add_Tick({Load-MMLog;if($null-ne$script:mmProcess -and $script:mmProcess.HasExited){$exit=$script:mmProcess.ExitCode;$timer.Stop();$progress.Visible=$false;$tabs.Enabled=$true;$lblOperation.Text=if($exit-eq0){'Operación completada'}else{'Operación terminada con error'};$lblOperation.ForeColor=if($exit-eq0){$green}else{$red};$script:mmProcess.Dispose();$script:mmProcess=$null;Refresh-MMAll}})
$form.Add_Shown({try{Refresh-MMAll;$lblOperation.Text='Preparado · Usa Escanear para refrescar el inventario completo';$lblOperation.ForeColor=$green}catch{$lblOperation.Text='Error al cargar estado: '+$_.Exception.Message;$lblOperation.ForeColor=$red;try{Load-MMLog}catch{}}})
$form.Add_FormClosing({if($null-ne$script:mmProcess -and -not$script:mmProcess.HasExited){if([System.Windows.Forms.MessageBox]::Show('Hay una operación de mods en curso. ¿Cerrar igualmente?','Gestor de mods','YesNo','Warning') -ne 'Yes'){$_.Cancel=$true}}})
[void]$form.ShowDialog()
