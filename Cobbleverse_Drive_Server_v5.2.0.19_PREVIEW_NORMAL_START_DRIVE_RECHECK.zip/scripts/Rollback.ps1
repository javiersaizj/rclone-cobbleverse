﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
. (Join-Path $PSScriptRoot "DeltaSync.ps1")
$session=$null; $heartbeat=$null
try {
    Initialize-CobbleverseEnvironment
    if ($null -ne (Get-DirtyMarker)) { throw "Hay una sesion local pendiente de recuperar. Ejecuta primero 02_INICIAR_COBBLEVERSE.bat y usa RECUPERAR." }
    $session=Acquire-GameplayLock
    $heartbeat=Start-LockHeartbeat -SessionId $session
    Set-GameplayLockStatus -SessionId $session -Status "rollback-local-backup"

    # Primero este PC se pone exactamente en el estado compartido actual.
    $null = Apply-RemoteDeltaChanges
    $before = Get-FastManifestData

    Write-Host "=== BACKUPS LOCALES DE ESTE PC ===" -ForegroundColor Green
    Invoke-Restic -Arguments @("snapshots", "--host", $env:COMPUTERNAME) | Out-Null
    $id=Read-Host "Escribe el ID del snapshot LOCAL que quieres restaurar"
    if ([string]::IsNullOrWhiteSpace($id)) { throw "ID vacio." }
    $answer=Read-Host "Esto convertira ese backup en el estado compartido actual. Escribe RESTAURAR"
    if ($answer -cne 'RESTAURAR') { throw "Cancelado." }

    Restore-LocalSnapshotToServer -SnapshotId $id
    Normalize-ServerProperties
    $after = Get-FastManifestData
    $published = Publish-DeltaChanges -BeforeManifest $before -AfterManifest $after -SessionId $session -Reason "rollback-$id"
    Write-Host ("Rollback completado y publicado como generacion {0}; {1} archivos transferidos." -f $published.generation,$published.changed) -ForegroundColor Green
    Release-GameplayLock -SessionId $session; $session=$null
}
catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
finally { Stop-LockHeartbeat -Job $heartbeat; if($null -ne $session){Release-GameplayLock -SessionId $session} }
