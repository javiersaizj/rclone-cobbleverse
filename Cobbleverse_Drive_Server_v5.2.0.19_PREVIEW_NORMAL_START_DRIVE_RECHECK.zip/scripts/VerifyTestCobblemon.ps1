Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'ModManagerCore.ps1')
. (Join-Path $PSScriptRoot 'ModTestCore.ps1')
Initialize-App
Initialize-ModManagerPaths
Initialize-ModTestPaths

function Show-CobblemonInDir {
    param([string]$Label,[string]$Dir)
    Write-Host ''
    Write-Host ("=== {0} ===" -f $Label) -ForegroundColor Cyan
    Write-Host $Dir -ForegroundColor DarkGray
    if(-not(Test-Path -LiteralPath $Dir -PathType Container)){Write-Host 'Carpeta no existe.' -ForegroundColor Red;return}
    $found=$false
    foreach($f in @(Get-ChildItem -LiteralPath $Dir -File -Filter '*.jar' -ErrorAction SilentlyContinue)){
        $id=Get-ModTestJarPrimaryId -Path $f.FullName
        if(([string]$id).ToLowerInvariant() -ne 'cobblemon'){continue}
        $found=$true
        $m=Get-JarModMetadata -Path $f.FullName -Presence 'unknown' -SourceMap (Get-ModManagerSourceMap)
        Write-Host ("Archivo:  {0}" -f $f.Name) -ForegroundColor White
        Write-Host ("ID:       {0}" -f [string]$m.id) -ForegroundColor White
        Write-Host ("Version:  {0}" -f [string]$m.version) -ForegroundColor Green
        Write-Host ("SHA1:     {0}" -f [string]$m.sha1) -ForegroundColor DarkGray
        Write-Host ("SHA256:   {0}" -f [string]$m.sha256) -ForegroundColor DarkGray
    }
    if(-not$found){Write-Host 'No se encontró ningún JAR con id=cobblemon.' -ForegroundColor Red}
}

$ready=Get-ModTestReady
Write-Host '=== SELLO READY ===' -ForegroundColor Cyan
if($null-eq$ready){
    Write-Host 'No existe test-ready.json: el TEST no está terminado/validado.' -ForegroundColor Red
}else{
    Write-Host ("Builder: {0}" -f [string]$ready.builderVersion) -ForegroundColor White
    $foundReady=$false
    foreach($x in @($ready.items)){
        if(@($x.ids) -contains 'cobblemon'){
            $foundReady=$true
            Write-Host ("Cobblemon esperado: {0} [{1}]" -f [string]$x.versionNumber,[string]$x.versionId) -ForegroundColor Magenta
            Write-Host ("Archivo esperado:   {0}" -f [string]$x.fileName) -ForegroundColor Magenta
            Write-Host ("SHA1 esperado:      {0}" -f [string]$x.sha1) -ForegroundColor DarkGray
        }
    }
    if(-not$foundReady){Write-Host 'El sello READY no contiene Cobblemon como root seleccionado.' -ForegroundColor Yellow}
}

$state=Get-ModTestState
Show-CobblemonInDir -Label 'TEST CLIENTE PREPARADO' -Dir $script:ModTestClientModsDir
if($null-ne$state -and -not[string]::IsNullOrWhiteSpace([string]$state.testServerPath)){
    Show-CobblemonInDir -Label 'TEST SERVIDOR' -Dir (Join-Path ([string]$state.testServerPath) 'mods')
}else{
    Write-Host ''
    Write-Host 'No hay estado TEST guardado.' -ForegroundColor Yellow
}

$instance=Get-ModManagerClientInstancePath
Show-CobblemonInDir -Label 'PERFIL CURSEFORGE ACTUAL' -Dir (Join-Path $instance 'mods')

Write-Host ''
Write-Host 'Pulsa ENTER para cerrar.' -ForegroundColor DarkGray
[void][Console]::ReadLine()
