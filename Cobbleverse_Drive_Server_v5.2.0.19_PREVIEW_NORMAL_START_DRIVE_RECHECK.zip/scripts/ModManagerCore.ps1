﻿# Cobbleverse Mod Manager core. Deliberately isolated from the world/delta sync.
# Compatible with Windows PowerShell 5.1.
Set-StrictMode -Version 2.0

function Initialize-ModManagerPaths {
    $script:ModManagerDir = Join-Path $script:DataDir 'mod-manager'
    $script:ModManagerStageDir = Join-Path $script:ModManagerDir 'staging'
    $script:ModManagerBackupDir = Join-Path $script:ModManagerDir 'transactions'
    $script:ModManagerInventoryPath = Join-Path $script:ModManagerDir 'inventory.json'
    $script:ModManagerStatusPath = Join-Path $script:ModManagerDir 'status.json'
    $script:ModManagerSearchPath = Join-Path $script:ModManagerDir 'search-results.json'
    $script:ModManagerUpdatesPath = Join-Path $script:ModManagerDir 'updates.json'
    $script:ModManagerCrashPath = Join-Path $script:ModManagerDir 'crash-analysis.json'
    $script:ModManagerSourceMapPath = Join-Path $script:ModManagerDir 'source-map.json'
    $script:ModManagerLocalStatePath = Join-Path $script:ModManagerDir 'local-state.json'
    $script:ModManagerLastTransactionPath = Join-Path $script:ModManagerDir 'last-transaction.json'
    $script:RemoteModsRoot = "$script:RemoteRoot/mod-manager-v1"
    $script:RemoteModsControl = "$script:RemoteModsRoot/control"
    $script:RemoteModsManifest = "$script:RemoteModsControl/manifest.json"
    $script:RemoteModsPackages = "$script:RemoteModsRoot/packages"
    $script:RemoteModsHistory = "$script:RemoteModsRoot/history"
    $script:RemoteModsClients = "$script:RemoteModsRoot/clients"
    New-Item -ItemType Directory -Force -Path $script:ModManagerDir,$script:ModManagerStageDir,$script:ModManagerBackupDir | Out-Null
}

# v5.1.0 HOTFIX: el gestor de mods no necesita inicializar Restic ni el repositorio
# de backups del servidor para poder abrirse. El inicializador completo podía hacer
# que el PowerShell hijo terminase antes de mostrar la ventana.
function Initialize-ModManagerEnvironment {
    Load-CobbleverseConfig

    foreach($dir in @($script:DataDir,$script:ToolsDir,$script:ServerDir)){
        if(-not [string]::IsNullOrWhiteSpace([string]$dir)){
            New-Item -ItemType Directory -Force -Path $dir | Out-Null
        }
    }

    if(Test-Path -LiteralPath $script:RcloneConfig){
        $env:RCLONE_CONFIG=$script:RcloneConfig
    }

    Initialize-ModManagerPaths
}

function Assert-ModManagerDriveReady {
    if(-not(Test-Path -LiteralPath $script:RcloneExe)){
        throw 'Falta rclone. Ejecuta primero 00_INSTALAR_Y_CONFIGURAR.bat.'
    }
    if(-not(Test-Path -LiteralPath $script:RcloneConfig)){
        throw 'Falta la configuración de Google Drive. Ejecuta primero 00_INSTALAR_Y_CONFIGURAR.bat.'
    }
    $env:RCLONE_CONFIG=$script:RcloneConfig
}


function Get-ModManagerLoader {
    if ($script:Config.PSObject.Properties.Name -contains 'ModManagerLoader') {
        $x=([string]$script:Config.ModManagerLoader).Trim().ToLowerInvariant(); if($x){return $x}
    }
    if(Test-Path (Join-Path $script:ServerDir '.fabric')){return 'fabric'}
    if(Test-Path (Join-Path $script:ServerDir 'libraries\net\neoforged')){return 'neoforge'}
    if(Test-Path (Join-Path $script:ServerDir 'libraries\net\minecraftforge')){return 'forge'}
    return 'fabric'
}

function Get-ModManagerClientInstancePath {
    $p=''
    if($script:Config.PSObject.Properties.Name -contains 'MinecraftClientInstancePath'){$p=[string]$script:Config.MinecraftClientInstancePath}
    if([string]::IsNullOrWhiteSpace($p)){$p='%USERPROFILE%\curseforge\minecraft\Instances\COBBLEVERSE - Pokemon Adventure [Cobblemon]'}
    return [Environment]::ExpandEnvironmentVariables($p.Trim('"'))
}
function Get-ModManagerClientModsDir { return (Join-Path (Get-ModManagerClientInstancePath) 'mods') }
function Get-ModManagerServerModsDir { return (Join-Path $script:ServerDir 'mods') }

function Write-ModManagerJson { param([string]$Path,$Object,[int]$Depth=20) [IO.File]::WriteAllText($Path,(ConvertTo-Json -InputObject $Object -Depth $Depth),(New-Object Text.UTF8Encoding($false))) }
function Read-ModManagerJson { param([string]$Path) if(-not(Test-Path -LiteralPath $Path)){return $null}; try{return ([IO.File]::ReadAllText($Path)|ConvertFrom-Json)}catch{return $null} }

function Get-ModManagerSourceMap {
    $o=Read-ModManagerJson $script:ModManagerSourceMapPath; $h=@{}
    if($null -ne $o){foreach($p in $o.PSObject.Properties){$h[[string]$p.Name]=$p.Value}}
    return $h
}
function Save-ModManagerSourceMap { param([hashtable]$Map) Write-ModManagerJson $script:ModManagerSourceMapPath $Map 20 }

function Get-ModFileHashes {
    param([string]$Path)
    return [pscustomobject]@{sha256=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant();sha1=(Get-FileHash -LiteralPath $Path -Algorithm SHA1).Hash.ToLowerInvariant()}
}


# Acepta tanto entradas de manifest gestionado (sha256) como filas de inventario
# antiguas/caché (clientSha256/serverSha256). Evita excepciones de StrictMode si
# una estructura previa no contiene directamente la propiedad sha256.
function Get-ModEntrySha256 {
    param($Entry)
    if($null -eq $Entry){return ''}
    foreach($propName in @('sha256','clientSha256','serverSha256')){
        if($Entry.PSObject.Properties.Name -contains $propName){
            $value=[string]$Entry.$propName
            if(-not[string]::IsNullOrWhiteSpace($value)){return $value.Trim().ToLowerInvariant()}
        }
    }
    return ''
}

function Convert-ModEnvironmentToSide {
    param([string]$Environment)
    $e=([string]$Environment).ToLowerInvariant()
    if($e -in @('client_only','singleplayer_only')){return 'client'}
    if($e -in @('server_only','dedicated_server_only')){return 'server'}
    return 'both'
}

function Get-JarModMetadata {
    param([Parameter(Mandatory=$true)][string]$Path,[string]$Presence='unknown',[hashtable]$SourceMap=$null)
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $f=Get-Item -LiteralPath $Path -ErrorAction Stop
    $hash=Get-ModFileHashes $Path
    $id=[IO.Path]::GetFileNameWithoutExtension($f.Name);$name=$id;$version='?';$loader='unknown';$environment='unknown';$depends=@();$breaks=@();$metadataOk=$false
    $zip=$null
    try{
        $zip=[IO.Compression.ZipFile]::OpenRead($Path)
        $fabric=$zip.Entries|Where-Object{$_.FullName -eq 'fabric.mod.json'}|Select-Object -First 1
        if($null -ne $fabric){
            $sr=New-Object IO.StreamReader($fabric.Open());try{$j=$sr.ReadToEnd()|ConvertFrom-Json}finally{$sr.Dispose()}
            $loader='fabric';$metadataOk=$true
            if($j.PSObject.Properties.Name -contains 'id'){$id=[string]$j.id}
            if($j.PSObject.Properties.Name -contains 'name' -and -not[string]::IsNullOrWhiteSpace([string]$j.name)){$name=[string]$j.name}else{$name=$id}
            if($j.PSObject.Properties.Name -contains 'version'){$version=[string]$j.version}
            if($j.PSObject.Properties.Name -contains 'environment'){$environment=[string]$j.environment}
            if($j.PSObject.Properties.Name -contains 'depends' -and $null -ne $j.depends){foreach($p in $j.depends.PSObject.Properties){$depends += [string]$p.Name}}
            if($j.PSObject.Properties.Name -contains 'breaks' -and $null -ne $j.breaks){foreach($p in $j.breaks.PSObject.Properties){$breaks += [string]$p.Name}}
        } else {
            $quilt=$zip.Entries|Where-Object{$_.FullName -eq 'quilt.mod.json'}|Select-Object -First 1
            if($null -ne $quilt){
                $sr=New-Object IO.StreamReader($quilt.Open());try{$j=$sr.ReadToEnd()|ConvertFrom-Json}finally{$sr.Dispose()}
                $loader='quilt';$metadataOk=$true
                try{$id=[string]$j.quilt_loader.id;$version=[string]$j.quilt_loader.version;$name=[string]$j.quilt_loader.metadata.name}catch{}
                if([string]::IsNullOrWhiteSpace($name)){$name=$id}
            } else {
                $toml=$zip.Entries|Where-Object{$_.FullName -in @('META-INF/mods.toml','META-INF/neoforge.mods.toml')}|Select-Object -First 1
                if($null -ne $toml){
                    $loader=if($toml.FullName -like '*neoforge*'){'neoforge'}else{'forge'};$metadataOk=$true
                    $sr=New-Object IO.StreamReader($toml.Open());try{$txt=$sr.ReadToEnd()}finally{$sr.Dispose()}
                    if($txt -match '(?im)^\s*modId\s*=\s*["'']([^"'']+)["'']'){$id=$Matches[1]}
                    if($txt -match '(?im)^\s*displayName\s*=\s*["'']([^"'']+)["'']'){$name=$Matches[1]}else{$name=$id}
                    if($txt -match '(?im)^\s*version\s*=\s*["'']([^"'']+)["'']'){$version=$Matches[1]}
                }
            }
        }
    }catch{}finally{if($null-ne$zip){$zip.Dispose()}}
    $side='both'
    if($environment -eq 'client'){$side='client'}elseif($environment -eq 'server'){$side='server'}elseif($Presence -in @('client','server','both')){$side=$Presence}
    $source='local';$projectId='';$versionId='';$sourceEnvironment='';$sourceUrl=''
    if($null -ne $SourceMap -and $SourceMap.ContainsKey($hash.sha256)){
        $s=$SourceMap[$hash.sha256];$source=[string]$s.source;$projectId=[string]$s.projectId;$versionId=[string]$s.versionId;$sourceEnvironment=[string]$s.environment;$sourceUrl=[string]$s.url
        if(-not[string]::IsNullOrWhiteSpace($sourceEnvironment)){$side=Convert-ModEnvironmentToSide $sourceEnvironment}
    }
    return [pscustomobject][ordered]@{id=$id;name=$name;version=$version;fileName=$f.Name;bytes=[int64]$f.Length;sha256=$hash.sha256;sha1=$hash.sha1;loader=$loader;environment=$environment;side=$side;depends=[string[]]$depends;breaks=[string[]]$breaks;metadataOk=$metadataOk;source=$source;projectId=$projectId;sourceVersionId=$versionId;sourceEnvironment=$sourceEnvironment;sourceUrl=$sourceUrl;path=$f.FullName}
}

function Get-ModManagerInventory {
    Initialize-ModManagerPaths
    $clientDir=Get-ModManagerClientModsDir;$serverDir=Get-ModManagerServerModsDir
    $sourceMap=Get-ModManagerSourceMap
    $client=@();$server=@()
    if(Test-Path -LiteralPath $clientDir){foreach($f in @(Get-ChildItem -LiteralPath $clientDir -File -Filter '*.jar' -ErrorAction SilentlyContinue)){$client += Get-JarModMetadata -Path $f.FullName -Presence 'client' -SourceMap $sourceMap}}
    if(Test-Path -LiteralPath $serverDir){foreach($f in @(Get-ChildItem -LiteralPath $serverDir -File -Filter '*.jar' -ErrorAction SilentlyContinue)){$server += Get-JarModMetadata -Path $f.FullName -Presence 'server' -SourceMap $sourceMap}}
    $keys=@{};foreach($m in @($client+$server)){$k=if([string]::IsNullOrWhiteSpace([string]$m.id)){$m.fileName}else{$m.id};$keys[$k.ToLowerInvariant()]=$true}
    $rows=New-Object 'System.Collections.Generic.List[object]';$problems=New-Object 'System.Collections.Generic.List[string]'
    foreach($k in @($keys.Keys|Sort-Object)){
        $c=@($client|Where-Object{([string]$_.id).ToLowerInvariant() -eq $k});$s=@($server|Where-Object{([string]$_.id).ToLowerInvariant() -eq $k})
        if($c.Count -gt 1){$problems.Add("ID duplicado en cliente: $k")};if($s.Count -gt 1){$problems.Add("ID duplicado en servidor: $k")}
        $cm=if($c.Count){$c[0]}else{$null};$sm=if($s.Count){$s[0]}else{$null}
        $name=if($null-ne$cm){$cm.name}elseif($null-ne$sm){$sm.name}else{$k}
        $side=if($null-ne$cm -and $null-ne$sm){'both'}elseif($null-ne$cm){'client'}else{'server'}
        $status='OK';if($null-ne$cm -and $null-ne$sm -and [string]$cm.sha256 -ne [string]$sm.sha256){$status='VERSIÓN DISTINTA';$problems.Add("Cliente/servidor difieren: $name")}elseif($null-ne$cm -and $null-ne$sm -and [string]$cm.fileName -ne [string]$sm.fileName){$status='NOMBRE DE JAR DISTINTO';$problems.Add("Cliente/servidor usan distinto nombre de JAR: $name")}
        $src=if($null-ne$cm -and [string]$cm.source -ne 'local'){$cm}elseif($null-ne$sm){$sm}else{$cm}
        $rows.Add([pscustomobject][ordered]@{id=$k;name=$name;versionClient=if($null-ne$cm){$cm.version}else{''};versionServer=if($null-ne$sm){$sm.version}else{''};side=$side;clientFile=if($null-ne$cm){$cm.fileName}else{''};serverFile=if($null-ne$sm){$sm.fileName}else{''};clientSha256=if($null-ne$cm){$cm.sha256}else{''};serverSha256=if($null-ne$sm){$sm.sha256}else{''};sha1=if($null-ne$cm){$cm.sha1}elseif($null-ne$sm){$sm.sha1}else{''};bytes=if($null-ne$cm){$cm.bytes}elseif($null-ne$sm){$sm.bytes}else{0};loader=if($null-ne$cm){$cm.loader}elseif($null-ne$sm){$sm.loader}else{'unknown'};depends=if($null-ne$cm){$cm.depends}elseif($null-ne$sm){$sm.depends}else{@()};breaks=if($null-ne$cm){$cm.breaks}elseif($null-ne$sm){$sm.breaks}else{@()};source=if($null-ne$src){$src.source}else{'local'};projectId=if($null-ne$src){$src.projectId}else{''};sourceVersionId=if($null-ne$src){$src.sourceVersionId}else{''};sourceEnvironment=if($null-ne$src){$src.sourceEnvironment}else{''};status=$status})
    }
    $inv=[ordered]@{format='cobbleverse-mod-inventory-v1';utc=[DateTimeOffset]::UtcNow.ToString('o');host=$env:COMPUTERNAME;clientId=(Get-OrCreateClientId);minecraftVersion=[string]$script:Config.MinecraftVersion;loader=(Get-ModManagerLoader);clientPath=(Get-ModManagerClientInstancePath);serverPath=$script:ServerDir;clientCount=$client.Count;serverCount=$server.Count;problems=[string[]]$problems.ToArray();mods=$rows.ToArray()}
    Write-ModManagerJson $script:ModManagerInventoryPath $inv 20
    return $inv
}

function Test-ModManagerInventoryCompatibility {
    param($Inventory)
    $issues=New-Object 'System.Collections.Generic.List[object]';$warnings=New-Object 'System.Collections.Generic.List[object]'
    $ids=@{};foreach($m in @($Inventory.mods)){$ids[[string]$m.id]=$true;if([string]$m.status -ne 'OK'){$issues.Add([pscustomobject]@{mod=$m.name;issue=$m.status})}}
    foreach($m in @($Inventory.mods)){
        foreach($d in @($m.depends)){
            $dep=[string]$d;if($dep -in @('minecraft','java','fabricloader','fabric-loader','quilt_loader')){continue}
            if(-not $ids.ContainsKey($dep)){$warnings.Add([pscustomobject]@{mod=$m.name;issue=("Dependencia declarada no detectada: $dep")})}
        }
        foreach($b in @($m.breaks)){if($ids.ContainsKey([string]$b)){$issues.Add([pscustomobject]@{mod=$m.name;issue=("Incompatible con mod instalado: $b")})}}
    }
    return [pscustomobject]@{ok=($issues.Count -eq 0);issues=$issues.ToArray();warnings=$warnings.ToArray()}
}

function Convert-InventoryToManagedManifest {
    param($Inventory,[int64]$Generation=0,[string]$Reason='adopt')
    $mods=New-Object 'System.Collections.Generic.List[object]'
    foreach($m in @($Inventory.mods)){
        if([string]$m.status -ne 'OK'){continue}
        $sha=if([string]$m.side -eq 'server'){$m.serverSha256}else{$m.clientSha256};$fn=if([string]$m.side -eq 'server'){$m.serverFile}else{$m.clientFile};$ver=if([string]$m.side -eq 'server'){$m.versionServer}else{$m.versionClient}
        $mods.Add([pscustomobject][ordered]@{id=[string]$m.id;name=[string]$m.name;version=[string]$ver;side=[string]$m.side;fileName=[string]$fn;sha256=[string]$sha;sha1=[string]$m.sha1;bytes=[int64]$m.bytes;loader=[string]$m.loader;depends=[string[]]@($m.depends);breaks=[string[]]@($m.breaks);source=[string]$m.source;projectId=[string]$m.projectId;sourceVersionId=[string]$m.sourceVersionId;sourceEnvironment=[string]$m.sourceEnvironment})
    }
    return [ordered]@{format='cobbleverse-modset-v1';generation=$Generation;updatedUtc=[DateTimeOffset]::UtcNow.ToString('o');updatedBy=$env:COMPUTERNAME;reason=$Reason;minecraftVersion=[string]$script:Config.MinecraftVersion;loader=(Get-ModManagerLoader);mods=$mods.ToArray()}
}

function Get-RemoteModManifest {
    Initialize-ModManagerPaths
    $raw=Invoke-RcloneCapture -Arguments @('cat',$script:RemoteModsManifest,'--config',$script:RcloneConfig) -IgnoreExitCode
    if($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)){return $null};try{return ($raw|ConvertFrom-Json)}catch{return $null}
}

function Set-RemoteModManifest {
    param($Manifest)
    Initialize-ModManagerPaths
    Invoke-Rclone -Arguments @('mkdir',$script:RemoteModsControl,'--config',$script:RcloneConfig)|Out-Null
    Invoke-Rclone -Arguments @('mkdir',$script:RemoteModsHistory,'--config',$script:RcloneConfig)|Out-Null
    $tmp=Join-Path $script:ModManagerDir ('manifest-'+[guid]::NewGuid().ToString('N')+'.json');Write-ModManagerJson $tmp $Manifest 30
    try{
        $hist="$script:RemoteModsHistory/g$([int64]$Manifest.generation).json"
        Invoke-Rclone -Arguments @('copyto',$tmp,$hist,'--config',$script:RcloneConfig,'--no-traverse')|Out-Null
        Invoke-Rclone -Arguments @('copyto',$tmp,$script:RemoteModsManifest,'--config',$script:RcloneConfig,'--no-traverse')|Out-Null
    }finally{Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}
}

function Get-LocalModState { Initialize-ModManagerPaths;return (Read-ModManagerJson $script:ModManagerLocalStatePath) }
function Set-LocalModState { param($Manifest) Initialize-ModManagerPaths;Write-ModManagerJson $script:ModManagerLocalStatePath ([ordered]@{generation=[int64]$Manifest.generation;utc=[DateTimeOffset]::UtcNow.ToString('o');host=$env:COMPUTERNAME;manifestHash=(Get-ModManifestDigest $Manifest)}) 10 }
function Get-ModManifestDigest { param($Manifest) $json=ConvertTo-Json $Manifest -Depth 30 -Compress;$sha=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($json)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()} }

function Get-LocalJarForManifestEntry {
    param($Entry)
    $entrySha=Get-ModEntrySha256 $Entry;if([string]::IsNullOrWhiteSpace($entrySha)){return $null}
    $c=Join-Path (Get-ModManagerClientModsDir) ([string]$Entry.fileName);$s=Join-Path (Get-ModManagerServerModsDir) ([string]$Entry.fileName)
    foreach($p in @($c,$s)){if(Test-Path -LiteralPath $p){$h=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant();if($h -eq $entrySha){return $p}}}
    return $null
}

function Ensure-RemoteModPackages {
    param($Manifest)
    Initialize-ModManagerPaths
    $stage=Join-Path $script:ModManagerStageDir ('upload-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $stage|Out-Null
    try{
        foreach($m in @($Manifest.mods)){
            $entrySha=Get-ModEntrySha256 $m;if([string]::IsNullOrWhiteSpace($entrySha)){throw "La entrada de $($m.name) no contiene SHA-256 válido. Pulsa Escanear y vuelve a publicar el modset."}
            $src=Get-LocalJarForManifestEntry $m;if($null-eq$src){throw "No se encuentra localmente el JAR exacto de $($m.name) ($entrySha)."}
            $dst=Join-Path $stage ($entrySha+'.jar');if(-not(Test-Path -LiteralPath $dst)){Copy-Item -LiteralPath $src -Destination $dst -Force}
        }
        Invoke-Rclone -Arguments @('mkdir',$script:RemoteModsPackages,'--config',$script:RcloneConfig)|Out-Null
        Invoke-Rclone -Arguments @('copy',$stage,$script:RemoteModsPackages,'--config',$script:RcloneConfig,'--ignore-existing','--transfers','4','--checkers','8','--drive-chunk-size',(Get-DriveChunkSizeArgument),'--stats','3s','--stats-one-line')|Out-Null
    }finally{Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}
}

function Publish-CurrentModSet {
    param([string]$Reason='manual')
    $inv=Get-ModManagerInventory;$check=Test-ModManagerInventoryCompatibility $inv
    if(-not $check.ok){$msg=(@($check.issues)|ForEach-Object{"$($_.mod): $($_.issue)"}) -join '; ';throw "No se publica porque hay incompatibilidades: $msg"}
    $remote=Get-RemoteModManifest;[int64]$g=1;if($null-ne$remote){try{$g=[int64]$remote.generation+1}catch{}}
    $manifest=Convert-InventoryToManagedManifest -Inventory $inv -Generation $g -Reason $Reason
    Ensure-RemoteModPackages $manifest
    # La huella estática existente actúa como barrera de seguridad para el servidor del otro PC.
    # Se publica antes del manifiesto actual: manifest.json es el commit final del modset.
    Publish-StaticBaseInfo | Out-Null
    Set-RemoteModManifest $manifest
    Set-LocalModState $manifest
    Publish-ModClientState $manifest
    return $manifest
}

function Publish-ModClientState {
    param($Manifest)
    Initialize-ModManagerPaths;$client=Get-OrCreateClientId
    Invoke-Rclone -Arguments @('mkdir',$script:RemoteModsClients,'--config',$script:RcloneConfig)|Out-Null
    $tmp=Join-Path $script:ModManagerDir ('client-'+[guid]::NewGuid().ToString('N')+'.json');$o=[ordered]@{clientId=$client;host=$env:COMPUTERNAME;generation=[int64]$Manifest.generation;utc=[DateTimeOffset]::UtcNow.ToString('o');manifestHash=(Get-ModManifestDigest $Manifest)};Write-ModManagerJson $tmp $o 8
    try{Invoke-Rclone -Arguments @('copyto',$tmp,"$script:RemoteModsClients/$client.json",'--config',$script:RcloneConfig,'--no-traverse')|Out-Null}finally{Remove-Item $tmp -Force -ErrorAction SilentlyContinue}
    try{Invoke-ModManagerRemoteCleanup -Manifest $Manifest|Out-Null}catch{Write-Warning ("No se pudo ejecutar la limpieza segura de paquetes antiguos: {0}" -f $_.Exception.Message)}
}


function Get-RemoteModClients {
    Initialize-ModManagerPaths
    $raw=Invoke-RcloneCapture -Arguments @('lsf',$script:RemoteModsClients,'--files-only','--config',$script:RcloneConfig) -IgnoreExitCode
    if($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace([string]$raw)){return @()}
    $items=New-Object 'System.Collections.Generic.List[object]'
    foreach($line in @($raw -split '\r?\n')){
        $name=([string]$line).Trim()
        if([string]::IsNullOrWhiteSpace($name) -or -not $name.EndsWith('.json',[StringComparison]::OrdinalIgnoreCase)){continue}
        $json=Invoke-RcloneCapture -Arguments @('cat',"$script:RemoteModsClients/$name",'--config',$script:RcloneConfig) -IgnoreExitCode
        if($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace([string]$json)){continue}
        try{$obj=$json|ConvertFrom-Json;if($null-ne$obj){$items.Add($obj)}}catch{}
    }
    return $items.ToArray()
}

function Invoke-ModManagerRemoteCleanup {
    param($Manifest=$null)
    Initialize-ModManagerPaths
    if($null-eq$Manifest){$Manifest=Get-RemoteModManifest}
    if($null-eq$Manifest){return $false}

    $clients=@(Get-RemoteModClients)
    if($clients.Count -lt 2){return $false}
    $manifestHash=Get-ModManifestDigest $Manifest
    foreach($client in $clients){
        try{if([int64]$client.generation -ne [int64]$Manifest.generation){return $false}}catch{return $false}
        if(-not($client.PSObject.Properties.Name -contains 'manifestHash')){return $false}
        if([string]$client.manifestHash -ne [string]$manifestHash){return $false}
    }

    $keep=@{}
    foreach($m in @($Manifest.mods)){
        $sha=Get-ModEntrySha256 $m
        if(-not[string]::IsNullOrWhiteSpace($sha)){$keep[$sha]=$true}
    }

    $raw=Invoke-RcloneCapture -Arguments @('lsf',$script:RemoteModsPackages,'--files-only','--config',$script:RcloneConfig) -IgnoreExitCode
    if($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace([string]$raw)){return $true}

    [int]$deleted=0
    foreach($line in @($raw -split '\r?\n')){
        $name=([string]$line).Trim()
        if([string]::IsNullOrWhiteSpace($name) -or -not $name.EndsWith('.jar',[StringComparison]::OrdinalIgnoreCase)){continue}
        $sha=[IO.Path]::GetFileNameWithoutExtension($name).ToLowerInvariant()
        if($keep.ContainsKey($sha)){continue}

        $remote="$script:RemoteModsPackages/$name"
        $code=Invoke-Rclone -Arguments @('deletefile',$remote,'--config',$script:RcloneConfig,'--drive-use-trash=false') -IgnoreExitCode
        if($code -eq 0){$deleted++}
    }

    if($deleted -gt 0){
        Write-Host ("Limpieza de mods en Drive: {0} paquete(s) antiguo(s) eliminados definitivamente; la papelera no se utiliza." -f $deleted) -ForegroundColor DarkGreen
    }
    return $true
}

function New-ModTransactionBackup {
    param($DesiredManifest,[string]$Reason='apply')
    Initialize-ModManagerPaths;$id=(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6);$root=Join-Path $script:ModManagerBackupDir $id;New-Item -ItemType Directory -Force -Path $root|Out-Null
    $record=[ordered]@{id=$id;utc=[DateTimeOffset]::UtcNow.ToString('o');reason=$Reason;client=@();server=@()}
    foreach($side in @('client','server')){
        $dir=if($side-eq'client'){Get-ModManagerClientModsDir}else{Get-ModManagerServerModsDir};New-Item -ItemType Directory -Force -Path $dir|Out-Null
        $wanted=@{};foreach($m in @($DesiredManifest.mods)){if([string]$m.side -eq $side -or [string]$m.side -eq 'both'){$wanted[[string]$m.fileName]=(Get-ModEntrySha256 $m)}}
        $changes=New-Object 'System.Collections.Generic.List[object]'
        foreach($f in @(Get-ChildItem -LiteralPath $dir -File -Filter '*.jar' -ErrorAction SilentlyContinue)){
            $h=(Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant();$needBackup=(!$wanted.ContainsKey($f.Name) -or $wanted[$f.Name].ToLowerInvariant() -ne $h)
            if($needBackup){$sd=Join-Path $root $side;New-Item -ItemType Directory -Force -Path $sd|Out-Null;Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $sd $f.Name) -Force;$changes.Add([pscustomobject]@{file=$f.Name;existed=$true})}
        }
        foreach($fn in $wanted.Keys){$p=Join-Path $dir $fn;if(-not(Test-Path -LiteralPath $p)){$changes.Add([pscustomobject]@{file=$fn;existed=$false})}}
        $record[$side]=$changes.ToArray()
    }
    Write-ModManagerJson (Join-Path $root 'transaction.json') $record 12;Write-ModManagerJson $script:ModManagerLastTransactionPath $record 12
    Get-ChildItem -LiteralPath $script:ModManagerBackupDir -Directory|Sort-Object LastWriteTime -Descending|Select-Object -Skip 8|Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    return $record
}

function Restore-ModTransaction {
    param([string]$TransactionId='')
    Initialize-ModManagerPaths
    if([string]::IsNullOrWhiteSpace($TransactionId)){$last=Read-ModManagerJson $script:ModManagerLastTransactionPath;if($null-eq$last){throw 'No hay transacción anterior para deshacer.'};$TransactionId=[string]$last.id}
    $root=Join-Path $script:ModManagerBackupDir $TransactionId;$rec=Read-ModManagerJson (Join-Path $root 'transaction.json');if($null-eq$rec){throw "No existe la transacción $TransactionId."}
    foreach($side in @('client','server')){
        $dir=if($side-eq'client'){Get-ModManagerClientModsDir}else{Get-ModManagerServerModsDir};$backup=Join-Path $root $side
        foreach($ch in @($rec.$side)){$dst=Join-Path $dir ([string]$ch.file);if([bool]$ch.existed){$src=Join-Path $backup ([string]$ch.file);if(Test-Path -LiteralPath $src){Copy-Item -LiteralPath $src -Destination $dst -Force}}else{Remove-Item -LiteralPath $dst -Force -ErrorAction SilentlyContinue}}
    }
    Get-ModManagerInventory|Out-Null
}

function Download-RemotePackage {
    param($Entry,[string]$Destination)
    $entrySha=Get-ModEntrySha256 $Entry
    if([string]::IsNullOrWhiteSpace($entrySha)){throw "La entrada de $($Entry.name) no contiene SHA-256 válido."}
    $remote="$script:RemoteModsPackages/$entrySha.jar";Invoke-Rclone -Arguments @('copyto',$remote,$Destination,'--config',$script:RcloneConfig,'--no-traverse')|Out-Null
    $h=(Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash.ToLowerInvariant();if($h -ne $entrySha){throw "Hash incorrecto al descargar $($Entry.name)."}
}

function Apply-RemoteModSet {
    $manifest=Get-RemoteModManifest;if($null-eq$manifest){throw 'Drive todavía no tiene un modset gestionado.'}
    if([string]$manifest.minecraftVersion -ne [string]$script:Config.MinecraftVersion){throw "El modset es para Minecraft $($manifest.minecraftVersion), este servidor usa $($script:Config.MinecraftVersion)."}
    $loader=Get-ModManagerLoader;if([string]$manifest.loader -ne $loader){throw "El modset usa $($manifest.loader), este PC está configurado como $loader."}
    $tx=New-ModTransactionBackup -DesiredManifest $manifest -Reason ("sync-g"+$manifest.generation)
    $work=Join-Path $script:ModManagerStageDir ('apply-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $work|Out-Null
    try{
        foreach($m in @($manifest.mods)){
            $entrySha=Get-ModEntrySha256 $m;if([string]::IsNullOrWhiteSpace($entrySha)){throw "El manifiesto remoto contiene una entrada sin SHA-256 válida ($($m.name)). Vuelve a publicar el modset desde el PC correcto."}
            $pkg=Join-Path $work ($entrySha+'.jar');if(-not(Test-Path -LiteralPath $pkg)){Download-RemotePackage -Entry $m -Destination $pkg}
        }
        foreach($side in @('client','server')){
            $dir=if($side-eq'client'){Get-ModManagerClientModsDir}else{Get-ModManagerServerModsDir};New-Item -ItemType Directory -Force -Path $dir|Out-Null
            $wanted=@{};foreach($m in @($manifest.mods)){if([string]$m.side -eq $side -or [string]$m.side -eq 'both'){$wanted[[string]$m.fileName]=$m}}
            foreach($f in @(Get-ChildItem -LiteralPath $dir -File -Filter '*.jar' -ErrorAction SilentlyContinue)){if(-not $wanted.ContainsKey($f.Name)){Remove-Item -LiteralPath $f.FullName -Force}}
            foreach($fn in $wanted.Keys){$m=$wanted[$fn];$entrySha=Get-ModEntrySha256 $m;if([string]::IsNullOrWhiteSpace($entrySha)){throw "La entrada remota de $($m.name) no contiene SHA-256 válida."};$dst=Join-Path $dir $fn;$ok=$false;if(Test-Path -LiteralPath $dst){$h=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant();$ok=($h -eq $entrySha)};if(-not$ok){Copy-Item -LiteralPath (Join-Path $work ($entrySha+'.jar')) -Destination $dst -Force}}
        }
        Set-LocalModState $manifest;Publish-ModClientState $manifest;Get-ModManagerInventory|Out-Null;Publish-StaticBaseInfo|Out-Null
    }catch{Restore-ModTransaction -TransactionId ([string]$tx.id);throw}finally{Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue}
    return $manifest
}

function Invoke-ModrinthJson {
    param([string]$Method='GET',[string]$Url,$Body=$null)
    $headers=@{'User-Agent'='CobbleverseServerManager/5.2.0.13 (local mod manager)';'Accept'='application/json'}
    for($attempt=1;$attempt -le 4;$attempt++){
        try{
            if($Method -eq 'POST'){return Invoke-RestMethod -Method Post -Uri $Url -Headers $headers -ContentType 'application/json' -Body (ConvertTo-Json $Body -Depth 15 -Compress) -UseBasicParsing}
            return Invoke-RestMethod -Method Get -Uri $Url -Headers $headers -UseBasicParsing
        }catch{
            $statusCode=0
            try{if($null-ne$_.Exception.Response){$statusCode=[int]$_.Exception.Response.StatusCode}}catch{}
            if($attempt -lt 4 -and ($statusCode -eq 429 -or $statusCode -ge 500)){
                Start-Sleep -Seconds ([Math]::Min(8,2*$attempt))
                continue
            }
            throw
        }
    }
}

function Search-ModrinthMods {
    param([string]$Query)
    $mc=[uri]::EscapeDataString([string]$script:Config.MinecraftVersion);$loader=[uri]::EscapeDataString((Get-ModManagerLoader));$facets='[["project_type:mod"],["versions:'+([string]$script:Config.MinecraftVersion)+'"],["categories:'+(Get-ModManagerLoader)+'"]]';$url='https://api.modrinth.com/v2/search?limit=40&index=relevance&query='+[uri]::EscapeDataString($Query)+'&facets='+[uri]::EscapeDataString($facets)
    $r=Invoke-ModrinthJson -Url $url;$rows=New-Object 'System.Collections.Generic.List[object]'
    foreach($h in @($r.hits)){$rows.Add([pscustomobject]@{projectId=[string]$h.project_id;title=[string]$h.title;author=[string]$h.author;description=[string]$h.description;downloads=[int64]$h.downloads;environment=(@($h.environment)-join ',');versions=(@($h.versions)-join ',');icon=[string]$h.icon_url})}
    Write-ModManagerJson $script:ModManagerSearchPath ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');query=$Query;results=$rows.ToArray()}) 15
    return $rows.ToArray()
}

function Get-ModrinthCompatibleVersion {
    param([string]$ProjectId)
    $targetGame=([string]$script:Config.MinecraftVersion).Trim()
    $targetLoader=([string](Get-ModManagerLoader)).Trim().ToLowerInvariant()
    $loadersJson=ConvertTo-Json @($targetLoader) -Compress
    $gamesJson=ConvertTo-Json @($targetGame) -Compress
    $url='https://api.modrinth.com/v2/project/'+[uri]::EscapeDataString($ProjectId)+'/version?loaders='+[uri]::EscapeDataString($loadersJson)+'&game_versions='+[uri]::EscapeDataString($gamesJson)+'&include_changelog=false'
    $all=@(Invoke-ModrinthJson -Url $url);if($all.Count -eq 0){return $null}
    $bestRelease=$null;$bestReleaseDate=[DateTimeOffset]::MinValue;$bestAny=$null;$bestAnyDate=[DateTimeOffset]::MinValue
    foreach($v in $all){
        $games=@($v.game_versions|ForEach-Object{([string]$_).Trim()});$loaders=@($v.loaders|ForEach-Object{([string]$_).Trim().ToLowerInvariant()})
        if(-not(($games -contains $targetGame) -and ($loaders -contains $targetLoader))){continue}
        $published=[DateTimeOffset]::MinValue;try{$published=[DateTimeOffset]::Parse([string]$v.date_published,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)}catch{}
        if($published -gt $bestAnyDate){$bestAny=$v;$bestAnyDate=$published}
        if((([string]$v.version_type).Trim().ToLowerInvariant() -eq 'release') -and $published -gt $bestReleaseDate){$bestRelease=$v;$bestReleaseDate=$published}
    }
    if($null-ne$bestRelease){return $bestRelease};return $bestAny
}

function Get-ModrinthVersionById { param([string]$VersionId) return (Invoke-ModrinthJson -Url ('https://api.modrinth.com/v2/version/'+[uri]::EscapeDataString($VersionId))) }
function Get-ModrinthProject { param([string]$ProjectId) return (Invoke-ModrinthJson -Url ('https://api.modrinth.com/v2/project/'+[uri]::EscapeDataString($ProjectId))) }

function Get-ModrinthPrimaryFile { param($Version) $f=@($Version.files|Where-Object{$_.primary -eq $true -and ([string]$_.filename).ToLowerInvariant().EndsWith('.jar')}|Select-Object -First 1);if($f.Count){return $f[0]};$f=@($Version.files|Where-Object{([string]$_.filename).ToLowerInvariant().EndsWith('.jar')}|Select-Object -First 1);if($f.Count){return $f[0]};return $null }

function Resolve-ModrinthPlan {
    param([string]$ProjectId)
    $planned=@{};$visiting=@{}
    function AddProject([string]$projectIdValue,[string]$ForcedVersionId){
        if($planned.ContainsKey($projectIdValue)){return};if($visiting.ContainsKey($projectIdValue)){return};$visiting[$projectIdValue]=$true
        $v=if([string]::IsNullOrWhiteSpace($ForcedVersionId)){Get-ModrinthCompatibleVersion $projectIdValue}else{Get-ModrinthVersionById $ForcedVersionId}
        if($null-eq$v){throw "No existe una versión compatible de $projectIdValue para Minecraft $($script:Config.MinecraftVersion) / $(Get-ModManagerLoader)."}
        if(-not(@($v.game_versions) -contains [string]$script:Config.MinecraftVersion)){throw "La dependencia $projectIdValue no es compatible con Minecraft $($script:Config.MinecraftVersion)."}
        if(-not(@($v.loaders) -contains (Get-ModManagerLoader))){throw "La dependencia $projectIdValue no soporta $(Get-ModManagerLoader)."}
        foreach($d in @($v.dependencies)){
            if([string]$d.dependency_type -eq 'required'){
                if(-not[string]::IsNullOrWhiteSpace([string]$d.project_id)){AddProject ([string]$d.project_id) ([string]$d.version_id)}elseif(-not[string]::IsNullOrWhiteSpace([string]$d.version_id)){$dv=Get-ModrinthVersionById ([string]$d.version_id);AddProject ([string]$dv.project_id) ([string]$d.version_id)}
            }
        }
        $p=Get-ModrinthProject $projectIdValue;$file=Get-ModrinthPrimaryFile $v;if($null-eq$file){throw "La versión $($v.version_number) de $($p.title) no contiene un JAR instalable."}
        $planned[$projectIdValue]=[pscustomobject]@{projectId=$projectIdValue;project=$p;version=$v;file=$file;side=(Convert-ModEnvironmentToSide ([string]$v.environment))}
        [void]$visiting.Remove($projectIdValue)
    }
    AddProject $ProjectId ''
    return @($planned.Values)
}

function Download-ModrinthPlan {
    param([object[]]$Plan)
    Initialize-ModManagerPaths;$dir=Join-Path $script:ModManagerStageDir ('modrinth-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $dir|Out-Null;$map=Get-ModManagerSourceMap;$files=New-Object 'System.Collections.Generic.List[object]'
    foreach($x in $Plan){
        $dest=Join-Path $dir ([string]$x.file.filename);Invoke-WebRequest -Uri ([string]$x.file.url) -OutFile $dest -UseBasicParsing -Headers @{'User-Agent'='CobbleverseServerManager/5.2.0'}
        $hash=Get-ModFileHashes $dest;$expectedSha1='';if(($x.file.PSObject.Properties.Name -contains 'hashes') -and $null-ne$x.file.hashes -and ($x.file.hashes.PSObject.Properties.Name -contains 'sha1')){$expectedSha1=[string]$x.file.hashes.sha1};if(-not[string]::IsNullOrWhiteSpace($expectedSha1) -and $hash.sha1 -ne $expectedSha1.ToLowerInvariant()){throw "Hash SHA1 incorrecto para $($x.project.title)."}
        $map[$hash.sha256]=[pscustomobject]@{source='modrinth';projectId=[string]$x.projectId;versionId=[string]$x.version.id;environment=[string]$x.version.environment;url=[string]$x.file.url;versionNumber=[string]$x.version.version_number;title=[string]$x.project.title}
        $files.Add([pscustomobject]@{path=$dest;side=[string]$x.side;projectId=[string]$x.projectId;versionId=[string]$x.version.id;name=[string]$x.project.title})
    }
    Save-ModManagerSourceMap $map;return [pscustomobject]@{directory=$dir;files=$files.ToArray()}
}

function Install-StagedModsAndPublish {
    param([object[]]$Files,[string]$Reason='change')
    $before=Get-ModManagerInventory
    # Create desired manifest based on current installation plus staged JARs, then apply transactionally.
    $temp=Join-Path $script:ModManagerStageDir ('compose-'+[guid]::NewGuid().ToString('N'));$c=Join-Path $temp 'client';$s=Join-Path $temp 'server';New-Item -ItemType Directory -Force -Path $c,$s|Out-Null
    try{
        foreach($f in @(Get-ChildItem -LiteralPath (Get-ModManagerClientModsDir) -File -Filter '*.jar' -ErrorAction SilentlyContinue)){Copy-Item $f.FullName (Join-Path $c $f.Name) -Force}
        foreach($f in @(Get-ChildItem -LiteralPath (Get-ModManagerServerModsDir) -File -Filter '*.jar' -ErrorAction SilentlyContinue)){Copy-Item $f.FullName (Join-Path $s $f.Name) -Force}
        foreach($x in $Files){$meta=Get-JarModMetadata -Path ([string]$x.path) -Presence ([string]$x.side) -SourceMap (Get-ModManagerSourceMap);foreach($dir in @($c,$s)){foreach($old in @(Get-ChildItem -LiteralPath $dir -File -Filter '*.jar' -ErrorAction SilentlyContinue)){try{$om=Get-JarModMetadata -Path $old.FullName -Presence 'unknown' -SourceMap (Get-ModManagerSourceMap);if([string]$om.id -eq [string]$meta.id){Remove-Item $old.FullName -Force}}catch{}}};if([string]$x.side -in @('client','both')){Copy-Item ([string]$x.path) (Join-Path $c ([IO.Path]::GetFileName([string]$x.path))) -Force};if([string]$x.side -in @('server','both')){Copy-Item ([string]$x.path) (Join-Path $s ([IO.Path]::GetFileName([string]$x.path))) -Force}}
        # Build a synthetic inventory from temp dirs by temporarily scanning them through helper metadata.
        $modsC=@();foreach($f in @(Get-ChildItem $c -File -Filter '*.jar')){$modsC+=Get-JarModMetadata $f.FullName 'client' (Get-ModManagerSourceMap)};$modsS=@();foreach($f in @(Get-ChildItem $s -File -Filter '*.jar')){$modsS+=Get-JarModMetadata $f.FullName 'server' (Get-ModManagerSourceMap)}
        $keys=@{};foreach($m in @($modsC+$modsS)){$keys[[string]$m.id]=$true};$rows=@();$probs=@();foreach($k in $keys.Keys){$cm=@($modsC|Where-Object{$_.id-eq$k}|Select-Object -First 1);$sm=@($modsS|Where-Object{$_.id-eq$k}|Select-Object -First 1);$cv=if($cm.Count){$cm[0]}else{$null};$sv=if($sm.Count){$sm[0]}else{$null};$side=if($null-ne$cv-and$null-ne$sv){'both'}elseif($null-ne$cv){'client'}else{'server'};$status='OK';if($null-ne$cv-and$null-ne$sv-and$cv.sha256-ne$sv.sha256){$status='VERSIÓN DISTINTA';$probs+=$k};$src=if($null-ne$cv){$cv}else{$sv};$rows+=[pscustomobject]@{id=$k;name=$src.name;versionClient=if($null-ne$cv){$cv.version}else{''};versionServer=if($null-ne$sv){$sv.version}else{''};side=$side;clientFile=if($null-ne$cv){$cv.fileName}else{''};serverFile=if($null-ne$sv){$sv.fileName}else{''};clientSha256=if($null-ne$cv){$cv.sha256}else{''};serverSha256=if($null-ne$sv){$sv.sha256}else{''};sha1=$src.sha1;bytes=$src.bytes;loader=$src.loader;depends=$src.depends;breaks=$src.breaks;source=$src.source;projectId=$src.projectId;sourceVersionId=$src.sourceVersionId;sourceEnvironment=$src.sourceEnvironment;status=$status}}
        $fake=[pscustomobject]@{mods=$rows;problems=$probs};$check=Test-ModManagerInventoryCompatibility $fake;if(-not$check.ok){throw ((@($check.issues)|ForEach-Object{"$($_.mod): $($_.issue)"}) -join '; ')}
        $remote=Get-RemoteModManifest;[int64]$g=1;if($null-ne$remote){$g=[int64]$remote.generation+1};$desired=Convert-InventoryToManagedManifest $fake $g $Reason;$tx=New-ModTransactionBackup $desired $Reason
        # Copy exact temp contents to real dirs.
        foreach($pair in @(@('client',$c,(Get-ModManagerClientModsDir)),@('server',$s,(Get-ModManagerServerModsDir)))){$srcDir=$pair[1];$dstDir=$pair[2];New-Item -ItemType Directory -Force -Path $dstDir|Out-Null;Get-ChildItem $dstDir -File -Filter '*.jar' -ErrorAction SilentlyContinue|Remove-Item -Force;foreach($f in @(Get-ChildItem $srcDir -File -Filter '*.jar')){Copy-Item $f.FullName (Join-Path $dstDir $f.Name) -Force}}
        try{Ensure-RemoteModPackages $desired;Publish-StaticBaseInfo|Out-Null;Set-RemoteModManifest $desired;Set-LocalModState $desired;Publish-ModClientState $desired;Get-ModManagerInventory|Out-Null}catch{Restore-ModTransaction ([string]$tx.id);throw}
        return $desired
    }finally{Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue}
}

function Remove-ManagedModAndPublish {
    param([string]$ModId)
    $inv=Get-ModManagerInventory;$target=@($inv.mods|Where-Object{[string]$_.id -eq $ModId}|Select-Object -First 1);if($target.Count-eq0){throw "No se encuentra el mod $ModId."}
    $t=$target[0];$files=@();$remote=Get-RemoteModManifest;[int64]$g=1;if($null-ne$remote){$g=[int64]$remote.generation+1}
    $newRows=@($inv.mods|Where-Object{[string]$_.id -ne $ModId});$fake=[pscustomobject]@{mods=$newRows;problems=@()};$desired=Convert-InventoryToManagedManifest $fake $g ("remove-$ModId");$check=Test-ModManagerInventoryCompatibility $fake
    $tx=New-ModTransactionBackup $desired ("remove-$ModId")
    try{if(-not[string]::IsNullOrWhiteSpace([string]$t.clientFile)){Remove-Item -LiteralPath (Join-Path (Get-ModManagerClientModsDir) ([string]$t.clientFile)) -Force -ErrorAction SilentlyContinue};if(-not[string]::IsNullOrWhiteSpace([string]$t.serverFile)){Remove-Item -LiteralPath (Join-Path (Get-ModManagerServerModsDir) ([string]$t.serverFile)) -Force -ErrorAction SilentlyContinue};Ensure-RemoteModPackages $desired;Publish-StaticBaseInfo|Out-Null;Set-RemoteModManifest $desired;Set-LocalModState $desired;Publish-ModClientState $desired;Get-ModManagerInventory|Out-Null}catch{Restore-ModTransaction ([string]$tx.id);throw}
}

function Resolve-ExistingModsAgainstModrinth {
    $inv=Get-ModManagerInventory;$hashes=@($inv.mods|Where-Object{![string]::IsNullOrWhiteSpace([string]$_.sha1)}|ForEach-Object{[string]$_.sha1}|Sort-Object -Unique);if($hashes.Count-eq0){return $inv}
    $body=@{hashes=$hashes;algorithm='sha1'};$versions=Invoke-ModrinthJson -Method POST -Url 'https://api.modrinth.com/v2/version_files' -Body $body;$map=Get-ModManagerSourceMap
    foreach($p in $versions.PSObject.Properties){$v=$p.Value;$file=Get-ModrinthPrimaryFile $v;if($null-eq$file){continue};$sha256='';if(($file.PSObject.Properties.Name -contains 'hashes') -and $null-ne$file.hashes -and ($file.hashes.PSObject.Properties.Name -contains 'sha256')){$sha256=[string]$file.hashes.sha256};if([string]::IsNullOrWhiteSpace($sha256)){continue};$map[$sha256]=[pscustomobject]@{source='modrinth';projectId=[string]$v.project_id;versionId=[string]$v.id;environment=[string]$v.environment;url=[string]$file.url;versionNumber=[string]$v.version_number;title=''}}
    Save-ModManagerSourceMap $map;return (Get-ModManagerInventory)
}

function Find-ModUpdates {
    $inv=Resolve-ExistingModsAgainstModrinth;$rows=New-Object 'System.Collections.Generic.List[object]'
    foreach($m in @($inv.mods)){
        if([string]::IsNullOrWhiteSpace([string]$m.projectId)){continue}
        try{$v=Get-ModrinthCompatibleVersion ([string]$m.projectId);if($null-eq$v){continue};if([string]$v.id -ne [string]$m.sourceVersionId){$rows.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;current=if($m.versionClient){[string]$m.versionClient}else{[string]$m.versionServer};latest=[string]$v.version_number;projectId=[string]$m.projectId;currentVersionId=[string]$m.sourceVersionId;latestVersionId=[string]$v.id;side=[string]$m.side})}}catch{}
    }
    Write-ModManagerJson $script:ModManagerUpdatesPath ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');updates=$rows.ToArray()}) 15;return $rows.ToArray()
}

function Update-ManagedModFromModrinth {
    param([string]$ProjectId,[string]$Side='both')
    $plan=Resolve-ModrinthPlan $ProjectId;$dl=Download-ModrinthPlan $plan
    try{return (Install-StagedModsAndPublish -Files $dl.files -Reason ("update-$ProjectId"))}finally{Remove-Item -LiteralPath $dl.directory -Recurse -Force -ErrorAction SilentlyContinue}
}

function Import-LocalJarAndPublish {
    param([string]$JarPath,[string]$Side='both')
    if(-not(Test-Path -LiteralPath $JarPath -PathType Leaf)){throw 'No existe el JAR seleccionado.'}
    if([IO.Path]::GetExtension($JarPath).ToLowerInvariant() -ne '.jar'){throw 'Solo se admiten archivos .jar.'}

    $m=Get-JarModMetadata $JarPath $Side (Get-ModManagerSourceMap)
    if(-not$m.metadataOk){Write-Warning 'El JAR no expone metadatos Fabric/Quilt/Forge reconocibles; la compatibilidad no puede verificarse completamente.'}

    # Importar JAR queda reservado para mods NUEVOS. Si el ID ya existe, obligamos
    # a usar la operación explícita de actualización para no sustituir algo por error.
    $inv=Get-ModManagerInventory
    $existing=@($inv.mods|Where-Object{([string]$_.id).Equals([string]$m.id,[StringComparison]::OrdinalIgnoreCase)}|Select-Object -First 1)
    if($existing.Count -gt 0){
        throw ("El mod '{0}' ({1}) ya está instalado. Selecciónalo en la lista y usa 'Actualizar desde .jar' para sustituir la versión anterior conservando automáticamente su ámbito." -f $existing[0].name,$m.id)
    }

    return (Install-StagedModsAndPublish -Files @([pscustomobject]@{path=$JarPath;side=$Side;name=$m.name}) -Reason ("manual-add-$($m.id)"))
}

function Update-ManagedModFromLocalJar {
    param([string]$JarPath,[string]$ModId)
    if(-not(Test-Path -LiteralPath $JarPath -PathType Leaf)){throw 'No existe el JAR seleccionado.'}
    if([IO.Path]::GetExtension($JarPath).ToLowerInvariant() -ne '.jar'){throw 'Solo se admiten archivos .jar.'}
    if([string]::IsNullOrWhiteSpace($ModId)){throw 'Selecciona primero el mod que quieres actualizar.'}

    # Se vuelve a escanear en el worker para no confiar solo en la caché de la GUI.
    $inv=Get-ModManagerInventory
    $target=@($inv.mods|Where-Object{([string]$_.id).Equals($ModId,[StringComparison]::OrdinalIgnoreCase)}|Select-Object -First 1)
    if($target.Count -eq 0){throw "El mod seleccionado ($ModId) ya no está instalado. Pulsa Escanear y vuelve a intentarlo."}
    $old=$target[0]
    $side=[string]$old.side

    $newMeta=Get-JarModMetadata $JarPath $side (Get-ModManagerSourceMap)
    if(-not$newMeta.metadataOk){throw "No se puede actualizar '$($old.name)' con ese archivo porque el JAR no expone metadatos de mod reconocibles."}
    if(-not([string]$newMeta.id).Equals([string]$old.id,[StringComparison]::OrdinalIgnoreCase)){
        throw ("El JAR seleccionado pertenece al mod '{0}' (ID {1}), pero has seleccionado '{2}' (ID {3}). No se ha cambiado nada." -f $newMeta.name,$newMeta.id,$old.name,$old.id)
    }

    # Install-StagedModsAndPublish elimina del conjunto temporal cualquier JAR con
    # el mismo ID antes de copiar el nuevo. El ámbito se conserva del mod instalado.
    # Además crea una transacción de rollback antes de tocar las carpetas reales.
    return (Install-StagedModsAndPublish -Files @([pscustomobject]@{path=$JarPath;side=$side;name=$newMeta.name}) -Reason ("manual-update-$($old.id)"))
}

function Analyze-ModCrash {
    Initialize-ModManagerPaths;$inv=Get-ModManagerInventory;$sources=@()
    $crashDirs=@((Join-Path $script:ServerDir 'crash-reports'),(Join-Path (Get-ModManagerClientInstancePath) 'crash-reports'))
    foreach($d in $crashDirs){if(Test-Path -LiteralPath $d){$x=Get-ChildItem -LiteralPath $d -File -Filter '*.txt' -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1;if($null-ne$x){$sources+=$x}}}
    foreach($p in @((Join-Path $script:ServerDir 'logs\latest.log'),(Join-Path (Get-ModManagerClientInstancePath) 'logs\latest.log'))){if(Test-Path -LiteralPath $p){$sources+=Get-Item $p}}
    $txt='';foreach($f in $sources){try{$txt += "`n--- $($f.FullName) ---`n"+(Get-Content $f.FullName -Tail 2500 -ErrorAction SilentlyContinue|Out-String)}catch{}}
    $cand=New-Object 'System.Collections.Generic.List[object]'
    foreach($m in @($inv.mods)){$score=0;$why=@();$id=[regex]::Escape([string]$m.id);if($txt -match "(?i)\b$id\b"){$score+=5;$why+='id mencionado'};$fn=if($m.clientFile){[string]$m.clientFile}else{[string]$m.serverFile};if($fn -and $txt.IndexOf($fn,[StringComparison]::OrdinalIgnoreCase)-ge0){$score+=10;$why+='jar mencionado'};if($score-gt0){$cand.Add([pscustomobject]@{id=[string]$m.id;name=[string]$m.name;score=$score;reason=($why-join ', ')})}}
    $sorted=@($cand.ToArray()|Sort-Object @{Expression='score';Descending=$true}, @{Expression='name';Descending=$false});$o=[ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');sources=@($sources|ForEach-Object{$_.FullName});candidates=$sorted;note='Es una heurística: un mod mencionado en un stack trace no siempre es el culpable. Usa Desinstalar seleccionado o Deshacer última transacción para recuperar.'};Write-ModManagerJson $script:ModManagerCrashPath $o 15;return $o
}

function Get-ModManagerStatus {
    param([switch]$RefreshInventory,[switch]$SkipRemote)
    Initialize-ModManagerPaths

    $inv=$null
    if($RefreshInventory){
        $inv=Get-ModManagerInventory
    } else {
        $inv=Read-ModManagerJson $script:ModManagerInventoryPath
    }

    $clientCount=0;$serverCount=0;$problemCount=0
    if($null-ne$inv){
        $clientCount=[int]$inv.clientCount
        $serverCount=[int]$inv.serverCount
        $problemCount=@($inv.problems).Count
    } else {
        $clientDir=Get-ModManagerClientModsDir;$serverDir=Get-ModManagerServerModsDir
        if(Test-Path -LiteralPath $clientDir){$clientCount=@(Get-ChildItem -LiteralPath $clientDir -File -Filter '*.jar' -ErrorAction SilentlyContinue).Count}
        if(Test-Path -LiteralPath $serverDir){$serverCount=@(Get-ChildItem -LiteralPath $serverDir -File -Filter '*.jar' -ErrorAction SilentlyContinue).Count}
    }

    $local=Get-LocalModState
    $remote=$null
    $cached=Read-ModManagerJson $script:ModManagerStatusPath
    if(-not$SkipRemote){try{$remote=Get-RemoteModManifest}catch{}}

    $remoteGeneration=0;$remoteAvailable=$false
    if($null-ne$remote){
        $remoteGeneration=[int64]$remote.generation;$remoteAvailable=$true
    } elseif($null-ne$cached){
        try{$remoteGeneration=[int64]$cached.remoteGeneration}catch{}
        try{$remoteAvailable=[bool]$cached.remoteAvailable}catch{}
    }

    $o=[ordered]@{
        utc=[DateTimeOffset]::UtcNow.ToString('o')
        clientPath=(Get-ModManagerClientInstancePath)
        serverPath=$script:ServerDir
        minecraftVersion=[string]$script:Config.MinecraftVersion
        loader=(Get-ModManagerLoader)
        clientMods=[int]$clientCount
        serverMods=[int]$serverCount
        problems=[int]$problemCount
        localGeneration=if($null-ne$local){[int64]$local.generation}else{0}
        remoteGeneration=[int64]$remoteGeneration
        enrolled=($null-ne$local -or $remoteAvailable)
        remoteAvailable=$remoteAvailable
    }
    Write-ModManagerJson $script:ModManagerStatusPath $o 10
    return $o
}
