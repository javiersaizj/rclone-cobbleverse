﻿# Advanced UI/features shared by 4.9.10 -> 5.0.
# The VERSION.txt number gates which cumulative features are visible.

$script:advancedStage = 0
$script:advancedInitialized = $false
$script:advancedLastRefresh = [DateTime]::MinValue
$script:advancedLastBackupListStamp = [DateTime]::MinValue
$script:advancedLastNetworkStamp = [DateTime]::MinValue
$script:advancedLastEnvironmentStamp = [DateTime]::MinValue
$script:advancedLastCheckpointStamp = [DateTime]::MinValue
$script:advancedJavaCpuSample = $null
$script:advancedJavaCpuAt = $null
$script:advancedServerSeenAt = $null
$script:advScheduleKind = ''
$script:advScheduleDue = [DateTime]::MinValue
$script:advScheduleWarn5 = $false
$script:advScheduleWarn1 = $false
$script:advPendingRestart = $false
$script:advRestartAfter = [DateTime]::MinValue
$script:advShutdownAfterSync = $false
$script:advHistoryGrid = $null
$script:advHealthServer = $null
$script:advHealthGen = $null
$script:advHealthSync = $null
$script:advHealthJava = $null
$script:advHealthPlayers = $null
$script:advHealthUptime = $null
$script:advHealthDisk = $null
$script:advHealthBackup = $null
$script:advHealthCrash = $null
$script:advHealthPerf = $null
$script:advBackupGrid = $null
$script:advNetworkText = $null
$script:advPlayersCount = $null
$script:advPlayersList = $null
$script:advEnvironmentText = $null
$script:advCheckpointLabel = $null
$script:advAutomationState = $null
$script:advPerfGrid = $null
$script:advV5Text = $null
$script:advancedCenterTab = $null
$script:advancedInnerTabs = $null

function Get-AdvancedStageFromVersion {
    $v=[string](Get-AppVersion)
    $v=$v.Trim().TrimStart([char]0xFEFF)
    if($v -match '^5\.') { return 100 }
    if($v -match '^4\.9\.(\d+)') { return [int]$Matches[1] }
    return 0
}

function Write-AdvancedActionRequest {
    param([hashtable]$Data)
    $path=Join-Path $script:DataDir 'advanced-action.json'
    [IO.File]::WriteAllText($path,(ConvertTo-Json -InputObject $Data -Depth 8),(New-Object Text.UTF8Encoding($false)))
}

function Start-AdvancedAction {
    param([string]$Label,[hashtable]$Data,[bool]$SafeWhileServerRunning=$false)
    try {
        Write-AdvancedActionRequest -Data $Data
        $def=[pscustomobject]@{Label=$Label;Script='AdvancedAction.ps1';SafeWhileServerRunning=$SafeWhileServerRunning;AdminSeparate=$false}
        Start-MaintenanceTask -Definition $def
    } catch {
        [System.Windows.Forms.MessageBox]::Show(('No se pudo iniciar la tarea: '+$_.Exception.Message),'Cobbleverse','OK','Error')|Out-Null
    }
}

function New-AdvButton {
    param([string]$Caption,[int]$X,[int]$Y,[int]$W=160,[int]$H=32)
    $b=New-Object System.Windows.Forms.Button
    $b.Text=$Caption;$b.Location=New-Object System.Drawing.Point($X,$Y);$b.Size=New-Object System.Drawing.Size($W,$H)
    $b.FlatStyle='Flat';$b.BackColor=$panel2;$b.ForeColor=$text;$b.FlatAppearance.BorderColor=[System.Drawing.Color]::FromArgb(72,75,88)
    return $b
}

function New-AdvLabel {
    param([string]$Caption,[int]$X,[int]$Y,[int]$W=250,[int]$H=22,[bool]$Bold=$false)
    $l=New-Object System.Windows.Forms.Label;$l.Text=$Caption;$l.Location=New-Object System.Drawing.Point($X,$Y);$l.Size=New-Object System.Drawing.Size($W,$H);$l.ForeColor=$text
    if($Bold){$l.Font=New-Object System.Drawing.Font('Segoe UI Semibold',10)}
    return $l
}

function Add-AdvancedTab {
    param([System.Windows.Forms.TabControl]$Tabs,[string]$Title)
    $t=New-Object System.Windows.Forms.TabPage;$t.Text=$Title;$t.BackColor=$dark;$t.ForeColor=$text;[void]$Tabs.TabPages.Add($t);return $t
}

function Get-AdvancedHistoryRows {
    $path=Join-Path $script:DataDir 'generation-history.jsonl'
    $rows=@();if(-not(Test-Path -LiteralPath $path)){return @($rows)}
    try{
        foreach($line in @(Get-Content -LiteralPath $path -ErrorAction SilentlyContinue)){
            if([string]::IsNullOrWhiteSpace($line)){continue}
            try{$rows += ($line|ConvertFrom-Json)}catch{}
        }
    }catch{}
    return @($rows|Sort-Object {[DateTimeOffset]::Parse([string]$_.utc)} -Descending)
}

function Refresh-AdvancedHistory {
    if($null -eq $script:advHistoryGrid){return}
    $script:advHistoryGrid.Rows.Clear()
    foreach($r in @(Get-AdvancedHistoryRows|Select-Object -First 250)){
        $mb='';try{$mb=('{0:N1}' -f ([int64]$r.bytes/1MB))}catch{}
        $when='';try{$when=[DateTimeOffset]::Parse([string]$r.utc).LocalDateTime.ToString('dd/MM HH:mm:ss')}catch{$when=[string]$r.utc}
        [void]$script:advHistoryGrid.Rows.Add(('G'+[string]$r.generation),[string]$r.event,[string]$r.sourceHost,$when,[string]$r.changed,[string]$r.deleted,$mb,[string]$r.reason)
    }
}

function Get-AdvancedPlayers {
    $set=@{}
    if(-not(Test-Path -LiteralPath $script:ServerLogPath)){return @()}
    try{$raw=Get-Content -LiteralPath $script:ServerLogPath -Raw -ErrorAction Stop}catch{return @()}
    foreach($m in [regex]::Matches($raw,'(?im):\s*([A-Za-z0-9_]{1,16}) joined the game')){$set[$m.Groups[1].Value]=$true}
    foreach($m in [regex]::Matches($raw,'(?im):\s*([A-Za-z0-9_]{1,16}) left the game')){[void]$set.Remove($m.Groups[1].Value)}
    foreach($m in [regex]::Matches($raw,'(?im):\s*([A-Za-z0-9_]{1,16}) lost connection')){[void]$set.Remove($m.Groups[1].Value)}
    return @($set.Keys|Sort-Object)
}

function Refresh-AdvancedPlayers {
    if($null -eq $script:advPlayersList){return}
    $old=[string]$script:advPlayersList.SelectedItem
    $script:advPlayersList.Items.Clear();foreach($p in @(Get-AdvancedPlayers)){[void]$script:advPlayersList.Items.Add($p)}
    if(-not[string]::IsNullOrWhiteSpace($old)){for($i=0;$i -lt $script:advPlayersList.Items.Count;$i++){if([string]$script:advPlayersList.Items[$i] -eq $old){$script:advPlayersList.SelectedIndex=$i;break}}}
    if($null -ne $script:advPlayersCount){$script:advPlayersCount.Text=('Jugadores detectados: '+$script:advPlayersList.Items.Count)}
}

function Refresh-AdvancedDashboard {
    if($null -eq $script:advHealthServer){return}
    $serverRunning=($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited)
    if($serverRunning){if($null -eq $script:advancedServerSeenAt){$script:advancedServerSeenAt=Get-Date};$script:advHealthServer.Text='Servidor local: ACTIVO';$script:advHealthServer.ForeColor=[System.Drawing.Color]::LimeGreen}
    else{$script:advancedServerSeenAt=$null;$script:advHealthServer.Text='Servidor local: apagado';$script:advHealthServer.ForeColor=$muted}
    $local=Get-LocalGenerationNumber;$remote=$script:remoteGeneration
    $script:advHealthGen.Text=('Generación: PC G{0} / Drive G{1}' -f $(if($null -eq $local){'?'}else{$local}),$(if($null -eq $remote){'?'}else{$remote}))
    $pending=Get-LocalPendingSyncSummary;$script:advHealthSync.Text=if($pending.hasPending){('Sync pendiente: {0} paquete(s), {1}' -f $pending.count,(Format-UiBytes $pending.bytes))}else{'Sync: al día'}
    $sp=Get-ServerPathFromConfig
    try{$drive=[IO.DriveInfo]::new(([IO.Path]::GetPathRoot($sp)));$script:advHealthDisk.Text=('Disco libre: {0:N1} GB de {1:N1} GB' -f ($drive.AvailableFreeSpace/1GB),($drive.TotalSize/1GB))}catch{$script:advHealthDisk.Text='Disco libre: ?'}
    $javaText='Java RAM: -'
    if($serverRunning){
        try{
            $j=@(Get-Process java -ErrorAction SilentlyContinue|Sort-Object WorkingSet64 -Descending|Select-Object -First 1)
            if($j.Count -gt 0){$javaText=('Java RAM: {0:N2} GB' -f ($j[0].WorkingSet64/1GB))}
        }catch{}
    }
    $script:advHealthJava.Text=$javaText
    $players=@(Get-AdvancedPlayers);$script:advHealthPlayers.Text=('Jugadores detectados: '+$players.Count)
    if($serverRunning -and $null -ne $script:advancedServerSeenAt){$span=(Get-Date)-$script:advancedServerSeenAt;$script:advHealthUptime.Text=('Uptime GUI: {0:00}:{1:00}:{2:00}' -f [int]$span.TotalHours,$span.Minutes,$span.Seconds)}else{$script:advHealthUptime.Text='Uptime GUI: -'}
    $lb=Join-Path $script:DataDir 'last-backup.json';if(Test-Path $lb){try{$x=[IO.File]::ReadAllText($lb)|ConvertFrom-Json;$script:advHealthBackup.Text=('Último backup: '+[DateTimeOffset]::Parse([string]$x.utc).LocalDateTime.ToString('dd/MM HH:mm'))}catch{$script:advHealthBackup.Text='Último backup: ?'}}else{$script:advHealthBackup.Text='Último backup: no registrado'}
    $cr=Join-Path $script:DataDir 'last-crash.json';if(Test-Path $cr){try{$x=[IO.File]::ReadAllText($cr)|ConvertFrom-Json;$script:advHealthCrash.Text=('Último crash: exit '+$x.exitCode+' · '+[DateTimeOffset]::Parse([string]$x.utc).LocalDateTime.ToString('dd/MM HH:mm'));$script:advHealthCrash.ForeColor=[System.Drawing.Color]::OrangeRed}catch{}}else{$script:advHealthCrash.Text='Último crash: ninguno registrado';$script:advHealthCrash.ForeColor=$muted}
    $perf=Join-Path $script:DataDir 'performance-last.json';if(Test-Path $perf){try{$x=[IO.File]::ReadAllText($perf)|ConvertFrom-Json;$script:advHealthPerf.Text=('Último arranque {0:N2}s · cierre/sync {1:N2}s' -f [double]$x.StartupPipelineSeconds,[double]$x.ClosePipelineSeconds)}catch{$script:advHealthPerf.Text='Rendimiento: ?'}}else{$script:advHealthPerf.Text='Rendimiento: sin datos'}
}

function Refresh-AdvancedBackupList {
    if($null -eq $script:advBackupGrid){return}
    $path=Join-Path $script:DataDir 'backup-list.json';if(-not(Test-Path $path)){return}
    try{$stamp=(Get-Item $path).LastWriteTime;if($stamp -eq $script:advancedLastBackupListStamp){return};$script:advancedLastBackupListStamp=$stamp;$obj=[IO.File]::ReadAllText($path)|ConvertFrom-Json}catch{return}
    $script:advBackupGrid.Rows.Clear()
    foreach($s in @($obj.snapshots)){
        $id=[string]$s.short_id;if([string]::IsNullOrWhiteSpace($id)){$id=[string]$s.id}
        $time='';try{$time=[DateTimeOffset]::Parse([string]$s.time).LocalDateTime.ToString('dd/MM/yyyy HH:mm')}catch{$time=[string]$s.time}
        $tags=(@($s.tags)-join ', ');[void]$script:advBackupGrid.Rows.Add($id,$time,[string]$s.hostname,$tags)
    }
}

function Refresh-AdvancedNetwork {
    if($null -eq $script:advNetworkText){return}
    $path=Join-Path $script:DataDir 'network-diagnostics.json';if(-not(Test-Path $path)){return}
    try{$stamp=(Get-Item $path).LastWriteTime;if($stamp -eq $script:advancedLastNetworkStamp){return};$script:advancedLastNetworkStamp=$stamp;$o=[IO.File]::ReadAllText($path)|ConvertFrom-Json}catch{return}
    $script:advNetworkText.Text=("PC: {0}`r`nPuerto Minecraft: {1}`r`nEscucha local: {2}`r`nLAN: {3}`r`nIP pública: {4}`r`nDirección fija: {5}`r`nPuerto externo: {6}`r`n`r`n{7}" -f $o.host,$o.serverPort,$o.localListening,(@($o.lanIPv4)-join ', '),$o.publicIPv4,$o.publicHost,$o.externalPort,$o.note)
}

function Refresh-AdvancedEnvironment {
    if($null -eq $script:advEnvironmentText){return}
    $path=Join-Path $script:DataDir 'environment-compare.json';if(-not(Test-Path $path)){return}
    try{$stamp=(Get-Item $path).LastWriteTime;if($stamp -eq $script:advancedLastEnvironmentStamp){return};$script:advancedLastEnvironmentStamp=$stamp;$o=[IO.File]::ReadAllText($path)|ConvertFrom-Json}catch{return}
    if(-not[bool]$o.otherFound){$script:advEnvironmentText.Text='Tu manifiesto se ha publicado. El otro PC todavía no ha publicado el suyo.';return}
    $lines=@("Comparado con: $($o.otherHost)","Diferencias: $($o.differentCount)",'')+@($o.different|Select-Object -First 100)
    $script:advEnvironmentText.Text=($lines -join "`r`n")
}

function Refresh-AdvancedCheckpoint {
    if($null -eq $script:advCheckpointLabel){return}
    $path=Join-Path $script:DataDir 'checkpoint-result.json';if(-not(Test-Path $path)){return}
    try{$stamp=(Get-Item $path).LastWriteTime;if($stamp -eq $script:advancedLastCheckpointStamp){return};$script:advancedLastCheckpointStamp=$stamp;$o=[IO.File]::ReadAllText($path)|ConvertFrom-Json}catch{return}
    if([bool]$o.created){$script:advCheckpointLabel.Text=('Último checkpoint: G{0} → G{1} · {2} archivos · {3}' -f $o.from,$o.to,$o.changed,(Format-UiBytes ([int64]$o.bytes)))}else{$script:advCheckpointLabel.Text=('Checkpoint: no creado ('+[string]$o.reason+')')}
}

function Invoke-AdvancedPlayerCommand {
    param([string]$Command)
    if($null -eq $script:serverProcess -or $script:serverProcess.HasExited){[System.Windows.Forms.MessageBox]::Show('Los controles de jugadores solo pueden enviar comandos cuando Minecraft está ejecutándose en ESTE PC.','Cobbleverse','OK','Information')|Out-Null;return}
    [void](Send-ProcessInput -Process $script:serverProcess -Text $Command -LogBox $script:txtServerLog)
}

function Update-AdvancedAutomation {
    if($script:advScheduleKind -ne '' -and $script:advScheduleDue -gt [DateTime]::MinValue){
        $left=$script:advScheduleDue-(Get-Date)
        if($null -ne $script:advAutomationState){$script:advAutomationState.Text=('Programado: {0} en {1:mm\:ss}' -f $script:advScheduleKind,$left)}
        if($left.TotalMinutes -le 5 -and -not $script:advScheduleWarn5 -and $left.TotalSeconds -gt 60){Invoke-AdvancedPlayerCommand -Command 'say [Cobbleverse] Reinicio/apagado programado en menos de 5 minutos.';$script:advScheduleWarn5=$true}
        if($left.TotalMinutes -le 1 -and -not $script:advScheduleWarn1 -and $left.TotalSeconds -gt 0){Invoke-AdvancedPlayerCommand -Command 'say [Cobbleverse] Reinicio/apagado programado en 1 minuto.';$script:advScheduleWarn1=$true}
        if($left.TotalSeconds -le 0){
            $kind=$script:advScheduleKind;$script:advScheduleKind='';Invoke-AdvancedPlayerCommand -Command 'stop';$script:stopRequested=$true
            if($kind -eq 'reiniciar'){$script:advPendingRestart=$true;$script:advRestartAfter=(Get-Date).AddSeconds(4)}
        }
    }
    if($script:advPendingRestart -and (Get-Date) -ge $script:advRestartAfter){
        if(($null -eq $script:serverProcess -or $script:serverProcess.HasExited) -and ($null -eq $script:taskProcess -or $script:taskProcess.HasExited) -and -not(Get-LocalPendingSyncSummary).hasPending){$script:advPendingRestart=$false;Start-ServerFromGui}
    }
    if($script:advShutdownAfterSync){
        if(($null -eq $script:serverProcess -or $script:serverProcess.HasExited) -and ($null -eq $script:taskProcess -or $script:taskProcess.HasExited) -and -not(Get-LocalPendingSyncSummary).hasPending){$script:advShutdownAfterSync=$false;Start-Process -FilePath 'shutdown.exe' -ArgumentList '/s /t 0' -WindowStyle Hidden}
    }
}



function Refresh-AdvancedPerformanceHistory {
    if($null -eq $script:advPerfGrid){return}
    $path=Join-Path $script:DataDir 'performance-history.jsonl';if(-not(Test-Path $path)){return}
    $script:advPerfGrid.Rows.Clear();$rows=@()
    foreach($line in @(Get-Content -LiteralPath $path -ErrorAction SilentlyContinue)){if([string]::IsNullOrWhiteSpace($line)){continue};try{$rows+=($line|ConvertFrom-Json)}catch{}}
    foreach($o in @($rows|Select-Object -Last 50|Sort-Object utc -Descending)){
        $when='';try{$when=[DateTimeOffset]::Parse([string]$o.utc).LocalDateTime.ToString('dd/MM HH:mm')}catch{$when=[string]$o.utc}
        [void]$script:advPerfGrid.Rows.Add($when,('{0:N2}'-f[double]$o.StartupPipelineSeconds),('{0:N2}'-f[double]$o.DriveControlSeconds),('{0:N2}'-f[double]$o.ManifestPrepareSeconds),('{0:N2}'-f[double]$o.CloseValidationSeconds),('{0:N2}'-f[double]$o.OutboxBuildSeconds),('{0:N2}'-f[double]$o.UploadAndCommitSeconds),('{0:N2}'-f[double]$o.ClosePipelineSeconds))
    }
}

function Refresh-AdvancedV5 {
    if($null -eq $script:advV5Text){return}
    $lines=New-Object 'System.Collections.Generic.List[string]'
    $pre=Join-Path $script:DataDir 'preflight.json'
    if(Test-Path $pre){try{$o=[IO.File]::ReadAllText($pre)|ConvertFrom-Json;$lines.Add(('PRECHECK: '+$(if([bool]$o.ok){'OK'}else{'ATENCIÓN'})));foreach($c in @($o.checks)){$lines.Add(('  {0}: {1} — {2}' -f $c.name,$(if([bool]$c.ok){'OK'}else{'FALLO'}),$c.detail))}}catch{}}
    $du=Join-Path $script:DataDir 'drive-usage.json';if(Test-Path $du){try{$o=[IO.File]::ReadAllText($du)|ConvertFrom-Json;$lines.Add(('DRIVE DELTA: {0} · {1} objetos' -f (Format-UiBytes ([int64]$o.bytes)),[int64]$o.count))}catch{}}
    $sp=Join-Path $script:DataDir 'sync-plan.json';if(Test-Path $sp){try{$o=[IO.File]::ReadAllText($sp)|ConvertFrom-Json;$lines.Add(('ACTUALIZACIÓN: G{0} → G{1} · {2} generaciones · aprox {3}' -f $o.from,$o.to,$o.generations,(Format-UiBytes ([int64]$o.bytes))))}catch{}}
    $ir=Join-Path $script:DataDir 'integrity-result.json';if(Test-Path $ir){try{$o=[IO.File]::ReadAllText($ir)|ConvertFrom-Json;$msg='sin comparación';if([bool]$o.otherFound){if([int64]$o.otherGeneration -ne [int64]$o.generation){$msg=('otro PC en G'+$o.otherGeneration)}elseif($o.match -eq $true){$msg='COINCIDE con '+$o.otherHost}else{$msg='NO COINCIDE con '+$o.otherHost}};$lines.Add(('INTEGRIDAD G{0}: {1}' -f $o.generation,$msg))}catch{}}
    if($lines.Count -eq 0){$lines.Add('Todavía no hay resultados. Usa los botones superiores.')}
    $script:advV5Text.Text=($lines -join "`r`n")
}

function Start-AdvancedUpdater {
    if($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited){[System.Windows.Forms.MessageBox]::Show('Apaga y sincroniza el servidor antes de actualizar la aplicación.','Cobbleverse','OK','Warning')|Out-Null;return}
    if($null -ne $script:taskProcess -and -not $script:taskProcess.HasExited){[System.Windows.Forms.MessageBox]::Show('Espera a que termine la tarea actual.','Cobbleverse','OK','Warning')|Out-Null;return}
    $dlg=New-Object System.Windows.Forms.OpenFileDialog;$dlg.Filter='Cobbleverse ZIP (*.zip)|*.zip';$dlg.Title='Selecciona una versión nueva de Cobbleverse Server Manager'
    if($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){return}
    if([System.Windows.Forms.MessageBox]::Show('La app se cerrará, actualizará scripts/recursos y conservará config.json y data. ¿Continuar?','Cobbleverse updater','YesNo','Warning') -ne 'Yes'){return}
    $up=Join-Path $PSScriptRoot 'Updater.ps1';$ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $updaterArgs=('-NoProfile -ExecutionPolicy Bypass -File "{0}" -Package "{1}" -Root "{2}" -WaitPid {3}' -f $up,$dlg.FileName,$script:Root,$PID)
    Start-Process -FilePath $ps -ArgumentList $updaterArgs -WindowStyle Hidden|Out-Null
    $script:closingAllowed=$true;$script:toolsClosingAllowed=$true
    try{if($null-ne$toolsForm -and -not$toolsForm.IsDisposed){$toolsForm.Close()}}catch{}
    $form.Close()
}

function Update-AdvancedFeatures {
    if(-not $script:advancedInitialized){return}
    Update-AdvancedAutomation
    if(((Get-Date)-$script:advancedLastRefresh).TotalSeconds -lt 4){return}
    $script:advancedLastRefresh=Get-Date
    Refresh-AdvancedDashboard;Refresh-AdvancedHistory;Refresh-AdvancedPlayers;Refresh-AdvancedBackupList;Refresh-AdvancedNetwork;Refresh-AdvancedEnvironment;Refresh-AdvancedCheckpoint;Refresh-AdvancedPerformanceHistory;Refresh-AdvancedV5
}

function Initialize-AdvancedFeatures {
    param([System.Windows.Forms.TabControl]$Tabs)
    $script:advancedStage=Get-AdvancedStageFromVersion
    if($script:advancedStage -lt 10){return}
    $center=Add-AdvancedTab -Tabs $Tabs -Title 'Centro 5.0'
    $script:advancedCenterTab=$center
    $inner=New-Object System.Windows.Forms.TabControl;$inner.Dock='Fill';$inner.Multiline=$true;$inner.Padding=New-Object System.Drawing.Point(14,6);$center.Controls.Add($inner)
    $script:advancedInnerTabs=$inner
    # Desde este punto la zona 5.0 ya existe. Si un modulo posterior falla, no desaparece toda la UI nueva.
    $script:advancedInitialized=$true

    if($script:advancedStage -ge 10){
        $homeTab=Add-AdvancedTab -Tabs $inner -Title 'Inicio'
        $homeTitle=New-AdvLabel 'Centro de control Cobbleverse 5.0' 22 22 620 32 $true;$homeTitle.Font=New-Object System.Drawing.Font('Segoe UI Semibold',16);$homeTab.Controls.Add($homeTitle)
        $homeText=New-Object System.Windows.Forms.Label;$homeText.Location=New-Object System.Drawing.Point(24,70);$homeText.Size=New-Object System.Drawing.Size(980,180);$homeText.ForeColor=$muted;$homeText.Text='Funciones 5.0 activas: historial de generaciones, salud, backups, red, jugadores, mantenimiento, watchdog, catch-up, automatizaciones, diagnóstico y rendimiento. Usa las pestañas de arriba para acceder a cada módulo.';$homeTab.Controls.Add($homeText)
        $homeVersion=New-AdvLabel ('Versión cargada: '+(Get-AppVersion)) 24 270 600 28 $true;$homeVersion.ForeColor=$orange;$homeTab.Controls.Add($homeVersion)

        $t=Add-AdvancedTab -Tabs $inner -Title 'Historial'
        $b=New-AdvButton 'Actualizar' 12 12 110 30;$t.Controls.Add($b);$b.Add_Click({Refresh-AdvancedHistory})
        $script:advHistoryGrid=New-Object System.Windows.Forms.DataGridView;$script:advHistoryGrid.Location=New-Object System.Drawing.Point(12,52);$script:advHistoryGrid.Size=New-Object System.Drawing.Size(1080,560);$script:advHistoryGrid.Anchor='Top,Bottom,Left,Right';$script:advHistoryGrid.ReadOnly=$true;$script:advHistoryGrid.AllowUserToAddRows=$false;$script:advHistoryGrid.AutoSizeColumnsMode='Fill';$script:advHistoryGrid.BackgroundColor=$panel;$script:advHistoryGrid.ForeColor=[System.Drawing.Color]::Black
        foreach($c in @('Generación','Evento','Origen','Fecha','Modificados','Borrados','MB','Motivo')){[void]$script:advHistoryGrid.Columns.Add($c,$c)};$t.Controls.Add($script:advHistoryGrid)
    }

    if($script:advancedStage -ge 11){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Salud'
        $script:advHealthServer=New-AdvLabel 'Servidor local: ?' 20 20 360 26 $true;$t.Controls.Add($script:advHealthServer)
        $script:advHealthGen=New-AdvLabel 'Generación: ?' 20 58 420 24 $false;$t.Controls.Add($script:advHealthGen)
        $script:advHealthSync=New-AdvLabel 'Sync: ?' 20 90 520 24 $false;$t.Controls.Add($script:advHealthSync)
        $script:advHealthJava=New-AdvLabel 'Java RAM: ?' 20 122 360 24 $false;$t.Controls.Add($script:advHealthJava)
        $script:advHealthPlayers=New-AdvLabel 'Jugadores: ?' 20 154 360 24 $false;$t.Controls.Add($script:advHealthPlayers)
        $script:advHealthUptime=New-AdvLabel 'Uptime GUI: ?' 20 186 360 24 $false;$t.Controls.Add($script:advHealthUptime)
        $script:advHealthDisk=New-AdvLabel 'Disco libre: ?' 20 218 500 24 $false;$t.Controls.Add($script:advHealthDisk)
        $script:advHealthBackup=New-AdvLabel 'Último backup: ?' 20 250 500 24 $false;$t.Controls.Add($script:advHealthBackup)
        $script:advHealthCrash=New-AdvLabel 'Último crash: ?' 20 282 700 24 $false;$script:advHealthCrash.ForeColor=$muted;$t.Controls.Add($script:advHealthCrash)
        $script:advHealthPerf=New-AdvLabel 'Rendimiento: ?' 20 314 700 24 $false;$t.Controls.Add($script:advHealthPerf)
        $b=New-AdvButton 'Refrescar ahora' 20 360 160 32;$t.Controls.Add($b);$b.Add_Click({$script:advancedLastRefresh=[DateTime]::MinValue;Refresh-AdvancedDashboard})
    }

    if($script:advancedStage -ge 12){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Backups'
        $b1=New-AdvButton 'Refrescar backups' 12 12 150 30;$t.Controls.Add($b1);$b1.Add_Click({Start-AdvancedAction -Label 'Listar backups' -Data @{action='backup-list'} -SafeWhileServerRunning $true})
        $b2=New-AdvButton 'Crear backup' 172 12 140 30;$t.Controls.Add($b2);$b2.Add_Click({Start-AdvancedAction -Label 'Crear backup' -Data @{action='backup-create'} -SafeWhileServerRunning $false})
        $b3=New-AdvButton 'Restaurar seleccionado' 322 12 180 30;$t.Controls.Add($b3);$b3.Add_Click({if($script:advBackupGrid.SelectedRows.Count -eq 0){return};$id=[string]$script:advBackupGrid.SelectedRows[0].Cells[0].Value;if([System.Windows.Forms.MessageBox]::Show(('¿Restaurar backup '+$id+' y publicarlo como nueva generación?'),'Cobbleverse','YesNo','Warning') -eq 'Yes'){Start-AdvancedAction -Label 'Restaurar backup' -Data @{action='backup-restore';snapshotId=$id} -SafeWhileServerRunning $false}})
        $script:advBackupGrid=New-Object System.Windows.Forms.DataGridView;$script:advBackupGrid.Location=New-Object System.Drawing.Point(12,54);$script:advBackupGrid.Size=New-Object System.Drawing.Size(1080,555);$script:advBackupGrid.Anchor='Top,Bottom,Left,Right';$script:advBackupGrid.ReadOnly=$true;$script:advBackupGrid.SelectionMode='FullRowSelect';$script:advBackupGrid.MultiSelect=$false;$script:advBackupGrid.AllowUserToAddRows=$false;$script:advBackupGrid.AutoSizeColumnsMode='Fill';$script:advBackupGrid.BackgroundColor=$panel;$script:advBackupGrid.ForeColor=[System.Drawing.Color]::Black
        foreach($c in @('ID','Fecha','PC','Etiquetas')){[void]$script:advBackupGrid.Columns.Add($c,$c)};$t.Controls.Add($script:advBackupGrid)
    }

    if($script:advancedStage -ge 13){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Red'
        $b=New-AdvButton 'Ejecutar diagnóstico' 16 16 180 32;$t.Controls.Add($b);$b.Add_Click({Start-AdvancedAction -Label 'Diagnóstico de red' -Data @{action='network-diagnostics'} -SafeWhileServerRunning $true})
        $script:advNetworkText=New-Object System.Windows.Forms.TextBox;$script:advNetworkText.Multiline=$true;$script:advNetworkText.ReadOnly=$true;$script:advNetworkText.ScrollBars='Vertical';$script:advNetworkText.Location=New-Object System.Drawing.Point(16,62);$script:advNetworkText.Size=New-Object System.Drawing.Size(1060,500);$script:advNetworkText.Anchor='Top,Bottom,Left,Right';$script:advNetworkText.BackColor=$panel2;$script:advNetworkText.ForeColor=$text;$script:advNetworkText.Font=New-Object System.Drawing.Font('Consolas',10);$t.Controls.Add($script:advNetworkText)
    }

    if($script:advancedStage -ge 14){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Jugadores'
        $script:advPlayersCount=New-AdvLabel 'Jugadores detectados: 0' 16 16 260 24 $true;$t.Controls.Add($script:advPlayersCount)
        $script:advPlayersList=New-Object System.Windows.Forms.ListBox;$script:advPlayersList.Location=New-Object System.Drawing.Point(16,50);$script:advPlayersList.Size=New-Object System.Drawing.Size(280,430);$script:advPlayersList.BackColor=$panel2;$script:advPlayersList.ForeColor=$text;$t.Controls.Add($script:advPlayersList)
        $x=320;$kick=New-AdvButton 'Kick' $x 50 120 32;$op=New-AdvButton 'OP' $x 92 120 32;$deop=New-AdvButton 'DeOP' $x 134 120 32;$wl=New-AdvButton 'Whitelist +' $x 176 120 32;$save=New-AdvButton 'save-all' $x 218 120 32
        foreach($b in @($kick,$op,$deop,$wl,$save)){$t.Controls.Add($b)}
        $kick.Add_Click({$p=[string]$script:advPlayersList.SelectedItem;if($p){Invoke-AdvancedPlayerCommand -Command ('kick '+$p)}});$op.Add_Click({$p=[string]$script:advPlayersList.SelectedItem;if($p){Invoke-AdvancedPlayerCommand -Command ('op '+$p)}});$deop.Add_Click({$p=[string]$script:advPlayersList.SelectedItem;if($p){Invoke-AdvancedPlayerCommand -Command ('deop '+$p)}});$wl.Add_Click({$p=[string]$script:advPlayersList.SelectedItem;if($p){Invoke-AdvancedPlayerCommand -Command ('whitelist add '+$p)}});$save.Add_Click({Invoke-AdvancedPlayerCommand -Command 'save-all'})
        $msg=New-Object System.Windows.Forms.TextBox;$msg.Location=New-Object System.Drawing.Point(320,280);$msg.Size=New-Object System.Drawing.Size(430,25);$msg.BackColor=$panel2;$msg.ForeColor=$text;$t.Controls.Add($msg);$say=New-AdvButton 'Enviar mensaje' 760 278 140 30;$t.Controls.Add($say);$say.Add_Click({if(-not[string]::IsNullOrWhiteSpace($msg.Text)){Invoke-AdvancedPlayerCommand -Command ('say '+$msg.Text);$msg.Clear()}})
        $note=New-AdvLabel 'Administración directa disponible cuando el servidor está ejecutándose en este PC.' 320 330 650 44 $false;$note.ForeColor=$muted;$t.Controls.Add($note)
    }

    if($script:advancedStage -ge 15){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Mantenimiento'
        $b1=New-AdvButton 'Activar mantenimiento' 16 16 180 32;$t.Controls.Add($b1);$b1.Add_Click({Start-AdvancedAction -Label 'Activar mantenimiento' -Data @{action='maintenance-enter';message='Actualizando mods/configuración'} -SafeWhileServerRunning $false})
        $b2=New-AdvButton 'Finalizar mantenimiento' 206 16 180 32;$t.Controls.Add($b2);$b2.Add_Click({Start-AdvancedAction -Label 'Finalizar mantenimiento' -Data @{action='maintenance-exit'} -SafeWhileServerRunning $false})
        $b3=New-AdvButton 'Comparar mods entre PCs' 396 16 190 32;$t.Controls.Add($b3);$b3.Add_Click({Start-AdvancedAction -Label 'Comparar entorno' -Data @{action='environment-compare'} -SafeWhileServerRunning $false})
        $script:advEnvironmentText=New-Object System.Windows.Forms.TextBox;$script:advEnvironmentText.Multiline=$true;$script:advEnvironmentText.ReadOnly=$true;$script:advEnvironmentText.ScrollBars='Vertical';$script:advEnvironmentText.Location=New-Object System.Drawing.Point(16,66);$script:advEnvironmentText.Size=New-Object System.Drawing.Size(1060,490);$script:advEnvironmentText.Anchor='Top,Bottom,Left,Right';$script:advEnvironmentText.BackColor=$panel2;$script:advEnvironmentText.ForeColor=$text;$script:advEnvironmentText.Font=New-Object System.Drawing.Font('Consolas',9);$t.Controls.Add($script:advEnvironmentText)
    }

    if($script:advancedStage -ge 16){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Watchdog'
        $l=New-AdvLabel 'El watchdog registra cualquier salida no limpia de Java, conserva la sesión y deja que la sincronización segura termine antes de liberar el mundo.' 18 20 950 55 $false;$t.Controls.Add($l)
        $b=New-AdvButton 'Borrar aviso de crash' 18 92 180 32;$t.Controls.Add($b);$b.Add_Click({Remove-Item -LiteralPath (Join-Path $script:DataDir 'last-crash.json') -Force -ErrorAction SilentlyContinue;Refresh-AdvancedDashboard})
        $restart=New-AdvButton 'Reiniciar servidor ahora' 208 92 190 32;$t.Controls.Add($restart);$restart.Add_Click({if($null -eq $script:serverProcess -or $script:serverProcess.HasExited){Start-ServerFromGui}else{[System.Windows.Forms.MessageBox]::Show('El servidor ya está activo. Usa Automatización para reinicio controlado.','Cobbleverse')|Out-Null}})
    }

    if($script:advancedStage -ge 17){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Catch-up'
        $l=New-AdvLabel 'Crea un paquete acumulado desde el PC más atrasado hasta la generación actual. Las generaciones originales se conservan como respaldo.' 16 18 950 48 $false;$t.Controls.Add($l)
        $b=New-AdvButton 'Crear checkpoint catch-up' 16 78 210 34;$t.Controls.Add($b);$b.Add_Click({Start-AdvancedAction -Label 'Crear checkpoint catch-up' -Data @{action='checkpoint-create'} -SafeWhileServerRunning $false})
        $script:advCheckpointLabel=New-AdvLabel 'Checkpoint: sin datos' 16 132 900 28 $true;$t.Controls.Add($script:advCheckpointLabel)
    }

    if($script:advancedStage -ge 18){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Automatización'
        $t.Controls.Add((New-AdvLabel 'Minutos:' 18 22 80 24 $false));$num=New-Object System.Windows.Forms.NumericUpDown;$num.Location=New-Object System.Drawing.Point(100,20);$num.Minimum=1;$num.Maximum=240;$num.Value=10;$t.Controls.Add($num)
        $r=New-AdvButton 'Reiniciar después' 18 62 170 32;$s=New-AdvButton 'Apagar servidor después' 198 62 190 32;$c=New-AdvButton 'Cancelar programación' 398 62 190 32;foreach($b in @($r,$s,$c)){$t.Controls.Add($b)}
        $r.Add_Click({$script:advScheduleKind='reiniciar';$script:advScheduleDue=(Get-Date).AddMinutes([double]$num.Value);$script:advScheduleWarn5=$false;$script:advScheduleWarn1=$false});$s.Add_Click({$script:advScheduleKind='apagar';$script:advScheduleDue=(Get-Date).AddMinutes([double]$num.Value);$script:advScheduleWarn5=$false;$script:advScheduleWarn1=$false});$c.Add_Click({$script:advScheduleKind='';$script:advScheduleDue=[DateTime]::MinValue})
        $script:advAutomationState=New-AdvLabel 'Sin programación activa' 18 112 680 28 $true;$t.Controls.Add($script:advAutomationState)
        $shutdown=New-AdvButton 'Stop + sincronizar + apagar Windows' 18 164 270 34;$t.Controls.Add($shutdown);$shutdown.Add_Click({if([System.Windows.Forms.MessageBox]::Show('¿Apagar Windows automáticamente cuando Minecraft cierre y la sincronización quede completada?','Cobbleverse','YesNo','Warning') -eq 'Yes'){$script:advShutdownAfterSync=$true;if($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited){Invoke-AdvancedPlayerCommand -Command 'stop'}else{[System.Windows.Forms.MessageBox]::Show('No hay servidor local activo.','Cobbleverse')|Out-Null}}})
    }

    if($script:advancedStage -ge 19){
        $t=Add-AdvancedTab -Tabs $inner -Title 'Diagnóstico'
        $b1=New-AdvButton 'Crear ZIP diagnóstico' 18 18 190 34;$t.Controls.Add($b1);$b1.Add_Click({Start-AdvancedAction -Label 'Crear diagnóstico' -Data @{action='diagnostic-bundle'} -SafeWhileServerRunning $true})
        $b2=New-AdvButton 'Exportar preferencias' 218 18 190 34;$t.Controls.Add($b2);$b2.Add_Click({Start-AdvancedAction -Label 'Exportar preferencias' -Data @{action='export-preferences'} -SafeWhileServerRunning $true})
        $b3=New-AdvButton 'Abrir carpeta data' 418 18 160 34;$t.Controls.Add($b3);$b3.Add_Click({Start-Process explorer.exe -ArgumentList ('"{0}"' -f $script:DataDir)|Out-Null})
        $b4=New-AdvButton 'Actualizar app desde ZIP' 588 18 190 34;$t.Controls.Add($b4);$b4.Add_Click({Start-AdvancedUpdater})
        $note=New-AdvLabel 'El ZIP de diagnóstico excluye rclone.conf, tokens y contraseñas. Las preferencias tampoco incluyen credenciales de Google Drive.' 18 76 900 55 $false;$note.ForeColor=$muted;$t.Controls.Add($note)
    }


    if($script:advancedStage -ge 100){
        $tm=Add-AdvancedTab -Tabs $inner -Title 'Mods'
        $mt=New-AdvLabel 'Gestor de Mods' 18 20 520 34 $true;$mt.Font=New-Object System.Drawing.Font('Segoe UI Semibold',16);$tm.Controls.Add($mt)
        $md=New-AdvLabel 'Gestiona el modpack de CurseForge sin mezclarlo con la sincronización del mundo: inventario, compatibilidad, búsqueda, actualizaciones, dependencias, distribución a ambos PCs/servidor y rollback.' 18 64 980 58 $false;$md.ForeColor=$muted;$tm.Controls.Add($md)
        $mb=New-AdvButton 'Abrir gestor de mods' 18 136 210 38;$mb.BackColor=$orange;$mb.ForeColor=[System.Drawing.Color]::Black;$tm.Controls.Add($mb)
        $mb.Add_Click({
            try{
                $mg=Join-Path $PSScriptRoot 'ModManagerGUI.ps1'
                if(-not(Test-Path -LiteralPath $mg)){throw "No se encuentra el gestor de mods: $mg"}
                & $mg
            }
            catch{
                $mmLog=Join-Path $script:DataDir 'mod-manager-startup-error.log'
                $mmDetail=@(
                    ('Fecha: '+[DateTimeOffset]::Now.ToString('o')),
                    'Versión: 5.1.0.2 PREVIEW - DIRECT MOD MANAGER LAUNCH',
                    ('Error: '+$_.Exception.Message),
                    ('Tipo: '+$_.Exception.GetType().FullName),
                    ('Posición: '+$_.InvocationInfo.PositionMessage),
                    ('Script stack: '+$_.ScriptStackTrace),
                    '',
                    ($_ | Out-String)
                ) -join "`r`n"
                try{[IO.File]::WriteAllText($mmLog,$mmDetail,(New-Object Text.UTF8Encoding($false)))}catch{}
                [System.Windows.Forms.MessageBox]::Show(
                    ("No se pudo abrir el Gestor de Mods.`r`n`r`n"+$_.Exception.Message+"`r`n`r`nPosición:`r`n"+$_.InvocationInfo.PositionMessage+"`r`n`r`nDetalle guardado en:`r`n"+$mmLog),
                    'Cobbleverse - Gestor de Mods',
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Error
                )|Out-Null
            }
        })
        $mn=New-AdvLabel 'Seguridad: /mods/** sigue excluido del protocolo del mundo. El gestor usa mod-manager-v1 en Drive y crea una transacción de rollback antes de aplicar cambios.' 18 196 980 55 $false;$mn.ForeColor=$muted;$tm.Controls.Add($mn)

        $tp=Add-AdvancedTab -Tabs $inner -Title 'Rendimiento'
        $script:advPerfGrid=New-Object System.Windows.Forms.DataGridView;$script:advPerfGrid.Dock='Fill';$script:advPerfGrid.ReadOnly=$true;$script:advPerfGrid.AllowUserToAddRows=$false;$script:advPerfGrid.AutoSizeColumnsMode='Fill';$script:advPerfGrid.BackgroundColor=$panel;$script:advPerfGrid.ForeColor=[System.Drawing.Color]::Black
        foreach($c in @('Fecha','Antes Java','Drive inicial','Manifiesto','Validación','ZIP/outbox','Subida','Cierre total')){[void]$script:advPerfGrid.Columns.Add($c,$c)};$tp.Controls.Add($script:advPerfGrid)

        $t=Add-AdvancedTab -Tabs $inner -Title '5.0'
        $b1=New-AdvButton 'Comprobación previa' 16 16 180 32;$t.Controls.Add($b1);$b1.Add_Click({Start-AdvancedAction -Label 'Precheck 5.0' -Data @{action='preflight'} -SafeWhileServerRunning $true})
        $b2=New-AdvButton 'Medir uso Drive' 206 16 160 32;$t.Controls.Add($b2);$b2.Add_Click({Start-AdvancedAction -Label 'Medir Drive' -Data @{action='drive-usage'} -SafeWhileServerRunning $true})
        $b3=New-AdvButton 'Calcular actualización' 376 16 180 32;$t.Controls.Add($b3);$b3.Add_Click({Start-AdvancedAction -Label 'Plan de sync' -Data @{action='sync-plan'} -SafeWhileServerRunning $true})
        $b4=New-AdvButton 'Verificar integridad profunda' 566 16 220 32;$t.Controls.Add($b4);$b4.Add_Click({if([System.Windows.Forms.MessageBox]::Show('Esta comprobación lee el contenido de todos los archivos sincronizados y puede tardar varios minutos. ¿Continuar?','Integridad','YesNo','Warning') -eq 'Yes'){Start-AdvancedAction -Label 'Integridad profunda' -Data @{action='integrity-deep'} -SafeWhileServerRunning $false}})
        $script:advV5Text=New-Object System.Windows.Forms.TextBox;$script:advV5Text.Multiline=$true;$script:advV5Text.ReadOnly=$true;$script:advV5Text.ScrollBars='Vertical';$script:advV5Text.Location=New-Object System.Drawing.Point(16,62);$script:advV5Text.Size=New-Object System.Drawing.Size(1050,310);$script:advV5Text.Anchor='Top,Left,Right';$script:advV5Text.BackColor=$panel2;$script:advV5Text.ForeColor=$text;$script:advV5Text.Font=New-Object System.Drawing.Font('Consolas',9);$t.Controls.Add($script:advV5Text)
        $up=New-AdvButton 'Actualizar app desde ZIP' 16 392 200 32;$t.Controls.Add($up);$up.Add_Click({Start-AdvancedUpdater})
        $save=New-AdvButton 'Guardar perfil UI' 226 392 160 32;$t.Controls.Add($save);$save.Add_Click({$dir=Join-Path $script:DataDir 'ui-profiles';New-Item -ItemType Directory -Force -Path $dir|Out-Null;$d=New-Object System.Windows.Forms.SaveFileDialog;$d.InitialDirectory=$dir;$d.Filter='Diseño UI (*.json)|*.json';$d.FileName='mi-diseno.json';if($d.ShowDialog() -eq 'OK'){if(Test-Path -LiteralPath $script:UiLayoutPath){Copy-Item -LiteralPath $script:UiLayoutPath -Destination $d.FileName -Force}else{[System.Windows.Forms.MessageBox]::Show('Guarda primero un diseño desde el editor visual.','Cobbleverse')|Out-Null}}})
        $load=New-AdvButton 'Cargar perfil UI' 396 392 160 32;$t.Controls.Add($load);$load.Add_Click({$dir=Join-Path $script:DataDir 'ui-profiles';New-Item -ItemType Directory -Force -Path $dir|Out-Null;$d=New-Object System.Windows.Forms.OpenFileDialog;$d.InitialDirectory=$dir;$d.Filter='Diseño UI (*.json)|*.json';if($d.ShowDialog() -eq 'OK'){Copy-Item -LiteralPath $d.FileName -Destination $script:UiLayoutPath -Force;try{$layout=[IO.File]::ReadAllText($script:UiLayoutPath)|ConvertFrom-Json;Apply-UiLayoutObject -Layout $layout -MarkCustom}catch{}}})
        $note=New-AdvLabel '5.0 PREVIEW: conserva el protocolo de sincronización de 4.9.x. Si algo no te convence, puedes volver a una versión del paquete de rollback.' 16 446 980 48 $false;$note.ForeColor=$orange;$t.Controls.Add($note)
    }

    $script:advancedInitialized=$true
    Refresh-AdvancedHistory;Refresh-AdvancedDashboard;Refresh-AdvancedPlayers;Refresh-AdvancedBackupList;Refresh-AdvancedNetwork;Refresh-AdvancedEnvironment;Refresh-AdvancedCheckpoint
}
