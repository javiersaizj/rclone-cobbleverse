﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
. (Join-Path $PSScriptRoot "DeltaSync.ps1")

$session = $null
$heartbeat = $null

function Find-ImportedServerRoot {
    param([string]$Path)
    if (Test-Path (Join-Path $Path "server.properties")) { return (Resolve-Path $Path).Path }
    if (Test-Path (Join-Path $Path "mods")) { return (Resolve-Path $Path).Path }
    $prop = Get-ChildItem -Path $Path -Recurse -File -Filter "server.properties" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -ne $prop) { return $prop.Directory.FullName }
    $mods = Get-ChildItem -Path $Path -Recurse -Directory -Filter "mods" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -ne $mods) { return $mods.Parent.FullName }
    throw "No se ha encontrado la raiz del servidor dentro de esa carpeta."
}

try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== SEGUNDO PC - VINCULAR SU PROPIA COPIA DEL HOSTING - v4.3 ===" -ForegroundColor Green
    Write-Host "NO copies nada desde el PC1. Selecciona la carpeta completa que este PC ya tiene descargada del hosting." -ForegroundColor Cyan
    Write-Host ""

    $baseline = Get-RemoteDeltaBaseline
    $current = Get-RemoteDeltaCurrent
    if ($null -eq $baseline -or $null -eq $current) { throw "El PC principal aun no ha creado la base v4.3. Ejecuta primero 01_IMPORTAR_DESDE_HOSTING.bat en PC1." }

    $sourceInput = (Read-Host "Ruta de CobbleverseShared/servidor del hosting en ESTE PC").Trim('"')
    if (-not (Test-Path -LiteralPath $sourceInput -PathType Container)) { throw "La ruta indicada no existe o no es una carpeta." }
    $sourceRoot = Find-ImportedServerRoot -Path $sourceInput

    $session = Acquire-GameplayLock
    $heartbeat = Start-LockHeartbeat -SessionId $session
    Set-GameplayLockStatus -SessionId $session -Status "linking-second-pc"

    $configured = Set-ConfiguredServerPath -Path $sourceRoot
    Write-Host "Carpeta del servidor configurada: $configured" -ForegroundColor Green
    Normalize-ServerProperties
    Ensure-EulaAccepted
    $jar = Find-ServerJar
    if ($null -eq $jar) { throw "No se ha encontrado un launcher/JAR del servidor en esta copia." }
    $script:Config.ServerJar = $jar
    $script:Config.SyncProtocol = 'delta-overlay-v1'
    Save-CobbleverseConfig

    $check = Assert-LocalBaseMatchesRemoteDelta
    Set-LocalDeltaState -Generation 0 -BaselineId ([string]$baseline.baselineId)
    Publish-DeltaClientState -Generation 0 -Status 'base-ready'
    Write-Host "La base local coincide con PC1." -ForegroundColor Green

    Set-GameplayLockStatus -SessionId $session -Status "applying-pending-deltas"
    $applied = Apply-RemoteDeltaChanges
    Write-Host ("PC2 actualizado a la generacion {0}." -f $applied.generation) -ForegroundColor Green

    $null = Try-AutoRebaseDelta
    Show-DeltaRemoteUsage

    Write-Host ""
    Write-Host "SEGUNDO PC VINCULADO CORRECTAMENTE." -ForegroundColor Green
    Write-Host "Desde ahora ambos PCs usan 02_INICIAR_COBBLEVERSE.bat." -ForegroundColor Cyan
    Write-Host "El script arrancara directamente el servidor desde: $script:ServerDir" -ForegroundColor Cyan

    Release-GameplayLock -SessionId $session
    $session = $null
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    if (-not [string]::IsNullOrWhiteSpace([string]$_.ScriptStackTrace)) {
        Write-Host "Detalle tecnico:" -ForegroundColor DarkGray
        Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    }
    exit 1
}
finally {
    Stop-LockHeartbeat -Job $heartbeat
    if ($null -ne $session) { Release-GameplayLock -SessionId $session }
}
