﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
try {
    Initialize-CobbleverseEnvironment
    if ([string]::IsNullOrWhiteSpace([string]$script:Config.ServerPath)) { throw "Configura primero la carpeta real del servidor." }
    Write-Host "Creando backup LOCAL deduplicado. No usa Google Drive..." -ForegroundColor Cyan
    Backup-Server -ExtraTags @('manual-v42')
    Write-Host "Backup local completado." -ForegroundColor Green
}
catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
