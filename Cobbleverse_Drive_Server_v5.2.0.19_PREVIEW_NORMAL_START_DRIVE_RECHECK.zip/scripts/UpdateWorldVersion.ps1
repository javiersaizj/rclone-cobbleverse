﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
. (Join-Path $PSScriptRoot "DeltaSync.ps1")

$maintenanceSession = $null
$maintenanceHeartbeat = $null

try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== COBBLEVERSE - ACTUALIZAR VERSION DE MUNDO v4.9.9 PERFORMANCE ===" -ForegroundColor Green
    Write-Host "Carpeta real del servidor: $script:ServerDir" -ForegroundColor DarkGray

    if ([string]::IsNullOrWhiteSpace([string]$script:Config.ServerPath)) {
        throw "Este PC aun no tiene configurada su carpeta CobbleverseShared. Ejecuta 01_IMPORTAR_DESDE_HOSTING.bat (PC1) u 08_PREPARAR_SEGUNDO_PC.bat (PC2)."
    }
    if (-not (Test-Path -LiteralPath $script:ServerDir -PathType Container)) { throw "No existe la carpeta configurada del servidor: $script:ServerDir" }

    # Nunca se pisan avances locales pendientes.
    $dirty = Get-DirtyMarker
    if ($null -ne $dirty) {
        throw "Este PC tiene una sesion local pendiente de publicar. Arranca el servidor en este mismo PC y recupera/cierra esa sesion antes de usar la actualizacion manual."
    }

    $local = Get-LocalDeltaState
    if ($null -eq $local) { throw "Este PC aun no esta vinculado. Usa 01_IMPORTAR... (PC1) u 08_PREPARAR_SEGUNDO_PC.bat (PC2)." }
    Write-Host ("Generacion local actual: {0}" -f ([int64]$local.generation)) -ForegroundColor DarkGray

    # v4.9.6: IMPORTANTE. La descarga de generaciones NO reserva server-lock.json.
    # Es una operacion de lectura/aplicacion sobre ESTE PC, por lo que el otro ordenador
    # puede arrancar Minecraft mientras nosotros nos ponemos al dia.
    Write-Host "Actualizacion no exclusiva: el otro PC puede arrancar Minecraft mientras este PC descarga generaciones." -ForegroundColor DarkGreen

    $controlSnapshot = Get-RemoteDeltaSnapshot
    $deltaCurrent = $controlSnapshot.Current
    $deltaBaseline = $controlSnapshot.Baseline
    if ($null -eq $deltaCurrent -or $null -eq $deltaBaseline) { throw "No existe la base delta v4.2 en Drive. Configura primero PC1." }

    Write-Host ""
    Write-Host "Comprobando si hay generaciones pendientes en Drive..." -ForegroundColor Cyan
    $applied = Apply-RemoteDeltaChanges -Baseline $deltaBaseline -Current $deltaCurrent

    $localAfter = Get-LocalDeltaState
    if ($null -eq $localAfter) { throw "No se pudo leer la generacion local tras actualizar." }

    Write-Host ""
    Write-Host ("Este PC ya queda en la generacion {0}." -f ([int64]$localAfter.generation)) -ForegroundColor Green
    Write-Host ("Resumen: {0} archivos descargados / actualizados; {1} borrados." -f ([int64]$applied.downloaded),([int64]$applied.deleted)) -ForegroundColor DarkGray

    # La compactacion SI necesita una ventana exclusiva, porque modifica baseline/current
    # y purga bundles. Solo intentamos tomar ese bloqueo DESPUES de terminar la descarga.
    # Si otro PC ha arrancado Minecraft mientras actualizabamos, simplemente se omite:
    # sus paquetes quedan en Drive y se limpiaran en un mantenimiento posterior.
    Write-Host ""
    Write-Host "Revisando si se pueden compactar generaciones antiguas..." -ForegroundColor DarkCyan
    $rebased = $false
    $lockBeforeMaintenance = Get-RemoteLock
    if ($null -ne $lockBeforeMaintenance) {
        Write-Host ("Hay una sesion de servidor reservada por {0}; se omite la compactacion para no interferir con Minecraft." -f [string]$lockBeforeMaintenance.host) -ForegroundColor DarkGray
    }
    else {
        try {
            # Acquire-GameplayLock resuelve tambien la carrera si el otro PC pulsa Iniciar
            # justo en este instante. Si perdemos esa carrera, la actualizacion del mundo
            # YA esta completada: solo se omite la limpieza.
            $maintenanceSession = Acquire-GameplayLock
            $maintenanceHeartbeat = Start-LockHeartbeat -SessionId $maintenanceSession
            Set-GameplayLockStatus -SessionId $maintenanceSession -Status "maintenance-rebase"
            $rebased = Try-AutoRebaseDelta -ExpectedGeneration ([int64]$localAfter.generation) -ExpectedSessionId $maintenanceSession
        }
        catch {
            Write-Host ("Compactacion pospuesta de forma segura: {0}" -f $_.Exception.Message) -ForegroundColor DarkGray
            $rebased = $false
        }
        finally {
            try { Stop-LockHeartbeat -Job $maintenanceHeartbeat } catch {}
            $maintenanceHeartbeat = $null
            try {
                if (-not [string]::IsNullOrWhiteSpace([string]$maintenanceSession)) {
                    Release-GameplayLock -SessionId $maintenanceSession
                }
            } catch {}
            $maintenanceSession = $null
        }
    }

    if ($rebased) {
        Write-Host "Compactacion completada: Drive ya no necesita conservar las generaciones antiguas para este mundo." -ForegroundColor Green
    }
    else {
        Write-Host "La actualizacion local esta completa. La limpieza de Drive queda para cuando exista una ventana segura." -ForegroundColor DarkGray
    }

    Write-Host ""
    Write-Host "ACTUALIZACION MANUAL COMPLETADA." -ForegroundColor Green
}
finally {
    try { Stop-LockHeartbeat -Job $maintenanceHeartbeat } catch {}
    try {
        if (-not [string]::IsNullOrWhiteSpace([string]$maintenanceSession)) {
            Release-GameplayLock -SessionId $maintenanceSession
        }
    } catch {}
}
