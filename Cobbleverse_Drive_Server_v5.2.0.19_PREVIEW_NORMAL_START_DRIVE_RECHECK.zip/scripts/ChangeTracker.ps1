﻿param(
    [Parameter(Mandatory=$true)][string]$ServerDir,
    [Parameter(Mandatory=$true)][string]$BaselineManifestPath,
    [Parameter(Mandatory=$true)][string]$CandidatesPath,
    [Parameter(Mandatory=$true)][string]$StatePath,
    [Parameter(Mandatory=$true)][string]$StopPath,
    [Parameter(Mandatory=$true)][string]$ReadyPath,
    [Parameter(Mandatory=$true)][string]$FinalDirsPath,
    [string]$LogPath = "",
    [int]$SweepIntervalMs = 3000,
    [int]$DirectoriesPerSweep = 1
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-Utf8NoBomAtomic {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$Text)
    $tmp = $Path + '.tmp-' + [guid]::NewGuid().ToString('N')
    [IO.File]::WriteAllText($tmp, $Text, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $tmp -Destination $Path -Force
}

function Write-LinesAtomic {
    param([Parameter(Mandatory=$true)][string]$Path,[string[]]$Lines=@())
    $tmp = $Path + '.tmp-' + [guid]::NewGuid().ToString('N')
    [IO.File]::WriteAllLines($tmp, [string[]]$Lines, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $tmp -Destination $Path -Force
}


function Write-TrackerLog {
    param([string]$Message)
    if ([string]::IsNullOrWhiteSpace($LogPath)) { return }
    try {
        $parentLog = Split-Path -Parent $LogPath
        if (-not [string]::IsNullOrWhiteSpace($parentLog)) { New-Item -ItemType Directory -Force -Path $parentLog | Out-Null }
        [IO.File]::AppendAllText($LogPath, (("[{0}] {1}`r`n" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'),$Message)), (New-Object Text.UTF8Encoding($false)))
    } catch {}
}

function Test-ExcludedRel {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    $p = $RelativePath.Replace('\','/').TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($p)) { return $true }
    $first = ($p -split '/',2)[0]
    foreach ($name in @('logs','crash-reports','backups','.cache','.mixin.out')) {
        if ($first -ieq $name) { return $true }
    }
    if ($p -ieq 'world/session.lock') { return $true }
    $leaf = [IO.Path]::GetFileName($p)
    if ($leaf -like 'hs_err_pid*.log' -or $leaf -ieq 'debug.log') { return $true }
    return $false
}

$watcher = $null
$subs = @()
$candidates = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$overflow = $false
$requiresFullScan = $false
Write-TrackerLog -Message ("Tracker process started. ServerDir={0}" -f $ServerDir)
try {
$root = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($ServerDir)).TrimEnd([char[]]@([char]'\',[char]'/'))
$rootPrefix = $root + [IO.Path]::DirectorySeparatorChar
$parent = Split-Path -Parent $CandidatesPath
if (-not [string]::IsNullOrWhiteSpace($parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
Remove-Item -LiteralPath $CandidatesPath,$StatePath,$ReadyPath,$FinalDirsPath -Force -ErrorAction SilentlyContinue

# Baja prioridad para que el preescaneo ceda CPU al servidor Java.
try { (Get-Process -Id $PID).PriorityClass = 'BelowNormal' } catch {}

$baselineRaw = [IO.File]::ReadAllText($BaselineManifestPath)

# v4.9.8: Windows PowerShell 5.1 puede entregar el array JSON completo como un
# único System.Object[] al usar ConvertFrom-Json. Si se envuelve otra vez en @(),
# cada propiedad (.s/.t) se convierte en otro Object[] y el cast a Int64 falla.
# Aplanamos explícitamente cualquier nivel de array antes de procesar registros.
$baselineItems = New-Object 'System.Collections.Generic.List[object]'
function Add-BaselineParsedItem {
    param($Value)
    if ($null -eq $Value) { return }
    if ($Value -is [System.Array]) {
        foreach ($child in $Value) { Add-BaselineParsedItem -Value $child }
        return
    }
    $baselineItems.Add($Value)
}
if (-not [string]::IsNullOrWhiteSpace($baselineRaw)) {
    $parsedBaseline = ConvertFrom-Json -InputObject $baselineRaw
    Add-BaselineParsedItem -Value $parsedBaseline
}
Write-TrackerLog -Message ("Baseline JSON parsed. Records={0}" -f $baselineItems.Count)

$baselineMap = @{}
$baselineByDir = @{}
foreach ($item in $baselineItems) {
    if ($null -eq $item) { continue }
    if (-not ($item.PSObject.Properties.Name -contains 'p') -or -not ($item.PSObject.Properties.Name -contains 's') -or -not ($item.PSObject.Properties.Name -contains 't')) {
        throw "Registro inválido en el manifiesto inicial: faltan p/s/t."
    }
    $p = ([string]$item.p).Replace('\','/').TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($p) -or (Test-ExcludedRel $p)) { continue }

    $sizeValue = $item.s
    $timeValue = $item.t
    if ($sizeValue -is [System.Array]) {
        if ($sizeValue.Count -ne 1) { throw "Tamaño no escalar en el manifiesto para '$p' (Count=$($sizeValue.Count))." }
        $sizeValue = $sizeValue[0]
    }
    if ($timeValue -is [System.Array]) {
        if ($timeValue.Count -ne 1) { throw "Fecha no escalar en el manifiesto para '$p' (Count=$($timeValue.Count))." }
        $timeValue = $timeValue[0]
    }
    $rec = [pscustomobject]@{ p=$p; s=[Convert]::ToInt64($sizeValue); t=[Convert]::ToInt64($timeValue) }
    $baselineMap[$p] = $rec
    $slash = $p.LastIndexOf('/')
    $dirRel = ''
    if ($slash -ge 0) { $dirRel = $p.Substring(0,$slash) }
    if (-not $baselineByDir.ContainsKey($dirRel)) { $baselineByDir[$dirRel] = New-Object 'System.Collections.Generic.List[string]' }
    $baselineByDir[$dirRel].Add($p)
}

$candidates = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$dirQueue = New-Object 'System.Collections.Generic.Queue[string]'
foreach ($d in @($baselineByDir.Keys | Sort-Object)) { $dirQueue.Enqueue([string]$d) }
[int64]$sweepsCompleted = 0
$requiresFullScan = $false
$overflow = $false
$lastEventUtc = $null
$script:lastFlush = [DateTime]::UtcNow.AddSeconds(-10)
$lastSweep = [DateTime]::UtcNow.AddMilliseconds(-$SweepIntervalMs)
$startedUtc = [DateTimeOffset]::UtcNow

function Get-RelFromFull {
    param([string]$FullPath)
    if ([string]::IsNullOrWhiteSpace($FullPath)) { return $null }
    try { $full = [IO.Path]::GetFullPath($FullPath) } catch { return $null }
    if ($full.Length -lt $root.Length -or -not $full.StartsWith($root,[StringComparison]::OrdinalIgnoreCase)) { return $null }
    $rel = $full.Substring($root.Length).TrimStart([char[]]@([char]'\',[char]'/')).Replace('\','/')
    if ([string]::IsNullOrWhiteSpace($rel) -or (Test-ExcludedRel $rel)) { return $null }
    return $rel
}

function Add-Candidate {
    param([string]$FullPath)
    $rel = Get-RelFromFull $FullPath
    if (-not [string]::IsNullOrWhiteSpace($rel)) { $null = $candidates.Add($rel) }
}

function Write-State {
    param([string]$Status='running')
    $lastEventText = $null
    if ($null -ne $lastEventUtc) { $lastEventText = $lastEventUtc.ToString('o') }
    $obj = [ordered]@{
        protocol = 'background-change-tracker-v1'
        status = $Status
        pid = $PID
        startedUtc = $startedUtc.ToString('o')
        updatedUtc = [DateTimeOffset]::UtcNow.ToString('o')
        lastEventUtc = $lastEventText
        candidates = [int64]$candidates.Count
        sweepsCompleted = [int64]$sweepsCompleted
        remainingDirectoriesInSweep = [int64]$dirQueue.Count
        overflow = [bool]$overflow
        requiresFullScan = [bool]$requiresFullScan
    }
    Write-Utf8NoBomAtomic -Path $StatePath -Text (ConvertTo-Json -InputObject $obj -Depth 4 -Compress)
    Write-LinesAtomic -Path $CandidatesPath -Lines @($candidates | Sort-Object)
    $script:lastFlush = [DateTime]::UtcNow
}

$watcher = New-Object IO.FileSystemWatcher
$watcher.Path = $root
$watcher.IncludeSubdirectories = $true
$watcher.NotifyFilter = [IO.NotifyFilters]'FileName, DirectoryName, LastWrite, Size'
try { $watcher.InternalBufferSize = 65536 } catch {}
$watcher.EnableRaisingEvents = $true
$subs = @()
    $subs += Register-ObjectEvent -InputObject $watcher -EventName Changed -SourceIdentifier ('ct-changed-' + $PID)
    $subs += Register-ObjectEvent -InputObject $watcher -EventName Created -SourceIdentifier ('ct-created-' + $PID)
    $subs += Register-ObjectEvent -InputObject $watcher -EventName Deleted -SourceIdentifier ('ct-deleted-' + $PID)
    $subs += Register-ObjectEvent -InputObject $watcher -EventName Renamed -SourceIdentifier ('ct-renamed-' + $PID)
    $subs += Register-ObjectEvent -InputObject $watcher -EventName Error   -SourceIdentifier ('ct-error-' + $PID)

    Write-State -Status 'ready'
    Write-Utf8NoBomAtomic -Path $ReadyPath -Text ([DateTimeOffset]::UtcNow.ToString('o'))
    Write-TrackerLog -Message ("Tracker READY. BaselineFiles={0}; Directories={1}" -f $baselineMap.Count,$baselineByDir.Count)

    $stopSeen = $false
    while (-not $stopSeen) {
        # Drenar eventos sin trabajo pesado.
        foreach ($evt in @(Get-Event -ErrorAction SilentlyContinue)) {
            if ($null -eq $evt -or -not ([string]$evt.SourceIdentifier).StartsWith('ct-')) { continue }
            try {
                if ([string]$evt.SourceIdentifier -like 'ct-error-*') {
                    $overflow = $true
                    $requiresFullScan = $true
                }
                elseif ([string]$evt.SourceIdentifier -like 'ct-renamed-*') {
                    $args = $evt.SourceEventArgs
                    Add-Candidate -FullPath ([string]$args.OldFullPath)
                    Add-Candidate -FullPath ([string]$args.FullPath)
                    # Renombrar una carpeta puede mover muchos hijos sin que Windows entregue
                    # un evento por archivo. En ese caso preferimos el escaneo completo al cerrar.
                    $oldRel = Get-RelFromFull ([string]$args.OldFullPath)
                    if ((-not [string]::IsNullOrWhiteSpace($oldRel) -and $baselineByDir.ContainsKey($oldRel)) -or (Test-Path -LiteralPath ([string]$args.FullPath) -PathType Container)) { $requiresFullScan = $true }
                    $lastEventUtc = [DateTimeOffset]::UtcNow
                }
                else {
                    $args = $evt.SourceEventArgs
                    $fullPath = [string]$args.FullPath
                    Add-Candidate -FullPath $fullPath
                    $rel = Get-RelFromFull $fullPath
                    if (-not [string]::IsNullOrWhiteSpace($rel)) {
                        # Una eliminacion que coincide con una carpeta de la base exige fallback.
                        if ([string]$evt.SourceIdentifier -like 'ct-deleted-*' -and $baselineByDir.ContainsKey($rel)) { $requiresFullScan = $true }
                        if ([string]$evt.SourceIdentifier -like 'ct-created-*' -and (Test-Path -LiteralPath $fullPath -PathType Container)) {
                            # Una carpeta completamente nueva puede contener muchos hijos. Para no
                            # depender de que Windows entregue cada evento hijo, preferimos fallback
                            # completo al cerrar. Es raro y prioriza fiabilidad.
                            $dirQueue.Enqueue($rel)
                            $requiresFullScan = $true
                        }
                    }
                    $lastEventUtc = [DateTimeOffset]::UtcNow
                }
            }
            catch { $requiresFullScan = $true }
            finally { Remove-Event -EventIdentifier $evt.EventIdentifier -ErrorAction SilentlyContinue }
        }

        # Barrido suave: como maximo unas pocas carpetas por ciclo. Solo metadatos.
        if (([DateTime]::UtcNow - $lastSweep).TotalMilliseconds -ge $SweepIntervalMs) {
            for ($i=0; $i -lt [Math]::Max(1,$DirectoriesPerSweep); $i++) {
                if ($dirQueue.Count -eq 0) {
                    $sweepsCompleted++
                    foreach ($d in @($baselineByDir.Keys | Sort-Object)) { $dirQueue.Enqueue([string]$d) }
                    if ($dirQueue.Count -eq 0) { break }
                }
                $dirRel = $dirQueue.Dequeue()
                $dirFull = $root
                if (-not [string]::IsNullOrWhiteSpace($dirRel)) { $dirFull = Join-Path $root ($dirRel.Replace('/','\')) }
                if (-not (Test-Path -LiteralPath $dirFull -PathType Container)) {
                    if ($baselineByDir.ContainsKey($dirRel)) { foreach ($p in $baselineByDir[$dirRel]) { $null = $candidates.Add([string]$p) } }
                    continue
                }
                try {
                    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
                    $di = New-Object IO.DirectoryInfo($dirFull)
                    foreach ($fi in $di.EnumerateFiles()) {
                        $rel = Get-RelFromFull $fi.FullName
                        if ([string]::IsNullOrWhiteSpace($rel)) { continue }
                        $null = $seen.Add($rel)
                        if (-not $baselineMap.ContainsKey($rel)) { $null = $candidates.Add($rel); continue }
                        $old = $baselineMap[$rel]
                        if ([int64]$old.s -ne [int64]$fi.Length -or [int64]$old.t -ne [int64]$fi.LastWriteTimeUtc.Ticks) { $null = $candidates.Add($rel) }
                    }
                    if ($baselineByDir.ContainsKey($dirRel)) {
                        foreach ($p in $baselineByDir[$dirRel]) { if (-not $seen.Contains([string]$p)) { $null = $candidates.Add([string]$p) } }
                    }
                    # Incorporar subcarpetas nuevas al barrido sin recorrerlas de golpe.
                    foreach ($sub in $di.EnumerateDirectories()) {
                        if (($sub.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                        $subRel = Get-RelFromFull $sub.FullName
                        if (-not [string]::IsNullOrWhiteSpace($subRel) -and -not $baselineByDir.ContainsKey($subRel)) {
                            $dirQueue.Enqueue($subRel)
                            # Descubrir una carpeta que no existia en la base es una situacion
                            # excepcional: hacemos fallback completo al cierre para incluir todos
                            # sus posibles descendientes con maxima seguridad.
                            $requiresFullScan = $true
                        }
                    }
                }
                catch { $requiresFullScan = $true }
            }
            $lastSweep = [DateTime]::UtcNow
        }

        if (([DateTime]::UtcNow - $script:lastFlush).TotalSeconds -ge 5) { Write-State -Status 'running' }
        if (Test-Path -LiteralPath $StopPath) { $stopSeen = $true; break }
        Start-Sleep -Milliseconds 200
    }

    # Dejar una pequena ventana para que lleguen los ultimos eventos generados por el cierre de Java.
    Start-Sleep -Milliseconds 750
    foreach ($evt in @(Get-Event -ErrorAction SilentlyContinue)) {
        if ($null -eq $evt -or -not ([string]$evt.SourceIdentifier).StartsWith('ct-')) { continue }
        try {
            if ([string]$evt.SourceIdentifier -like 'ct-error-*') { $overflow=$true; $requiresFullScan=$true }
            elseif ([string]$evt.SourceIdentifier -like 'ct-renamed-*') {
                Add-Candidate -FullPath ([string]$evt.SourceEventArgs.OldFullPath)
                Add-Candidate -FullPath ([string]$evt.SourceEventArgs.FullPath)
                $oldRel = Get-RelFromFull ([string]$evt.SourceEventArgs.OldFullPath)
                if ((-not [string]::IsNullOrWhiteSpace($oldRel) -and $baselineByDir.ContainsKey($oldRel)) -or (Test-Path -LiteralPath ([string]$evt.SourceEventArgs.FullPath) -PathType Container)) { $requiresFullScan=$true }
            }
            else {
                $fullPath = [string]$evt.SourceEventArgs.FullPath
                Add-Candidate -FullPath $fullPath
                $rel = Get-RelFromFull $fullPath
                if (-not [string]::IsNullOrWhiteSpace($rel)) {
                    if ([string]$evt.SourceIdentifier -like 'ct-deleted-*' -and $baselineByDir.ContainsKey($rel)) { $requiresFullScan=$true }
                    if ([string]$evt.SourceIdentifier -like 'ct-created-*' -and (Test-Path -LiteralPath $fullPath -PathType Container)) { $requiresFullScan=$true }
                }
            }
        }
        catch { $requiresFullScan=$true }
        finally { Remove-Event -EventIdentifier $evt.EventIdentifier -ErrorAction SilentlyContinue }
    }
    $watcher.EnableRaisingEvents = $false

    # v4.9.1: guardar las carpetas que quedan SIN revisar en el ciclo suave actual.
    # El cierre las inspeccionara de forma directa. Con esto cada carpeta queda cubierta
    # o bien durante la sesion, o bien justo al cerrar. El punto representa la raiz.
    $remainingDirs = New-Object 'System.Collections.Generic.List[string]'
    foreach ($d in @($dirQueue.ToArray())) {
        if ([string]::IsNullOrWhiteSpace([string]$d)) { $remainingDirs.Add('.') }
        else { $remainingDirs.Add(([string]$d).Replace('\','/')) }
    }
    Write-LinesAtomic -Path $FinalDirsPath -Lines ([string[]]@($remainingDirs | Sort-Object -Unique))
    Write-State -Status 'stopped-cleanly'
    Write-TrackerLog -Message ("Tracker stopped cleanly. Candidates={0}; Sweeps={1}; RemainingDirs={2}" -f $candidates.Count,$sweepsCompleted,$dirQueue.Count)
}
catch {
    $requiresFullScan = $true
    Write-TrackerLog -Message ("TRACKER FAILED: {0}`r`n{1}" -f $_.Exception.Message,$_.ScriptStackTrace)
    try {
        $errObj = [ordered]@{
            protocol='background-change-tracker-v1'; status='failed'; pid=$PID
            updatedUtc=[DateTimeOffset]::UtcNow.ToString('o'); candidates=[int64]$candidates.Count
            overflow=[bool]$overflow; requiresFullScan=$true; error=$_.Exception.Message
        }
        Write-Utf8NoBomAtomic -Path $StatePath -Text (ConvertTo-Json -InputObject $errObj -Depth 4 -Compress)
        Write-LinesAtomic -Path $CandidatesPath -Lines @($candidates | Sort-Object)
    } catch {}
    exit 2
}
finally {
    if ($null -ne $watcher) { try { $watcher.EnableRaisingEvents=$false; $watcher.Dispose() } catch {} }
    foreach ($s in @($subs)) { try { Unregister-Event -SubscriptionId $s.Id -ErrorAction SilentlyContinue } catch {} }
}
