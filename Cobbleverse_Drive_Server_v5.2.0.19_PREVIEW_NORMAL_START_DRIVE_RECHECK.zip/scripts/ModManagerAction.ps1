﻿Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'DeltaSync.ps1')
. (Join-Path $PSScriptRoot 'ModManagerCore.ps1')
. (Join-Path $PSScriptRoot 'ModTestCore.ps1')

Initialize-ModManagerEnvironment
$reqPath=Join-Path $script:ModManagerDir 'action.json'
if(-not(Test-Path -LiteralPath $reqPath)){throw 'No existe la petición del gestor de mods.'}
$req=[IO.File]::ReadAllText($reqPath)|ConvertFrom-Json
$action=[string]$req.action

function Assert-NoActiveServerForMods {
    Assert-ModManagerDriveReady
    $lock=Get-RemoteLock
    if($null-ne$lock){
        $status=[string]$lock.status
        if($status -in @('claiming','preparing','server-running','stopping','syncing','restore-backup')){throw "No se pueden modificar mods mientras el servidor está reservado/activo ($status, $($lock.host)). Apágalo y sincroniza primero."}
    }
}
function Write-Result([string]$Name,$Object){Write-ModManagerJson (Join-Path $script:ModManagerDir $Name) $Object 30}

try{
    switch($action){
        'status' { Assert-ModManagerDriveReady;$s=Get-ModManagerStatus;Write-Host ("Mods: cliente {0}, servidor {1}; G local {2}, Drive {3}." -f $s.clientMods,$s.serverMods,$s.localGeneration,$s.remoteGeneration) -ForegroundColor Green }
        'scan' { $i=Get-ModManagerInventory;$c=Test-ModManagerInventoryCompatibility $i;Write-Result 'validation.json' $c;Write-Host ("Escaneo completado: {0} cliente, {1} servidor, {2} problemas." -f $i.clientCount,$i.serverCount,@($i.problems).Count) -ForegroundColor $(if($c.ok){'Green'}else{'Yellow'}) }
        'adopt' { Assert-NoActiveServerForMods;$m=Publish-CurrentModSet -Reason 'adopt-current-pack';Write-Host ("Pack actual adoptado como modset G{0}: {1} mods gestionados." -f $m.generation,@($m.mods).Count) -ForegroundColor Green }
        'sync' { Assert-NoActiveServerForMods;$m=Apply-RemoteModSet;Write-Host ("Modset G{0} aplicado en cliente y servidor local." -f $m.generation) -ForegroundColor Green }
        'search' { $q=[string]$req.query;if([string]::IsNullOrWhiteSpace($q)){throw 'Escribe un nombre para buscar.'};$r=Search-ModrinthMods $q;Write-Host ("Modrinth: {0} resultados compatibles con {1}/{2}." -f @($r).Count,$script:Config.MinecraftVersion,(Get-ModManagerLoader)) -ForegroundColor Green }
        'add-modrinth' { Assert-NoActiveServerForMods;$projectIdValue=[string]$req.projectId;if([string]::IsNullOrWhiteSpace($projectIdValue)){throw 'Proyecto Modrinth vacío.'};$plan=Resolve-ModrinthPlan $projectIdValue;$dl=Download-ModrinthPlan $plan;try{$m=Install-StagedModsAndPublish -Files $dl.files -Reason ("add-modrinth-$projectIdValue");Write-Host ("Añadido y publicado: {0}. Dependencias incluidas: {1}. Modset G{2}." -f (($plan|Where-Object{$_.projectId-eq$projectIdValue}|Select-Object -First 1).project.title),([Math]::Max(0,@($plan).Count-1)),$m.generation) -ForegroundColor Green}finally{Remove-Item -LiteralPath $dl.directory -Recurse -Force -ErrorAction SilentlyContinue} }
        'import-jar' { Assert-NoActiveServerForMods;$m=Import-LocalJarAndPublish -JarPath ([string]$req.jarPath) -Side ([string]$req.side);Write-Host ("JAR importado y modset publicado como G{0}." -f $m.generation) -ForegroundColor Green }
        'update-local-jar' { Assert-NoActiveServerForMods;$m=Update-ManagedModFromLocalJar -JarPath ([string]$req.jarPath) -ModId ([string]$req.modId);Write-Host ("Mod actualizado desde JAR; versión anterior sustituida y modset publicado como G{0}." -f $m.generation) -ForegroundColor Green }
        'resolve-online' { $i=Resolve-ExistingModsAgainstModrinth;Write-Host ("Identificación online completada para {0} mods." -f @($i.mods|Where-Object{$_.source-eq'modrinth'}).Count) -ForegroundColor Green }
        'check-updates' { $u=Find-ModUpdates;Write-Host ("Actualizaciones compatibles encontradas: {0}." -f @($u).Count) -ForegroundColor Green }
        'update-project' { Assert-NoActiveServerForMods;$projectIdValue=[string]$req.projectId;if([string]::IsNullOrWhiteSpace($projectIdValue)){throw 'Este mod no está identificado en Modrinth. Usa Identificar online o importa el JAR manualmente.'};$m=Update-ManagedModFromModrinth -ProjectId $projectIdValue;Write-Host ("Mod actualizado con dependencias; modset G{0}." -f $m.generation) -ForegroundColor Green }
        'update-all' {
            Assert-NoActiveServerForMods;$updates=@(Find-ModUpdates);if($updates.Count-eq0){Write-Host 'No hay actualizaciones compatibles identificadas.' -ForegroundColor Green;break}
            $all=@{};foreach($u in $updates){foreach($x in @(Resolve-ModrinthPlan ([string]$u.projectId))){$all[[string]$x.projectId]=$x}}
            $dl=Download-ModrinthPlan @($all.Values);try{$m=Install-StagedModsAndPublish -Files $dl.files -Reason 'update-all-compatible';Write-Host ("Actualizados {0} proyectos/dependencias; modset G{1}." -f @($all.Values).Count,$m.generation) -ForegroundColor Green}finally{Remove-Item -LiteralPath $dl.directory -Recurse -Force -ErrorAction SilentlyContinue}
        }
        'remove' { Assert-NoActiveServerForMods;$id=[string]$req.modId;if([string]::IsNullOrWhiteSpace($id)){throw 'Selecciona un mod.'};Remove-ManagedModAndPublish $id;Write-Host ("Mod $id eliminado del cliente/servidor según su ámbito y cambio publicado.") -ForegroundColor Green }
        'rollback' { Assert-NoActiveServerForMods;Restore-ModTransaction;Write-Host 'Última transacción de mods deshecha localmente. Revisa el resultado y pulsa Publicar pack actual si quieres convertirlo en la versión compartida.' -ForegroundColor Yellow }
        'publish' { Assert-NoActiveServerForMods;$m=Publish-CurrentModSet -Reason 'manual-publish';Write-Host ("Estado local publicado como modset G{0}." -f $m.generation) -ForegroundColor Green }
        'analyze-crash' { $o=Analyze-ModCrash;Write-Host ("Análisis de crash: {0} candidatos encontrados." -f @($o.candidates).Count) -ForegroundColor Green }
        'validate' { $i=Get-ModManagerInventory;$c=Test-ModManagerInventoryCompatibility $i;Write-Result 'validation.json' $c;if($c.ok){Write-Host ("Validación estática OK. Avisos: {0}." -f @($c.warnings).Count) -ForegroundColor Green}else{Write-Host ("Validación: {0} incompatibilidades y {1} avisos." -f @($c.issues).Count,@($c.warnings).Count) -ForegroundColor Red} }
        'build-test-pack' { Assert-NoActiveServerForMods;$mc=[string]$req.minecraftVersion;$loader=Get-ModManagerLoader;$st=New-ModTestBulkEnvironment -MinecraftVersion $mc -Loader $loader;Write-Host ("Entorno TEST creado: {0} actualizaciones, {1} mods conservados, {2} dependencias, {3} addon(s)/mod(s) a vigilar. Mundo copia en {4}." -f $st.updated,$st.keptCurrent,$st.dependencies,$st.riskyAddons,$st.testServerPath) -ForegroundColor Green }
        'activate-test-client' { $st=Activate-ModTestClient;Write-Host ("TEST copiado al perfil 'New Cobbleverse'. Ábrelo en CurseForge y conecta al servidor TEST por el puerto {0}." -f $st.testPort) -ForegroundColor Yellow }
        'restore-normal-client' { Restore-ModTestClientNormal|Out-Null;Write-Host "Modo TEST desactivado. El perfil NORMAL nunca fue sustituido; selecciónalo en CurseForge." -ForegroundColor Green }
        'start-test-server' { $st=Start-ModTestServerConsole;Write-Host ("Servidor TEST lanzado en una consola independiente. Puerto {0}; ciérralo escribiendo stop." -f $st.testPort) -ForegroundColor Green }
        'promote-test' { Assert-NoActiveServerForMods;$st=Promote-ModTestToNormal;Write-Host ("TEST promovido a NORMAL y publicado como modset G{0}. El mundo normal se ha conservado. La copia anterior de mods/config sigue guardada." -f $st.publishedGeneration) -ForegroundColor Green }
        'delete-test' { Remove-ModTestEnvironment;Write-Host 'Entorno TEST eliminado. El mundo NORMAL no se ha tocado.' -ForegroundColor Green }
        'delete-promotion-backup' { Remove-LatestModPromotionBackup;Write-Host 'Copia anterior de mods/config eliminada.' -ForegroundColor Green }
        default { throw "Acción desconocida del gestor de mods: $action" }
    }
    Get-ModManagerStatus|Out-Null
}
catch{
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    try{Write-Result 'last-error.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');action=$action;message=$_.Exception.Message;detail=($_|Out-String)})}catch{}
    exit 1
}
