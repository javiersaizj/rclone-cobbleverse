﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== BACKUPS LOCALES DE COBBLEVERSE EN ESTE PC ===" -ForegroundColor Green
    Write-Host "Estos backups NO ocupan espacio en Google Drive." -ForegroundColor Cyan
    Invoke-Restic -Arguments @("snapshots", "--host", $env:COMPUTERNAME) | Out-Null
}
catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
