﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'DeltaSync.ps1')

$lockSession = $null
$heartbeat = $null
try {
    Initialize-CobbleverseEnvironment
    # Si la GUI fue terminada a la fuerza pero Java siguiera vivo, no empaquetamos un
    # mundo que Minecraft todavia esta escribiendo. Se reintentara cuando el puerto cierre.
    $localPort = Get-MinecraftServerPort
    $listener = $null
    try { $listener = Get-NetTCPConnection -State Listen -LocalPort $localPort -ErrorAction SilentlyContinue | Select-Object -First 1 } catch { }
    if ($null -ne $listener) {
        Write-Host 'Minecraft sigue escuchando en este PC; la recuperacion se pospone hasta que se cierre.' -ForegroundColor Yellow
        exit 2
    }
    $dirty = Get-DirtyMarker
    $pending = @(Get-PendingSyncItems)
    if ($null -eq $dirty -and $pending.Count -eq 0) { exit 0 }

    # Si hubo apagado brusco antes de crear el outbox READY, reconstruimos SOLO desde
    # el manifiesto previo a la sesion y el estado local actual. No descargamos nada encima.
    if ($pending.Count -eq 0 -and $null -ne $dirty) {
        if (-not [bool]$script:Config.AutoRecoverInterruptedSession) { throw 'Hay una sesion interrumpida que requiere recuperacion manual.' }
        $manifestPath = [string]$dirty.manifestPath
        if ([string]::IsNullOrWhiteSpace($manifestPath) -or -not (Test-Path -LiteralPath $manifestPath)) { throw 'Falta el manifiesto previo de la sesion interrumpida.' }
        Write-Host 'Sesion interrumpida detectada. Reconstruyendo outbox local antes de tocar Drive...' -ForegroundColor Yellow
        $before = Load-FastManifestData -Path $manifestPath
        $after = Get-FastManifestData
        $local = Get-LocalDeltaState
        if ($null -eq $local) { throw 'Falta la generacion local durante la recuperacion.' }
        $queued = Queue-DeltaChangesForSafePublish -BeforeManifest $before -AfterManifest $after -SessionId ([string]$dirty.sessionId) -Reason 'recovery-after-crash' -BaseGeneration ([int64]$dirty.startGeneration) -BaselineId ([string]$local.baselineId)
        if (-not $queued.queued) {
            Write-Host 'La sesion interrumpida no dejo cambios relevantes.' -ForegroundColor DarkGray
        }
        $pending = @(Get-PendingSyncItems)
    }

    # Nunca publicamos cambios mientras otro PC posee una sesion valida.
    $existing = Get-RemoteLock
    if ($null -ne $existing) {
        $sameRecovery = $false
        if ($null -ne $dirty) { $sameRecovery = ([string]$existing.host -eq $env:COMPUTERNAME -and [string]$existing.sessionId -eq [string]$dirty.sessionId) }
        if (-not $sameRecovery) {
            Write-Host ("Sincronizacion pendiente pospuesta: el servidor esta reservado por {0}." -f [string]$existing.host) -ForegroundColor Yellow
            exit 2
        }
    }

    $recoveryId = ''
    if ($null -ne $dirty) { $recoveryId = [string]$dirty.sessionId }
    $lockSession = Acquire-GameplayLock -RecoverySessionId $recoveryId
    $heartbeat = Start-LockHeartbeat -SessionId $lockSession
    Set-GameplayLockStatus -SessionId $lockSession -Status 'retrying-pending-sync'

    if ($pending.Count -gt 0) {
        $result = Publish-PendingSyncQueue
        Write-Host ("Outbox publicado. Generacion final: G{0}." -f $result.generation) -ForegroundColor Green
    }

    # Si no habia cambios o el commit ya estaba hecho, solo queda confirmar que Drive
    # responde y liberar el lock. El dirty marker se borra DESPUES de esto.
    if (-not (Test-DriveRemote)) { throw 'Drive sigue sin conexion; se conserva la recuperacion pendiente.' }
    $released = Release-GameplayLock -SessionId $lockSession
    if (-not $released) { throw 'No se pudo confirmar la liberacion del bloqueo remoto.' }
    $lockSession = $null
    Clear-DirtyMarker
    Remove-Item -LiteralPath $script:SessionStartManifestPath -Force -ErrorAction SilentlyContinue
    Write-Host 'Sincronizacion pendiente finalizada y bloqueo remoto liberado.' -ForegroundColor Green
    exit 0
}
catch {
    Write-Host ("PENDIENTE: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    exit 1
}
finally {
    try { Stop-LockHeartbeat -Job $heartbeat } catch {}
    # No se fuerza la eliminacion de un lock si no podemos confirmar Drive. Se conserva
    # para que el otro PC NO abra una rama mientras este mundo sigue pendiente.
    if ($null -ne $lockSession -and (Test-DriveRemote)) {
        try { [void](Release-GameplayLock -SessionId $lockSession) } catch {}
    }
}
