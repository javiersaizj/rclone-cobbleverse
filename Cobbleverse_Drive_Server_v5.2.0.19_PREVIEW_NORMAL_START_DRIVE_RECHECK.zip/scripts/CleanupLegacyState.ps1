﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== LIMPIAR ESTADO REMOTO DE v4.0/v4.1 ===" -ForegroundColor Yellow
    Write-Host "v4.2 usa CobbleverseSync/delta-v1 y NO usa CobbleverseSync/state." -ForegroundColor Cyan
    $raw = Invoke-RcloneCapture -Arguments @('size', $script:RemoteState, '--json', '--config', $script:RcloneConfig) -IgnoreExitCode
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) {
        Write-Host "No se ha encontrado estado antiguo en Drive." -ForegroundColor Green
        exit 0
    }
    try { $size = $raw | ConvertFrom-Json } catch { $size = $null }
    if ($null -ne $size) { Write-Host ("Espacio antiguo detectado: {0} ({1} archivos)." -f (Format-ByteSize ([int64]$size.bytes)),$size.count) -ForegroundColor Yellow }
    $answer = Read-Host "Escribe BORRAR_ESTADO_V4_ANTIGUO para eliminarlo de Drive"
    if ($answer -cne 'BORRAR_ESTADO_V4_ANTIGUO') { throw "Cancelado." }
    Invoke-Rclone -Arguments @('purge', $script:RemoteState, '--config', $script:RcloneConfig, '--drive-use-trash=false') -IgnoreExitCode | Out-Null
    Invoke-Rclone -Arguments @('deletefile', $script:RemoteStateVersion, '--config', $script:RcloneConfig, '--drive-use-trash=false') -IgnoreExitCode | Out-Null
    Invoke-Rclone -Arguments @('deletefile', $script:RemoteBaseInfo, '--config', $script:RcloneConfig, '--drive-use-trash=false') -IgnoreExitCode | Out-Null
    Write-Host "Estado antiguo eliminado. El protocolo delta-v1 no se ha tocado." -ForegroundColor Green
}
catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
