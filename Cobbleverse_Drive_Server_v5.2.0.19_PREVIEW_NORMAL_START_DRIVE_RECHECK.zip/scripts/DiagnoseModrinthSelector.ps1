Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'ModManagerCore.ps1')
. (Join-Path $PSScriptRoot 'ModTestCore.ps1')
Initialize-App
Initialize-ModManagerPaths
$mc='1.21.1';$loader='fabric'
Write-Host 'Consultando proyecto oficial Modrinth por slug: cobblemon' -ForegroundColor Cyan
$p=Get-ModrinthProject 'cobblemon'
Write-Host ("Proyecto: {0} | slug={1} | id={2}" -f [string]$p.title,[string]$p.slug,[string]$p.id) -ForegroundColor White
$v=Get-ModrinthCompatibleVersionForTarget -ProjectId ([string]$p.id) -MinecraftVersion $mc -Loader $loader
if($null-eq$v){throw 'No se encontró una versión compatible de Cobblemon.'}
Write-Host ("SELECCION: {0} | versionId={1} | fecha={2} | loaders={3} | Minecraft={4}" -f [string]$v.version_number,[string]$v.id,[string]$v.date_published,(@($v.loaders)-join ','),(@($v.game_versions)-join ',')) -ForegroundColor Green
Write-Host ''
Write-Host 'Pulsa ENTER para cerrar.' -ForegroundColor DarkGray
[void][Console]::ReadLine()
