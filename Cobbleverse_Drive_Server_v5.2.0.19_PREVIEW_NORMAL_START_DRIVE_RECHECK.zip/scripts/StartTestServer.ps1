﻿Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'DeltaSync.ps1')
. (Join-Path $PSScriptRoot 'ModManagerCore.ps1')
. (Join-Path $PSScriptRoot 'ModTestCore.ps1')

try{
    Initialize-ModManagerEnvironment
    Initialize-ModTestPaths
    $state=Get-ModTestState
    if($null-eq$state){throw 'No existe un entorno TEST. Créalo desde el Gestor de Mods.'}
    $testServer=[string]$state.testServerPath
    if(-not(Test-Path -LiteralPath $testServer -PathType Container)){throw "No existe el servidor TEST: $testServer"}
    $java=Resolve-JavaExecutable
    if($null-eq$java){throw 'No se encuentra Java.'}
    $major=Get-JavaMajorVersion -JavaExe $java
    if($major -lt 21){throw "Se necesita Java 21 o superior. Detectado: $major"}

    $jar=''
    if(($state.PSObject.Properties.Name -contains 'testServerJar') -and -not[string]::IsNullOrWhiteSpace([string]$state.testServerJar)){
        $candidate=[string]$state.testServerJar
        if(Test-Path -LiteralPath (Join-Path $testServer $candidate)){$jar=$candidate}
    }
    if([string]::IsNullOrWhiteSpace($jar)){
        $normalServer=$script:ServerDir
        $script:ServerDir=$testServer
        $jar=Find-ServerJar
        $script:ServerDir=$normalServer
    }
    if([string]::IsNullOrWhiteSpace($jar)){throw "No se encuentra launcher/server.jar en $testServer"}
    $jarPath=Join-Path $testServer $jar
    Write-Host (" Fabric TEST: {0}" -f $jar) -ForegroundColor Cyan

    $running=[ordered]@{processId=[int]$PID;startedUtc=[DateTimeOffset]::UtcNow.ToString('o');testServerPath=$testServer;port=[int]$state.testPort}
    Write-ModManagerJson $script:ModTestServerRunningPath $running 10

    $host.UI.RawUI.WindowTitle='Cobbleverse - SERVIDOR TEST MODS (MUNDO COPIA)'
    Write-Host '==============================================================' -ForegroundColor Yellow
    Write-Host ' COBBLEVERSE - SERVIDOR TEST DE MODS' -ForegroundColor Yellow
    Write-Host ' MUNDO: COPIA AISLADA. EL MUNDO NORMAL NO SE TOCA.' -ForegroundColor Green
    Write-Host (" Carpeta: {0}" -f $testServer) -ForegroundColor Cyan
    Write-Host (" Puerto : {0}" -f [int]$state.testPort) -ForegroundColor Cyan
    Write-Host ' Para cerrar correctamente escribe: stop' -ForegroundColor Magenta
    Write-Host '==============================================================' -ForegroundColor Yellow

    Push-Location $testServer
    try{
        $javaArgs=@("-Xms$($script:Config.MinRamGB)G","-Xmx$($script:Config.MaxRamGB)G",'-jar',$jarPath,'nogui')
        & $java @javaArgs
        $javaExit=$LASTEXITCODE
    }finally{Pop-Location}
    if($javaExit -ne 0){throw "El servidor TEST terminó con código Java $javaExit."}
}
catch{
    Write-Host ''
    Write-Host ('ERROR TEST: '+$_.Exception.Message) -ForegroundColor Red
    Write-Host ($_|Out-String) -ForegroundColor DarkRed
    Read-Host 'Pulsa ENTER para cerrar'
}
finally{
    try{Initialize-ModManagerEnvironment;Initialize-ModTestPaths;Remove-Item -LiteralPath $script:ModTestServerRunningPath -Force -ErrorAction SilentlyContinue}catch{}
}
