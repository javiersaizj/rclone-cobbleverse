﻿param(
    [Parameter(Mandatory=$true)][string]$Package,
    [Parameter(Mandatory=$true)][string]$Root,
    [int]$WaitPid=0
)
Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Windows.Forms
$ErrorActionPreference='Stop'
try {
    if($WaitPid -gt 0){
        for($i=0;$i -lt 120;$i++){
            if($null -eq (Get-Process -Id $WaitPid -ErrorAction SilentlyContinue)){break}
            Start-Sleep -Milliseconds 500
        }
    }
    if(-not(Test-Path -LiteralPath $Package -PathType Leaf)){throw "No existe el ZIP: $Package"}
    $tmp=Join-Path $env:TEMP ('cobbleverse-update-'+[guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $tmp|Out-Null
    Expand-Archive -LiteralPath $Package -DestinationPath $tmp -Force
    $source=$tmp
    $dirs=@(Get-ChildItem -LiteralPath $tmp -Directory)
    if($dirs.Count -eq 1){$source=$dirs[0].FullName}
    if(-not(Test-Path -LiteralPath (Join-Path $source 'scripts\ServerManagerGUI.ps1'))){
        $candidate=Get-ChildItem -LiteralPath $tmp -Recurse -Filter 'ServerManagerGUI.ps1' -File|Select-Object -First 1
        if($null -eq $candidate){throw 'El ZIP no parece una versión válida de Cobbleverse Server Manager.'}
        $source=Split-Path -Parent (Split-Path -Parent $candidate.FullName)
    }
    foreach($item in @(Get-ChildItem -LiteralPath $source -Force)){
        if($item.Name -in @('data','config.json','local_backups')){continue}
        $dest=Join-Path $Root $item.Name
        if($item.PSIsContainer){
            New-Item -ItemType Directory -Force -Path $dest|Out-Null
            foreach($child in @(Get-ChildItem -LiteralPath $item.FullName -Force)){Copy-Item -LiteralPath $child.FullName -Destination $dest -Recurse -Force}
        }
        else{Copy-Item -LiteralPath $item.FullName -Destination $dest -Force}
    }
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Start-Process -FilePath (Join-Path $Root '02_INICIAR_COBBLEVERSE.bat') -WorkingDirectory $Root|Out-Null
}
catch {
    $log=Join-Path $Root 'data\updater-error.log'
    try{[IO.File]::WriteAllText($log,($_|Out-String),(New-Object Text.UTF8Encoding($false)))}catch{}
    [System.Windows.Forms.MessageBox]::Show(('Error actualizando Cobbleverse: '+$_.Exception.Message),'Cobbleverse updater','OK','Error')|Out-Null
    exit 1
}
