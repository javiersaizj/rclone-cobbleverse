﻿Set-StrictMode -Version 2.0
$ErrorActionPreference="Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== ELIMINAR REPOSITORIO RESTIC REMOTO ANTIGUO v3.x ===" -ForegroundColor Yellow
    Write-Host "Solo elimina: $script:OldRemoteResticRepo" -ForegroundColor Cyan
    Write-Host "NO elimina el estado v4, el mundo local ni los backups locales." -ForegroundColor Cyan
    $probe=Invoke-RcloneCapture -Arguments @("lsf",$script:OldRemoteResticRepo,"--max-depth","1","--config",$script:RcloneConfig) -IgnoreExitCode
    if($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($probe)){Write-Host "No hay un repositorio remoto antiguo que limpiar." -ForegroundColor Green; exit 0}
    $answer=Read-Host "Escribe ELIMINAR_RESTIC_REMOTO para borrarlo definitivamente de Drive"
    if($answer -cne 'ELIMINAR_RESTIC_REMOTO'){throw "Cancelado."}
    Invoke-Rclone -Arguments @("purge",$script:OldRemoteResticRepo,"--config",$script:RcloneConfig,"--drive-use-trash=false") | Out-Null
    Write-Host "Repositorio remoto antiguo eliminado. Espacio recuperado en Drive." -ForegroundColor Green
}
catch{Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1}
