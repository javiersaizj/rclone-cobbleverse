﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:Root = Split-Path -Parent $PSScriptRoot
$script:DataDir = Join-Path $script:Root 'data'
$script:AssetsDir = Join-Path $script:Root 'assets'
$script:ConfigPath = Join-Path $script:Root 'config.json'
$script:RcloneExe = Join-Path $script:Root 'tools\rclone\rclone.exe'
$script:RcloneConfig = Join-Path $script:DataDir 'rclone.conf'
$script:ServerLogPath = Join-Path $script:DataDir 'gui-server-current.log'
$script:TaskLogPath = Join-Path $script:DataDir 'gui-tools-current.log'
$script:ServerRunnerPath = Join-Path $script:DataDir 'gui-run-server.cmd'
$script:TaskRunnerPath = Join-Path $script:DataDir 'gui-run-task.cmd'
$script:serverLogOffset = [int64]0
$script:taskLogOffset = [int64]0
$script:serverProcess = $null
$script:taskProcess = $null
$script:serverRunner = $null
$script:taskRunner = $null
$script:mirrorTaskLogToServer = $false
$script:taskMirrorHeader = ''
$script:lastLockState = 'unknown'
$script:lastLockObject = $null
$script:lastStatusCheck = [DateTime]::MinValue
$script:closingAllowed = $false
$script:stopRequested = $false
$script:localPhase = 'offline'
$script:connectionValues = @()
$script:lastConnectionSignature = ''
$script:cachedRemoteState = [pscustomobject]@{Kind='unknown';Lock=$null;Message='Consultando Drive...'}
$script:statusQueryProcess = $null
$script:statusQueryStarted = [DateTime]::MinValue
$script:statusQueryOut = Join-Path $script:DataDir 'gui-status.out'
$script:statusQueryErr = Join-Path $script:DataDir 'gui-status.err'
$script:statusQueryCmd = Join-Path $script:DataDir 'gui-status.cmd'
$script:statusQueryCode = Join-Path $script:DataDir 'gui-status.code'
$script:statusGenerationOut = Join-Path $script:DataDir 'gui-generation.out'
$script:statusGenerationErr = Join-Path $script:DataDir 'gui-generation.err'
$script:statusGenerationCode = Join-Path $script:DataDir 'gui-generation.code'
$script:remoteGeneration = $null
$script:generationRefreshBurstUntil = [DateTime]::MinValue
$script:generationRefreshNext = [DateTime]::MinValue
$script:UiLayoutPath = Join-Path $script:DataDir 'ui-layout.json'
$script:PendingSyncRoot = Join-Path $script:DataDir 'pending-sync'
$script:DirtyMarkerPathGui = Join-Path $script:DataDir 'local-session-in-progress.json'
$script:pendingSyncProcess = $null
$script:pendingSyncNextTry = [DateTime]::MinValue
$script:PendingSyncLogPath = Join-Path $script:DataDir 'gui-pending-sync.log'
$script:PendingSyncRunnerPath = Join-Path $script:DataDir 'gui-run-pending-sync.cmd'
$script:pendingSyncLogOffset = [int64]0
$script:modAutoSyncProcess = $null
$script:modAutoSyncState = 'pending'
$script:modAutoSyncLogPath = Join-Path $script:DataDir 'gui-mod-autosync.log'
$script:modAutoSyncRunnerPath = Join-Path $script:DataDir 'gui-run-mod-autosync.cmd'
$script:modAutoSyncLogOffset = [int64]0
$script:internetAvailable = $null
$script:customUiLayoutActive = $false
$script:uiEditable = @{}
$script:uiDefaults = @{}
$script:curseForgePlayTimer = $null
$script:curseForgePlayDeadline = [DateTime]::MinValue

New-Item -ItemType Directory -Force -Path $script:DataDir | Out-Null

# Evita dos ventanas del manager en el mismo PC.
$createdNew = $false
$script:appMutex = New-Object System.Threading.Mutex($true, 'Cobbleverse_Server_Manager_v47', [ref]$createdNew)
if (-not $createdNew) {
    [System.Windows.Forms.MessageBox]::Show('Cobbleverse Server Manager ya esta abierto en este PC.', 'Cobbleverse', 'OK', 'Information') | Out-Null
    exit 0
}

function Get-UiConfig {
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) { return $null }
    try { return (Get-Content -LiteralPath $script:ConfigPath -Raw | ConvertFrom-Json) }
    catch { return $null }
}

function Get-ServerPathFromConfig {
    $cfg = Get-UiConfig
    if ($null -eq $cfg) { return '' }
    if ($cfg.PSObject.Properties.Name -contains 'ServerPath' -and -not [string]::IsNullOrWhiteSpace([string]$cfg.ServerPath)) {
        return [Environment]::ExpandEnvironmentVariables(([string]$cfg.ServerPath).Trim().Trim('"'))
    }
    if ($cfg.PSObject.Properties.Name -contains 'ServerFolder') {
        return (Join-Path $script:Root ([string]$cfg.ServerFolder))
    }
    return ''
}


function Get-MinecraftClientInstancePath {
    $cfg = Get-UiConfig
    if ($null -ne $cfg -and $cfg.PSObject.Properties.Name -contains 'MinecraftClientInstancePath' -and -not [string]::IsNullOrWhiteSpace([string]$cfg.MinecraftClientInstancePath)) {
        $configured = [Environment]::ExpandEnvironmentVariables(([string]$cfg.MinecraftClientInstancePath).Trim().Trim('"'))
        if (Test-Path -LiteralPath $configured -PathType Container) { return $configured }
    }

    $defaultPath = Join-Path $env:USERPROFILE 'curseforge\minecraft\Instances\COBBLEVERSE - Pokemon Adventure [Cobblemon]'
    if (Test-Path -LiteralPath $defaultPath -PathType Container) { return $defaultPath }

    $instancesRoot = Join-Path $env:USERPROFILE 'curseforge\minecraft\Instances'
    if (Test-Path -LiteralPath $instancesRoot -PathType Container) {
        $match = @(Get-ChildItem -LiteralPath $instancesRoot -Directory -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -like 'COBBLEVERSE*' -or $_.Name -like '*Cobbleverse*'
        } | Sort-Object Name | Select-Object -First 1)
        if ($match.Count -gt 0) { return [string]$match[0].FullName }
    }
    return $defaultPath
}

function Get-MinecraftShortcutInfo {
    param([string]$ShortcutPath)

    if ([string]::IsNullOrWhiteSpace($ShortcutPath) -or -not (Test-Path -LiteralPath $ShortcutPath -PathType Leaf)) { return $null }

    $ext = [IO.Path]::GetExtension($ShortcutPath)
    $baseName = [IO.Path]::GetFileNameWithoutExtension($ShortcutPath)
    $target = ''
    $arguments = ''
    $working = ''
    $extra = ''

    try {
        if ($ext -ieq '.lnk') {
            $shell = New-Object -ComObject WScript.Shell
            $sc = $shell.CreateShortcut($ShortcutPath)
            $target = [string]$sc.TargetPath
            $arguments = [string]$sc.Arguments
            $working = [string]$sc.WorkingDirectory
        }
        elseif ($ext -ieq '.url') {
            $extra = [IO.File]::ReadAllText($ShortcutPath)
        }
        else {
            return $null
        }
    }
    catch { return $null }

    $signature = (($baseName + ' ' + $target + ' ' + $arguments + ' ' + $working + ' ' + $extra) -replace '\\','/').ToLowerInvariant()
    return [pscustomobject]@{
        Path = $ShortcutPath
        BaseName = $baseName
        TargetPath = $target
        Arguments = $arguments
        WorkingDirectory = $working
        Signature = $signature
    }
}

function Get-MinecraftShortcutScore {
    param($Info, [string]$InstancePath)

    if ($null -eq $Info) { return -1 }

    $name = ([string]$Info.BaseName).ToLowerInvariant()
    $sig = [string]$Info.Signature
    $rootNorm = (($script:Root -replace '\\','/').ToLowerInvariant())
    $instanceNorm = (($InstancePath -replace '\\','/').ToLowerInvariant())

    # Nunca permitir que "Jugar" vuelva a abrir este propio Server Manager.
    if ($name -match 'server\s*manager|manager\s*server') { return -1 }
    if ($sig -match 'servermanagergui\.ps1|02_iniciar_cobbleverse|cobbleverse_server_manager') { return -1 }
    if (-not [string]::IsNullOrWhiteSpace($rootNorm) -and $sig.Contains($rootNorm) -and $sig -match 'cobbleverse.*manager') { return -1 }

    $score = 0
    $packNameHit = $false

    if ($name -eq 'cobbleverse - pokemon adventure [cobblemon]') { $score += 150; $packNameHit = $true }
    elseif ($name -match 'pokemon\s+adventure') { $score += 120; $packNameHit = $true }
    elseif ($name -match '^cobbleverse\b') { $score += 90; $packNameHit = $true }
    elseif ($name -match 'cobbleverse') { $score += 60; $packNameHit = $true }

    if (-not [string]::IsNullOrWhiteSpace($instanceNorm) -and $sig.Contains($instanceNorm)) { $score += 150; $packNameHit = $true }
    if ($sig -match 'curseforge') { $score += 70 }
    if ($sig -match 'overwolf') { $score += 50 }
    if ($sig -match 'minecraft') { $score += 35 }
    if ($sig -match 'pokemon\s+adventure|cobbleverse') { $score += 40 }

    # Un acceso directo genérico de CurseForge/Minecraft no basta: debe identificar COBBLEVERSE.
    if (-not $packNameHit -and $sig -notmatch 'pokemon\s+adventure|cobbleverse') { return -1 }

    return $score
}

function Find-MinecraftPlayShortcut {
    $cfg = Get-UiConfig
    $instancePath = Get-MinecraftClientInstancePath

    if ($null -ne $cfg -and $cfg.PSObject.Properties.Name -contains 'MinecraftPlayShortcut' -and -not [string]::IsNullOrWhiteSpace([string]$cfg.MinecraftPlayShortcut)) {
        $configured = [Environment]::ExpandEnvironmentVariables(([string]$cfg.MinecraftPlayShortcut).Trim().Trim('"'))
        $info = Get-MinecraftShortcutInfo -ShortcutPath $configured
        if ((Get-MinecraftShortcutScore -Info $info -InstancePath $instancePath) -ge 0) { return $configured }
        try { Add-UiLogLine -Box $script:txtServerLog -Text ('Jugar: se ignora MinecraftPlayShortcut porque no parece un acceso directo del perfil COBBLEVERSE: ' + $configured) } catch { }
    }

    $dirs = New-Object System.Collections.Generic.List[string]
    foreach ($d in @(
        [Environment]::GetFolderPath('Desktop'),
        [Environment]::GetFolderPath('CommonDesktopDirectory'),
        (Join-Path $env:USERPROFILE 'Desktop'),
        (Join-Path $env:USERPROFILE 'OneDrive\Desktop'),
        [Environment]::GetFolderPath('StartMenu'),
        [Environment]::GetFolderPath('CommonStartMenu')
    )) {
        if (-not [string]::IsNullOrWhiteSpace($d) -and (Test-Path -LiteralPath $d -PathType Container) -and -not $dirs.Contains($d)) { [void]$dirs.Add($d) }
    }

    $candidates = New-Object System.Collections.Generic.List[object]
    foreach ($dir in $dirs) {
        $files = @()
        try {
            $files = @(Get-ChildItem -LiteralPath $dir -File -Recurse -ErrorAction SilentlyContinue | Where-Object {
                $_.Extension -ieq '.lnk' -or $_.Extension -ieq '.url'
            })
        }
        catch { $files = @() }

        foreach ($file in $files) {
            $info = Get-MinecraftShortcutInfo -ShortcutPath $file.FullName
            $score = Get-MinecraftShortcutScore -Info $info -InstancePath $instancePath
            if ($score -ge 0) {
                [void]$candidates.Add([pscustomobject]@{Path=[string]$file.FullName;Score=[int]$score;Name=[string]$file.Name})
            }
        }
    }

    # Algunas instalaciones dejan accesos directos dentro de la propia instancia.
    if (Test-Path -LiteralPath $instancePath -PathType Container) {
        foreach ($file in @(Get-ChildItem -LiteralPath $instancePath -File -ErrorAction SilentlyContinue | Where-Object {
            $_.Extension -ieq '.lnk' -or $_.Extension -ieq '.url'
        })) {
            $info = Get-MinecraftShortcutInfo -ShortcutPath $file.FullName
            $score = Get-MinecraftShortcutScore -Info $info -InstancePath $instancePath
            if ($score -ge 0) {
                [void]$candidates.Add([pscustomobject]@{Path=[string]$file.FullName;Score=[int]$score;Name=[string]$file.Name})
            }
        }
    }

    if ($candidates.Count -eq 0) { return '' }
    $best = @($candidates | Sort-Object @{Expression='Score';Descending=$true}, @{Expression='Name';Descending=$false} | Select-Object -First 1)
    if ($best.Count -gt 0) { return [string]$best[0].Path }
    return ''
}


function Initialize-CurseForgePlayAutomation {
    try { Add-Type -AssemblyName UIAutomationClient -ErrorAction Stop } catch { }
    try { Add-Type -AssemblyName UIAutomationTypes -ErrorAction Stop } catch { }

    if (-not ('Cobbleverse.PlayNative' -as [type])) {
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
namespace Cobbleverse {
    public static class PlayNative {
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
        [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
        public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        public const uint MOUSEEVENTF_LEFTUP = 0x0004;
    }
}
"@ -ErrorAction Stop
    }
}

function Invoke-AutomationElementClick {
    param(
        $Element,
        $Window
    )

    if ($null -eq $Element) { return $false }

    try {
        $pattern = $null
        if ($Element.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$pattern)) {
            ([System.Windows.Automation.InvokePattern]$pattern).Invoke()
            return $true
        }
    }
    catch { }

    try {
        $rect = $Element.Current.BoundingRectangle
        if ($rect.Width -le 1 -or $rect.Height -le 1) { return $false }
        $x = [int]($rect.Left + ($rect.Width / 2))
        $y = [int]($rect.Top + ($rect.Height / 2))
        $hWnd = [IntPtr]::Zero
        if ($null -ne $Window) { $hWnd = [IntPtr]$Window.Current.NativeWindowHandle }
        if ($hWnd -ne [IntPtr]::Zero) {
            [Cobbleverse.PlayNative]::ShowWindow($hWnd, 9) | Out-Null
            [Cobbleverse.PlayNative]::SetForegroundWindow($hWnd) | Out-Null
            Start-Sleep -Milliseconds 100
        }
        [Cobbleverse.PlayNative]::SetCursorPos($x, $y) | Out-Null
        [Cobbleverse.PlayNative]::mouse_event([Cobbleverse.PlayNative]::MOUSEEVENTF_LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
        [Cobbleverse.PlayNative]::mouse_event([Cobbleverse.PlayNative]::MOUSEEVENTF_LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
        return $true
    }
    catch { return $false }
}

function Try-InvokeCurseForgeCobbleversePlay {
    Initialize-CurseForgePlayAutomation

    $rootAutomation = [System.Windows.Automation.AutomationElement]::RootElement
    $windows = $rootAutomation.FindAll(
        [System.Windows.Automation.TreeScope]::Children,
        [System.Windows.Automation.Condition]::TrueCondition
    )

    foreach ($window in $windows) {
        try {
            $windowName = [string]$window.Current.Name
            if ($windowName -notmatch '(?i)curseforge') { continue }
            if ($window.Current.IsOffscreen) {
                $hRestore = [IntPtr]$window.Current.NativeWindowHandle
                if ($hRestore -ne [IntPtr]::Zero) { [Cobbleverse.PlayNative]::ShowWindow($hRestore, 9) | Out-Null }
            }

            $elements = $window.FindAll(
                [System.Windows.Automation.TreeScope]::Descendants,
                [System.Windows.Automation.Condition]::TrueCondition
            )

            $packElements = New-Object System.Collections.Generic.List[object]
            $playElements = New-Object System.Collections.Generic.List[object]

            foreach ($element in $elements) {
                try {
                    $elementName = [string]$element.Current.Name
                    if (-not [string]::IsNullOrWhiteSpace($elementName) -and $elementName -match '(?i)cobbleverse') {
                        [void]$packElements.Add($element)
                    }
                    if (($elementName -ieq 'Play' -or $elementName -ieq 'Jugar') -and $element.Current.IsEnabled -and -not $element.Current.IsOffscreen) {
                        [void]$playElements.Add($element)
                    }
                }
                catch { }
            }

            if ($playElements.Count -eq 0) { continue }

            $bestButton = $null
            $bestDistance = [double]::MaxValue

            if ($packElements.Count -gt 0) {
                foreach ($packElement in $packElements) {
                    try {
                        $packRect = $packElement.Current.BoundingRectangle
                        if ($packRect.Width -le 0 -or $packRect.Height -le 0) { continue }
                        $packX = $packRect.Left + ($packRect.Width / 2)
                        $packY = $packRect.Top + ($packRect.Height / 2)

                        foreach ($playElement in $playElements) {
                            try {
                                $playRect = $playElement.Current.BoundingRectangle
                                if ($playRect.Width -le 0 -or $playRect.Height -le 0) { continue }
                                $playX = $playRect.Left + ($playRect.Width / 2)
                                $playY = $playRect.Top + ($playRect.Height / 2)
                                $dx = $playX - $packX
                                $dy = $playY - $packY
                                $distance = ($dx * $dx) + ($dy * $dy)
                                if ($playY -lt ($packRect.Top - 30)) { $distance += 1000000 }
                                if ($distance -lt $bestDistance) {
                                    $bestDistance = $distance
                                    $bestButton = $playElement
                                }
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
            }

            # Si CurseForge solo expone un unico Play visible, es seguro usarlo como fallback.
            if ($null -eq $bestButton -and $playElements.Count -eq 1) {
                $bestButton = $playElements[0]
            }

            if ($null -ne $bestButton) {
                $clicked = Invoke-AutomationElementClick -Element $bestButton -Window $window
                if ($clicked) {
                    # Dejamos que CurseForge procese el click y despues lo minimizamos.
                    Start-Sleep -Milliseconds 350
                    try {
                        $hWnd = [IntPtr]$window.Current.NativeWindowHandle
                        if ($hWnd -ne [IntPtr]::Zero) { [Cobbleverse.PlayNative]::ShowWindow($hWnd, 6) | Out-Null }
                    }
                    catch { }
                    return $true
                }
            }
        }
        catch { }
    }

    return $false
}

function Stop-CurseForgePlayAutomation {
    if ($null -ne $script:curseForgePlayTimer) {
        try { $script:curseForgePlayTimer.Stop() } catch { }
        try { $script:curseForgePlayTimer.Dispose() } catch { }
        $script:curseForgePlayTimer = $null
    }
}

function Start-CurseForgePlayAutomation {
    Stop-CurseForgePlayAutomation
    $script:curseForgePlayDeadline = [DateTime]::Now.AddSeconds(20)
    $script:curseForgePlayTimer = New-Object System.Windows.Forms.Timer
    $script:curseForgePlayTimer.Interval = 500
    $script:curseForgePlayTimer.Add_Tick({
        try {
            if (Try-InvokeCurseForgeCobbleversePlay) {
                Stop-CurseForgePlayAutomation
                Add-UiLogLine -Box $script:txtServerLog -Text 'Jugar: Play de COBBLEVERSE pulsado automaticamente en CurseForge.'
                return
            }

            if ([DateTime]::Now -ge $script:curseForgePlayDeadline) {
                Stop-CurseForgePlayAutomation
                Add-UiLogLine -Box $script:txtServerLog -Text 'Jugar: CurseForge abrio, pero no pude localizar automaticamente el boton Play de COBBLEVERSE.'
                [System.Windows.Forms.MessageBox]::Show(
                    "CurseForge se ha abierto, pero no he podido localizar el boton Play de COBBLEVERSE en 20 segundos.`r`n`r`nDeja visible la pantalla 'My Modpacks' con COBBLEVERSE instalado y vuelve a pulsar Jugar.`r`n`r`nSi esto se repite, pasame el nuevo gui-startup-error.log o una captura y adapto el detector a tu version de CurseForge.",
                    'Cobbleverse - Jugar', 'OK', 'Warning') | Out-Null
            }
        }
        catch {
            if ([DateTime]::Now -ge $script:curseForgePlayDeadline) {
                Stop-CurseForgePlayAutomation
                try { Add-UiLogLine -Box $script:txtServerLog -Text ('Jugar: automatizacion CurseForge fallo: ' + $_.Exception.Message) } catch { }
            }
        }
    })
    $script:curseForgePlayTimer.Start()
}

function Start-MinecraftClientFromGui {
    try {
        $shortcut = Find-MinecraftPlayShortcut
        $instancePath = Get-MinecraftClientInstancePath

        if (-not [string]::IsNullOrWhiteSpace($shortcut) -and (Test-Path -LiteralPath $shortcut -PathType Leaf)) {
            Start-Process -FilePath $shortcut | Out-Null
            Add-UiLogLine -Box $script:txtServerLog -Text ('Jugar: abriendo COBBLEVERSE mediante "{0}" y esperando el boton Play de CurseForge...' -f ([IO.Path]::GetFileName($shortcut)))
            Start-CurseForgePlayAutomation
            return
        }

        $instanceFound = Test-Path -LiteralPath $instancePath -PathType Container
        $where = if ($instanceFound) { "`r`n`r`nInstancia detectada:`r`n$instancePath" } else { "`r`n`r`nRuta esperada:`r`n$instancePath" }
        [System.Windows.Forms.MessageBox]::Show(
            "He encontrado la instalación de COBBLEVERSE, pero no un acceso directo del PERFIL.$where`r`n`r`nCrea una sola vez el acceso directo de COBBLEVERSE desde CurseForge. A partir de ahi, el boton Jugar del Server Manager abrira CurseForge, localizara COBBLEVERSE y pulsara Play automaticamente.`r`n`r`nSi ya tienes el acceso directo, colocalo en el Escritorio o indica su ruta en config.json con MinecraftPlayShortcut.",
            'Cobbleverse - Jugar', 'OK', 'Information') | Out-Null
    }
    catch {
        try { Add-UiLogLine -Box $script:txtServerLog -Text ('Jugar: error: ' + $_.Exception.Message) } catch { }
        [System.Windows.Forms.MessageBox]::Show(('No se pudo iniciar Cobbleverse: ' + $_.Exception.Message),'Cobbleverse - Jugar','OK','Error') | Out-Null
    }
}

function Get-AppVersion {
    $path = Join-Path $script:Root 'VERSION.txt'
    if (-not (Test-Path -LiteralPath $path)) { return 'desconocida' }
    try {
        $v = ([IO.File]::ReadAllText($path)).Trim()
        if ([string]::IsNullOrWhiteSpace($v)) { return 'desconocida' }
        return $v
    }
    catch { return 'desconocida' }
}

function Get-LocalGenerationNumber {
    $path = Join-Path $script:DataDir 'local-generation.json'
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try {
        $obj = ([IO.File]::ReadAllText($path) | ConvertFrom-Json)
        if ($obj.PSObject.Properties.Name -contains 'generation') { return [int64]$obj.generation }
    }
    catch { }
    return $null
}


function Get-LocalPendingSyncSummary {
    [int64]$count = 0
    [int64]$bytes = 0
    if (Test-Path -LiteralPath $script:PendingSyncRoot -PathType Container) {
        foreach ($dir in @(Get-ChildItem -LiteralPath $script:PendingSyncRoot -Directory -ErrorAction SilentlyContinue | Where-Object { -not $_.Name.StartsWith('.building-') })) {
            $p = Join-Path $dir.FullName 'pending.json'
            if (-not (Test-Path -LiteralPath $p)) { continue }
            try {
                $m = [IO.File]::ReadAllText($p) | ConvertFrom-Json
                if ([string]$m.status -eq 'ready') { $count++; $bytes += [int64]$m.bundleBytes }
            } catch { }
        }
    }
    $dirty = Test-Path -LiteralPath $script:DirtyMarkerPathGui -PathType Leaf
    return [pscustomobject]@{count=$count;bytes=$bytes;dirty=$dirty;hasPending=($count -gt 0 -or $dirty)}
}

function Format-UiBytes {
    param([int64]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes/1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes/1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N1} KB' -f ($Bytes/1KB)) }
    return ("$Bytes B")
}

function Update-SyncSafetyUi {
    if ($null -ne $script:lblInternetState) {
        if ($script:internetAvailable -eq $true) { $script:lblInternetState.Text='Internet/Drive: OK'; $script:lblInternetState.ForeColor=[System.Drawing.Color]::LimeGreen }
        elseif ($script:internetAvailable -eq $false) { $script:lblInternetState.Text='Internet/Drive: SIN CONEXIÓN'; $script:lblInternetState.ForeColor=[System.Drawing.Color]::Crimson }
        else { $script:lblInternetState.Text='Internet/Drive: ?'; $script:lblInternetState.ForeColor=$muted }
    }
    if ($null -ne $script:lblSyncState) {
        $p = Get-LocalPendingSyncSummary
        if ($p.hasPending) {
            if ($p.count -gt 0) { $script:lblSyncState.Text=('Sync: PENDIENTE {0} ({1})' -f $p.count,(Format-UiBytes $p.bytes)) }
            else { $script:lblSyncState.Text='Sync: SESIÓN INTERRUMPIDA' }
            $script:lblSyncState.ForeColor=$orange
        }
        else { $script:lblSyncState.Text='Sync: al día'; $script:lblSyncState.ForeColor=[System.Drawing.Color]::LimeGreen }
    }
}

function Start-PendingSyncRetryIfNeeded {
    $retryCfg = Get-UiConfig
    if ($null -ne $retryCfg -and $retryCfg.PSObject.Properties.Name -contains 'AutoRetryPendingSync' -and -not [bool]$retryCfg.AutoRetryPendingSync) { return }
    if ($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited) { return }
    if ($null -ne $script:taskProcess -and -not $script:taskProcess.HasExited) { return }
    if ($null -ne $script:pendingSyncProcess -and -not $script:pendingSyncProcess.HasExited) { return }
    if ((Get-Date) -lt $script:pendingSyncNextTry) { return }
    $p = Get-LocalPendingSyncSummary
    if (-not $p.hasPending) { return }
    try {
        $script:pendingSyncLogOffset=[int64]0
        $target=Join-Path $PSScriptRoot 'RetryPendingSync.ps1'
        $script:pendingSyncProcess=Start-LoggedScript -TargetScript $target -LogPath $script:PendingSyncLogPath -RunnerPath $script:PendingSyncRunnerPath
        Add-UiLogLine -Box $script:txtServerLog -Text 'Sincronización pendiente detectada: reintento automático iniciado.'
    } catch {
        $retrySeconds=30; $cfgRetry=Get-UiConfig; if ($null -ne $cfgRetry -and $cfgRetry.PSObject.Properties.Name -contains 'PendingSyncRetrySeconds') { $retrySeconds=[Math]::Max(5,[int]$cfgRetry.PendingSyncRetrySeconds) }; $script:pendingSyncNextTry=(Get-Date).AddSeconds($retrySeconds)
    }
}

function Register-UiEditableControl {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][System.Windows.Forms.Control]$Control,
        [Parameter(Mandatory=$true)][ValidateSet('header','status','footer')][string]$Section
    )
    $entry = [pscustomobject]@{ Name=$Name; Control=$Control; Section=$Section }
    $script:uiEditable[$Name] = $entry
    $script:uiDefaults[$Name] = [pscustomobject]@{
        x = [int]$Control.Left
        y = [int]$Control.Top
        width = [int]$Control.Width
        height = [int]$Control.Height
    }
}

function Get-UiLayoutControlRecord {
    param($Layout,[string]$Name)
    if ($null -eq $Layout -or -not ($Layout.PSObject.Properties.Name -contains 'controls') -or $null -eq $Layout.controls) { return $null }
    $prop = $Layout.controls.PSObject.Properties | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
    if ($null -eq $prop) { return $null }
    return $prop.Value
}

function Apply-UiLayoutObject {
    param($Layout,[switch]$MarkCustom)
    if ($null -eq $Layout) { return }
    foreach ($key in @($script:uiEditable.Keys)) {
        $entry = $script:uiEditable[$key]
        $g = Get-UiLayoutControlRecord -Layout $Layout -Name $key
        if ($null -eq $g) { continue }
        try {
            $x = [int]$g.x; $y = [int]$g.y; $w = [int]$g.width; $h = [int]$g.height
            if ($w -lt 8) { $w = 8 }; if ($h -lt 8) { $h = 8 }
            $entry.Control.Location = New-Object System.Drawing.Point($x,$y)
            if (-not $entry.Control.AutoSize) { $entry.Control.Size = New-Object System.Drawing.Size($w,$h) }
        }
        catch { }
    }
    if ($MarkCustom) { $script:customUiLayoutActive = $true }
}

function Load-SavedUiLayout {
    if (-not (Test-Path -LiteralPath $script:UiLayoutPath)) { return }
    try {
        $layout = ([IO.File]::ReadAllText($script:UiLayoutPath) | ConvertFrom-Json)
        Apply-UiLayoutObject -Layout $layout -MarkCustom
    }
    catch {
        Add-UiLogLine -Box $script:txtServerLog -Text ('No se pudo cargar el diseño personalizado: ' + $_.Exception.Message)
    }
}

function Apply-DefaultUiLayout {
    foreach ($key in @($script:uiEditable.Keys)) {
        if (-not $script:uiDefaults.ContainsKey($key)) { continue }
        $entry = $script:uiEditable[$key]
        $g = $script:uiDefaults[$key]
        $entry.Control.Location = New-Object System.Drawing.Point([int]$g.x,[int]$g.y)
        if (-not $entry.Control.AutoSize) { $entry.Control.Size = New-Object System.Drawing.Size([int]$g.width,[int]$g.height) }
    }
    $script:customUiLayoutActive = $false
}

function Update-GenerationUi {
    if ($null -eq $script:lblWorldLocalGen -or $null -eq $script:lblWorldDriveGen) { return }
    $local = Get-LocalGenerationNumber
    if ($null -eq $local) { $script:lblWorldLocalGen.Text = 'Mundo PC: G?' }
    else { $script:lblWorldLocalGen.Text = ('Mundo PC: G{0}' -f $local) }

    if ($null -eq $script:remoteGeneration) { $script:lblWorldDriveGen.Text = 'Drive: G?' }
    else { $script:lblWorldDriveGen.Text = ('Drive: G{0}' -f ([int64]$script:remoteGeneration)) }

    $script:lblWorldLocalGen.ForeColor = $muted
    $script:lblWorldDriveGen.ForeColor = $muted
    if ($null -ne $local -and $null -ne $script:remoteGeneration) {
        $remote = [int64]$script:remoteGeneration
        if ($local -eq $remote) {
            $script:lblWorldLocalGen.ForeColor = [System.Drawing.Color]::LimeGreen
            $script:lblWorldDriveGen.ForeColor = [System.Drawing.Color]::LimeGreen
            if ($null -ne $script:btnUpdateWorld) { $script:btnUpdateWorld.BackColor = $panel2; $script:btnUpdateWorld.ForeColor = $text }
        }
        elseif ($local -lt $remote) {
            $script:lblWorldDriveGen.ForeColor = $orange
            if ($null -ne $script:btnUpdateWorld) { $script:btnUpdateWorld.BackColor = $orange; $script:btnUpdateWorld.ForeColor = [System.Drawing.Color]::Black }
        }
        else {
            $script:lblWorldLocalGen.ForeColor = [System.Drawing.Color]::Crimson
            if ($null -ne $script:btnUpdateWorld) { $script:btnUpdateWorld.BackColor = [System.Drawing.Color]::FromArgb(178,48,55); $script:btnUpdateWorld.ForeColor = [System.Drawing.Color]::White }
        }
    }
}

function Escape-CmdQuotedValue {
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    return $Value.Replace('"','""')
}

function New-LoggedRunner {
    param(
        [Parameter(Mandatory=$true)][string]$TargetScript,
        [Parameter(Mandatory=$true)][string]$LogPath,
        [Parameter(Mandatory=$true)][string]$RunnerPath
    )
    $target = Escape-CmdQuotedValue $TargetScript
    $log = Escape-CmdQuotedValue $LogPath
    $lines = @(
        '@echo off',
        'chcp 65001 >nul',
        ('cd /d "{0}"' -f (Escape-CmdQuotedValue $script:Root)),
        ('powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "{0}" >> "{1}" 2>&1' -f $target,$log),
        'exit /b %errorlevel%'
    )
    Set-Content -LiteralPath $RunnerPath -Value $lines -Encoding ASCII
}

function Start-LoggedScript {
    param(
        [Parameter(Mandatory=$true)][string]$TargetScript,
        [Parameter(Mandatory=$true)][string]$LogPath,
        [Parameter(Mandatory=$true)][string]$RunnerPath
    )
    if (-not (Test-Path -LiteralPath $TargetScript)) { throw "No existe el script: $TargetScript" }
    Remove-Item -LiteralPath $LogPath -Force -ErrorAction SilentlyContinue
    Set-Content -LiteralPath $LogPath -Value '' -Encoding UTF8
    New-LoggedRunner -TargetScript $TargetScript -LogPath $LogPath -RunnerPath $RunnerPath

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $env:ComSpec
    $psi.Arguments = ('/d /q /c ""{0}""' -f $RunnerPath)
    $psi.WorkingDirectory = $script:Root
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardInput = $true
    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    if (-not $proc.Start()) { throw 'No se pudo iniciar el proceso.' }
    return $proc
}

function Read-NewLogText {
    param([string]$Path, [ref]$Offset)
    if (-not (Test-Path -LiteralPath $Path)) { return '' }
    $fs = $null
    $sr = $null
    try {
        $fs = New-Object System.IO.FileStream($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        if ($Offset.Value -gt $fs.Length) { $Offset.Value = [int64]0 }
        [void]$fs.Seek([int64]$Offset.Value, [System.IO.SeekOrigin]::Begin)
        $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8, $true)
        $text = $sr.ReadToEnd()
        $Offset.Value = [int64]$fs.Position
        return $text
    }
    catch { return '' }
    finally {
        if ($null -ne $sr) { $sr.Dispose() }
        elseif ($null -ne $fs) { $fs.Dispose() }
    }
}

function Append-LogText {
    param([System.Windows.Forms.RichTextBox]$Box, [string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return }
    # Limita el visor a ~1,5 M caracteres para que siga fluido tras muchas horas.
    if ($Box.TextLength -gt 1500000) {
        $Box.Select(0, 400000)
        $Box.SelectedText = ''
    }
    $Box.SelectionStart = $Box.TextLength
    $Box.SelectionLength = 0
    $Box.SelectionColor = [System.Drawing.Color]::Gainsboro
    $Box.AppendText($Text)
    $Box.SelectionStart = $Box.TextLength
    $Box.ScrollToCaret()
}

function Add-UiLogLine {
    param([System.Windows.Forms.RichTextBox]$Box, [string]$Text)
    Append-LogText -Box $Box -Text (("[{0}] {1}`r`n" -f (Get-Date -Format 'HH:mm:ss'),$Text))
}

function Send-ProcessInput {
    param([System.Diagnostics.Process]$Process, [string]$Text, [System.Windows.Forms.RichTextBox]$LogBox)
    if ($null -eq $Process) { return $false }
    try {
        if ($Process.HasExited) { return $false }
        $Process.StandardInput.WriteLine($Text)
        $Process.StandardInput.Flush()
        if ($null -ne $LogBox) { Add-UiLogLine -Box $LogBox -Text ("> $Text") }
        return $true
    }
    catch {
        if ($null -ne $LogBox) { Add-UiLogLine -Box $LogBox -Text ("No se pudo enviar la entrada: " + $_.Exception.Message) }
        return $false
    }
}

function Quote-NativeArgument {
    param([string]$Value)
    if ($null -eq $Value) { return '""' }
    return '"' + $Value.Replace('"','\"') + '"'
}

function Invoke-QuickCapture {
    param([string]$FileName, [string]$Arguments, [int]$TimeoutMs = 3000)
    if (-not (Test-Path -LiteralPath $FileName)) { return [pscustomobject]@{Ok=$false;Code=-1;Out='';Err='missing executable';TimedOut=$false} }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $FileName
    $psi.Arguments = $Arguments
    $psi.WorkingDirectory = $script:Root
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    try {
        [void]$p.Start()
        if (-not $p.WaitForExit($TimeoutMs)) {
            try { $p.Kill() } catch {}
            return [pscustomobject]@{Ok=$false;Code=-2;Out='';Err='timeout';TimedOut=$true}
        }
        $out = $p.StandardOutput.ReadToEnd()
        $err = $p.StandardError.ReadToEnd()
        return [pscustomobject]@{Ok=($p.ExitCode -eq 0);Code=$p.ExitCode;Out=$out;Err=$err;TimedOut=$false}
    }
    catch { return [pscustomobject]@{Ok=$false;Code=-3;Out='';Err=$_.Exception.Message;TimedOut=$false} }
    finally { $p.Dispose() }
}

function Parse-RemoteLockResult {
    param([int]$ExitCode, [string]$OutText, [string]$ErrText)
    if ($ExitCode -ne 0) {
        $combined = ([string]$OutText + ' ' + [string]$ErrText)
        if ($combined -match '(?i)object not found|directory not found|not found') {
            return [pscustomobject]@{Kind='offline';Lock=$null;Message='Sin bloqueo remoto'}
        }
        return [pscustomobject]@{Kind='unknown';Lock=$null;Message=('No se pudo consultar Drive: ' + ([string]$ErrText).Trim())}
    }
    if ([string]::IsNullOrWhiteSpace([string]$OutText)) { return [pscustomobject]@{Kind='offline';Lock=$null;Message='Sin bloqueo remoto'} }
    try { $lock = ([string]$OutText | ConvertFrom-Json) }
    catch { return [pscustomobject]@{Kind='unknown';Lock=$null;Message='El bloqueo remoto no contiene JSON valido'} }

    $stale = $false
    try {
        $cfg = Get-UiConfig
        $timeoutMin = 10.0
        if ($null -ne $cfg -and $cfg.PSObject.Properties.Name -contains 'GameplayLockTimeoutMinutes') { $timeoutMin = [double]$cfg.GameplayLockTimeoutMinutes }
        $hb = [DateTimeOffset]::Parse([string]$lock.heartbeatUtc)
        $stale = (([DateTimeOffset]::UtcNow - $hb).TotalMinutes -ge $timeoutMin)
    }
    catch { $stale = $true }
    if ($stale) { return [pscustomobject]@{Kind='stale';Lock=$lock;Message='Bloqueo antiguo/caducado'} }
    if ([string]$lock.host -eq $env:COMPUTERNAME) { return [pscustomobject]@{Kind='local';Lock=$lock;Message='Reservado por este PC'} }
    return [pscustomobject]@{Kind='remote';Lock=$lock;Message='Reservado por otro PC'}
}

function Start-RemoteStatusQuery {
    if ($null -ne $script:statusQueryProcess -and -not $script:statusQueryProcess.HasExited) { return }
    $cfg = Get-UiConfig
    if ($null -eq $cfg) {
        $script:cachedRemoteState = [pscustomobject]@{Kind='unconfigured';Lock=$null;Message='Falta config.json'}
        return
    }
    if (-not (Test-Path -LiteralPath $script:RcloneExe) -or -not (Test-Path -LiteralPath $script:RcloneConfig)) {
        $script:cachedRemoteState = [pscustomobject]@{Kind='unconfigured';Lock=$null;Message='Falta rclone o su configuracion'}
        return
    }
    $remote = ('{0}:{1}/control/server-lock.json' -f [string]$cfg.DriveRemote,([string]$cfg.DriveBasePath).Trim('/'))
    $remoteGeneration = ('{0}:{1}/delta-v1/control/current.json' -f [string]$cfg.DriveRemote,([string]$cfg.DriveBasePath).Trim('/'))
    Remove-Item -LiteralPath $script:statusQueryOut,$script:statusQueryErr,$script:statusQueryCode,$script:statusGenerationOut,$script:statusGenerationErr,$script:statusGenerationCode,$script:statusQueryCmd -Force -ErrorAction SilentlyContinue
    $cmdLines = @(
        '@echo off',
        ('"{0}" cat "{1}" --config "{2}" > "{3}" 2> "{4}"' -f $script:RcloneExe,$remote,$script:RcloneConfig,$script:statusQueryOut,$script:statusQueryErr),
        ('> "{0}" echo %errorlevel%' -f $script:statusQueryCode),
        ('"{0}" cat "{1}" --config "{2}" > "{3}" 2> "{4}"' -f $script:RcloneExe,$remoteGeneration,$script:RcloneConfig,$script:statusGenerationOut,$script:statusGenerationErr),
        ('> "{0}" echo %errorlevel%' -f $script:statusGenerationCode),
        'exit /b 0'
    )
    Set-Content -LiteralPath $script:statusQueryCmd -Value $cmdLines -Encoding ASCII
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $env:ComSpec
    $psi.Arguments = ('/d /q /c ""{0}""' -f $script:statusQueryCmd)
    $psi.WorkingDirectory = $script:Root
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    try {
        if ($p.Start()) {
            $script:statusQueryProcess = $p
            $script:statusQueryStarted = Get-Date
        }
        else { $p.Dispose() }
    }
    catch {
        $p.Dispose()
        $script:cachedRemoteState = [pscustomobject]@{Kind='unknown';Lock=$null;Message=('No se pudo iniciar consulta Drive: ' + $_.Exception.Message)}
    }
}

function Poll-RemoteStatusQuery {
    if ($null -eq $script:statusQueryProcess) { return $false }
    if (-not $script:statusQueryProcess.HasExited) {
        if (((Get-Date) - $script:statusQueryStarted).TotalSeconds -gt 15) {
            try { $script:statusQueryProcess.Kill() } catch {}
            try { $script:statusQueryProcess.Dispose() } catch {}
            $script:statusQueryProcess = $null
            $script:cachedRemoteState = [pscustomobject]@{Kind='unknown';Lock=$null;Message='La consulta a Drive ha tardado demasiado'}
            $script:remoteGeneration = $null
$script:generationRefreshBurstUntil = [DateTime]::MinValue
$script:generationRefreshNext = [DateTime]::MinValue
            return $true
        }
        return $false
    }
    $processCode = $script:statusQueryProcess.ExitCode
    try { $script:statusQueryProcess.Dispose() } catch {}
    $script:statusQueryProcess = $null
    $code = $processCode
    if (Test-Path -LiteralPath $script:statusQueryCode) {
        try { $code = [int]((Get-Content -LiteralPath $script:statusQueryCode -Raw).Trim()) } catch { $code = $processCode }
    }
    $out = if (Test-Path -LiteralPath $script:statusQueryOut) { Get-Content -LiteralPath $script:statusQueryOut -Raw -ErrorAction SilentlyContinue } else { '' }
    $err = if (Test-Path -LiteralPath $script:statusQueryErr) { Get-Content -LiteralPath $script:statusQueryErr -Raw -ErrorAction SilentlyContinue } else { '' }
    $script:cachedRemoteState = Parse-RemoteLockResult -ExitCode $code -OutText ([string]$out) -ErrText ([string]$err)

    $script:remoteGeneration = $null
$script:generationRefreshBurstUntil = [DateTime]::MinValue
$script:generationRefreshNext = [DateTime]::MinValue
    $script:internetAvailable = $false
    $generationCode = -1
    if (Test-Path -LiteralPath $script:statusGenerationCode) {
        try { $generationCode = [int]((Get-Content -LiteralPath $script:statusGenerationCode -Raw).Trim()) } catch { $generationCode = -1 }
    }
    if ($generationCode -eq 0 -and (Test-Path -LiteralPath $script:statusGenerationOut)) {
        try {
            $genObj = (Get-Content -LiteralPath $script:statusGenerationOut -Raw | ConvertFrom-Json)
            if ($genObj.PSObject.Properties.Name -contains 'generation') { $script:remoteGeneration = [int64]$genObj.generation }
            $script:internetAvailable = $true
        }
        catch { $script:remoteGeneration = $null }
    }

    # Si current.json se ha podido leer pero server-lock.json no existe, el servidor esta
    # realmente libre. No dependemos del texto exacto del error de rclone/Google Drive.
    if ($script:internetAvailable -eq $true -and $code -ne 0) {
        $script:cachedRemoteState = [pscustomobject]@{Kind='offline';Lock=$null;Message='Sin bloqueo remoto'}
    }

    $script:lastStatusCheck = Get-Date
    return $true
}

function Request-GenerationRefreshBurst {
    param([int]$Seconds = 12)
    $script:generationRefreshBurstUntil = (Get-Date).AddSeconds([Math]::Max(2,$Seconds))
    $script:generationRefreshNext = [DateTime]::MinValue
    Update-GenerationUi
}

function Force-RemoteStatusRefresh {
    # v4.9.9: tras publicar/aplicar una generación no esperamos al siguiente ciclo normal.
    # Cancelamos una consulta antigua si sigue viva y pedimos current.json de nuevo ya.
    if ($null -ne $script:statusQueryProcess) {
        try {
            if (-not $script:statusQueryProcess.HasExited) { $script:statusQueryProcess.Kill() }
        } catch { }
        try { $script:statusQueryProcess.Dispose() } catch { }
        $script:statusQueryProcess = $null
    }
    Remove-Item -LiteralPath $script:statusQueryOut,$script:statusQueryErr,$script:statusQueryCode,$script:statusGenerationOut,$script:statusGenerationErr,$script:statusGenerationCode,$script:statusQueryCmd -Force -ErrorAction SilentlyContinue
    Start-RemoteStatusQuery
}

function Get-ConnectionEntriesFromLock {
    param($Lock)
    $entries = @()
    if ($null -eq $Lock) { return @($entries) }
    $serverPort = 25565
    $externalPort = 25565
    try { $serverPort = [int]$Lock.serverPort } catch {}
    try { $externalPort = [int]$Lock.externalPort } catch { $externalPort = $serverPort }
    if ($Lock.PSObject.Properties.Name -contains 'lanIPv4') {
        foreach ($ip in @($Lock.lanIPv4)) {
            if (-not [string]::IsNullOrWhiteSpace([string]$ip)) {
                $addr = ("{0}:{1}" -f $ip,$serverPort)
                $entries += [pscustomobject]@{Label=("Misma red: {0}" -f $addr);Address=$addr;Priority=2}
            }
        }
    }
    if ($Lock.PSObject.Properties.Name -contains 'publicHost' -and -not [string]::IsNullOrWhiteSpace([string]$Lock.publicHost)) {
        $addr = ("{0}:{1}" -f [string]$Lock.publicHost,$externalPort)
        $entries += [pscustomobject]@{Label=("Internet / fija: {0}" -f $addr);Address=$addr;Priority=0}
    }
    if ($Lock.PSObject.Properties.Name -contains 'publicIPv4' -and -not [string]::IsNullOrWhiteSpace([string]$Lock.publicIPv4)) {
        $addr = ("{0}:{1}" -f [string]$Lock.publicIPv4,$externalPort)
        $entries += [pscustomobject]@{Label=("Internet / IP publica: {0}" -f $addr);Address=$addr;Priority=1}
    }
    return @($entries)
}

function Get-ConnectionEntriesFromServerLog {
    $entries = @()
    if (-not (Test-Path -LiteralPath $script:ServerLogPath)) { return @($entries) }
    try { $raw = Get-Content -LiteralPath $script:ServerLogPath -Raw -ErrorAction Stop } catch { return @($entries) }
    $seen = @{}
    $patterns = @(
        [pscustomobject]@{Regex='(?im)IP LOCAL PARA CONECTARSE:\s*([^\r\n]+)';Prefix='Misma red';Priority=2},
        [pscustomobject]@{Regex='(?im)DIRECCION FIJA INTERNET:\s*([^\r\n]+)';Prefix='Internet / fija';Priority=0},
        [pscustomobject]@{Regex='(?im)IP PUBLICA ACTUAL:\s*([^\r\n]+)';Prefix='Internet / IP publica';Priority=1}
    )
    foreach ($p in $patterns) {
        foreach ($m in [regex]::Matches($raw,$p.Regex)) {
            $addr = $m.Groups[1].Value.Trim()
            if (-not [string]::IsNullOrWhiteSpace($addr) -and -not $seen.ContainsKey($addr)) {
                $seen[$addr] = $true
                $entries += [pscustomobject]@{Label=("{0}: {1}" -f $p.Prefix,$addr);Address=$addr;Priority=$p.Priority}
            }
        }
    }
    return @($entries)
}

function Set-ConnectionEntries {
    param([object[]]$Entries)
    if ($null -eq $script:cmbConnection) { return }
    $oldAddress = $null
    if ($script:cmbConnection.SelectedIndex -ge 0 -and $script:cmbConnection.SelectedIndex -lt $script:connectionValues.Count) {
        $oldAddress = [string]$script:connectionValues[$script:cmbConnection.SelectedIndex]
    }
    $sorted = @($Entries | Sort-Object Priority,Label)
    $labels = @($sorted | ForEach-Object { [string]$_.Label })
    $values = @($sorted | ForEach-Object { [string]$_.Address })
    $signature = ($labels -join '|')
    if ($signature -eq [string]$script:lastConnectionSignature) { return }
    $script:lastConnectionSignature = $signature
    $script:cmbConnection.BeginUpdate()
    try {
        $script:cmbConnection.Items.Clear()
        foreach ($label in $labels) { [void]$script:cmbConnection.Items.Add($label) }
        $script:connectionValues = @($values)
        if ($labels.Count -eq 0) {
            [void]$script:cmbConnection.Items.Add('Sin dirección disponible todavía')
            $script:connectionValues = @('')
            $script:cmbConnection.SelectedIndex = 0
        }
        else {
            $selected = 0
            if (-not [string]::IsNullOrWhiteSpace($oldAddress)) {
                for ($i=0; $i -lt $values.Count; $i++) { if ($values[$i] -eq $oldAddress) { $selected=$i; break } }
            }
            $script:cmbConnection.SelectedIndex = $selected
        }
    }
    finally { $script:cmbConnection.EndUpdate() }
}

function Set-LedState {
    param([string]$State)
    $dim = [System.Drawing.Color]::FromArgb(70,70,78)
    $script:ledLocal.ForeColor = $dim
    $script:ledRemote.ForeColor = $dim
    $script:ledOffline.ForeColor = $dim
    switch ($State) {
        'local'   { $script:ledLocal.ForeColor = [System.Drawing.Color]::LimeGreen }
        'remote'  { $script:ledRemote.ForeColor = [System.Drawing.Color]::DodgerBlue }
        'offline' { $script:ledOffline.ForeColor = [System.Drawing.Color]::Crimson }
        'stale'   { $script:ledOffline.ForeColor = [System.Drawing.Color]::DarkOrange }
        default   { }
    }
}

function Set-OnlineSummaryLed {
    param([bool]$Online)
    if ($Online) {
        $script:ledOnlineSummary.ForeColor = [System.Drawing.Color]::LimeGreen
    }
    else {
        $script:ledOnlineSummary.ForeColor = [System.Drawing.Color]::Crimson
    }
}

function Start-ModAutoSyncIfNeeded {
    if ($null -ne $script:modAutoSyncProcess -and -not $script:modAutoSyncProcess.HasExited) { return }
    if ($script:modAutoSyncState -eq 'ok') { return }
    try {
        $script:modAutoSyncLogOffset = [int64]0
        $script:modAutoSyncState = 'running'
        Remove-Item -LiteralPath $script:modAutoSyncLogPath,$script:modAutoSyncRunnerPath -Force -ErrorAction SilentlyContinue
        Add-UiLogLine -Box $script:txtServerLog -Text 'Mods: comprobando automáticamente si Drive tiene un modset más nuevo...'
        $target = Join-Path $PSScriptRoot 'AutoSyncMods.ps1'
        $script:modAutoSyncProcess = Start-LoggedScript -TargetScript $target -LogPath $script:modAutoSyncLogPath -RunnerPath $script:modAutoSyncRunnerPath
        Update-StatusUi
    }
    catch {
        $script:modAutoSyncState = 'error'
        Add-UiLogLine -Box $script:txtServerLog -Text ('ERROR al iniciar sincronización automática de mods: ' + $_.Exception.Message)
    }
}

function Poll-ModAutoSync {
    $chunk = Read-NewLogText -Path $script:modAutoSyncLogPath -Offset ([ref]$script:modAutoSyncLogOffset)
    if (-not [string]::IsNullOrEmpty($chunk)) { Append-LogText -Box $script:txtServerLog -Text $chunk }
    if ($null -eq $script:modAutoSyncProcess -or -not $script:modAutoSyncProcess.HasExited) { return }

    $code = $script:modAutoSyncProcess.ExitCode
    $chunk2 = Read-NewLogText -Path $script:modAutoSyncLogPath -Offset ([ref]$script:modAutoSyncLogOffset)
    if (-not [string]::IsNullOrEmpty($chunk2)) { Append-LogText -Box $script:txtServerLog -Text $chunk2 }
    try { $script:modAutoSyncProcess.Dispose() } catch {}
    $script:modAutoSyncProcess = $null
    Remove-Item -LiteralPath $script:modAutoSyncRunnerPath -Force -ErrorAction SilentlyContinue

    if ($code -eq 0) {
        $script:modAutoSyncState = 'ok'
        Add-UiLogLine -Box $script:txtServerLog -Text 'Mods: sincronización automática comprobada/completada. Ya es seguro iniciar el servidor.'
    }
    else {
        $script:modAutoSyncState = 'error'
        Add-UiLogLine -Box $script:txtServerLog -Text 'Mods: la sincronización automática ha fallado. Iniciar servidor queda bloqueado para evitar arrancar con versiones distintas entre PCs.'
    }
    Update-StatusUi
}

function Update-StatusUi {
    $state = $script:cachedRemoteState
    $script:lastLockState = [string]$state.Kind
    $script:lastLockObject = $state.Lock

    $serverProcRunning = ($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited)
    $taskProcRunning = ($null -ne $script:taskProcess -and -not $script:taskProcess.HasExited)
    $pendingProcRunning = ($null -ne $script:pendingSyncProcess -and -not $script:pendingSyncProcess.HasExited)
    $localPending = (Get-LocalPendingSyncSummary).hasPending
    $modSyncRunning = ($null -ne $script:modAutoSyncProcess -and -not $script:modAutoSyncProcess.HasExited)
    $modSyncBlocking = ($script:modAutoSyncState -ne 'ok')

    # LED resumen: solo verde cuando el servidor ya esta realmente online.
    $isOnlineNow = $false
    if ($serverProcRunning -and [string]$script:localPhase -eq 'server-running' -and -not $script:stopRequested) {
        $isOnlineNow = $true
    }
    elseif (-not $serverProcRunning -and ($state.Kind -eq 'local' -or $state.Kind -eq 'remote') -and $null -ne $state.Lock) {
        try { $isOnlineNow = ([string]$state.Lock.status -eq 'server-running') } catch { $isOnlineNow = $false }
    }
    Set-OnlineSummaryLed -Online $isOnlineNow

    # Si esta GUI posee un proceso vivo, ese dato local manda sobre una consulta lenta a Drive.
    $activeOther = $false
    $activeLocalOutsideGui = $false
    if ($serverProcRunning) {
        Set-LedState -State 'local'
        $script:lblPcValue.Text = $env:COMPUTERNAME
        if ($script:stopRequested) { $script:lblStateValue.Text = 'Apagando / guardando / sincronizando...' }
        elseif ([string]$script:localPhase -eq 'server-running') { $script:lblStateValue.Text = 'Server online' }
        else { $script:lblStateValue.Text = 'Iniciando / preparando...' }

        $entries = @()
        if ($state.Kind -eq 'local' -and $null -ne $state.Lock) { $entries = @(Get-ConnectionEntriesFromLock -Lock $state.Lock) }
        if ($entries.Count -eq 0) { $entries = @(Get-ConnectionEntriesFromServerLog) }
        Set-ConnectionEntries -Entries $entries

        $script:btnStart.Enabled = $false
        $script:btnStart.Text = 'Iniciando / ejecutando...'
        $script:btnStop.Enabled = (-not $script:stopRequested)
        if ($script:stopRequested) { $script:btnStop.Text = 'Apagando y sincronizando...' } else { $script:btnStop.Text = 'Apagar servidor' }
    }
    else {
        Set-LedState -State $state.Kind
        if ($state.Kind -eq 'local' -or $state.Kind -eq 'remote') {
            $lock = $state.Lock
            $script:lblStateValue.Text = [string]$lock.status
            $script:lblPcValue.Text = [string]$lock.host
            Set-ConnectionEntries -Entries @(Get-ConnectionEntriesFromLock -Lock $lock)
        }
        elseif ($state.Kind -eq 'stale') {
            $script:lblStateValue.Text = 'Bloqueo sin heartbeat · NO iniciar sin confirmar'
            $script:lblPcValue.Text = if ($null -ne $state.Lock) { [string]$state.Lock.host } else { '-' }
            Set-ConnectionEntries -Entries @()
        }
        elseif ($state.Kind -eq 'offline') {
            $script:lblStateValue.Text = 'Offline'
            $script:lblPcValue.Text = '-'
            Set-ConnectionEntries -Entries @()
        }
        else {
            $script:lblStateValue.Text = 'Consultando / sin acceso a Drive'
            $script:lblPcValue.Text = '-'
            Set-ConnectionEntries -Entries @()
        }

        $activeOther = ($state.Kind -eq 'remote')
        $activeLocalOutsideGui = ($state.Kind -eq 'local')
        $canAttemptAuthoritativeStart = ($state.Kind -eq 'offline' -or $state.Kind -eq 'unknown')
        $script:btnStart.Enabled = (-not $taskProcRunning -and -not $pendingProcRunning -and -not $localPending -and -not $modSyncBlocking -and -not $activeOther -and -not $activeLocalOutsideGui -and $canAttemptAuthoritativeStart)
        $script:btnStop.Enabled = $false
        $script:btnStop.Text = 'Apagar servidor'
        if ($modSyncRunning -or $script:modAutoSyncState -eq 'pending') { $script:btnStart.Text = 'Sincronizando mods...' }
        elseif ($script:modAutoSyncState -eq 'error') { $script:btnStart.Text = 'Error sincronizando mods' }
        elseif ($activeOther) { $script:btnStart.Text = 'Servidor activo en otro PC' }
        elseif ($activeLocalOutsideGui) { $script:btnStart.Text = 'Servidor activo en este PC' }
        elseif ($state.Kind -eq 'unknown') { $script:btnStart.Text = 'Iniciar servidor (verificar Drive)' }
        else { $script:btnStart.Text = 'Iniciar servidor' }
    }
    # v4.9.5: actualizar este PC es no exclusivo. Puede hacerse incluso si Minecraft
    # esta funcionando en el OTRO PC. Solo se bloquea si ESTE PC tiene su servidor
    # abierto/reservado o si ya hay otra tarea local en marcha.
    $manualUpdateAllowed = (-not $serverProcRunning -and -not $taskProcRunning -and -not $pendingProcRunning -and -not $localPending -and -not $modSyncBlocking -and -not $activeLocalOutsideGui)
    $script:btnUpdateWorld.Enabled = $manualUpdateAllowed
    if (-not $taskProcRunning) { $script:btnUpdateWorld.Text = 'Actualizar versión de mundo' }

    Update-GenerationUi
    Update-SyncSafetyUi
    if ($script:lastStatusCheck -gt [DateTime]::MinValue) { $script:lblLastCheck.Text = ('Drive: {0}' -f $script:lastStatusCheck.ToString('HH:mm:ss')) }
    else { $script:lblLastCheck.Text = 'Drive: consultando...' }
}

function Start-ServerFromGui {
    if ($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited) { return }
    if ($script:modAutoSyncState -ne 'ok') {
        $msg = if ($script:modAutoSyncState -eq 'error') { 'La sincronización automática de mods con Drive ha fallado. Revisa el log antes de iniciar el servidor.' } else { 'Espera a que termine la sincronización automática de mods con Drive.' }
        [System.Windows.Forms.MessageBox]::Show($msg, 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }
    if ($null -ne $script:taskProcess -and -not $script:taskProcess.HasExited) {
        [System.Windows.Forms.MessageBox]::Show('Espera a que termine la tarea de Herramientas antes de iniciar el servidor.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }
    if (($null -ne $script:pendingSyncProcess -and -not $script:pendingSyncProcess.HasExited) -or (Get-LocalPendingSyncSummary).hasPending) {
        [System.Windows.Forms.MessageBox]::Show('Este PC tiene una sincronización pendiente. Espera a que el outbox se publique antes de iniciar otro servidor.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        Start-PendingSyncRetryIfNeeded
        return
    }

    $startState = $script:cachedRemoteState
    if ($null -ne $startState) {
        if ($startState.Kind -eq 'remote') {
            [System.Windows.Forms.MessageBox]::Show('El servidor está reservado por el otro PC. No se iniciará otra rama del mundo.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
            return
        }
        if ($startState.Kind -eq 'local') {
            [System.Windows.Forms.MessageBox]::Show('Drive indica que este PC ya tiene una sesión reservada. Espera a que se libere o usa Forzar desbloqueo si sabes que no hay ningún servidor activo.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
            return
        }
        if ($startState.Kind -eq 'stale') {
            [System.Windows.Forms.MessageBox]::Show('Hay un bloqueo antiguo en Drive. Confírmalo antes de iniciar para no crear dos ramas del mundo.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
            return
        }
        if ($startState.Kind -eq 'unconfigured') {
            [System.Windows.Forms.MessageBox]::Show('Falta la configuración de Drive/rclone. El servidor compartido NORMAL necesita esa configuración para proteger el mundo entre los dos PCs.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
            return
        }
    }
    try {
        $script:serverLogOffset = [int64]0
        $script:stopRequested = $false
        $script:localPhase = 'starting'
        $script:txtServerLog.Clear()
        if ($null -ne $startState -and $startState.Kind -eq 'unknown') {
            Add-UiLogLine -Box $script:txtServerLog -Text 'El panel no ha podido confirmar Drive. Se intentará el arranque NORMAL de forma segura: StartServer volverá a consultar Drive y NO lanzará Java si no puede leer la generación/reservar el mundo.'
        }
        Add-UiLogLine -Box $script:txtServerLog -Text 'Iniciando flujo normal de Cobbleverse v4.3...'
        $target = Join-Path $PSScriptRoot 'StartServer.ps1'
        $script:serverProcess = Start-LoggedScript -TargetScript $target -LogPath $script:ServerLogPath -RunnerPath $script:ServerRunnerPath
        $script:serverRunner = $script:ServerRunnerPath
        $script:btnStart.Enabled = $false
    }
    catch {
        Add-UiLogLine -Box $script:txtServerLog -Text ('ERROR al iniciar: ' + $_.Exception.Message)
    }
}

function Stop-ServerFromGui {
    if ($null -eq $script:serverProcess -or $script:serverProcess.HasExited) {
        [System.Windows.Forms.MessageBox]::Show('Esta ventana no tiene un proceso de servidor local al que enviar stop.', 'Cobbleverse', 'OK', 'Information') | Out-Null
        return
    }
    if (Send-ProcessInput -Process $script:serverProcess -Text 'stop' -LogBox $script:txtServerLog) {
        $script:stopRequested = $true
        $script:localPhase = 'stopping'
        $script:btnStop.Enabled = $false
        $script:btnStop.Text = 'Apagando y sincronizando...'
        Set-OnlineSummaryLed -Online $false
        Update-StatusUi
        Add-UiLogLine -Box $script:txtServerLog -Text 'Se ha enviado STOP. Espera a que Java cierre, se publiquen los cambios y se libere el bloqueo.'
    }
}

function Start-MaintenanceTask {
    param($Definition)
    if ($null -ne $script:taskProcess -and -not $script:taskProcess.HasExited) {
        [System.Windows.Forms.MessageBox]::Show('Ya hay una tarea de herramientas en ejecución.', 'Cobbleverse', 'OK', 'Information') | Out-Null
        return
    }
    if ($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited -and -not [bool]$Definition.SafeWhileServerRunning) {
        [System.Windows.Forms.MessageBox]::Show('Apaga primero el servidor y espera a que termine la sincronización antes de ejecutar esta tarea.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }

    if ([bool]$Definition.AdminSeparate) {
        try {
            Add-UiLogLine -Box $script:txtToolsLog -Text ('Abriendo como administrador: ' + [string]$Definition.Label)
            Add-UiLogLine -Box $script:txtToolsLog -Text 'Por la elevacion UAC, esta tarea mostrara su propia ventana de consola.'
            $scriptPath = Join-Path $PSScriptRoot ([string]$Definition.Script)
            $args = ('-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $scriptPath)
            Start-Process -FilePath 'powershell.exe' -ArgumentList $args -Verb RunAs | Out-Null
        }
        catch { Add-UiLogLine -Box $script:txtToolsLog -Text ('ERROR: ' + $_.Exception.Message) }
        return
    }

    try {
        $script:taskLogOffset = [int64]0
        $script:txtToolsLog.Clear()
        Add-UiLogLine -Box $script:txtToolsLog -Text ('Ejecutando: ' + [string]$Definition.Label)
        $target = Join-Path $PSScriptRoot ([string]$Definition.Script)
        $script:taskProcess = Start-LoggedScript -TargetScript $target -LogPath $script:TaskLogPath -RunnerPath $script:TaskRunnerPath
        $script:taskRunner = $script:TaskRunnerPath
        foreach ($b in $script:maintenanceButtons) { $b.Enabled = $false }
        $script:btnStart.Enabled = $false
    }
    catch { Add-UiLogLine -Box $script:txtToolsLog -Text ('ERROR al ejecutar tarea: ' + $_.Exception.Message) }
}

function Start-WorldUpdateFromGui {
    if ($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited) {
        [System.Windows.Forms.MessageBox]::Show('No puedes actualizar los archivos de ESTE PC mientras su propio Minecraft esta abierto. Apaga primero este servidor.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }
    if ($null -ne $script:taskProcess -and -not $script:taskProcess.HasExited) {
        [System.Windows.Forms.MessageBox]::Show('Ya hay otra tarea en ejecución. Espera a que termine.', 'Cobbleverse', 'OK', 'Information') | Out-Null
        return
    }
    try {
        $script:taskLogOffset = [int64]0
        $script:mirrorTaskLogToServer = $true
        $script:taskMirrorHeader = 'Actualización manual de versión de mundo'
        Add-UiLogLine -Box $script:txtServerLog -Text 'Iniciando actualización manual de la versión del mundo sin arrancar Minecraft...'
        Add-UiLogLine -Box $script:txtServerLog -Text 'Se descargaran solo las generaciones pendientes. Esta operacion ya NO reserva el servidor: el otro PC puede iniciar Minecraft mientras tanto.'
        $target = Join-Path $PSScriptRoot 'UpdateWorldVersion.ps1'
        $script:taskProcess = Start-LoggedScript -TargetScript $target -LogPath $script:TaskLogPath -RunnerPath $script:TaskRunnerPath
        $script:taskRunner = $script:TaskRunnerPath
        foreach ($b in $script:maintenanceButtons) { $b.Enabled = $false }
        $script:btnStart.Enabled = $false
        $script:btnUpdateWorld.Enabled = $false
        $script:btnUpdateWorld.Text = 'Actualizando...'
    }
    catch {
        $script:mirrorTaskLogToServer = $false
        Add-UiLogLine -Box $script:txtServerLog -Text ('ERROR al iniciar la actualización manual: ' + $_.Exception.Message)
    }
}

function Open-ServerFolder {
    $path = Get-ServerPathFromConfig
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) {
        [System.Windows.Forms.MessageBox]::Show('La carpeta del servidor todavia no esta configurada o no existe.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }
    Start-Process explorer.exe -ArgumentList ('"{0}"' -f $path) | Out-Null
}

. (Join-Path $PSScriptRoot 'AdvancedFeatures.ps1')

# ---------------- UI ----------------
$dark = [System.Drawing.Color]::FromArgb(20,21,27)
$panel = [System.Drawing.Color]::FromArgb(29,31,39)
$panel2 = [System.Drawing.Color]::FromArgb(37,39,49)
$orange = [System.Drawing.Color]::FromArgb(242,137,40)
$text = [System.Drawing.Color]::FromArgb(235,236,242)
$muted = [System.Drawing.Color]::FromArgb(164,167,180)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Cobbleverse Server Manager'
$form.StartPosition = 'CenterScreen'
$form.MinimumSize = New-Object System.Drawing.Size(980,680)
$form.Size = New-Object System.Drawing.Size(1180,820)
$form.BackColor = $dark
$form.ForeColor = $text
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

$iconPath = Join-Path $script:AssetsDir 'cobbleverse.ico'
if (Test-Path -LiteralPath $iconPath) {
    try { $form.Icon = New-Object System.Drawing.Icon($iconPath) } catch {}
}

$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Top'
$header.Height = 88
$header.BackColor = $panel
$form.Controls.Add($header)

$logo = New-Object System.Windows.Forms.PictureBox
$logo.Location = New-Object System.Drawing.Point(18,11)
$logo.Size = New-Object System.Drawing.Size(64,64)
$logo.SizeMode = 'Zoom'
$logoPath = Join-Path $script:AssetsDir 'cobbleverse-logo.png'
if (Test-Path -LiteralPath $logoPath) {
    try {
        $tempImg = [System.Drawing.Image]::FromFile($logoPath)
        $logo.Image = New-Object System.Drawing.Bitmap($tempImg)
        $tempImg.Dispose()
    } catch {}
}
$header.Controls.Add($logo)

$title = New-Object System.Windows.Forms.Label
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(96,16)
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 20)
$title.ForeColor = $text
$title.Text = 'Cobbleverse Server Manager'
$header.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.AutoSize = $true
$subtitle.Location = New-Object System.Drawing.Point(99,53)
$subtitle.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$subtitle.ForeColor = $muted
$subtitle.Text = 'Servidor compartido · deltas rápidos · Google Drive'
$header.Controls.Add($subtitle)

$script:btnUpdateWorld = New-Object System.Windows.Forms.Button
$script:btnUpdateWorld.Size = New-Object System.Drawing.Size(240,34)
$script:btnUpdateWorld.Location = New-Object System.Drawing.Point(900,26)
$script:btnUpdateWorld.Anchor = 'Top,Right'
$script:btnUpdateWorld.Text = 'Actualizar versión de mundo'
$script:btnUpdateWorld.FlatStyle = 'Flat'
$script:btnUpdateWorld.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(72,75,88)
$script:btnUpdateWorld.BackColor = $panel2
$script:btnUpdateWorld.ForeColor = $text
$script:btnUpdateWorld.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$header.Controls.Add($script:btnUpdateWorld)
$header.Add_Resize({
    if (-not $script:customUiLayoutActive) {
        $script:btnUpdateWorld.Left = [Math]::Max(800,$header.ClientSize.Width - $script:btnUpdateWorld.Width - 18)
        if ($null -ne $script:btnOpenCenter) { $script:btnOpenCenter.Left = [Math]::Max(670,$script:btnUpdateWorld.Left - $script:btnOpenCenter.Width - 10) }
        if ($null -ne $script:btnHome) { $script:btnHome.Left = [Math]::Max(570,$script:btnOpenCenter.Left - $script:btnHome.Width - 10) }
        if ($null -ne $script:btnPlay) { $script:btnPlay.Left = [Math]::Max(470,$script:btnHome.Left - $script:btnPlay.Width - 10) }
    }
})
$headerTip = New-Object System.Windows.Forms.ToolTip
$headerTip.SetToolTip($script:btnUpdateWorld, 'Pone este PC al día sin abrir el servidor. Si ambos PCs ya están sincronizados, también compacta Drive.')


$script:btnOpenCenter = New-Object System.Windows.Forms.Button
$script:btnOpenCenter.Size = New-Object System.Drawing.Size(120,34)
$script:btnOpenCenter.Location = New-Object System.Drawing.Point(770,26)
$script:btnOpenCenter.Anchor = 'Top,Right'
$script:btnOpenCenter.Text = 'Centro 5.0'
$script:btnOpenCenter.FlatStyle = 'Flat'
$script:btnOpenCenter.FlatAppearance.BorderSize = 0
$script:btnOpenCenter.BackColor = $orange
$script:btnOpenCenter.ForeColor = [System.Drawing.Color]::Black
$script:btnOpenCenter.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$header.Controls.Add($script:btnOpenCenter)

$script:btnHome = New-Object System.Windows.Forms.Button
$script:btnHome.Size = New-Object System.Drawing.Size(90,34)
$script:btnHome.Location = New-Object System.Drawing.Point(670,26)
$script:btnHome.Anchor = 'Top,Right'
$script:btnHome.Text = 'Home'
$script:btnHome.FlatStyle = 'Flat'
$script:btnHome.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(72,75,88)
$script:btnHome.BackColor = $panel2
$script:btnHome.ForeColor = $text
$script:btnHome.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$header.Controls.Add($script:btnHome)

$script:btnPlay = New-Object System.Windows.Forms.Button
$script:btnPlay.Size = New-Object System.Drawing.Size(90,34)
$script:btnPlay.Location = New-Object System.Drawing.Point(570,26)
$script:btnPlay.Anchor = 'Top,Right'
$script:btnPlay.Text = 'Jugar'
$script:btnPlay.FlatStyle = 'Flat'
$script:btnPlay.FlatAppearance.BorderSize = 0
$script:btnPlay.BackColor = [System.Drawing.Color]::FromArgb(70,180,90)
$script:btnPlay.ForeColor = [System.Drawing.Color]::White
$script:btnPlay.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$header.Controls.Add($script:btnPlay)
$headerTip.SetToolTip($script:btnPlay, 'Un clic: abre COBBLEVERSE en CurseForge y pulsa Play automaticamente.')

# El TabControl no usa Dock=Fill porque, al haberse creado despues del header,
# WinForms podia extenderlo por debajo del encabezado y ocultar tanto las pestañas
# principales como las internas del Centro 5.0. Se posiciona explicitamente debajo.
$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = 'None'
$tabs.Location = New-Object System.Drawing.Point(0,$header.Height)
$tabs.Size = New-Object System.Drawing.Size($form.ClientSize.Width,[Math]::Max(120,$form.ClientSize.Height-$header.Height))
$tabs.Anchor = 'Top,Bottom,Left,Right'
$tabs.Padding = New-Object System.Drawing.Point(18,7)
$form.Controls.Add($tabs)

$tabServer = New-Object System.Windows.Forms.TabPage
$tabServer.Text = 'Servidor'
$tabServer.BackColor = $dark
$tabServer.ForeColor = $text
$tabs.TabPages.Add($tabServer)

# Las herramientas viven en una ventana independiente, abrible/cerrable sin afectar al servidor.
$script:toolsClosingAllowed = $false
$toolsForm = New-Object System.Windows.Forms.Form
$toolsForm.Text = 'Cobbleverse - Herramientas y backups'
$toolsForm.StartPosition = 'Manual'
$toolsForm.MinimumSize = New-Object System.Drawing.Size(920,600)
$toolsForm.Size = New-Object System.Drawing.Size(1080,720)
$toolsForm.BackColor = $dark
$toolsForm.ForeColor = $text
$toolsForm.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$toolsForm.ShowInTaskbar = $true
if (Test-Path -LiteralPath $iconPath) {
    try { $toolsForm.Icon = New-Object System.Drawing.Icon($iconPath) } catch {}
}

# ---- tab servidor ----
$mainLayout = New-Object System.Windows.Forms.TableLayoutPanel
$mainLayout.Dock = 'Fill'
$mainLayout.BackColor = $dark
$mainLayout.ColumnCount = 1
$mainLayout.RowCount = 3
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,132)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,100)))
$tabServer.Controls.Add($mainLayout)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Dock = 'Fill'
$statusPanel.BackColor = $panel
$statusPanel.Padding = New-Object System.Windows.Forms.Padding(16)
$mainLayout.Controls.Add($statusPanel,0,0)

$ledFont = New-Object System.Drawing.Font('Segoe UI Symbol', 22)
$script:ledLocal = New-Object System.Windows.Forms.Label
$script:ledLocal.AutoSize = $true
$script:ledLocal.Font = $ledFont
$script:ledLocal.Location = New-Object System.Drawing.Point(15,10)
$script:ledLocal.Text = '●'
$statusPanel.Controls.Add($script:ledLocal)
$lblLocalLed = New-Object System.Windows.Forms.Label
$lblLocalLed.AutoSize = $true
$lblLocalLed.Location = New-Object System.Drawing.Point(49,21)
$lblLocalLed.Text = 'Server online · este PC'
$statusPanel.Controls.Add($lblLocalLed)

$script:ledRemote = New-Object System.Windows.Forms.Label
$script:ledRemote.AutoSize = $true
$script:ledRemote.Font = $ledFont
$script:ledRemote.Location = New-Object System.Drawing.Point(225,10)
$script:ledRemote.Text = '●'
$statusPanel.Controls.Add($script:ledRemote)
$lblRemoteLed = New-Object System.Windows.Forms.Label
$lblRemoteLed.AutoSize = $true
$lblRemoteLed.Location = New-Object System.Drawing.Point(259,21)
$lblRemoteLed.Text = 'Server online · otro PC'
$statusPanel.Controls.Add($lblRemoteLed)

$script:ledOffline = New-Object System.Windows.Forms.Label
$script:ledOffline.AutoSize = $true
$script:ledOffline.Font = $ledFont
$script:ledOffline.Location = New-Object System.Drawing.Point(452,10)
$script:ledOffline.Text = '●'
$statusPanel.Controls.Add($script:ledOffline)
$lblOfflineLed = New-Object System.Windows.Forms.Label
$lblOfflineLed.AutoSize = $true
$lblOfflineLed.Location = New-Object System.Drawing.Point(486,21)
$lblOfflineLed.Text = 'Server offline'
$statusPanel.Controls.Add($lblOfflineLed)

$script:lblInternetState = New-Object System.Windows.Forms.Label
$script:lblInternetState.AutoSize = $true
$script:lblInternetState.Location = New-Object System.Drawing.Point(650,21)
$script:lblInternetState.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$script:lblInternetState.ForeColor = $muted
$script:lblInternetState.Text = 'Internet/Drive: ?'
$statusPanel.Controls.Add($script:lblInternetState)

$script:lblSyncState = New-Object System.Windows.Forms.Label
$script:lblSyncState.AutoSize = $true
$script:lblSyncState.Location = New-Object System.Drawing.Point(835,21)
$script:lblSyncState.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$script:lblSyncState.ForeColor = $muted
$script:lblSyncState.Text = 'Sync: comprobando...'
$statusPanel.Controls.Add($script:lblSyncState)

$lblState = New-Object System.Windows.Forms.Label
$lblState.AutoSize = $true
$lblState.Location = New-Object System.Drawing.Point(18,62)
$lblState.ForeColor = $muted
$lblState.Text = 'Estado:'
$statusPanel.Controls.Add($lblState)
$script:lblStateValue = New-Object System.Windows.Forms.Label
$script:lblStateValue.AutoSize = $false
$script:lblStateValue.Size = New-Object System.Drawing.Size(205,22)
$script:lblStateValue.AutoEllipsis = $true
$script:lblStateValue.Location = New-Object System.Drawing.Point(78,60)
$script:lblStateValue.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$script:lblStateValue.Text = 'Consultando...'
$statusPanel.Controls.Add($script:lblStateValue)

# LED resumen: ROJO = apagado/no listo, VERDE = servidor online.
$script:ledOnlineSummary = New-Object System.Windows.Forms.Label
$script:ledOnlineSummary.AutoSize = $true
$script:ledOnlineSummary.Font = New-Object System.Drawing.Font('Segoe UI Symbol',20)
$script:ledOnlineSummary.Location = New-Object System.Drawing.Point(287,40)
$script:ledOnlineSummary.Text = '●'
$script:ledOnlineSummary.ForeColor = [System.Drawing.Color]::Crimson
$statusPanel.Controls.Add($script:ledOnlineSummary)
$summaryTip = New-Object System.Windows.Forms.ToolTip
$summaryTip.SetToolTip($script:ledOnlineSummary, 'Rojo = apagado / Verde = online')

$lblPc = New-Object System.Windows.Forms.Label
$lblPc.AutoSize = $true
$lblPc.Location = New-Object System.Drawing.Point(330,62)
$lblPc.ForeColor = $muted
$lblPc.Text = 'PC activo:'
$statusPanel.Controls.Add($lblPc)
$script:lblPcValue = New-Object System.Windows.Forms.Label
$script:lblPcValue.AutoSize = $true
$script:lblPcValue.Location = New-Object System.Drawing.Point(397,62)
$script:lblPcValue.Text = '-'
$statusPanel.Controls.Add($script:lblPcValue)

$script:lblWorldLocalGen = New-Object System.Windows.Forms.Label
$script:lblWorldLocalGen.AutoSize = $true
$script:lblWorldLocalGen.Location = New-Object System.Drawing.Point(520,62)
$script:lblWorldLocalGen.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$script:lblWorldLocalGen.ForeColor = $muted
$script:lblWorldLocalGen.Text = 'Mundo PC: G?'
$statusPanel.Controls.Add($script:lblWorldLocalGen)

$script:lblWorldDriveGen = New-Object System.Windows.Forms.Label
$script:lblWorldDriveGen.AutoSize = $true
$script:lblWorldDriveGen.Location = New-Object System.Drawing.Point(650,62)
$script:lblWorldDriveGen.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$script:lblWorldDriveGen.ForeColor = $muted
$script:lblWorldDriveGen.Text = 'Drive: G?'
$statusPanel.Controls.Add($script:lblWorldDriveGen)
$generationTip = New-Object System.Windows.Forms.ToolTip
$generationTip.SetToolTip($script:lblWorldLocalGen, 'Generación del mundo que tiene físicamente este PC.')
$generationTip.SetToolTip($script:lblWorldDriveGen, 'Última generación publicada en Google Drive. Si es mayor que la del PC, conviene pulsar Actualizar versión de mundo.')

$lblConnection = New-Object System.Windows.Forms.Label
$lblConnection.AutoSize = $true
$lblConnection.Location = New-Object System.Drawing.Point(18,91)
$lblConnection.ForeColor = $muted
$lblConnection.Text = 'Conexión:'
$statusPanel.Controls.Add($lblConnection)
$script:cmbConnection = New-Object System.Windows.Forms.ComboBox
$script:cmbConnection.DropDownStyle = 'DropDownList'
$script:cmbConnection.Location = New-Object System.Drawing.Point(84,86)
$script:cmbConnection.Size = New-Object System.Drawing.Size(690,25)
$script:cmbConnection.BackColor = $panel2
$script:cmbConnection.ForeColor = $text
$statusPanel.Controls.Add($script:cmbConnection)

$script:btnCopyConnection = New-Object System.Windows.Forms.Button
$script:btnCopyConnection.Location = New-Object System.Drawing.Point(784,85)
$script:btnCopyConnection.Size = New-Object System.Drawing.Size(78,28)
$script:btnCopyConnection.Text = 'Copiar'
$script:btnCopyConnection.FlatStyle = 'Flat'
$script:btnCopyConnection.BackColor = $panel2
$script:btnCopyConnection.ForeColor = $text
$statusPanel.Controls.Add($script:btnCopyConnection)

$script:lblLastCheck = New-Object System.Windows.Forms.Label
$script:lblLastCheck.Anchor = 'Top,Right'
$script:lblLastCheck.AutoSize = $true
$script:lblLastCheck.ForeColor = $muted
$script:lblLastCheck.Location = New-Object System.Drawing.Point(885,91)
$script:lblLastCheck.Text = 'Drive: consultando...'
$statusPanel.Controls.Add($script:lblLastCheck)
$statusPanel.Add_Resize({
    if (-not $script:customUiLayoutActive) {
        $script:lblLastCheck.Left = [Math]::Max(760,$statusPanel.ClientSize.Width - $script:lblLastCheck.Width - 20)
        $script:btnCopyConnection.Left = [Math]::Max(610,$script:lblLastCheck.Left - 90)
        $script:cmbConnection.Width = [Math]::Max(360,$script:btnCopyConnection.Left - $script:cmbConnection.Left - 10)
    }
})

$script:txtServerLog = New-Object System.Windows.Forms.RichTextBox
$script:txtServerLog.Dock = 'Fill'
$script:txtServerLog.ReadOnly = $true
$script:txtServerLog.BackColor = [System.Drawing.Color]::FromArgb(10,11,15)
$script:txtServerLog.ForeColor = [System.Drawing.Color]::Gainsboro
$script:txtServerLog.BorderStyle = 'FixedSingle'
$script:txtServerLog.Font = New-Object System.Drawing.Font('Consolas',10)
$script:txtServerLog.WordWrap = $false
$mainLayout.Controls.Add($script:txtServerLog,0,1)

$serverControls = New-Object System.Windows.Forms.Panel
$serverControls.Dock = 'Fill'
$serverControls.BackColor = $panel
$mainLayout.Controls.Add($serverControls,0,2)

$script:btnStart = New-Object System.Windows.Forms.Button
$script:btnStart.Location = New-Object System.Drawing.Point(16,15)
$script:btnStart.Size = New-Object System.Drawing.Size(190,38)
$script:btnStart.Text = 'Iniciar servidor'
$script:btnStart.FlatStyle = 'Flat'
$script:btnStart.FlatAppearance.BorderSize = 0
$script:btnStart.BackColor = $orange
$script:btnStart.ForeColor = [System.Drawing.Color]::Black
$script:btnStart.Font = New-Object System.Drawing.Font('Segoe UI Semibold',10)
$serverControls.Controls.Add($script:btnStart)

$script:btnStop = New-Object System.Windows.Forms.Button
$script:btnStop.Location = New-Object System.Drawing.Point(217,15)
$script:btnStop.Size = New-Object System.Drawing.Size(190,38)
$script:btnStop.Text = 'Apagar servidor'
$script:btnStop.FlatStyle = 'Flat'
$script:btnStop.FlatAppearance.BorderSize = 0
$script:btnStop.BackColor = [System.Drawing.Color]::FromArgb(178,48,55)
$script:btnStop.ForeColor = [System.Drawing.Color]::White
$script:btnStop.Font = New-Object System.Drawing.Font('Segoe UI Semibold',10)
$script:btnStop.Enabled = $false
$serverControls.Controls.Add($script:btnStop)

$lblCommand = New-Object System.Windows.Forms.Label
$lblCommand.AutoSize = $true
$lblCommand.Location = New-Object System.Drawing.Point(432,11)
$lblCommand.ForeColor = $muted
$lblCommand.Text = 'Comando / respuesta manual (opcional):'
$serverControls.Controls.Add($lblCommand)

$script:txtServerInput = New-Object System.Windows.Forms.TextBox
$script:txtServerInput.Location = New-Object System.Drawing.Point(435,32)
$script:txtServerInput.Size = New-Object System.Drawing.Size(430,25)
$script:txtServerInput.BackColor = $panel2
$script:txtServerInput.ForeColor = $text
$script:txtServerInput.BorderStyle = 'FixedSingle'
$serverControls.Controls.Add($script:txtServerInput)

$script:btnSendServerInput = New-Object System.Windows.Forms.Button
$script:btnSendServerInput.Location = New-Object System.Drawing.Point(875,30)
$script:btnSendServerInput.Size = New-Object System.Drawing.Size(95,29)
$script:btnSendServerInput.Text = 'Enviar'
$script:btnSendServerInput.FlatStyle = 'Flat'
$script:btnSendServerInput.BackColor = $panel2
$script:btnSendServerInput.ForeColor = $text
$serverControls.Controls.Add($script:btnSendServerInput)

$script:btnOpenTools = New-Object System.Windows.Forms.Button
$script:btnOpenTools.Size = New-Object System.Drawing.Size(172,28)
$script:btnOpenTools.Location = New-Object System.Drawing.Point(970,64)
$script:btnOpenTools.Anchor = 'Bottom,Right'
$script:btnOpenTools.Text = 'Herramientas / backups'
$script:btnOpenTools.FlatStyle = 'Flat'
$script:btnOpenTools.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(72,75,88)
$script:btnOpenTools.BackColor = $panel2
$script:btnOpenTools.ForeColor = $text
$serverControls.Controls.Add($script:btnOpenTools)

$script:lblAppVersion = New-Object System.Windows.Forms.Label
$script:lblAppVersion.AutoSize = $true
$script:lblAppVersion.Anchor = 'Bottom,Right'
$script:lblAppVersion.ForeColor = $muted
$script:lblAppVersion.Font = New-Object System.Drawing.Font('Segoe UI Semibold',9)
$script:lblAppVersion.Text = ('App v{0}' -f (Get-AppVersion))
$script:lblAppVersion.Location = New-Object System.Drawing.Point(1060,72)
$serverControls.Controls.Add($script:lblAppVersion)
$serverControls.Add_Resize({
    if (-not $script:customUiLayoutActive) {
        $script:lblAppVersion.Left = [Math]::Max(900,$serverControls.ClientSize.Width - $script:lblAppVersion.Width - 16)
        $script:lblAppVersion.Top = [Math]::Max(68,$serverControls.ClientSize.Height - $script:lblAppVersion.Height - 10)
        $script:btnOpenTools.Left = [Math]::Max(700,$script:lblAppVersion.Left - $script:btnOpenTools.Width - 18)
        $script:btnOpenTools.Top = [Math]::Max(62,$serverControls.ClientSize.Height - $script:btnOpenTools.Height - 8)
    }
})

$hint = New-Object System.Windows.Forms.Label
$hint.AutoSize = $true
$hint.Location = New-Object System.Drawing.Point(16,67)
$hint.ForeColor = $muted
$hint.Text = 'Apagar servidor envía “stop” de forma limpia y espera la sincronización antes de liberar el otro PC.'
$serverControls.Controls.Add($hint)


# Controles que el editor visual puede mover/redimensionar.
Register-UiEditableControl -Name 'logo' -Control $logo -Section 'header'
Register-UiEditableControl -Name 'title' -Control $title -Section 'header'
Register-UiEditableControl -Name 'subtitle' -Control $subtitle -Section 'header'
Register-UiEditableControl -Name 'btnUpdateWorld' -Control $script:btnUpdateWorld -Section 'header'
Register-UiEditableControl -Name 'btnPlay' -Control $script:btnPlay -Section 'header'

Register-UiEditableControl -Name 'ledLocal' -Control $script:ledLocal -Section 'status'
Register-UiEditableControl -Name 'lblLocalLed' -Control $lblLocalLed -Section 'status'
Register-UiEditableControl -Name 'ledRemote' -Control $script:ledRemote -Section 'status'
Register-UiEditableControl -Name 'lblRemoteLed' -Control $lblRemoteLed -Section 'status'
Register-UiEditableControl -Name 'ledOffline' -Control $script:ledOffline -Section 'status'
Register-UiEditableControl -Name 'lblOfflineLed' -Control $lblOfflineLed -Section 'status'
Register-UiEditableControl -Name 'lblState' -Control $lblState -Section 'status'
Register-UiEditableControl -Name 'lblStateValue' -Control $script:lblStateValue -Section 'status'
Register-UiEditableControl -Name 'ledOnlineSummary' -Control $script:ledOnlineSummary -Section 'status'
Register-UiEditableControl -Name 'lblPc' -Control $lblPc -Section 'status'
Register-UiEditableControl -Name 'lblPcValue' -Control $script:lblPcValue -Section 'status'
Register-UiEditableControl -Name 'lblWorldLocalGen' -Control $script:lblWorldLocalGen -Section 'status'
Register-UiEditableControl -Name 'lblWorldDriveGen' -Control $script:lblWorldDriveGen -Section 'status'
Register-UiEditableControl -Name 'lblInternetState' -Control $script:lblInternetState -Section 'status'
Register-UiEditableControl -Name 'lblSyncState' -Control $script:lblSyncState -Section 'status'
Register-UiEditableControl -Name 'lblConnection' -Control $lblConnection -Section 'status'
Register-UiEditableControl -Name 'cmbConnection' -Control $script:cmbConnection -Section 'status'
Register-UiEditableControl -Name 'btnCopyConnection' -Control $script:btnCopyConnection -Section 'status'
Register-UiEditableControl -Name 'lblLastCheck' -Control $script:lblLastCheck -Section 'status'

Register-UiEditableControl -Name 'btnStart' -Control $script:btnStart -Section 'footer'
Register-UiEditableControl -Name 'btnStop' -Control $script:btnStop -Section 'footer'
Register-UiEditableControl -Name 'lblCommand' -Control $lblCommand -Section 'footer'
Register-UiEditableControl -Name 'txtServerInput' -Control $script:txtServerInput -Section 'footer'
Register-UiEditableControl -Name 'btnSendServerInput' -Control $script:btnSendServerInput -Section 'footer'
Register-UiEditableControl -Name 'hint' -Control $hint -Section 'footer'
Register-UiEditableControl -Name 'btnOpenTools' -Control $script:btnOpenTools -Section 'footer'
Register-UiEditableControl -Name 'lblAppVersion' -Control $script:lblAppVersion -Section 'footer'

# ---- tab herramientas ----
$toolsLayout = New-Object System.Windows.Forms.TableLayoutPanel
$toolsLayout.Dock = 'Fill'
$toolsLayout.BackColor = $dark
$toolsLayout.ColumnCount = 2
$toolsLayout.RowCount = 1
$toolsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,310)))
$toolsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
$toolsForm.Controls.Add($toolsLayout)

$toolsLeft = New-Object System.Windows.Forms.Panel
$toolsLeft.Dock = 'Fill'
$toolsLeft.BackColor = $panel
$toolsLeft.Padding = New-Object System.Windows.Forms.Padding(12)
$toolsLayout.Controls.Add($toolsLeft,0,0)

$toolsTitle = New-Object System.Windows.Forms.Label
$toolsTitle.AutoSize = $true
$toolsTitle.Location = New-Object System.Drawing.Point(15,14)
$toolsTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold',13)
$toolsTitle.Text = 'Tareas disponibles'
$toolsLeft.Controls.Add($toolsTitle)

$toolsHint = New-Object System.Windows.Forms.Label
$toolsHint.Location = New-Object System.Drawing.Point(16,45)
$toolsHint.Size = New-Object System.Drawing.Size(272,42)
$toolsHint.ForeColor = $muted
$toolsHint.Text = 'Ejecutan los mismos scripts de v4.3. Si una tarea pregunta algo, escríbelo abajo en Entrada.'
$toolsLeft.Controls.Add($toolsHint)

$flow = New-Object System.Windows.Forms.FlowLayoutPanel
$flow.Location = New-Object System.Drawing.Point(13,94)
$flow.Size = New-Object System.Drawing.Size(282,560)
$flow.Anchor = 'Top,Bottom,Left,Right'
$flow.FlowDirection = 'TopDown'
$flow.WrapContents = $false
$flow.AutoScroll = $true
$toolsLeft.Controls.Add($flow)

$definitions = @(
    [pscustomobject]@{Label='Instalar / configurar';Script='Setup.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Vincular PC principal';Script='ImportHosting.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Ver backups locales';Script='ListSnapshots.ps1';SafeWhileServerRunning=$true;AdminSeparate=$false},
    [pscustomobject]@{Label='Restaurar backup';Script='Rollback.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Forzar desbloqueo';Script='ForceUnlock.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Mantenimiento backups';Script='Maintenance.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Configurar dirección fija';Script='ConfigurePublicAddress.ps1';SafeWhileServerRunning=$false;AdminSeparate=$true},
    [pscustomobject]@{Label='Preparar segundo PC';Script='ExportSecondPC.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Limpiar restic antiguo Drive';Script='CleanupLegacyRemoteRestic.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Limpiar estado v4 antiguo';Script='CleanupLegacyState.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false},
    [pscustomobject]@{Label='Crear backup local ahora';Script='BackupNow.ps1';SafeWhileServerRunning=$false;AdminSeparate=$false}
)
$script:maintenanceButtons = @()
foreach ($def in $definitions) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Size = New-Object System.Drawing.Size(250,34)
    $btn.Margin = New-Object System.Windows.Forms.Padding(5,4,5,4)
    $btn.Text = [string]$def.Label
    $btn.FlatStyle = 'Flat'
    $btn.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(72,75,88)
    $btn.BackColor = $panel2
    $btn.ForeColor = $text
    $localDef = $def
    $btn.Add_Click(({ Start-MaintenanceTask -Definition $localDef }).GetNewClosure())
    $flow.Controls.Add($btn)
    $script:maintenanceButtons += $btn
}

$btnOpenServer = New-Object System.Windows.Forms.Button
$btnOpenServer.Size = New-Object System.Drawing.Size(250,34)
$btnOpenServer.Margin = New-Object System.Windows.Forms.Padding(5,12,5,4)
$btnOpenServer.Text = 'Abrir carpeta CobbleverseShared'
$btnOpenServer.FlatStyle = 'Flat'
$btnOpenServer.BackColor = $panel2
$btnOpenServer.ForeColor = $text
$btnOpenServer.Add_Click({ Open-ServerFolder })
$flow.Controls.Add($btnOpenServer)
$script:maintenanceButtons += $btnOpenServer

$btnOpenRoot = New-Object System.Windows.Forms.Button
$btnOpenRoot.Size = New-Object System.Drawing.Size(250,34)
$btnOpenRoot.Margin = New-Object System.Windows.Forms.Padding(5,4,5,4)
$btnOpenRoot.Text = 'Abrir carpeta del manager'
$btnOpenRoot.FlatStyle = 'Flat'
$btnOpenRoot.BackColor = $panel2
$btnOpenRoot.ForeColor = $text
$btnOpenRoot.Add_Click({ Start-Process explorer.exe -ArgumentList ('"{0}"' -f $script:Root) | Out-Null })
$flow.Controls.Add($btnOpenRoot)
$script:maintenanceButtons += $btnOpenRoot


$btnUiDesigner = New-Object System.Windows.Forms.Button
$btnUiDesigner.Size = New-Object System.Drawing.Size(250,34)
$btnUiDesigner.Margin = New-Object System.Windows.Forms.Padding(5,12,5,4)
$btnUiDesigner.Text = 'Editar interfaz visual'
$btnUiDesigner.FlatStyle = 'Flat'
$btnUiDesigner.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(242,137,40)
$btnUiDesigner.BackColor = $panel2
$btnUiDesigner.ForeColor = $text
$btnUiDesigner.Add_Click({ Show-UiDesigner })
$flow.Controls.Add($btnUiDesigner)

$toolsRight = New-Object System.Windows.Forms.TableLayoutPanel
$toolsRight.Dock = 'Fill'
$toolsRight.BackColor = $dark
$toolsRight.ColumnCount = 1
$toolsRight.RowCount = 2
$toolsRight.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
$toolsRight.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,74)))
$toolsLayout.Controls.Add($toolsRight,1,0)

$script:txtToolsLog = New-Object System.Windows.Forms.RichTextBox
$script:txtToolsLog.Dock = 'Fill'
$script:txtToolsLog.ReadOnly = $true
$script:txtToolsLog.BackColor = [System.Drawing.Color]::FromArgb(10,11,15)
$script:txtToolsLog.ForeColor = [System.Drawing.Color]::Gainsboro
$script:txtToolsLog.BorderStyle = 'FixedSingle'
$script:txtToolsLog.Font = New-Object System.Drawing.Font('Consolas',10)
$script:txtToolsLog.WordWrap = $false
$toolsRight.Controls.Add($script:txtToolsLog,0,0)

$toolsInputPanel = New-Object System.Windows.Forms.Panel
$toolsInputPanel.Dock = 'Fill'
$toolsInputPanel.BackColor = $panel
$toolsRight.Controls.Add($toolsInputPanel,0,1)
$lblToolsInput = New-Object System.Windows.Forms.Label
$lblToolsInput.AutoSize = $true
$lblToolsInput.Location = New-Object System.Drawing.Point(12,8)
$lblToolsInput.ForeColor = $muted
$lblToolsInput.Text = 'Entrada para la tarea actual:'
$toolsInputPanel.Controls.Add($lblToolsInput)
$script:txtToolsInput = New-Object System.Windows.Forms.TextBox
$script:txtToolsInput.Location = New-Object System.Drawing.Point(14,30)
$script:txtToolsInput.Size = New-Object System.Drawing.Size(540,25)
$script:txtToolsInput.Anchor = 'Top,Left,Right'
$script:txtToolsInput.BackColor = $panel2
$script:txtToolsInput.ForeColor = $text
$script:txtToolsInput.BorderStyle = 'FixedSingle'
$toolsInputPanel.Controls.Add($script:txtToolsInput)
$btnToolsSend = New-Object System.Windows.Forms.Button
$btnToolsSend.Size = New-Object System.Drawing.Size(90,28)
$btnToolsSend.Location = New-Object System.Drawing.Point(565,28)
$btnToolsSend.Anchor = 'Top,Right'
$btnToolsSend.Text = 'Enviar'
$btnToolsSend.FlatStyle = 'Flat'
$btnToolsSend.BackColor = $panel2
$btnToolsSend.ForeColor = $text
$toolsInputPanel.Controls.Add($btnToolsSend)

function Refresh-DesignerFields {
    if ($null -eq $script:designerClones -or [string]::IsNullOrWhiteSpace([string]$script:designerSelectedKey) -or -not $script:designerClones.ContainsKey($script:designerSelectedKey)) { return }
    $c = $script:designerClones[$script:designerSelectedKey]
    $script:designerUpdatingFields = $true
    try {
        $script:designerNumX.Value = [Math]::Min($script:designerNumX.Maximum,[Math]::Max($script:designerNumX.Minimum,$c.Left))
        $script:designerNumY.Value = [Math]::Min($script:designerNumY.Maximum,[Math]::Max($script:designerNumY.Minimum,$c.Top))
        $script:designerNumW.Value = [Math]::Min($script:designerNumW.Maximum,[Math]::Max($script:designerNumW.Minimum,$c.Width))
        $script:designerNumH.Value = [Math]::Min($script:designerNumH.Maximum,[Math]::Max($script:designerNumH.Minimum,$c.Height))
        $script:designerLblSelected.Text = ("Seleccionado: {0}`r`nSección: {1}" -f $script:designerSelectedKey,$script:uiEditable[$script:designerSelectedKey].Section)
    }
    finally { $script:designerUpdatingFields = $false }
}

function Select-DesignerControl {
    param([string]$Key)
    if ($null -eq $script:designerClones -or -not $script:designerClones.ContainsKey($Key)) { return }
    $script:designerSelectedKey = $Key
    foreach ($k in @($script:designerClones.Keys)) {
        $cc = $script:designerClones[$k]
        $cc.BackColor = $panel2
    }
    $sel = $script:designerClones[$Key]
    $sel.BackColor = [System.Drawing.Color]::FromArgb(78,60,38)
    if ($null -ne $script:designerList -and [string]$script:designerList.SelectedItem -ne $Key) {
        for ($i=0; $i -lt $script:designerList.Items.Count; $i++) {
            if ([string]$script:designerList.Items[$i] -eq $Key) { $script:designerList.SelectedIndex=$i; break }
        }
    }
    try { $sel.Focus() } catch {}
    Refresh-DesignerFields
}

function Show-UiDesigner {
    if ($script:uiEditable.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('No hay controles registrados para editar.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }

    $editor = New-Object System.Windows.Forms.Form
    $script:designerEditor = $editor
    $editor.Text = 'Cobbleverse - Editor visual de interfaz'
    $editor.StartPosition = 'CenterParent'
    $editor.Size = New-Object System.Drawing.Size(1380,840)
    $editor.MinimumSize = New-Object System.Drawing.Size(1100,720)
    $editor.BackColor = $dark
    $editor.ForeColor = $text
    $editor.Font = New-Object System.Drawing.Font('Segoe UI',9)
    $editor.KeyPreview = $true
    if (Test-Path -LiteralPath $iconPath) { try { $editor.Icon = New-Object System.Drawing.Icon($iconPath) } catch {} }

    $right = New-Object System.Windows.Forms.Panel
    $right.Dock = 'Right'
    $right.Width = 270
    $right.BackColor = $panel
    $editor.Controls.Add($right)

    $viewport = New-Object System.Windows.Forms.Panel
    $viewport.Dock = 'Fill'
    $viewport.AutoScroll = $true
    $viewport.BackColor = [System.Drawing.Color]::FromArgb(13,14,18)
    $editor.Controls.Add($viewport)

    $canvas = New-Object System.Windows.Forms.Panel
    $canvas.Location = New-Object System.Drawing.Point(12,12)
    $canvas.Size = New-Object System.Drawing.Size(1160,720)
    $canvas.BackColor = $dark
    $canvas.BorderStyle = 'FixedSingle'
    $viewport.Controls.Add($canvas)
    $viewport.AutoScrollMinSize = New-Object System.Drawing.Size(1190,750)

    $pHeader = New-Object System.Windows.Forms.Panel
    $pHeader.Location = New-Object System.Drawing.Point(0,0)
    $pHeader.Size = New-Object System.Drawing.Size(1158,88)
    $pHeader.BackColor = $panel
    $canvas.Controls.Add($pHeader)

    $pStatus = New-Object System.Windows.Forms.Panel
    $pStatus.Location = New-Object System.Drawing.Point(0,88)
    $pStatus.Size = New-Object System.Drawing.Size(1158,132)
    $pStatus.BackColor = $panel
    $canvas.Controls.Add($pStatus)

    $pConsole = New-Object System.Windows.Forms.Panel
    $pConsole.Location = New-Object System.Drawing.Point(0,220)
    $pConsole.Size = New-Object System.Drawing.Size(1158,400)
    $pConsole.BackColor = [System.Drawing.Color]::FromArgb(10,11,15)
    $pConsole.BorderStyle = 'FixedSingle'
    $canvas.Controls.Add($pConsole)
    $consoleLabel = New-Object System.Windows.Forms.Label
    $consoleLabel.AutoSize = $true
    $consoleLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,103,115)
    $consoleLabel.Font = New-Object System.Drawing.Font('Consolas',13)
    $consoleLabel.Location = New-Object System.Drawing.Point(16,16)
    $consoleLabel.Text = 'CONSOLA DEL SERVIDOR (área fija, no editable)'
    $pConsole.Controls.Add($consoleLabel)

    $pFooter = New-Object System.Windows.Forms.Panel
    $pFooter.Location = New-Object System.Drawing.Point(0,620)
    $pFooter.Size = New-Object System.Drawing.Size(1158,98)
    $pFooter.BackColor = $panel
    $canvas.Controls.Add($pFooter)

    $sectionParents = @{ header=$pHeader; status=$pStatus; footer=$pFooter }
    $script:designerClones = @{}
    $script:designerSelectedKey = $null
    $script:designerDragging = $false
    $script:designerDragOffset = New-Object System.Drawing.Point(0,0)
    $script:designerUpdatingFields = $false

    $lblEditorTitle = New-Object System.Windows.Forms.Label
    $lblEditorTitle.AutoSize = $true
    $lblEditorTitle.Location = New-Object System.Drawing.Point(14,14)
    $lblEditorTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold',13)
    $lblEditorTitle.Text = 'Editor visual'
    $right.Controls.Add($lblEditorTitle)

    $help = New-Object System.Windows.Forms.Label
    $help.Location = New-Object System.Drawing.Point(15,45)
    $help.Size = New-Object System.Drawing.Size(238,72)
    $help.ForeColor = $muted
    $help.Text = "Arrastra cualquier elemento en la maqueta. También puedes editar X/Y/Ancho/Alto. Flechas = 1 px; Shift+flecha = 10 px."
    $right.Controls.Add($help)

    $script:designerList = New-Object System.Windows.Forms.ListBox
    $script:designerList.Location = New-Object System.Drawing.Point(15,122)
    $script:designerList.Size = New-Object System.Drawing.Size(238,220)
    $script:designerList.BackColor = $panel2
    $script:designerList.ForeColor = $text
    $right.Controls.Add($script:designerList)

    $lblX = New-Object System.Windows.Forms.Label; $lblX.AutoSize=$true; $lblX.Location=New-Object System.Drawing.Point(15,360); $lblX.Text='X'; $right.Controls.Add($lblX)
    $script:designerNumX = New-Object System.Windows.Forms.NumericUpDown; $script:designerNumX.Location=New-Object System.Drawing.Point(45,356); $script:designerNumX.Size=New-Object System.Drawing.Size(82,24); $script:designerNumX.Maximum=2000; $right.Controls.Add($script:designerNumX)
    $lblY = New-Object System.Windows.Forms.Label; $lblY.AutoSize=$true; $lblY.Location=New-Object System.Drawing.Point(140,360); $lblY.Text='Y'; $right.Controls.Add($lblY)
    $script:designerNumY = New-Object System.Windows.Forms.NumericUpDown; $script:designerNumY.Location=New-Object System.Drawing.Point(166,356); $script:designerNumY.Size=New-Object System.Drawing.Size(82,24); $script:designerNumY.Maximum=1000; $right.Controls.Add($script:designerNumY)

    $lblW = New-Object System.Windows.Forms.Label; $lblW.AutoSize=$true; $lblW.Location=New-Object System.Drawing.Point(15,394); $lblW.Text='Ancho'; $right.Controls.Add($lblW)
    $script:designerNumW = New-Object System.Windows.Forms.NumericUpDown; $script:designerNumW.Location=New-Object System.Drawing.Point(62,390); $script:designerNumW.Size=New-Object System.Drawing.Size(66,24); $script:designerNumW.Minimum=8; $script:designerNumW.Maximum=2000; $right.Controls.Add($script:designerNumW)
    $lblH = New-Object System.Windows.Forms.Label; $lblH.AutoSize=$true; $lblH.Location=New-Object System.Drawing.Point(140,394); $lblH.Text='Alto'; $right.Controls.Add($lblH)
    $script:designerNumH = New-Object System.Windows.Forms.NumericUpDown; $script:designerNumH.Location=New-Object System.Drawing.Point(176,390); $script:designerNumH.Size=New-Object System.Drawing.Size(72,24); $script:designerNumH.Minimum=8; $script:designerNumH.Maximum=1000; $right.Controls.Add($script:designerNumH)

    $script:designerChkGrid = New-Object System.Windows.Forms.CheckBox
    $script:designerChkGrid.Location = New-Object System.Drawing.Point(15,430)
    $script:designerChkGrid.AutoSize = $true
    $script:designerChkGrid.Checked = $true
    $script:designerChkGrid.Text = 'Ajustar a rejilla de 5 px al soltar'
    $right.Controls.Add($script:designerChkGrid)

    $script:designerLblSelected = New-Object System.Windows.Forms.Label
    $script:designerLblSelected.Location = New-Object System.Drawing.Point(15,460)
    $script:designerLblSelected.Size = New-Object System.Drawing.Size(238,40)
    $script:designerLblSelected.ForeColor = $muted
    $script:designerLblSelected.Text = 'Selecciona un elemento.'
    $right.Controls.Add($script:designerLblSelected)

    $btnRestore = New-Object System.Windows.Forms.Button
    $btnRestore.Location = New-Object System.Drawing.Point(15,520)
    $btnRestore.Size = New-Object System.Drawing.Size(238,34)
    $btnRestore.Text = 'Restaurar posiciones predeterminadas'
    $btnRestore.FlatStyle = 'Flat'; $btnRestore.BackColor=$panel2; $btnRestore.ForeColor=$text
    $right.Controls.Add($btnRestore)

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Location = New-Object System.Drawing.Point(15,565)
    $btnSave.Size = New-Object System.Drawing.Size(238,38)
    $btnSave.Text = 'Guardar y aplicar'
    $btnSave.FlatStyle='Flat'; $btnSave.FlatAppearance.BorderSize=0; $btnSave.BackColor=$orange; $btnSave.ForeColor=[System.Drawing.Color]::Black
    $btnSave.Font = New-Object System.Drawing.Font('Segoe UI Semibold',10)
    $right.Controls.Add($btnSave)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Location = New-Object System.Drawing.Point(15,612)
    $btnCancel.Size = New-Object System.Drawing.Size(238,34)
    $btnCancel.Text = 'Cancelar sin guardar'
    $btnCancel.FlatStyle='Flat'; $btnCancel.BackColor=$panel2; $btnCancel.ForeColor=$text
    $right.Controls.Add($btnCancel)

    $pathLabel = New-Object System.Windows.Forms.Label
    $pathLabel.Location = New-Object System.Drawing.Point(15,663)
    $pathLabel.Size = New-Object System.Drawing.Size(238,58)
    $pathLabel.ForeColor = $muted
    $pathLabel.Text = "Diseño guardado en:`r`ndata\ui-layout.json`r`n(se conserva al actualizar la app)"
    $right.Controls.Add($pathLabel)

    foreach ($key in @($script:uiEditable.Keys | Sort-Object)) {
        [void]$script:designerList.Items.Add($key)
        $entry = $script:uiEditable[$key]
        $source = $entry.Control
        $parentPreview = $sectionParents[$entry.Section]
        $typeName = $source.GetType().Name
        $clone = $null
        if ($typeName -eq 'Button') {
            $clone = New-Object System.Windows.Forms.Button
            $clone.FlatStyle = 'Flat'
            $clone.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(100,103,115)
        }
        elseif ($typeName -eq 'TextBox') {
            $clone = New-Object System.Windows.Forms.TextBox
            $clone.BorderStyle = 'FixedSingle'
            $clone.ReadOnly = $true
        }
        elseif ($typeName -eq 'ComboBox') {
            $clone = New-Object System.Windows.Forms.ComboBox
            $clone.DropDownStyle = 'DropDownList'
            [void]$clone.Items.Add('Conexión / IP')
            $clone.SelectedIndex = 0
        }
        elseif ($typeName -eq 'PictureBox') {
            $clone = New-Object System.Windows.Forms.Panel
            $clone.BorderStyle = 'FixedSingle'
        }
        else {
            $clone = New-Object System.Windows.Forms.Label
            $clone.AutoSize = $false
            $clone.BorderStyle = 'FixedSingle'
            $clone.TextAlign = 'MiddleLeft'
        }
        $clone.Tag = $key
        $clone.Location = New-Object System.Drawing.Point($source.Left,$source.Top)
        $cw = [Math]::Max(18,$source.Width); $ch = [Math]::Max(18,$source.Height)
        $clone.Size = New-Object System.Drawing.Size($cw,$ch)
        $clone.BackColor = $panel2
        $clone.ForeColor = $text
        $clone.Font = New-Object System.Drawing.Font('Segoe UI',8)
        if ($typeName -eq 'PictureBox') {
            $clone.BackColor = [System.Drawing.Color]::FromArgb(55,57,68)
        }
        elseif ($key -like 'led*') {
            $clone.Text = '●'
            $clone.Font = New-Object System.Drawing.Font('Segoe UI Symbol',16)
            $clone.ForeColor = [System.Drawing.Color]::Crimson
        }
        else {
            $labelText = [string]$source.Text
            if ([string]::IsNullOrWhiteSpace($labelText)) { $labelText = $key }
            $clone.Text = $labelText
        }
        $parentPreview.Controls.Add($clone)
        $script:designerClones[$key] = $clone

        $clone.Add_MouseDown({
            param($sender,$e)
            if ($e.Button -ne [System.Windows.Forms.MouseButtons]::Left) { return }
            Select-DesignerControl -Key ([string]$sender.Tag)
            $script:designerDragging = $true
            $script:designerDragOffset = New-Object System.Drawing.Point($e.X,$e.Y)
            $sender.Capture = $true
        })
        $clone.Add_MouseMove({
            param($sender,$e)
            if (-not $script:designerDragging -or $e.Button -ne [System.Windows.Forms.MouseButtons]::Left) { return }
            $pt = $sender.Parent.PointToClient([System.Windows.Forms.Control]::MousePosition)
            $nx = [Math]::Max(0,$pt.X - $script:designerDragOffset.X)
            $ny = [Math]::Max(0,$pt.Y - $script:designerDragOffset.Y)
            $sender.Left = [Math]::Min([Math]::Max(0,$sender.Parent.ClientSize.Width - 8),$nx)
            $sender.Top = [Math]::Min([Math]::Max(0,$sender.Parent.ClientSize.Height - 8),$ny)
            Refresh-DesignerFields
        })
        $clone.Add_MouseUp({
            param($sender,$e)
            if ($e.Button -ne [System.Windows.Forms.MouseButtons]::Left) { return }
            $script:designerDragging = $false
            $sender.Capture = $false
            if ($script:designerChkGrid.Checked) {
                $sender.Left = [int]([Math]::Round($sender.Left / 5.0) * 5)
                $sender.Top = [int]([Math]::Round($sender.Top / 5.0) * 5)
            }
            Refresh-DesignerFields
        })
    }

    $script:designerList.Add_SelectedIndexChanged({
        if ($script:designerList.SelectedIndex -ge 0) { Select-DesignerControl -Key ([string]$script:designerList.SelectedItem) }
    })

    $numericHandler = {
        if ($script:designerUpdatingFields -or [string]::IsNullOrWhiteSpace([string]$script:designerSelectedKey) -or -not $script:designerClones.ContainsKey($script:designerSelectedKey)) { return }
        $c = $script:designerClones[$script:designerSelectedKey]
        $c.Location = New-Object System.Drawing.Point([int]$script:designerNumX.Value,[int]$script:designerNumY.Value)
        $c.Size = New-Object System.Drawing.Size([int]$script:designerNumW.Value,[int]$script:designerNumH.Value)
    }
    $script:designerNumX.Add_ValueChanged($numericHandler); $script:designerNumY.Add_ValueChanged($numericHandler); $script:designerNumW.Add_ValueChanged($numericHandler); $script:designerNumH.Add_ValueChanged($numericHandler)

    $editor.Add_KeyDown({
        param($sender,$e)
        if ([string]::IsNullOrWhiteSpace([string]$script:designerSelectedKey) -or -not $script:designerClones.ContainsKey($script:designerSelectedKey)) { return }
        $c = $script:designerClones[$script:designerSelectedKey]
        $step = 1; if ($e.Shift) { $step = 10 }
        $handled = $true
        switch ($e.KeyCode) {
            'Left'  { $c.Left = [Math]::Max(0,$c.Left-$step) }
            'Right' { $c.Left = $c.Left+$step }
            'Up'    { $c.Top = [Math]::Max(0,$c.Top-$step) }
            'Down'  { $c.Top = $c.Top+$step }
            default { $handled = $false }
        }
        if ($handled) { $e.SuppressKeyPress=$true; Refresh-DesignerFields }
    })

    $btnRestore.Add_Click({
        foreach ($key in @($script:designerClones.Keys)) {
            if (-not $script:uiDefaults.ContainsKey($key)) { continue }
            $g = $script:uiDefaults[$key]; $c = $script:designerClones[$key]
            $c.Location = New-Object System.Drawing.Point([int]$g.x,[int]$g.y)
            $c.Size = New-Object System.Drawing.Size([int]$g.width,[int]$g.height)
        }
        Refresh-DesignerFields
    })

    $btnSave.Add_Click({
        try {
            $controlsObj = [ordered]@{}
            foreach ($key in @($script:designerClones.Keys | Sort-Object)) {
                $c = $script:designerClones[$key]
                $controlsObj[$key] = [ordered]@{ x=[int]$c.Left; y=[int]$c.Top; width=[int]$c.Width; height=[int]$c.Height }
            }
            $layout = [ordered]@{
                schema = 1
                applicationVersion = Get-AppVersion
                savedUtc = [DateTimeOffset]::UtcNow.ToString('o')
                controls = $controlsObj
            }
            $json = ConvertTo-Json -InputObject $layout -Depth 8
            [IO.File]::WriteAllText($script:UiLayoutPath,$json,(New-Object Text.UTF8Encoding($false)))
            $layoutObject = ($json | ConvertFrom-Json)
            Apply-UiLayoutObject -Layout $layoutObject -MarkCustom
            Add-UiLogLine -Box $script:txtServerLog -Text 'Diseño personalizado guardado y aplicado.'
            $script:designerEditor.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $script:designerEditor.Close()
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(('No se pudo guardar el diseño: ' + $_.Exception.Message), 'Cobbleverse', 'OK', 'Error') | Out-Null
        }
    })
    $btnCancel.Add_Click({ $script:designerEditor.DialogResult=[System.Windows.Forms.DialogResult]::Cancel; $script:designerEditor.Close() })

    if ($script:designerList.Items.Count -gt 0) { $script:designerList.SelectedIndex = 0 }
    [void]$editor.ShowDialog($form)
    try { if ($null -ne $editor.Icon) { $editor.Icon.Dispose() } } catch {}
    $editor.Dispose()
    $script:designerEditor = $null
    $script:designerClones = $null
}

function Show-ToolsWindow {
    try {
        if (-not $toolsForm.Visible) {
            $x = $form.Left + [Math]::Max(20,[int](($form.Width - $toolsForm.Width) / 2))
            $y = $form.Top + [Math]::Max(20,[int](($form.Height - $toolsForm.Height) / 2))
            $toolsForm.Location = New-Object System.Drawing.Point($x,$y)
            $toolsForm.Show($form)
        }
        $toolsForm.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $toolsForm.BringToFront()
        $toolsForm.Activate()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(('No se pudo abrir Herramientas: ' + $_.Exception.Message), 'Cobbleverse', 'OK', 'Error') | Out-Null
    }
}

$toolsForm.Add_FormClosing({
    if (-not $script:toolsClosingAllowed -and $_.CloseReason -eq [System.Windows.Forms.CloseReason]::UserClosing) {
        $_.Cancel = $true
        $toolsForm.Hide()
    }
})

# Inicializa módulos acumulativos 4.9.10 -> 5.0 según VERSION.txt.
# Un fallo en un módulo avanzado nunca debe impedir que abra el manager principal.
try {
    Initialize-AdvancedFeatures -Tabs $tabs
}
catch {
    try {
        $startupErrorPath = Join-Path $script:DataDir 'gui-startup-error.log'
        $startupError = @(
            ('Fecha: ' + [DateTimeOffset]::Now.ToString('o')),
            ('Versión: ' + (Get-AppVersion)),
            ('Error: ' + $_.Exception.Message),
            ('Tipo: ' + $_.Exception.GetType().FullName),
            ('Posición: ' + [string]$_.InvocationInfo.PositionMessage),
            ('Script stack: ' + [string]$_.ScriptStackTrace)
        ) -join "`r`n"
        [IO.File]::WriteAllText($startupErrorPath,$startupError,(New-Object Text.UTF8Encoding($false)))
    } catch { }
    # No ocultar todo el Centro 5.0 por un único fallo. Si ya existe, añadimos una pestaña de error.
    try {
        if ($null -eq $script:advancedCenterTab) {
            $script:advancedCenterTab = New-Object System.Windows.Forms.TabPage
            $script:advancedCenterTab.Text = 'Centro 5.0'
            $script:advancedCenterTab.BackColor = $dark
            $script:advancedCenterTab.ForeColor = $text
            [void]$tabs.TabPages.Add($script:advancedCenterTab)
        }
        $errBox = New-Object System.Windows.Forms.TextBox
        $errBox.Multiline = $true; $errBox.ReadOnly = $true; $errBox.Dock = 'Fill'
        $errBox.BackColor = $panel2; $errBox.ForeColor = $text; $errBox.Font = New-Object System.Drawing.Font('Consolas',10)
        $errBox.Text = "Un módulo 5.0 no pudo inicializarse.`r`n`r`n" + $_.Exception.Message + "`r`n`r`nDetalle: data\gui-startup-error.log"
        if ($null -ne $script:advancedInnerTabs) {
            $et = New-Object System.Windows.Forms.TabPage; $et.Text='Error módulo'; $et.BackColor=$dark; $et.Controls.Add($errBox); [void]$script:advancedInnerTabs.TabPages.Add($et)
        } else { $script:advancedCenterTab.Controls.Add($errBox) }
    } catch { }
    [System.Windows.Forms.MessageBox]::Show(
        'La interfaz 5.0 se ha cargado parcialmente. El módulo que ha fallado aparece indicado en Centro 5.0 y el detalle está en data\gui-startup-error.log.',
        'Cobbleverse 5.0 - módulo avanzado',
        'OK','Warning') | Out-Null
}

# Eventos
$script:btnHome.Add_Click({
    try { $tabs.SelectedTab = $tabServer } catch { }
})
$script:btnPlay.Add_Click({ Start-MinecraftClientFromGui })
$script:btnOpenCenter.Add_Click({
    try {
        if ($null -ne $script:advancedCenterTab) { $tabs.SelectedTab = $script:advancedCenterTab }
        else { [System.Windows.Forms.MessageBox]::Show('Centro 5.0 no está inicializado. Revisa data\gui-startup-error.log.','Cobbleverse 5.0','OK','Warning') | Out-Null }
    } catch { }
})
$script:btnCopyConnection.Add_Click({
    try {
        $i = $script:cmbConnection.SelectedIndex
        if ($i -ge 0 -and $i -lt $script:connectionValues.Count) {
            $address = [string]$script:connectionValues[$i]
            if (-not [string]::IsNullOrWhiteSpace($address)) {
                [System.Windows.Forms.Clipboard]::SetText($address)
                Add-UiLogLine -Box $script:txtServerLog -Text ("Dirección copiada: {0}" -f $address)
            }
        }
    } catch { Add-UiLogLine -Box $script:txtServerLog -Text ('No se pudo copiar: ' + $_.Exception.Message) }
})
$script:btnStart.Add_Click({ Start-ServerFromGui })
$script:btnStop.Add_Click({ Stop-ServerFromGui })
$script:btnOpenTools.Add_Click({ Show-ToolsWindow })
$script:btnUpdateWorld.Add_Click({ Start-WorldUpdateFromGui })
$script:btnSendServerInput.Add_Click({
    $value = $script:txtServerInput.Text
    if (-not [string]::IsNullOrWhiteSpace($value)) {
        if (Send-ProcessInput -Process $script:serverProcess -Text $value -LogBox $script:txtServerLog) {
            if ($value.Trim().ToLowerInvariant() -eq 'stop') {
                $script:stopRequested = $true
                $script:localPhase = 'stopping'
                Update-StatusUi
            }
            $script:txtServerInput.Clear()
        }
    }
})
$script:txtServerInput.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $_.SuppressKeyPress = $true
        $script:btnSendServerInput.PerformClick()
    }
})
$btnToolsSend.Add_Click({
    $value = $script:txtToolsInput.Text
    if (-not [string]::IsNullOrWhiteSpace($value)) {
        if (Send-ProcessInput -Process $script:taskProcess -Text $value -LogBox $script:txtToolsLog) { $script:txtToolsInput.Clear() }
    }
})
$script:txtToolsInput.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $_.SuppressKeyPress = $true
        $btnToolsSend.PerformClick()
    }
})

$pollTimer = New-Object System.Windows.Forms.Timer
$pollTimer.Interval = 450
$pollCounter = 0
$pollTimer.Add_Tick({
    try {
        Poll-ModAutoSync
        $serverChunk = Read-NewLogText -Path $script:ServerLogPath -Offset ([ref]$script:serverLogOffset)
        if (-not [string]::IsNullOrEmpty($serverChunk)) {
            Append-LogText -Box $script:txtServerLog -Text $serverChunk
            if ($serverChunk -match '(?m)Done \([^\r\n]+\)! For help, type') { $script:localPhase = 'server-running' }
            if ($serverChunk -match '(?m)SINCRONIZACION COMPLETADA') {
                $script:localPhase = 'sync-complete'
                # v4.9.9: local-generation.json ya esta confirmado en este punto.
                Update-GenerationUi
                Request-GenerationRefreshBurst -Seconds 12
                Force-RemoteStatusRefresh
            }
            Update-StatusUi
        }
        $taskChunk = Read-NewLogText -Path $script:TaskLogPath -Offset ([ref]$script:taskLogOffset)
        if (-not [string]::IsNullOrEmpty($taskChunk)) {
            Append-LogText -Box $script:txtToolsLog -Text $taskChunk
            if ($script:mirrorTaskLogToServer) { Append-LogText -Box $script:txtServerLog -Text $taskChunk }
        }

        if ($null -ne $script:serverProcess -and $script:serverProcess.HasExited) {
            $exitCode = $script:serverProcess.ExitCode
            $serverChunk2 = Read-NewLogText -Path $script:ServerLogPath -Offset ([ref]$script:serverLogOffset)
            if (-not [string]::IsNullOrEmpty($serverChunk2)) { Append-LogText -Box $script:txtServerLog -Text $serverChunk2 }
            Add-UiLogLine -Box $script:txtServerLog -Text ("Proceso del servidor finalizado (codigo $exitCode).")
            $script:serverProcess.Dispose()
            $script:serverProcess = $null
            $script:stopRequested = $false
            $script:localPhase = 'offline'
            Remove-Item -LiteralPath $script:ServerRunnerPath -Force -ErrorAction SilentlyContinue
            $script:btnStop.Enabled = $false
            $script:btnStop.Text = 'Apagar servidor'
            Update-GenerationUi
            Request-GenerationRefreshBurst -Seconds 12
            Force-RemoteStatusRefresh
            Update-StatusUi
        }
        if ($null -ne $script:taskProcess -and $script:taskProcess.HasExited) {
            $exitCode = $script:taskProcess.ExitCode
            $taskChunk2 = Read-NewLogText -Path $script:TaskLogPath -Offset ([ref]$script:taskLogOffset)
            if (-not [string]::IsNullOrEmpty($taskChunk2)) { Append-LogText -Box $script:txtToolsLog -Text $taskChunk2 }
            Add-UiLogLine -Box $script:txtToolsLog -Text ("Tarea finalizada (codigo $exitCode).")
            if ($script:mirrorTaskLogToServer) {
                $taskCaption = 'Tarea'
                if (-not [string]::IsNullOrWhiteSpace($script:taskMirrorHeader)) { $taskCaption = $script:taskMirrorHeader }
                Add-UiLogLine -Box $script:txtServerLog -Text ($taskCaption + " finalizada (codigo $exitCode).")
                $script:mirrorTaskLogToServer = $false
                $script:taskMirrorHeader = ''
            }
            $script:taskProcess.Dispose()
            $script:taskProcess = $null
            Remove-Item -LiteralPath $script:TaskRunnerPath -Force -ErrorAction SilentlyContinue
            foreach ($b in $script:maintenanceButtons) { $b.Enabled = $true }
            $script:btnUpdateWorld.Text = 'Actualizar versión de mundo'
            $script:advancedLastRefresh = [DateTime]::MinValue
            # v4.9.6: refresco inmediato. No hace falta cerrar/reabrir la GUI para ver Gxx.
            Update-GenerationUi
            Update-SyncSafetyUi
            Request-GenerationRefreshBurst -Seconds 12
            Force-RemoteStatusRefresh
            Update-StatusUi
        }

        # Reintento automatico del outbox persistente. Es independiente de Minecraft.
        $pendingChunk = Read-NewLogText -Path $script:PendingSyncLogPath -Offset ([ref]$script:pendingSyncLogOffset)
        if (-not [string]::IsNullOrEmpty($pendingChunk)) { Append-LogText -Box $script:txtServerLog -Text $pendingChunk }
        if ($null -ne $script:pendingSyncProcess -and $script:pendingSyncProcess.HasExited) {
            $pendingCode=$script:pendingSyncProcess.ExitCode
            $pendingChunk2=Read-NewLogText -Path $script:PendingSyncLogPath -Offset ([ref]$script:pendingSyncLogOffset)
            if (-not [string]::IsNullOrEmpty($pendingChunk2)) { Append-LogText -Box $script:txtServerLog -Text $pendingChunk2 }
            try { $script:pendingSyncProcess.Dispose() } catch {}
            $script:pendingSyncProcess=$null
            Remove-Item -LiteralPath $script:PendingSyncRunnerPath -Force -ErrorAction SilentlyContinue
            if ((Get-LocalPendingSyncSummary).hasPending) { $retrySeconds=30; $cfgRetry=Get-UiConfig; if ($null -ne $cfgRetry -and $cfgRetry.PSObject.Properties.Name -contains 'PendingSyncRetrySeconds') { $retrySeconds=[Math]::Max(5,[int]$cfgRetry.PendingSyncRetrySeconds) }; $script:pendingSyncNextTry=(Get-Date).AddSeconds($retrySeconds) }
            else { $script:pendingSyncNextTry=[DateTime]::MinValue }
            Update-GenerationUi
            Update-SyncSafetyUi
            Request-GenerationRefreshBurst -Seconds 12
            Force-RemoteStatusRefresh
            Update-StatusUi
        }
        Start-PendingSyncRetryIfNeeded

        # v4.9.9: durante unos segundos despues de publicar/aplicar una generacion,
        # refrescamos mas deprisa para que Mundo PC / Drive cambien sin reiniciar la GUI.
        if ((Get-Date) -lt $script:generationRefreshBurstUntil) {
            Update-GenerationUi
            if ((Get-Date) -ge $script:generationRefreshNext -and $null -eq $script:statusQueryProcess) {
                Start-RemoteStatusQuery
                $script:generationRefreshNext = (Get-Date).AddMilliseconds(1200)
            }
        }

        # Consulta Drive en segundo plano para que la interfaz y los logs nunca se congelen.
        $statusChanged = Poll-RemoteStatusQuery
        if ($statusChanged) { Update-StatusUi }
        $pollCounter++
        if ($pollCounter -ge 5) {
            $pollCounter = 0
            if ($null -eq $script:statusQueryProcess) { Start-RemoteStatusQuery }
            Update-StatusUi
        }
        Update-AdvancedFeatures
    }
    catch { }
})

$form.Add_Shown({
    Set-LedState -State 'unknown'
    Add-UiLogLine -Box $script:txtServerLog -Text 'Interfaz lista. Cobbleverse 5.0.4 PREVIEW: cache de metadatos, descargas por lotes, ZIP rapido y metricas de rendimiento.'
    Add-UiLogLine -Box $script:txtToolsLog -Text 'Ventana de herramientas lista. Configuración existente conservada.'
    Set-ConnectionEntries -Entries @()
    Load-SavedUiLayout
    $script:lblAppVersion.Text = ('App v{0}' -f (Get-AppVersion))
    Start-ModAutoSyncIfNeeded
    Start-RemoteStatusQuery
    Update-StatusUi
    $pollTimer.Start()
    Start-PendingSyncRetryIfNeeded
})

$form.Add_FormClosing({
    if ($script:closingAllowed) { return }
    $serverRunning = ($null -ne $script:serverProcess -and -not $script:serverProcess.HasExited)
    $taskRunning = ($null -ne $script:taskProcess -and -not $script:taskProcess.HasExited)
    $modSyncRunning = ($null -ne $script:modAutoSyncProcess -and -not $script:modAutoSyncProcess.HasExited)
    if ($serverRunning) {
        $_.Cancel = $true
        [System.Windows.Forms.MessageBox]::Show('El servidor sigue ejecutándose. Usa “Apagar servidor” y espera a que termine la sincronización antes de cerrar la aplicación.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }
    if ($taskRunning) {
        $_.Cancel = $true
        [System.Windows.Forms.MessageBox]::Show('Hay una tarea de Herramientas en ejecución. Espera a que termine antes de cerrar la aplicación.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }
    if ($modSyncRunning) {
        $_.Cancel = $true
        [System.Windows.Forms.MessageBox]::Show('Se están sincronizando automáticamente los mods con Drive. Espera a que termine antes de cerrar la aplicación.', 'Cobbleverse', 'OK', 'Warning') | Out-Null
        return
    }
    $script:closingAllowed = $true
    $script:toolsClosingAllowed = $true
    try { if ($null -ne $toolsForm -and -not $toolsForm.IsDisposed) { $toolsForm.Close() } } catch {}
    $pollTimer.Stop()
})

try {
    [System.Windows.Forms.Application]::Run($form)
}
finally {
    try { $pollTimer.Stop(); $pollTimer.Dispose() } catch {}
    try { if ($null -ne $script:statusQueryProcess -and -not $script:statusQueryProcess.HasExited) { $script:statusQueryProcess.Kill() }; if ($null -ne $script:statusQueryProcess) { $script:statusQueryProcess.Dispose() } } catch {}
    try { if ($null -ne $script:pendingSyncProcess -and -not $script:pendingSyncProcess.HasExited) { $script:pendingSyncProcess.Kill() }; if ($null -ne $script:pendingSyncProcess) { $script:pendingSyncProcess.Dispose() } } catch {}
    try { if ($null -ne $script:modAutoSyncProcess -and -not $script:modAutoSyncProcess.HasExited) { $script:modAutoSyncProcess.Kill() }; if ($null -ne $script:modAutoSyncProcess) { $script:modAutoSyncProcess.Dispose() } } catch {}
    try { if ($null -ne $logo.Image) { $logo.Image.Dispose() } } catch {}
    try { if ($null -ne $toolsForm -and $null -ne $toolsForm.Icon) { $toolsForm.Icon.Dispose() } } catch {}
    try { if ($null -ne $toolsForm -and -not $toolsForm.IsDisposed) { $script:toolsClosingAllowed = $true; $toolsForm.Dispose() } } catch {}
    try { if ($null -ne $form.Icon) { $form.Icon.Dispose() } } catch {}
    try { $script:appMutex.ReleaseMutex() } catch {}
    try { $script:appMutex.Dispose() } catch {}
}
