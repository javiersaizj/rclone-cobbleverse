﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
. (Join-Path $PSScriptRoot "DeltaSync.ps1")

$session = $null
$heartbeat = $null

function Find-ImportedServerRoot {
    param([string]$Path)
    if (Test-Path (Join-Path $Path "server.properties")) { return (Resolve-Path $Path).Path }
    if (Test-Path (Join-Path $Path "mods")) { return (Resolve-Path $Path).Path }
    $prop = Get-ChildItem -Path $Path -Recurse -File -Filter "server.properties" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -ne $prop) { return $prop.Directory.FullName }
    $mods = Get-ChildItem -Path $Path -Recurse -Directory -Filter "mods" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -ne $mods) { return $mods.Parent.FullName }
    throw "No se ha encontrado la raiz de un servidor Minecraft dentro de la ruta indicada."
}

try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== PC PRINCIPAL - VINCULAR COPIA DEL HOSTING - DELTAS v4.3 ===" -ForegroundColor Green
    Write-Host "NO se copiaran los ~10 GB dentro del paquete y NO se subiran a Drive." -ForegroundColor Cyan
    Write-Host "Este script usara directamente la carpeta completa que ya descargaste del hosting." -ForegroundColor Cyan
    Write-Host "Drive guardara solo los archivos que cambien DESPUES de esta base comun." -ForegroundColor Cyan
    Write-Host ""

    $sourceInput = (Read-Host "Ruta de la carpeta completa del hosting en ESTE PC (ej. A:\CobbleverseShared)").Trim('"')
    if (-not (Test-Path -LiteralPath $sourceInput -PathType Container)) { throw "La ruta indicada no existe o no es una carpeta." }
    $sourceRoot = Find-ImportedServerRoot -Path $sourceInput

    $session = Acquire-GameplayLock
    $heartbeat = Start-LockHeartbeat -SessionId $session
    Set-GameplayLockStatus -SessionId $session -Status "linking-delta-base"

    $configured = Set-ConfiguredServerPath -Path $sourceRoot
    Write-Host "Carpeta del servidor configurada: $configured" -ForegroundColor Green

    Normalize-ServerProperties
    Ensure-EulaAccepted
    $jar = Find-ServerJar
    if ($null -eq $jar) { throw "No se ha encontrado server.jar/launcher Fabric en la carpeta. No se modifica tu copia automaticamente." }
    $script:Config.ServerJar = $jar
    $script:Config.SyncProtocol = 'delta-overlay-v1'
    Save-CobbleverseConfig
    Write-Host "Launcher: $jar"

    $existingDelta = Get-RemoteDeltaCurrent
    $force = $false
    if ($null -ne $existingDelta) {
        Write-Host "" 
        Write-Host "YA existe una base v4.3 en Drive (generacion $($existingDelta.generation))." -ForegroundColor Yellow
        Write-Host "Reiniciarla borra SOLO el overlay/deltas v4.3 de Drive. No toca tu carpeta local." -ForegroundColor Yellow
        $answer = Read-Host "Escribe REINICIAR_V42 solo si quieres crear una base nueva desde ESTA carpeta"
        if ($answer -cne 'REINICIAR_V42') { throw "No se ha reiniciado la base v4.3." }
        $force = $true
    }

    $result = Reset-DeltaProtocolFromLocalBase -ForceReset:$force
    Write-Host ""
    Write-Host "BASE v4.3 CREADA SIN SUBIR EL SERVIDOR COMPLETO." -ForegroundColor Green
    Write-Host ("Huella: {0} archivos, {1}. Solo se han leido nombres/tamanos." -f $result.baseline.files,(Format-ByteSize ([int64]$result.baseline.bytes))) -ForegroundColor Green
    Write-Host "Generacion inicial: 0" -ForegroundColor Green
    Write-Host ""
    Write-Host "A partir de ahora:" -ForegroundColor Cyan
    Write-Host " - Al arrancar: se mira un JSON pequeno en Drive y solo se descargan archivos que hayan cambiado en el otro PC."
    Write-Host " - Al cerrar: se comparan metadatos locales (ruta/tamano/fecha), NO se leen 10 GB, y solo se suben archivos modificados/nuevos."
    Write-Host " - logs/crash-reports/backups/cache no se sincronizan."
    Write-Host ""
    Show-DeltaRemoteUsage
    Write-Host "En el PC2 ejecuta 08_PREPARAR_SEGUNDO_PC.bat y elige SU propia carpeta descargada del hosting." -ForegroundColor Cyan
    Write-Host "Si v4.0/v4.1 llego a subir ~9 GB a CobbleverseSync/state, puedes borrarlos luego con 10_LIMPIAR_ESTADO_V4_ANTIGUO_DRIVE.bat." -ForegroundColor Yellow

    Release-GameplayLock -SessionId $session
    $session = $null
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    if (-not [string]::IsNullOrWhiteSpace([string]$_.ScriptStackTrace)) {
        Write-Host "Detalle tecnico:" -ForegroundColor DarkGray
        Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    }
    exit 1
}
finally {
    Stop-LockHeartbeat -Job $heartbeat
    if ($null -ne $session) { Release-GameplayLock -SessionId $session }
}
