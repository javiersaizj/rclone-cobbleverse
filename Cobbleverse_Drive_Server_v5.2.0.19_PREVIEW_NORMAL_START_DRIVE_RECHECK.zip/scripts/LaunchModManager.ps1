﻿Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'

$root=Split-Path -Parent $PSScriptRoot
$dataDir=Join-Path $root 'data'
$logPath=Join-Path $dataDir 'mod-manager-startup-error.log'
$gui=Join-Path $PSScriptRoot 'ModManagerGUI.ps1'

try{
    New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
    Remove-Item -LiteralPath $logPath -Force -ErrorAction SilentlyContinue

    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Application]::EnableVisualStyles()

    if(-not(Test-Path -LiteralPath $gui)){
        throw "No se encuentra el gestor de mods: $gui"
    }

    & $gui
    exit 0
}
catch{
    $detail=@(
        ('Fecha: '+[DateTimeOffset]::Now.ToString('o')),
        'Versión: 5.1.0.2 PREVIEW MOD MANAGER TRASH SAFE - DIRECT LAUNCH FIX',
        ('Error: '+$_.Exception.Message),
        ('Tipo: '+$_.Exception.GetType().FullName),
        ('Posición: '+$_.InvocationInfo.PositionMessage),
        ('Script stack: '+$_.ScriptStackTrace),
        '',
        ($_ | Out-String)
    ) -join "`r`n"
    try{[IO.File]::WriteAllText($logPath,$detail,(New-Object Text.UTF8Encoding($false)))}catch{}

    try{
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        [System.Windows.Forms.MessageBox]::Show(
            ("No se pudo abrir el Gestor de Mods.`r`n`r`n"+$_.Exception.Message+"`r`n`r`nSe ha guardado el detalle en:`r`n"+$logPath),
            'Cobbleverse - Gestor de Mods',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }catch{}

    Write-Host $detail -ForegroundColor Red
    exit 1
}
