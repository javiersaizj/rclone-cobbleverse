﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'DeltaSync.ps1')

$actionPath = Join-Path $script:DataDir 'advanced-action.json'
if (-not (Test-Path -LiteralPath $actionPath)) { throw 'No existe data\advanced-action.json.' }
$req = [IO.File]::ReadAllText($actionPath) | ConvertFrom-Json
$action = [string]$req.action

function Write-AdvJson {
    param([string]$Name,$Object)
    $p=Join-Path $script:DataDir $Name
    [IO.File]::WriteAllText($p,(ConvertTo-Json -InputObject $Object -Depth 12),(New-Object Text.UTF8Encoding($false)))
}

function New-ZipFromDirectoryNoCompression {
    param([string]$Source,[string]$ZipPath)
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue
    $fs=[IO.File]::Open($ZipPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $zip=$null
    try {
        $zip=New-Object IO.Compression.ZipArchive($fs,[IO.Compression.ZipArchiveMode]::Create,$false)
        $root=[IO.Path]::GetFullPath($Source).TrimEnd('\','/')
        foreach($f in @(Get-ChildItem -LiteralPath $Source -Recurse -File -ErrorAction SilentlyContinue)) {
            $rel=$f.FullName.Substring($root.Length).TrimStart('\','/').Replace('\','/')
            $e=$zip.CreateEntry($rel,[IO.Compression.CompressionLevel]::NoCompression)
            try { $e.LastWriteTime=New-Object DateTimeOffset($f.LastWriteTime) } catch {}
            $i=[IO.File]::Open($f.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
            $o=$e.Open(); try { $i.CopyTo($o,1048576) } finally { $o.Dispose(); $i.Dispose() }
        }
    } finally { if($null -ne $zip){$zip.Dispose()}; $fs.Dispose() }
}

function Get-EnvironmentManifest {
    $items=New-Object 'System.Collections.Generic.List[object]'
    $paths=@()
    $mods=Join-Path $script:ServerDir 'mods'
    if(Test-Path -LiteralPath $mods){$paths += @(Get-ChildItem -LiteralPath $mods -File -Filter '*.jar' -ErrorAction SilentlyContinue)}
    $serverProps=Join-Path $script:ServerDir 'server.properties'
    if(Test-Path -LiteralPath $serverProps){$paths += @(Get-Item -LiteralPath $serverProps)}
    foreach($f in $paths){
        $rel=$f.FullName.Substring($script:ServerDir.TrimEnd('\').Length).TrimStart('\').Replace('\','/')
        $hash=(Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash
        $items.Add([pscustomobject]@{path=$rel;bytes=[int64]$f.Length;sha256=$hash})
    }
    return [ordered]@{host=$env:COMPUTERNAME;clientId=(Get-OrCreateClientId);utc=[DateTimeOffset]::UtcNow.ToString('o');files=$items.ToArray()}
}

try {
    Initialize-CobbleverseEnvironment
    switch ($action) {
        'backup-list' {
            $raw=Invoke-ResticCapture -Arguments @('snapshots','--host',$env:COMPUTERNAME,'--json')
            $arr=@()
            if(-not [string]::IsNullOrWhiteSpace($raw)){ try{$arr=@($raw|ConvertFrom-Json)}catch{$arr=@()} }
            Write-AdvJson 'backup-list.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');snapshots=$arr})
            Write-Host ("Backups encontrados: {0}" -f $arr.Count) -ForegroundColor Green
        }
        'backup-create' {
            Write-Host 'Creando backup local deduplicado...' -ForegroundColor Cyan
            Backup-Server -ExtraTags @('gui-advanced')
            Write-AdvJson 'last-backup.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');host=$env:COMPUTERNAME;type='manual'})
            Write-Host 'Backup completado.' -ForegroundColor Green
        }
        'backup-restore' {
            $id=[string]$req.snapshotId
            if([string]::IsNullOrWhiteSpace($id)){throw 'Snapshot vacío.'}
            if($null -ne (Get-DirtyMarker)){throw 'Existe una sesión local pendiente; recupérala antes de restaurar.'}
            $m=Get-RemoteMaintenanceInfo; if($null -ne $m -and [string]$m.host -ne $env:COMPUTERNAME){throw ("Mantenimiento activo por {0}." -f [string]$m.host)}
            $session=Acquire-GameplayLock; $hb=Start-LockHeartbeat -SessionId $session
            try {
                Set-GameplayLockStatus -SessionId $session -Status 'restore-backup'
                $null=Apply-RemoteDeltaChanges
                $before=Get-FastManifestData
                Restore-LocalSnapshotToServer -SnapshotId $id
                Normalize-ServerProperties
                $after=Get-FastManifestData
                $r=Publish-DeltaChanges -BeforeManifest $before -AfterManifest $after -SessionId $session -Reason ("backup-restore-$id")
                Write-Host ("Backup restaurado y publicado como G{0}." -f $r.generation) -ForegroundColor Green
            } finally { Stop-LockHeartbeat -Job $hb; Release-GameplayLock -SessionId $session | Out-Null }
        }
        'network-diagnostics' {
            $info=Get-ServerConnectionInfo; $port=Get-MinecraftServerPort
            $listen=$false
            try{$listen=[bool](Test-NetConnection -ComputerName '127.0.0.1' -Port $port -InformationLevel Quiet -WarningAction SilentlyContinue)}catch{}
            $fw=@()
            try{$fw=@(Get-NetFirewallRule -ErrorAction Stop | Where-Object {$_.Enabled -eq 'True'} | Select-Object -First 200 DisplayName,Direction,Action)}catch{}
            $o=[ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');host=$env:COMPUTERNAME;serverPort=$port;lanIPv4=@($info.lanIPv4);publicIPv4=$info.publicIPv4;publicHost=$info.publicHost;externalPort=$info.externalPort;localListening=$listen;firewallRuleCount=$fw.Count;note='La accesibilidad pública real debe probarse desde otra red; NAT loopback no es fiable.'}
            Write-AdvJson 'network-diagnostics.json' $o
            Write-Host ("Puerto {0}; escucha local={1}; IP pública={2}" -f $port,$listen,$info.publicIPv4) -ForegroundColor Green
        }
        'maintenance-enter' {
            $obj=[ordered]@{host=$env:COMPUTERNAME;clientId=(Get-OrCreateClientId);utc=[DateTimeOffset]::UtcNow.ToString('o');message=([string]$req.message)}
            Set-RemoteMaintenanceInfo -Object $obj
            Write-Host 'Modo mantenimiento activado. Ningún PC podrá iniciar Minecraft hasta finalizarlo.' -ForegroundColor Yellow
        }
        'maintenance-exit' {
            $m=Get-RemoteMaintenanceInfo
            if($null -ne $m -and [string]$m.host -ne $env:COMPUTERNAME){throw ("El mantenimiento pertenece a {0}; finalízalo desde ese PC o fuerza el desbloqueo conscientemente." -f [string]$m.host)}
            Clear-RemoteMaintenanceInfo
            Write-Host 'Modo mantenimiento finalizado.' -ForegroundColor Green
        }
        'environment-compare' {
            $mine=Get-EnvironmentManifest
            Write-AdvJson 'environment-manifest.json' $mine
            $remoteDir="$script:RemoteControl/environments"
            Invoke-Rclone -Arguments @('mkdir',$remoteDir,'--config',$script:RcloneConfig) | Out-Null
            $tmp=Join-Path $script:DataDir 'environment-upload.json'; [IO.File]::WriteAllText($tmp,(ConvertTo-Json $mine -Depth 8 -Compress),(New-Object Text.UTF8Encoding($false)))
            try{Invoke-Rclone -Arguments @('copyto',$tmp,("$remoteDir/$($mine.clientId).json"),'--config',$script:RcloneConfig,'--no-traverse')|Out-Null}finally{Remove-Item $tmp -Force -ErrorAction SilentlyContinue}
            $names=Invoke-RcloneCapture -Arguments @('lsf',$remoteDir,'--files-only','--config',$script:RcloneConfig) -IgnoreExitCode
            $other=$null
            foreach($n in @($names -split '\r?\n')){
                $n=$n.Trim(); if([string]::IsNullOrWhiteSpace($n) -or $n -eq ($mine.clientId+'.json')){continue}
                $x=Get-RemoteJsonObject -RemotePath ("$remoteDir/$n"); if($null -ne $x){$other=$x;break}
            }
            $diff=@()
            if($null -ne $other){
                $a=@{};foreach($f in @($mine.files)){$a[[string]$f.path]=[string]$f.sha256}
                $b=@{};foreach($f in @($other.files)){$b[[string]$f.path]=[string]$f.sha256}
                $all=@($a.Keys+$b.Keys|Sort-Object -Unique)
                foreach($k in $all){if(-not $a.ContainsKey($k) -or -not $b.ContainsKey($k) -or $a[$k] -ne $b[$k]){$diff+=$k}}
            }
            $res=[ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');localHost=$env:COMPUTERNAME;otherHost=if($null -ne $other){[string]$other.host}else{''};different=[string[]]$diff;differentCount=$diff.Count;otherFound=($null -ne $other)}
            Write-AdvJson 'environment-compare.json' $res
            if($null -eq $other){Write-Host 'Se publicó el manifiesto. El otro PC todavía no ha publicado el suyo.' -ForegroundColor Yellow}else{Write-Host ("Comparación con {0}: {1} diferencias." -f $other.host,$diff.Count) -ForegroundColor Green}
        }
        'checkpoint-create' {
            $current=Get-RemoteDeltaCurrent; $baseline=Get-RemoteDeltaBaseline; $clients=@(Get-RemoteDeltaClients)
            if($null -eq $current -or $null -eq $baseline){throw 'Protocolo delta no inicializado.'}
            $to=[int64]$current.generation; $from=$to
            foreach($c in $clients){$g=[int64]$c.generation;if($g -lt $from){$from=$g}}
            if($from -ge $to){Write-Host 'No hay ningún PC atrasado; no hace falta checkpoint.' -ForegroundColor Green; Write-AdvJson 'checkpoint-result.json' ([ordered]@{created=$false;reason='no-backlog';from=$from;to=$to});break}
            $work=Join-Path $script:DataDir ('checkpoint-build-'+[guid]::NewGuid().ToString('N'));$overlay=Join-Path $work 'overlay';New-Item -ItemType Directory -Force -Path $overlay|Out-Null
            $deleted=@{}
            try{
                for([int64]$g=$from+1;$g -le $to;$g++){
                    $meta=Get-RemoteJsonObject -RemotePath (Get-RemoteGenerationMetaPath -Generation $g);if($null -eq $meta){throw "Falta metadato G$g"}
                    if(@($meta.changed).Count -gt 0){
                        $z=Join-Path $work ("g$g.zip");Invoke-Rclone -Arguments @('copyto',(Get-RemoteGenerationBundlePath -Generation $g),$z,'--config',$script:RcloneConfig,'--no-traverse')|Out-Null
                        Expand-DeltaBundleZip -ZipPath $z -DestinationRoot $overlay;Remove-Item $z -Force -ErrorAction SilentlyContinue
                        foreach($r in @($meta.changed)){$rr=([string]$r).Replace('\\','/');if($deleted.ContainsKey($rr)){$deleted.Remove($rr)}}
                    }
                    foreach($r in @($meta.deleted)){$rr=([string]$r).Replace('\\','/');$deleted[$rr]=$true;$lp=Join-Path $overlay ($rr.Replace('/','\\'));if(Test-Path -LiteralPath $lp -PathType Leaf){Remove-Item -LiteralPath $lp -Force}}
                }
                $zip=Join-Path $work 'checkpoint.zip';New-ZipFromDirectoryNoCompression -Source $overlay -ZipPath $zip
                $changed=@();[int64]$sourceBytes=0;$oroot=[IO.Path]::GetFullPath($overlay).TrimEnd('\\','/')
                foreach($f in @(Get-ChildItem -LiteralPath $overlay -Recurse -File -ErrorAction SilentlyContinue)){$changed += $f.FullName.Substring($oroot.Length).TrimStart('\\','/').Replace('\\','/');$sourceBytes += [int64]$f.Length}
                $meta=[ordered]@{baselineId=[string]$baseline.baselineId;fromGeneration=$from;toGeneration=$to;createdUtc=[DateTimeOffset]::UtcNow.ToString('o');createdBy=$env:COMPUTERNAME;changed=[string[]]$changed;deleted=[string[]]@($deleted.Keys);sourceBytes=$sourceBytes}
                $remoteRoot=Get-RemoteCheckpointRoot;Invoke-Rclone -Arguments @('mkdir',$remoteRoot,'--config',$script:RcloneConfig)|Out-Null
                Invoke-Rclone -Arguments @('copyto',$zip,(Get-RemoteCheckpointZipPath -FromGeneration $from -ToGeneration $to),'--config',$script:RcloneConfig,'--no-traverse','--drive-chunk-size',(Get-DriveChunkSizeArgument),'--stats','2s','--stats-one-line')|Out-Null
                Set-RemoteJsonObject -RemotePath (Get-RemoteCheckpointMetaPath -FromGeneration $from -ToGeneration $to) -Object $meta -TempPrefix 'checkpoint-meta'
                Write-AdvJson 'checkpoint-result.json' ([ordered]@{created=$true;from=$from;to=$to;changed=$changed.Count;deleted=$deleted.Count;bytes=(Get-Item $zip).Length})
                Write-Host ("Checkpoint catch-up creado: G{0}->G{1}, {2} archivos finales." -f $from,$to,$changed.Count) -ForegroundColor Green
            }finally{Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue}
        }
        'diagnostic-bundle' {
            $stamp=Get-Date -Format 'yyyyMMdd-HHmmss';$work=Join-Path $script:DataDir ('diag-'+$stamp);New-Item -ItemType Directory -Force -Path $work|Out-Null
            $safe=@('gui-server-current.log','gui-tools-current.log','change-tracker.log','background-drive-maintenance.log','performance-last.json','local-generation.json','generation-history.jsonl','last-crash.json','network-diagnostics.json','environment-compare.json','VERSION.txt')
            foreach($name in $safe){$src=if($name -eq 'VERSION.txt'){Join-Path $script:Root $name}else{Join-Path $script:DataDir $name};if(Test-Path -LiteralPath $src){Copy-Item -LiteralPath $src -Destination $work -Force}}
            if(Test-Path -LiteralPath $script:ConfigPath){$cfg=Get-Content $script:ConfigPath -Raw|ConvertFrom-Json;if($cfg.PSObject.Properties.Name -contains 'ServerPath'){$cfg.ServerPath='<redacted-local-path>'};if($cfg.PSObject.Properties.Name -contains 'DiscordWebhookUrl'){$cfg.DiscordWebhookUrl='<redacted>'};$cfg|ConvertTo-Json -Depth 10|Set-Content (Join-Path $work 'config-redacted.json') -Encoding UTF8}
            $zip=Join-Path $script:DataDir ('Cobbleverse-Diagnostico-'+$stamp+'.zip');Compress-Archive -Path (Join-Path $work '*') -DestinationPath $zip -Force;Remove-Item $work -Recurse -Force
            Write-AdvJson 'diagnostic-last.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');path=$zip})
            Write-Host ("Diagnóstico creado: {0}" -f $zip) -ForegroundColor Green
        }
        'export-preferences' {
            $stamp=Get-Date -Format 'yyyyMMdd-HHmmss';$work=Join-Path $script:DataDir ('prefs-'+$stamp);New-Item -ItemType Directory -Force -Path $work|Out-Null
            foreach($src in @($script:ConfigPath,(Join-Path $script:DataDir 'ui-layout.json'))){if(Test-Path -LiteralPath $src){Copy-Item -LiteralPath $src -Destination $work -Force}}
            $zip=Join-Path $script:DataDir ('Cobbleverse-Preferencias-'+$stamp+'.zip');Compress-Archive -Path (Join-Path $work '*') -DestinationPath $zip -Force;Remove-Item $work -Recurse -Force
            Write-AdvJson 'preferences-last.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');path=$zip})
            Write-Host 'Preferencias exportadas. No se ha incluido rclone.conf ni tokens.' -ForegroundColor Green
        }

        'preflight' {
            $checks=New-Object 'System.Collections.Generic.List[object]'
            function AddCheck([string]$Name,[bool]$Ok,[string]$Detail){$checks.Add([pscustomobject]@{name=$Name;ok=$Ok;detail=$Detail})}
            AddCheck 'Carpeta servidor' (Test-Path -LiteralPath $script:ServerDir -PathType Container) $script:ServerDir
            $java=Resolve-JavaExecutable;AddCheck 'Java' ($null -ne $java) $(if($null -ne $java){$java}else{'No encontrado'})
            if($null -ne $java){$maj=Get-JavaMajorVersion -JavaExe $java;AddCheck 'Java 21+' ($maj -ge 21) ("Java $maj")}
            AddCheck 'rclone' (Test-Path -LiteralPath $script:RcloneExe -PathType Leaf) $script:RcloneExe
            AddCheck 'rclone config' (Test-Path -LiteralPath $script:RcloneConfig -PathType Leaf) $script:RcloneConfig
            $driveOk=$false;try{$driveOk=Test-DriveRemote}catch{};AddCheck 'Google Drive' $driveOk $(if($driveOk){'Accesible'}else{'Sin acceso'})
            $dirty=(Get-DirtyMarker);AddCheck 'Sesión pendiente' ($null -eq $dirty) $(if($null -eq $dirty){'No'}else{'Sí: debe recuperarse'})
            $m=Get-RemoteMaintenanceInfo;AddCheck 'Mantenimiento' ($null -eq $m) $(if($null -eq $m){'No activo'}else{('Activo por '+[string]$m.host)})
            try{$root=[IO.Path]::GetPathRoot($script:ServerDir);$di=[IO.DriveInfo]::new($root);AddCheck 'Espacio libre' ($di.AvailableFreeSpace -gt 5GB) (('{0:N1} GB libres' -f ($di.AvailableFreeSpace/1GB)))}catch{AddCheck 'Espacio libre' $false $_.Exception.Message}
            $ok=(@($checks|Where-Object{-not $_.ok}).Count -eq 0)
            Write-AdvJson 'preflight.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');ok=$ok;checks=$checks.ToArray()})
            Write-Host ("Preflight: {0}/{1} comprobaciones correctas." -f (@($checks|Where-Object{$_.ok}).Count),$checks.Count) -ForegroundColor $(if($ok){'Green'}else{'Yellow'})
        }
        'drive-usage' {
            $raw=Invoke-RcloneCapture -Arguments @('size',$script:RemoteDeltaRoot,'--json','--config',$script:RcloneConfig) -IgnoreExitCode
            if($LASTEXITCODE -ne 0){throw 'No se pudo medir el uso de Drive.'}
            $o=$raw|ConvertFrom-Json
            Write-AdvJson 'drive-usage.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');bytes=[int64]$o.bytes;count=[int64]$o.count})
            Write-Host ("Drive delta: {0}; {1} objetos." -f (Format-ByteSize ([int64]$o.bytes)),[int64]$o.count) -ForegroundColor Green
        }
        'sync-plan' {
            $local=Get-LocalDeltaState;$current=Get-RemoteDeltaCurrent
            if($null -eq $local -or $null -eq $current){throw 'No se puede leer la generación local/remota.'}
            [int64]$from=[int64]$local.generation;[int64]$to=[int64]$current.generation;[int64]$bytes=0;[int64]$files=0
            if($to -gt $from){
                for([int64]$g=$from+1;$g -le $to;$g++){
                    $m=Get-RemoteJsonObject -RemotePath (Get-RemoteGenerationMetaPath -Generation $g)
                    if($null -ne $m){if($m.PSObject.Properties.Name -contains 'bundleBytes'){$bytes += [int64]$m.bundleBytes};$files += @($m.changed).Count}
                }
            }
            Write-AdvJson 'sync-plan.json' ([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');from=$from;to=$to;generations=[Math]::Max(0,$to-$from);bytes=$bytes;changedFiles=$files})
            Write-Host ("Plan: G{0}->G{1}, {2} generaciones, aprox. {3}." -f $from,$to,[Math]::Max(0,$to-$from),(Format-ByteSize $bytes)) -ForegroundColor Green
        }
        'integrity-deep' {
            $manifest=Get-FastManifestData
            $sha=[Security.Cryptography.SHA256]::Create();$builder=New-Object Text.StringBuilder;[int]$i=0
            foreach($rec in @($manifest.Records|Sort-Object p)){
                $path=Join-Path $script:ServerDir (([string]$rec.p).Replace('/','\'))
                $h=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
                [void]$builder.Append([string]$rec.p);[void]$builder.Append('|');[void]$builder.Append($h);[void]$builder.Append("`n")
                $i++;if(($i%100)-eq 0){Write-Host ("Integridad: {0}/{1} archivos..." -f $i,$manifest.Count) -ForegroundColor DarkGray}
            }
            $bytes=[Text.Encoding]::UTF8.GetBytes($builder.ToString());$digest=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','')
            $client=Get-OrCreateClientId;$obj=[ordered]@{host=$env:COMPUTERNAME;clientId=$client;generation=[int64](Get-LocalDeltaState).generation;utc=[DateTimeOffset]::UtcNow.ToString('o');files=[int64]$manifest.Count;bytes=[int64]$manifest.Bytes;digest=$digest}
            $remoteDir="$script:RemoteControl/integrity";Invoke-Rclone -Arguments @('mkdir',$remoteDir,'--config',$script:RcloneConfig)|Out-Null
            Set-RemoteJsonObject -RemotePath ("$remoteDir/$client.json") -Object $obj -TempPrefix 'integrity'
            $other=$null;$names=Invoke-RcloneCapture -Arguments @('lsf',$remoteDir,'--files-only','--config',$script:RcloneConfig) -IgnoreExitCode
            foreach($n in @($names -split '\r?\n')){$n=$n.Trim();if([string]::IsNullOrWhiteSpace($n)-or$n-eq($client+'.json')){continue};$x=Get-RemoteJsonObject -RemotePath ("$remoteDir/$n");if($null-ne$x){$other=$x;break}}
            $match=$null;if($null-ne$other -and [int64]$other.generation -eq [int64]$obj.generation){$match=([string]$other.digest -eq $digest)}
            Write-AdvJson 'integrity-result.json' ([ordered]@{utc=$obj.utc;generation=$obj.generation;digest=$digest;otherFound=($null-ne$other);otherHost=if($null-ne$other){[string]$other.host}else{''};otherGeneration=if($null-ne$other){[int64]$other.generation}else{-1};match=$match;files=$obj.files;bytes=$obj.bytes})
            Write-Host 'Verificación profunda terminada.' -ForegroundColor Green
        }
        default { throw "Acción avanzada desconocida: $action" }
    }
}
catch { Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red; exit 1 }
