﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
$IconPath = Join-Path $Root 'assets\cobbleverse.ico'
$GuiScript = Join-Path $Root 'scripts\ServerManagerGUI.ps1'
$ExePath = Join-Path $Root 'Cobbleverse Server Manager.exe'

if (-not (Test-Path -LiteralPath $IconPath)) { throw "No se encuentra el icono: $IconPath" }
if (-not (Test-Path -LiteralPath $GuiScript)) { throw "No se encuentra la GUI: $GuiScript" }

$source = @'
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

[assembly: AssemblyTitle("Cobbleverse Server Manager")]
[assembly: AssemblyDescription("Cobbleverse shared server launcher")]
[assembly: AssemblyCompany("Cobbleverse")]
[assembly: AssemblyProduct("Cobbleverse Server Manager")]
[assembly: AssemblyVersion("4.7.0.0")]
[assembly: AssemblyFileVersion("4.7.0.0")]

namespace CobbleverseServerManagerLauncher
{
    internal static class Program
    {
        [STAThread]
        private static int Main()
        {
            try
            {
                string root = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string gui = Path.Combine(root, "scripts", "ServerManagerGUI.ps1");
                if (!File.Exists(gui))
                {
                    MessageBox.Show("No se encuentra scripts\\ServerManagerGUI.ps1 junto al ejecutable.", "Cobbleverse Server Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 2;
                }

                var psi = new ProcessStartInfo();
                psi.FileName = "powershell.exe";
                psi.Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + gui + "\"";
                psi.WorkingDirectory = root;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;

                Process.Start(psi);
                return 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Cobbleverse Server Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
    }
}
'@

# Windows PowerShell 5.1 incluye el compilador de .NET Framework usado por CodeDom.
$provider = New-Object Microsoft.CSharp.CSharpCodeProvider
$params = New-Object System.CodeDom.Compiler.CompilerParameters
$params.GenerateExecutable = $true
$params.GenerateInMemory = $false
$params.IncludeDebugInformation = $false
$params.OutputAssembly = $ExePath
[void]$params.ReferencedAssemblies.Add('System.dll')
[void]$params.ReferencedAssemblies.Add('System.Windows.Forms.dll')
$params.CompilerOptions = ('/target:winexe /optimize+ /win32icon:"{0}"' -f $IconPath)

# Si existe una version anterior y no esta en uso, reemplazarla.
if (Test-Path -LiteralPath $ExePath) {
    try { Remove-Item -LiteralPath $ExePath -Force }
    catch { throw "No se puede reemplazar '$ExePath'. Cierra primero Cobbleverse Server Manager y vuelve a intentarlo." }
}

$result = $provider.CompileAssemblyFromSource($params, $source)
if ($result.Errors.HasErrors) {
    $messages = @()
    foreach ($e in $result.Errors) { $messages += ("Linea {0}: {1}" -f $e.Line,$e.ErrorText) }
    throw ("No se pudo crear el ejecutable:`r`n" + ($messages -join "`r`n"))
}
if (-not (Test-Path -LiteralPath $ExePath)) { throw 'El compilador termino sin crear el ejecutable.' }

Write-Host ''
Write-Host 'Ejecutable creado correctamente:' -ForegroundColor Green
Write-Host $ExePath -ForegroundColor Cyan
Write-Host ''
Write-Host 'Windows Explorer mostrara el icono de Cobbleverse directamente en este .exe.' -ForegroundColor Green
