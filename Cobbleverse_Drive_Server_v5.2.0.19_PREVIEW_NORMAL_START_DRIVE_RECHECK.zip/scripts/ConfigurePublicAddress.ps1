Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
try {
    Load-CobbleverseConfig
    New-Item -ItemType Directory -Force -Path $script:DataDir | Out-Null
    Write-Host "=== COBBLEVERSE - DIRECCION FIJA PARA INTERNET ===" -ForegroundColor Green
    Write-Host "Usa DuckDNS + apertura automatica del puerto por UPnP." -ForegroundColor Cyan
    $open = Read-Host "Abrir duckdns.org para crear/ver tu dominio y token? [S/n]"
    if ([string]::IsNullOrWhiteSpace($open) -or $open -match '^[sS]') { Start-Process "https://www.duckdns.org" }
    $sub=(Read-Host "Subdominio (ej. mi-cobbleverse)").Trim() -replace '\.duckdns\.org$',''
    if ($sub -notmatch '^[A-Za-z0-9-]+$') { throw "Subdominio no valido." }
    $secure=Read-Host "Token DuckDNS" -AsSecureString
    $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {$token=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)} finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
    if ([string]::IsNullOrWhiteSpace($token)) { throw "Token vacio." }
    Set-Content $script:DuckDnsTokenFile $token.Trim() -Encoding ASCII -NoNewline
    & attrib +h $script:DuckDnsTokenFile 2>$null
    $internal=Get-MinecraftServerPort
    $txt=Read-Host "Puerto publico [Enter=$internal]"
    $external=$internal
    if (-not [string]::IsNullOrWhiteSpace($txt)) {$external=[int]$txt; if($external -lt 1 -or $external -gt 65535){throw "Puerto no valido."}}
    $script:Config.PublicAccessMode='duckdns-upnp'; $script:Config.DuckDnsSubdomain=$sub; $script:Config.ExternalPort=$external; $script:Config.AutoUpnp=$true; Save-CobbleverseConfig
    $null=Update-DuckDns
    Write-Host "DuckDNS OK: $sub.duckdns.org" -ForegroundColor Green
    $lan=Get-PreferredLanIPv4
    if ([string]::IsNullOrWhiteSpace([string]$lan)) {throw "No se detecta IP LAN."}
    $test=Enable-UpnpPortMapping -ExternalPort $external -InternalPort $internal -InternalClient $lan
    if ([bool]$test.success) {
        Write-Host "UPnP OK: TCP $external -> ${lan}:$internal" -ForegroundColor Green
        $internet=Get-PublicIPv4
        if (-not [string]::IsNullOrWhiteSpace([string]$test.routerExternalIp) -and -not [string]::IsNullOrWhiteSpace([string]$internet) -and [string]$test.routerExternalIp -ne [string]$internet) {
            Write-Host "POSIBLE CG-NAT/DOBLE NAT: la IP WAN del router no coincide con la IP publica." -ForegroundColor Yellow
            Write-Host "Si desde fuera no conecta, necesitaremos un tunel externo." -ForegroundColor Yellow
        }
        Disable-UpnpPortMapping -ExternalPort $external
    } else {
        Write-Host "UPnP NO DISPONIBLE: $($test.message)" -ForegroundColor Yellow
        Write-Host "Activalo en el router o usa un tunel si estas bajo CG-NAT." -ForegroundColor Yellow
    }
    try {
        $rule="Cobbleverse Minecraft TCP $internal"
        Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
        New-NetFirewallRule -DisplayName $rule -Direction Inbound -Action Allow -Protocol TCP -LocalPort $internal -Profile Any | Out-Null
        Write-Host "Firewall de Windows preparado para TCP $internal." -ForegroundColor Green
    } catch { Write-Host "No se pudo crear la regla del Firewall automaticamente." -ForegroundColor Yellow }
    Write-Host ""
    Write-Host "DIRECCION PARA TODOS: $sub.duckdns.org`:$external" -ForegroundColor Magenta
    Write-Host "Configura el segundo PC con EL MISMO subdominio y token." -ForegroundColor Cyan
} catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
