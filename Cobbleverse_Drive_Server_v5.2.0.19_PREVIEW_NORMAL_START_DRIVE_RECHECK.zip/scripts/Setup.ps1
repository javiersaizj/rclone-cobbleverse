﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
. (Join-Path $PSScriptRoot "DeltaSync.ps1")

function Download-And-ExtractZip {
    param(
        [string]$Url,
        [string]$DestinationDir,
        [string]$ExeName,
        [string]$SourceExePattern = $ExeName
    )

    New-Item -ItemType Directory -Force -Path $DestinationDir | Out-Null
    $tempZip = Join-Path $env:TEMP ([guid]::NewGuid().ToString("N") + ".zip")
    $tempDir = Join-Path $env:TEMP ([guid]::NewGuid().ToString("N"))
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $tempZip
        Expand-Archive -Path $tempZip -DestinationPath $tempDir -Force

        # Algunos proyectos (por ejemplo restic) incluyen la version en el nombre
        # del ejecutable dentro del ZIP. Buscamos primero el nombre final y despues
        # el patron de origen, y siempre lo copiamos con el nombre esperado.
        $exe = Get-ChildItem -Path $tempDir -Recurse -File |
            Where-Object { $_.Name -ieq $ExeName } |
            Select-Object -First 1

        if ($null -eq $exe -and -not [string]::IsNullOrWhiteSpace($SourceExePattern)) {
            $exe = Get-ChildItem -Path $tempDir -Recurse -File -Filter $SourceExePattern |
                Select-Object -First 1
        }

        if ($null -eq $exe) {
            $found = (Get-ChildItem -Path $tempDir -Recurse -File -Filter "*.exe" |
                Select-Object -ExpandProperty Name) -join ", "
            throw "No se encontro el ejecutable esperado dentro del ZIP. Ejecutables encontrados: $found"
        }

        Copy-Item $exe.FullName (Join-Path $DestinationDir $ExeName) -Force

        if (-not (Test-Path (Join-Path $DestinationDir $ExeName))) {
            throw "No se pudo instalar $ExeName en $DestinationDir"
        }
    }
    finally {
        Remove-Item $tempZip -Force -ErrorAction SilentlyContinue
        Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Ensure-Tools {
    New-Item -ItemType Directory -Force -Path $script:RcloneDir, $script:ResticDir, $script:DataDir | Out-Null
    if (-not (Test-Path $script:RcloneExe)) {
        Write-Host "Descargando rclone estable..."
        Download-And-ExtractZip -Url "https://downloads.rclone.org/rclone-current-windows-amd64.zip" -DestinationDir $script:RcloneDir -ExeName "rclone.exe"
    }
    if (-not (Test-Path $script:ResticExe)) {
        Write-Host "Descargando restic 0.19.1..."
        Download-And-ExtractZip -Url "https://github.com/restic/restic/releases/download/v0.19.1/restic_0.19.1_windows_amd64.zip" -DestinationDir $script:ResticDir -ExeName "restic.exe" -SourceExePattern "restic_*_windows_amd64.exe"
    }
}

function Refresh-ProcessEnvironment {
    try {
        $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
        $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
        $env:Path = (($machinePath, $userPath) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) -join ";"

        $machineJavaHome = [Environment]::GetEnvironmentVariable("JAVA_HOME", "Machine")
        $userJavaHome = [Environment]::GetEnvironmentVariable("JAVA_HOME", "User")
        if (-not [string]::IsNullOrWhiteSpace($machineJavaHome)) {
            $env:JAVA_HOME = $machineJavaHome
        }
        elseif (-not [string]::IsNullOrWhiteSpace($userJavaHome)) {
            $env:JAVA_HOME = $userJavaHome
        }
    }
    catch {}
}

function Test-Java21Candidate {
    param([string]$Candidate)
    if ([string]::IsNullOrWhiteSpace($Candidate)) { return $null }
    try {
        $expanded = [Environment]::ExpandEnvironmentVariables($Candidate.Trim('"'))
        if (-not (Test-Path $expanded)) { return $null }
        $resolved = (Resolve-Path $expanded -ErrorAction Stop).Path
        $major = Get-JavaMajorVersion -JavaExe $resolved
        if ($major -ge 21) { return $resolved }
    }
    catch { }
    return $null
}

function Find-Java21 {
    $candidates = New-Object System.Collections.Generic.List[string]

    # 1) Java guardado por una ejecucion anterior.
    try {
        if ($null -ne $script:Config -and -not [string]::IsNullOrWhiteSpace([string]$script:Config.JavaPath) -and [string]$script:Config.JavaPath -ne "java") {
            $candidates.Add([string]$script:Config.JavaPath)
        }
    } catch {}

    # 2) JAVA_HOME (proceso, maquina o usuario).
    $javaHomes = @(
        $env:JAVA_HOME,
        [Environment]::GetEnvironmentVariable("JAVA_HOME", "Machine"),
        [Environment]::GetEnvironmentVariable("JAVA_HOME", "User")
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
    foreach ($javaHomePath in $javaHomes) {
        $candidate = Join-Path $javaHomePath "bin\java.exe"
        if (Test-Path $candidate) { $candidates.Add($candidate) }
    }

    # 3) PATH actual.
    try {
        $cmd = Get-Command java.exe -ErrorAction SilentlyContinue
        if ($null -ne $cmd -and -not [string]::IsNullOrWhiteSpace($cmd.Source)) {
            $candidates.Add($cmd.Source)
        }
    } catch {}
    try {
        (& where.exe java.exe 2>$null) | ForEach-Object {
            if (-not [string]::IsNullOrWhiteSpace($_)) { $candidates.Add($_.Trim()) }
        }
    } catch {}

    # 4) Registro de programas instalados. Winget instala Temurin mediante MSI y
    # normalmente deja InstallLocation aunque PATH/JAVA_HOME no se hayan refrescado.
    $uninstallRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($regRoot in $uninstallRoots) {
        try {
            Get-ItemProperty $regRoot -ErrorAction SilentlyContinue |
                Where-Object { ([string]$_.DisplayName) -match '(?i)(Temurin|Adoptium|OpenJDK|JDK).*21|21.*(Temurin|Adoptium|OpenJDK|JDK)' } |
                ForEach-Object {
                    $loc = [string]$_.InstallLocation
                    if (-not [string]::IsNullOrWhiteSpace($loc)) {
                        $candidate = Join-Path $loc 'bin\java.exe'
                        if (Test-Path $candidate) { $candidates.Add($candidate) }
                    }
                }
        } catch {}
    }

    # 5) Directorios habituales. Incluye Temurin/Adoptium y otras distribuciones
    # por si el usuario ya tenia un Java 21 valido.
    $roots = @(
        "C:\Program Files\Eclipse Adoptium",
        "C:\Program Files\Java",
        "C:\Program Files\Microsoft",
        "C:\Program Files\BellSoft",
        "C:\Program Files\Zulu",
        "C:\Program Files\Amazon Corretto",
        (Join-Path $env:LOCALAPPDATA "Programs\Eclipse Adoptium"),
        (Join-Path $env:USERPROFILE ".jdks")
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and (Test-Path $_) } | Select-Object -Unique

    foreach ($root in $roots) {
        try {
            Get-ChildItem $root -Recurse -File -Filter java.exe -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -match '\\bin\\java\.exe$' } |
                ForEach-Object { $candidates.Add($_.FullName) }
        } catch {}
    }

    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        $valid = Test-Java21Candidate -Candidate $candidate
        if ($null -ne $valid) { return $valid }
    }
    return $null
}

function Ensure-Java21 {
    Refresh-ProcessEnvironment
    $java = Find-Java21
    if ($null -ne $java) {
        $script:Config.JavaPath = $java
        Save-CobbleverseConfig
        Write-Host "Java 21+ detectado: $java" -ForegroundColor Green
        return
    }

    Write-Host "Java 21 no se ha podido localizar automaticamente." -ForegroundColor Yellow
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($null -ne $winget) {
        $answer = Read-Host "Instalar/reparar Eclipse Temurin JDK 21 automaticamente con winget? [S/n]"
        if ([string]::IsNullOrWhiteSpace($answer) -or $answer -match '^[sS]') {
            & $winget.Source install -e --id EclipseAdoptium.Temurin.21.JDK --accept-package-agreements --accept-source-agreements
            $wingetExit = $LASTEXITCODE

            for ($i = 0; $i -lt 10; $i++) {
                Refresh-ProcessEnvironment
                $java = Find-Java21
                if ($null -ne $java) { break }
                Start-Sleep -Seconds 1
            }

            if ($null -ne $java) {
                $script:Config.JavaPath = $java
                Save-CobbleverseConfig
                Write-Host "Java instalado y detectado: $java" -ForegroundColor Green
                return
            }

            # Winget devuelve un codigo distinto de cero tambien cuando el paquete
            # ya esta instalado y no hay actualizaciones. No lo tratamos como prueba
            # de que Java falte; damos una ultima via manual.
            if ($wingetExit -ne 0) {
                Write-Host "winget devolvio el codigo $wingetExit. Puede significar simplemente que Java ya estaba instalado." -ForegroundColor Yellow
            }
        }
    }

    Refresh-ProcessEnvironment
    $java = Find-Java21
    if ($null -ne $java) {
        $script:Config.JavaPath = $java
        Save-CobbleverseConfig
        Write-Host "Java 21+ detectado: $java" -ForegroundColor Green
        return
    }

    Write-Host "" 
    Write-Host "Java parece estar instalado, pero Windows no ha proporcionado una ruta detectable." -ForegroundColor Yellow
    Write-Host "Ruta habitual de Temurin:" -ForegroundColor Cyan
    Write-Host "  C:\Program Files\Eclipse Adoptium\jdk-21...\bin\java.exe"
    $manual = Read-Host "Pega aqui la ruta completa a java.exe, o pulsa ENTER para cancelar"
    if (-not [string]::IsNullOrWhiteSpace($manual)) {
        $valid = Test-Java21Candidate -Candidate $manual
        if ($null -ne $valid) {
            $script:Config.JavaPath = $valid
            Save-CobbleverseConfig
            Write-Host "Java 21+ configurado manualmente: $valid" -ForegroundColor Green
            return
        }
        throw "La ruta indicada no existe o no corresponde a Java 21 o superior: $manual"
    }

    throw "No se pudo localizar Java 21. No es necesario reinstalarlo si ya esta instalado: indica manualmente la ruta a bin\java.exe cuando el instalador la solicite."
}

function Invoke-RcloneSetupSafe {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)

    # Windows PowerShell 5.1 puede convertir la salida stderr de programas nativos
    # en errores de PowerShell cuando $ErrorActionPreference = "Stop". Durante la
    # deteccion/configuracion de rclone necesitamos el codigo de salida real, no
    # que PowerShell aborte antes de poder tratarlo.
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        $output = & $script:RcloneExe @Arguments 2>$null
        $code = $LASTEXITCODE
        return [pscustomobject]@{
            ExitCode = $code
            Output = @($output)
        }
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }
}

function Get-RcloneRemoteNames {
    $result = Invoke-RcloneSetupSafe -Arguments @("listremotes", "--config", $script:RcloneConfig)
    if ($result.ExitCode -ne 0) { return @() }

    return @(
        $result.Output |
            ForEach-Object { ([string]$_).Trim() } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { $_.TrimEnd(':') }
    )
}

function Ensure-RcloneDrive {
    if (-not (Test-Path $script:RcloneConfig)) {
        New-Item -ItemType File -Path $script:RcloneConfig -Force | Out-Null
    }
    $env:RCLONE_CONFIG = $script:RcloneConfig

    $remoteName = [string]$script:Config.DriveRemote
    $remoteNames = @(Get-RcloneRemoteNames)
    $remoteExists = ($remoteNames -contains $remoteName)

    if (-not $remoteExists) {
        Write-Host ""
        Write-Host "Google Drive todavia NO esta vinculado a este paquete." -ForegroundColor Yellow
        Write-Host "Ahora se abrira el configurador oficial de rclone." -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Debes crear un remote llamado EXACTAMENTE: $remoteName" -ForegroundColor Green
        Write-Host "Selecciona Google Drive (drive) y autoriza tu cuenta en el navegador."
        Write-Host "Al terminar, conserva el remote y sal del configurador con q."
        Write-Host ""
        Write-Host "IMPORTANTE EN 2026:" -ForegroundColor Yellow
        Write-Host "Google/rclone estan retirando el client_id compartido de rclone." -ForegroundColor Yellow
        Write-Host "Si rclone te pide Client ID/Client Secret, usa un OAuth Client propio" -ForegroundColor Yellow
        Write-Host "para que esta configuracion siga funcionando a largo plazo." -ForegroundColor Yellow
        Write-Host "La guia incluida en el paquete explica los pasos." -ForegroundColor Yellow
        Write-Host ""
        Read-Host "Pulsa ENTER para abrir el configurador de rclone" | Out-Null

        $previousPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = "Continue"
            & $script:RcloneExe config --config $script:RcloneConfig
            $configExit = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $previousPreference
        }

        if ($configExit -ne 0) {
            throw "El configurador de rclone termino con codigo $configExit."
        }

        $remoteNames = @(Get-RcloneRemoteNames)
        $remoteExists = ($remoteNames -contains $remoteName)
        if (-not $remoteExists) {
            $shown = if ($remoteNames.Count -gt 0) { $remoteNames -join ", " } else { "ninguno" }
            throw "No se creo el remote '$remoteName'. Remotes encontrados: $shown. Ejecuta de nuevo el instalador y crea uno llamado exactamente '$remoteName'."
        }
    }

    Write-Host "Comprobando acceso a Google Drive '$remoteName'..." -ForegroundColor Cyan
    $test = Invoke-RcloneSetupSafe -Arguments @("lsd", "$remoteName`:", "--config", $script:RcloneConfig)
    if ($test.ExitCode -ne 0) {
        Write-Host "El perfil '$remoteName' existe, pero no se ha podido acceder a Google Drive." -ForegroundColor Yellow
        Write-Host "Se abrira rclone para que puedas reconectar o editar ese remote." -ForegroundColor Yellow

        $previousPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = "Continue"
            & $script:RcloneExe config --config $script:RcloneConfig
            $null = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $previousPreference
        }

        $test = Invoke-RcloneSetupSafe -Arguments @("lsd", "$remoteName`:", "--config", $script:RcloneConfig)
        if ($test.ExitCode -ne 0) {
            throw "El remote '$remoteName' existe pero sigue sin poder acceder a Google Drive. Revisa la autorizacion de la cuenta en rclone."
        }
    }

    Write-Host "Google Drive conectado correctamente como '$remoteName'." -ForegroundColor Green
}

function Ensure-HybridStorage {
    $env:RCLONE_CONFIG = $script:RcloneConfig
    Write-Host "Preparando carpetas ligeras del protocolo DELTA v4.2 en Drive..." -ForegroundColor Cyan
    $r1 = Invoke-RcloneSetupSafe -Arguments @("mkdir", $script:RemoteControl, "--config", $script:RcloneConfig)
    if ($r1.ExitCode -ne 0) { throw "No se pudo crear/verificar la carpeta de bloqueo en Drive." }
    $r2 = Invoke-RcloneSetupSafe -Arguments @("mkdir", $script:RemoteDeltaControl, "--config", $script:RcloneConfig)
    if ($r2.ExitCode -ne 0) { throw "No se pudo crear/verificar delta-v1/control en Drive." }
    $r3 = Invoke-RcloneSetupSafe -Arguments @("mkdir", $script:RemoteDeltaFiles, "--config", $script:RcloneConfig)
    if ($r3.ExitCode -ne 0) { throw "No se pudo crear/verificar delta-v1/overlay/files en Drive." }
    $r4 = Invoke-RcloneSetupSafe -Arguments @("mkdir", $script:RemoteDeltaClients, "--config", $script:RcloneConfig)
    if ($r4.ExitCode -ne 0) { throw "No se pudo crear/verificar delta-v1/clients en Drive." }

    Ensure-LocalBackupRepository

    $legacyRestic = Invoke-RcloneSetupSafe -Arguments @("lsf", $script:OldRemoteResticRepo, "--max-depth", "1", "--config", $script:RcloneConfig)
    if ($legacyRestic.ExitCode -eq 0 -and $legacyRestic.Output.Count -gt 0) {
        Write-Host ""
        Write-Host "AVISO: se detectan datos del antiguo restic REMOTO de v3.x." -ForegroundColor Yellow
        Write-Host "v4.2 no los necesita. Puedes usar 09_LIMPIAR_RESTIC_ANTIGUO_DE_DRIVE.bat cuando quieras recuperar espacio." -ForegroundColor Yellow
    }

    $legacyState = Invoke-RcloneSetupSafe -Arguments @("lsf", $script:RemoteState, "--max-depth", "1", "--config", $script:RcloneConfig)
    if ($legacyState.ExitCode -eq 0 -and $legacyState.Output.Count -gt 0) {
        Write-Host ""
        Write-Host "AVISO: se detecta CobbleverseSync/state de v4.0/v4.1." -ForegroundColor Yellow
        Write-Host "Puede contener la subida de ~9 GB que empezaste. v4.2 NO la usa." -ForegroundColor Yellow
        Write-Host "Tras crear la base v4.2 puedes ejecutar 10_LIMPIAR_ESTADO_V4_ANTIGUO_DRIVE.bat." -ForegroundColor Yellow
    }
}

try {
    Write-Host "=== COBBLEVERSE - INSTALACION Y CONFIGURACION v4.2 DELTAS ===" -ForegroundColor Green
    Ensure-Tools
    Load-CobbleverseConfig
    Ensure-Java21
    Ensure-RcloneDrive
    Ensure-HybridStorage
    Write-Host ""
    Write-Host "CONFIGURACION COMPLETADA." -ForegroundColor Green
    Write-Host "Drive actuara como BUS DE CAMBIOS: no necesita una copia completa del servidor." -ForegroundColor Cyan
    Write-Host "Primer PC: ejecuta 01_IMPORTAR_DESDE_HOSTING.bat y selecciona su CobbleverseShared."
    Write-Host "Segundo PC: ejecuta 08_PREPARAR_SEGUNDO_PC.bat y selecciona SU propia CobbleverseShared."
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
