Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'

. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'DeltaSync.ps1')
. (Join-Path $PSScriptRoot 'ModManagerCore.ps1')

Initialize-ModManagerEnvironment

try {
    Assert-ModManagerDriveReady
    $remote = Get-RemoteModManifest
    if ($null -eq $remote) {
        Write-Host 'AUTO-MODS: Drive todavía no tiene un modset gestionado. No hay nada que descargar.' -ForegroundColor DarkGray
        exit 0
    }

    $remoteHash = Get-ModManifestDigest $remote
    $local = Get-LocalModState
    $needsSync = $true

    if ($null -ne $local) {
        try {
            $needsSync = ([int64]$local.generation -ne [int64]$remote.generation) -or ([string]$local.manifestHash -ne [string]$remoteHash)
        }
        catch { $needsSync = $true }
    }

    if (-not $needsSync) {
        Write-Host ("AUTO-MODS: este PC ya tiene el modset G{0}." -f [int64]$remote.generation) -ForegroundColor Green
        try { Publish-ModClientState $remote } catch { Write-Warning ("No se pudo refrescar el ACK de mods del PC: {0}" -f $_.Exception.Message) }
        exit 0
    }

    if ($null -eq $local) {
        Write-Host ("AUTO-MODS: este PC aún no estaba inscrito. Aplicando automáticamente el modset G{0} desde Drive..." -f [int64]$remote.generation) -ForegroundColor Cyan
    }
    else {
        Write-Host ("AUTO-MODS: Drive tiene G{0} y este PC G{1}. Sincronizando cliente + servidor automáticamente..." -f [int64]$remote.generation,[int64]$local.generation) -ForegroundColor Cyan
    }

    $applied = Apply-RemoteModSet
    Write-Host ("AUTO-MODS: sincronización completada. Cliente y servidor local quedan en G{0}." -f [int64]$applied.generation) -ForegroundColor Green
    exit 0
}
catch {
    Write-Host ("AUTO-MODS ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 1
}
