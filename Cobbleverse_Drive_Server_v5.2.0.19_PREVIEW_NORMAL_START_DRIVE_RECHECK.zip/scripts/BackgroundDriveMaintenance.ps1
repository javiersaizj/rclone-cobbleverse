﻿param(
    [Parameter(Mandatory=$true)][string]$SessionId,
    [Parameter(Mandatory=$true)][int64]$ExpectedGeneration,
    [Parameter(Mandatory=$true)][string]$SnapshotManifestPath,
    [Parameter(Mandatory=$true)][int]$ServerPort,
    [Parameter(Mandatory=$true)][string]$StopPath,
    [Parameter(Mandatory=$true)][string]$StatePath,
    [Parameter(Mandatory=$true)][string]$LogPath,
    [int]$DelaySeconds = 5,
    [int]$StartupTimeoutSeconds = 180
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'DeltaSync.ps1')

function Write-MaintenanceLog {
    param([string]$Text)
    try {
        $line = ('{0} {1}' -f [DateTimeOffset]::Now.ToString('yyyy-MM-dd HH:mm:ss'),$Text)
        [IO.File]::AppendAllText($LogPath, $line + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
    } catch {}
}

function Write-MaintenanceState {
    param([string]$Status,[string]$Message='')
    try {
        $obj = [ordered]@{ status=$Status; message=$Message; sessionId=$SessionId; generation=$ExpectedGeneration; updatedUtc=[DateTimeOffset]::UtcNow.ToString('o') }
        [IO.File]::WriteAllText($StatePath, ($obj | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
    } catch {}
}

function Test-ServerPortListening {
    try {
        $rows = @(Get-NetTCPConnection -State Listen -LocalPort $ServerPort -ErrorAction Stop)
        return ($rows.Count -gt 0)
    }
    catch {
        try {
            $raw = & netstat.exe -ano -p TCP 2>$null
            foreach ($line in @($raw)) {
                if ([string]$line -match ('^\s*TCP\s+\S+:' + [regex]::Escape([string]$ServerPort) + '\s+\S+\s+LISTENING\s+\d+\s*$')) { return $true }
            }
        } catch {}
    }
    return $false
}

try {
    Initialize-CobbleverseEnvironment
    try { [Diagnostics.Process]::GetCurrentProcess().PriorityClass = [Diagnostics.ProcessPriorityClass]::BelowNormal } catch {}
    Remove-Item -LiteralPath $StatePath -Force -ErrorAction SilentlyContinue
    Write-MaintenanceState -Status 'waiting-for-server'
    Write-MaintenanceLog "Mantenimiento v4.9.2 preparado; esperando a que Minecraft escuche en TCP $ServerPort."

    # Cargar el snapshot AHORA, antes de que la sesion pueda terminar y borrar el fichero.
    $snapshot = Load-FastManifestData -Path $SnapshotManifestPath

    $deadline = [DateTime]::UtcNow.AddSeconds([Math]::Max(20,$StartupTimeoutSeconds))
    while ([DateTime]::UtcNow -lt $deadline) {
        if (Test-Path -LiteralPath $StopPath) {
            Write-MaintenanceState -Status 'cancelled' -Message 'Servidor cerrado antes de iniciar mantenimiento.'
            Write-MaintenanceLog 'Cancelado antes de comenzar.'
            exit 0
        }
        if (Test-ServerPortListening) { break }
        Start-Sleep -Milliseconds 1000
    }

    if (-not (Test-ServerPortListening)) {
        Write-MaintenanceState -Status 'skipped' -Message 'Minecraft no llego a escuchar antes del timeout.'
        Write-MaintenanceLog 'No se detecto el puerto del servidor; mantenimiento omitido.'
        exit 0
    }

    for ($i=0; $i -lt [Math]::Max(0,$DelaySeconds); $i++) {
        if (Test-Path -LiteralPath $StopPath) {
            Write-MaintenanceState -Status 'cancelled' -Message 'Servidor cerrado durante la espera inicial.'
            Write-MaintenanceLog 'Cancelado durante la espera inicial.'
            exit 0
        }
        Start-Sleep -Seconds 1
    }

    if (Test-Path -LiteralPath $StopPath) { exit 0 }
    Write-MaintenanceState -Status 'running'
    Write-MaintenanceLog 'Minecraft ya esta escuchando. Comienza compactacion remota en segundo plano.'
    $rebased = Try-AutoRebaseDelta -ExpectedGeneration $ExpectedGeneration -ExpectedSessionId $SessionId -SnapshotManifest $snapshot
    if ($rebased) {
        Write-MaintenanceState -Status 'completed' -Message 'Compactacion realizada.'
        Write-MaintenanceLog 'Compactacion completada.'
    }
    else {
        Write-MaintenanceState -Status 'completed-noop' -Message 'No habia nada que compactar o los dos clientes aun no estaban sincronizados.'
        Write-MaintenanceLog 'Sin compactacion necesaria.'
    }
}
catch {
    Write-MaintenanceState -Status 'failed' -Message $_.Exception.Message
    Write-MaintenanceLog ("ERROR: " + $_.Exception.Message)
    exit 2
}
