﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Common.ps1")
try {
    Initialize-CobbleverseEnvironment
    Write-Host "=== MANTENIMIENTO DE BACKUPS LOCALES ===" -ForegroundColor Green
    Write-Host ("Conserva: ultimos {0}, {1} diarios y {2} semanales. Despues libera espacio LOCAL." -f $script:Config.LocalKeepLast,$script:Config.LocalKeepDaily,$script:Config.LocalKeepWeekly) -ForegroundColor Cyan
    $answer=Read-Host "Escribe MANTENIMIENTO para continuar"
    if ($answer -cne 'MANTENIMIENTO') { throw "Cancelado." }
    Invoke-Restic -Arguments @("forget","--host",$env:COMPUTERNAME,"--keep-last",[string]$script:Config.LocalKeepLast,"--keep-daily",[string]$script:Config.LocalKeepDaily,"--keep-weekly",[string]$script:Config.LocalKeepWeekly,"--prune") | Out-Null
    Write-Host "Mantenimiento local completado." -ForegroundColor Green
}
catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
