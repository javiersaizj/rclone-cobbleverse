# Optimización v4.9: preescaneo suave mientras el servidor está online

La v4.9 conserva el transporte rápido de v4.8 (un ZIP por generación) y reduce el trabajo al cerrar.

## Cómo funciona

1. Antes de iniciar Java se toma el manifiesto de metadatos inicial, igual que antes.
2. Se inicia `scripts/ChangeTracker.ps1` en un proceso separado con prioridad **BelowNormal**.
3. `FileSystemWatcher` registra rutas modificadas, creadas, borradas o renombradas prácticamente sin leer el disco.
4. Como red de seguridad, el tracker inspecciona por defecto **una carpeta cada 3 segundos** y compara solo tamaño/fecha. No lee el contenido de los archivos.
5. Al cerrar Minecraft, el tracker recibe 750 ms para recoger los últimos eventos de guardado.
6. Si el tracker está sano, la comprobación final consulta únicamente los archivos candidatos y reconstruye el manifiesto final en memoria.
7. Si existe cualquier duda (overflow del watcher, fallo del tracker, determinadas operaciones de directorio), se usa automáticamente el escaneo completo de v4.8.

Por tanto, la optimización nunca sustituye la ruta segura: solo evita el escaneo completo cuando el sistema de seguimiento puede garantizar que no perdió eventos.

## Ajustes

En `config.json` pueden aparecer:

```json
"BackgroundChangeTracking": true,
"BackgroundSweepIntervalMs": 3000,
"BackgroundSweepDirectoriesPerCycle": 1
```

Los valores por defecto están pensados para afectar lo mínimo posible al servidor. Con unas 400 carpetas, un barrido completo suave tarda aproximadamente 10 minutos, pero el watcher registra los cambios al instante durante todo ese tiempo.
