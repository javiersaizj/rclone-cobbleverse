﻿# Cobbleverse Server Manager — código fuente v4.7

Este proyecto es la versión editable del launcher/gestor. La interfaz está hecha con **Windows PowerShell 5.1 + WinForms**. El `.exe` generado es únicamente un launcher pequeño que abre `scripts/ServerManagerGUI.ps1`; la lógica real permanece en los `.ps1`.

## Archivos principales

- `scripts/ServerManagerGUI.ps1` — **interfaz gráfica completa**. Aquí cambias botones, textos, colores, tamaños, LEDs, paneles, ventanas, campos de IP, logs, etc.
- `scripts/StartServer.ps1` — flujo de arranque/apagado del servidor: bloqueo, descarga de cambios, Java, detección de cambios, subida y liberación.
- `scripts/DeltaSync.ps1` — protocolo delta entre PCs y Drive.
- `scripts/Common.ps1` — funciones comunes: configuración, rclone, locks, IP, paths, utilidades.
- `scripts/BuildLauncher.ps1` — genera `Cobbleverse Server Manager.exe` con el icono del proyecto.
- `scripts/ImportHosting.ps1` — vinculación de la copia descargada del hosting.
- `scripts/ExportSecondPC.ps1` — preparación/vinculación del segundo PC.
- `scripts/BackupNow.ps1`, `Rollback.ps1`, `ListSnapshots.ps1`, `Maintenance.ps1` — backups y mantenimiento.
- `assets/cobbleverse.ico` — icono del ejecutable.
- `assets/cobbleverse-logo.png` — logo mostrado en la GUI.

## Probar cambios sin recompilar nada

Ejecuta:

```bat
DEV_INICIAR_GUI.bat
```

Esto abre directamente `ServerManagerGUI.ps1`. Es la forma más cómoda de modificar la interfaz: guardas el `.ps1`, cierras/reabres la GUI y ves el cambio.

## Crear de nuevo el EXE con el icono

Con la GUI cerrada, ejecuta:

```bat
12_CREAR_EJECUTABLE_GUI.bat
```

Generará:

```text
Cobbleverse Server Manager.exe
```

El EXE **no contiene todo el programa dentro**: sigue necesitando la carpeta `scripts` junto a él. Esto permite que puedas seguir modificando los `.ps1` sin recompilar todo el proyecto.

## Dónde tocar la interfaz

En `scripts/ServerManagerGUI.ps1` busca estas funciones/nombres:

- `Set-LedState` — LEDs "este PC / otro PC / offline".
- `Set-OnlineSummaryLed` — LED rojo/verde resumen.
- `Update-StatusUi` — actualización de estado, PC activo y conexión.
- `Start-ServerFromGui` — botón Iniciar servidor.
- `Stop-ServerFromGui` — botón Apagar servidor.
- `Start-MaintenanceTask` — ejecución de herramientas/backups.
- `Open-ServerFolder` — abrir carpeta del servidor.
- `$form = New-Object System.Windows.Forms.Form` — creación de la ventana principal.
- `$toolsForm` — ventana independiente de herramientas/backups.
- `$statusPanel` — panel de estado.
- `$script:btnStart`, `$script:btnStop` — botones principales.
- `$script:cmbConnection` / `$script:btnCopyConnection` — dirección/IP copiable.

Los controles WinForms usan propiedades típicas:

```powershell
$control.Location = New-Object System.Drawing.Point(100,50)
$control.Size = New-Object System.Drawing.Size(160,35)
$control.Text = 'Texto'
$control.BackColor = [System.Drawing.Color]::Red
$control.Font = New-Object System.Drawing.Font('Segoe UI',10)
```

## Configuración real del servidor

Este ZIP **no contiene** `config.json`, `data/rclone.conf`, tokens de DuckDNS ni contraseñas. No conviene meterlos en un proyecto que puedas compartir.

Para usar el código contra tu instalación actual, tienes dos opciones:

1. Editar directamente los `.ps1` de tu instalación actual.
2. Copiar localmente (sin compartir) desde tu instalación funcional:
   - `config.json`
   - `data/rclone.conf`
   - los demás ficheros privados de `data` que necesites.

Nunca subas esos archivos a GitHub ni los envíes a otras personas.

## Flujo recomendado para desarrollar

1. Haz una copia de la instalación que funciona.
2. Edita `scripts/ServerManagerGUI.ps1` en VS Code o cualquier editor.
3. Prueba con `DEV_INICIAR_GUI.bat`.
4. Cuando estés conforme, ejecuta `12_CREAR_EJECUTABLE_GUI.bat` para refrescar el EXE/icono.
5. Para cambios en sincronización, toca `StartServer.ps1` / `DeltaSync.ps1` con más cuidado porque afectan al mundo y a Drive.

## Nota sobre versiones

La GUI se apoya en el backend delta v4.3/v4.x. Cambiar elementos visuales normalmente solo requiere `ServerManagerGUI.ps1`; no hace falta tocar la sincronización.

## v4.9 - seguimiento de cambios en segundo plano

- `scripts/ChangeTracker.ps1`: watcher + barrido suave de metadatos.
- `scripts/StartServer.ps1`: inicia/detiene el tracker y decide entre validación incremental o fallback completo.
- `scripts/DeltaSync.ps1`: `Get-FastManifestDataFromCandidates` reconstruye el manifiesto final consultando solo los candidatos.
- Si el tracker no es fiable, el comportamiento vuelve automáticamente al escaneo completo anterior.


## v4.9.1 - validación híbrida final

- `ChangeTracker.ps1` guarda `change-tracker-final-dirs.txt` con las carpetas pendientes del ciclo suave actual.
- `DeltaSync.ps1` añade `Get-FastManifestDataHybridFinal`: aplica candidatos y después inspecciona solo esas carpetas pendientes.
- `StartServer.ps1` exige que el recuento de carpetas pendientes coincida con el estado del tracker; si no, hace fallback completo.
- Cualquier carpeta nueva o situación delicada de directorios fuerza escaneo completo por seguridad.


## v4.9.3 - Fast Start

`BackgroundDriveMaintenance.ps1` espera al puerto Minecraft y ejecuta el rebase remoto fuera del camino critico. `Apply-RemoteDeltaChanges` acepta baseline/current prefetched para evitar llamadas repetidas. El snapshot usado por el rebase es el manifiesto anterior al arranque de Java.


## Editor visual v4.9.4
El diseño personalizado de la ventana principal se guarda en `data/ui-layout.json`. La GUI lo carga al abrirse. Borrar ese archivo devuelve el diseño automático por defecto en el siguiente inicio.
