﻿# Cobbleverse Server Manager 5.1 PREVIEW — Gestor de Mods

Esta versión parte de la rama validada 5.0.8. El protocolo del mundo no se ha cambiado: `/mods/**` continúa excluido del delta del mundo. El gestor usa un canal separado en Drive: `CobbleverseSync/mod-manager-v1/`.

## Flujo recomendado

1. Instala/importa el modpack inicial con CurseForge como hasta ahora.
2. Comprueba que el cliente y el servidor funcionan.
3. En `Centro 5.0 -> Mods`, abre el Gestor de Mods.
4. En `PCs / servidor`, pulsa `Adoptar pack actual` en el PC que tiene la instalación correcta. Esto publica el manifiesto y almacena los JAR por hash en Drive.
5. En el segundo PC, abre el gestor y pulsa `Sincronizar desde Drive`. Quedarán sincronizados los mods del cliente CurseForge y los del servidor local, con los mismos hashes/versiones.

## Funciones

- Escaneo de `mods` del cliente CurseForge y del servidor.
- Lectura de metadatos Fabric/Quilt y básica Forge/NeoForge desde los JAR.
- Detección de versiones distintas cliente/servidor, IDs duplicados, dependencias declaradas ausentes e incompatibilidades declaradas.
- Búsqueda online de mods compatibles mediante la API pública de Modrinth, filtrada por versión de Minecraft y loader.
- Instalación de un mod y resolución automática de dependencias obligatorias disponibles en Modrinth.
- Identificación por hash de mods existentes que también estén publicados en Modrinth.
- Búsqueda y actualización individual o masiva de versiones compatibles identificadas.
- Importación manual de un JAR para mods que no estén en Modrinth.
- Desinstalación de un mod seleccionado.
- Distribución por Drive con manifiesto versionado y paquetes por SHA-256.
- Transacción de rollback antes de cada cambio que vaya a sustituir/eliminar JARs.
- Análisis heurístico de `crash-reports` y `latest.log` para señalar mods mencionados en el fallo.

## Compatibilidad

La validación automática reduce mucho el riesgo, pero no puede demostrar que dos mods funcionarán juntos en ejecución. Se comprueban versión de Minecraft, loader, entorno cliente/servidor, dependencias conocidas, hashes y metadatos declarados. Los conflictos de mixins, bugs internos o incompatibilidades no declaradas solo pueden aparecer al ejecutar Minecraft/servidor. Por eso cada cambio crea rollback.

## CurseForge y Modrinth

CurseForge sigue sirviendo para descargar/importar el modpack inicial y para lanzar el cliente. Después, el gestor trata los JAR instalados como un modset propio. Para búsqueda y actualización automática se usa Modrinth porque su API pública permite filtrar por Minecraft/loader, consultar dependencias y verificar archivos por hash sin una API key. Los mods exclusivos de CurseForge se pueden mantener/importar mediante JAR manual; esta preview no necesita ni guarda una clave de CurseForge.

## Seguridad

- No modifica el sistema `delta-v1` del mundo.
- El mundo y los mods tienen canales de Drive separados.
- No permite modificar mods si detecta un bloqueo de servidor activo.
- `manifest.json` del gestor de mods es el commit del modset compartido.
- La huella estática ya existente se actualiza al publicar cambios, por lo que un PC con mods de servidor antiguos no debería poder arrancar el mismo mundo sin ponerse al día.
- Antes de aplicar un modset se guardan únicamente los JAR que van a sustituirse/eliminarse y la lista de archivos nuevos, evitando duplicar el pack entero en cada rollback.

## Limpieza automática de Drive

Esta 5.1.0 incluye limpieza segura para evitar que Cobbleverse vuelva a llenar la papelera de Google Drive.

- `delta-v1`: cuando los dos PCs están confirmados en la misma generación, la compactación elimina `bundles/`, `generations/` y datos antiguos con `--drive-use-trash=false`.
- `mod-manager-v1`: cada PC publica su generación y el hash del manifiesto. Solo cuando al menos dos clientes confirman exactamente el modset actual se eliminan de `packages/` los JAR por SHA-256 que ya no están referenciados.
- Si un PC está atrasado, la limpieza no borra sus paquetes necesarios.
- La aplicación no ejecuta `rclone cleanup`, porque eso podría vaciar la papelera completa de la cuenta de Google Drive. Solo elimina rutas propias bajo `CobbleverseSync`.

## Hotfix de arranque del Gestor de Mods

- El gestor usa un inicializador propio y ya no inicializa Restic solo para abrir la ventana.
- El launcher fuerza PowerShell STA para WinForms.
- Si el arranque falla, muestra el error y lo guarda en `data\mod-manager-startup-error.log`.
- El botón del Centro 5.0 lanza el gestor sin dejar una consola fugaz.


## v5.2.0 - TEST masivo seguro

La pestaña **TEST masivo** crea un entorno completamente local para probar una actualización global antes de tocar el pack real.

1. **Crear / reconstruir TEST**: identifica por hash los mods presentes en cliente/servidor, busca en Modrinth versiones compatibles con la versión de Minecraft indicada y resuelve dependencias obligatorias. Los mods no encontrados se conservan tal cual.
2. Se crea una carpeta de servidor independiente (`<ServerPath>__MOD_TEST`) con una **copia del mundo actual**. El mundo de prueba no usa el protocolo delta ni se sube a Drive.
3. **Activar cliente TEST** intercambia temporalmente `mods`, `config` y `defaultconfigs` del cliente, conservando el pack normal en carpetas de respaldo.
4. **Iniciar servidor TEST** arranca la copia del mundo en un puerto diferente. Para cerrarlo correctamente hay que escribir `stop`.
5. **Volver cliente a NORMAL** restaura exactamente el cliente anterior.
6. **Promover TEST a NORMAL** copia únicamente mods/config validados al pack normal y publica el modset. **Nunca sustituye el mundo normal por el mundo TEST.**
7. La copia anterior de mods/config se conserva hasta pulsar expresamente **Borrar copia anterior**.

La creación del entorno TEST puede ocupar varios GB porque la copia del mundo es deliberadamente independiente para evitar cualquier corrupción del mundo real.
