﻿# Cobbleverse Server Manager 5.0 PREVIEW

Esta versión conserva el protocolo delta/outbox de la rama 4.9.9 Performance y añade módulos funcionales de forma acumulativa.

## Seguridad y rollback

- No borra `config.json`, `data\`, `rclone.conf`, `ui-layout.json` ni las generaciones locales al actualizar.
- Los paquetes 4.9.10–4.9.19 incluidos en el Rollback Pack usan el mismo núcleo y habilitan las funciones progresivamente según `VERSION.txt`.
- Si 5.0 da problemas, con el servidor apagado y sincronizado se puede volver a la 4.9.x elegida sobrescribiendo scripts/recursos y conservando `config.json` y `data\`.

## Funciones 5.0

Historial de generaciones, salud del servidor, backups visuales, red, administración de jugadores locales, mantenimiento compartido, comparación de mods, watchdog, checkpoints catch-up, automatizaciones, diagnóstico, updater desde ZIP, preflight, uso de Drive, plan de actualización, verificación profunda de integridad, perfiles UI e historial de rendimiento.

`DiscordWebhookUrl` y `BackupBeforeSession` existen en config y están desactivados por defecto.


## 5.0.5 PREVIEW
Corrige una colisión con la variable automática `$HOME` de Windows PowerShell que impedía crear la pestaña Inicio de Centro 5.0.


## Botón Jugar (5.0.6)

La cabecera incluye `Jugar`. El manager detecta la instancia cliente bajo `%USERPROFILE%\curseforge\minecraft\Instances\COBBLEVERSE - Pokemon Adventure [Cobblemon]` y busca un acceso directo de lanzamiento de Cobbleverse en el Escritorio. La carpeta de la instancia no es por sí sola un lanzador. Si CurseForge todavía no ha creado el acceso directo del perfil, hay que crearlo una sola vez; después el manager puede abrirlo con un clic sin navegar por CurseForge. Se puede forzar otro acceso directo con `MinecraftPlayShortcut` en `config.json`.
