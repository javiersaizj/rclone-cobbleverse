@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === CREAR EJECUTABLE COBBLEVERSE SERVER MANAGER ===
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\BuildLauncher.ps1"
echo.
pause
