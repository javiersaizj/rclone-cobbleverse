# Hotfix v5.2.0.19

Corrige el bloqueo del botón **Iniciar servidor** cuando la consulta en segundo plano de Drive queda en estado `unknown`.

La GUI permite intentar el arranque, pero la seguridad real sigue en `StartServer.ps1`: antes de lanzar Java vuelve a leer Drive, verifica la generación y adquiere el bloqueo compartido. Si no puede hacerlo, aborta antes de Java.
