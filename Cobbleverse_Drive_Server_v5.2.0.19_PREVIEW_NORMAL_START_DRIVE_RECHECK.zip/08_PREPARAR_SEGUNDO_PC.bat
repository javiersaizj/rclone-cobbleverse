@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Cobbleverse - Preparar segundo PC desde hosting
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\ExportSecondPC.ps1"
echo.
pause
