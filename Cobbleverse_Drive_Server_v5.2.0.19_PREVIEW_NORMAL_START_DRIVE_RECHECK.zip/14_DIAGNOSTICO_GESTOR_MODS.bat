@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===============================================================
echo  COBBLEVERSE - DIAGNOSTICO GESTOR DE MODS
 echo ===============================================================
echo.
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -NoExit -File "%~dp0scripts\LaunchModManager.ps1"
