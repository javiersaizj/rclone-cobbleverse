﻿COBBLEVERSE COMPARTIDO v4.2 - DELTAS RAPIDOS
============================================

OBJETIVO
--------
Los dos PCs tienen por separado la MISMA copia completa descargada del hosting.
No se suben ~10 GB a Google Drive. Drive se usa como intermediario para:
  - server-lock.json: saber que PC tiene el servidor y mostrar IP/dominio/puerto.
  - current/index: saber que version tiene cada PC.
  - overlay/files: SOLO la ultima version de archivos que han cambiado.

PC1 y PC2 pueden tener rutas distintas, por ejemplo:
  PC1: A:\CobbleverseShared
  PC2: D:\Servers\CobbleverseShared
Cada uno guarda su ruta en su propio config.json.

PRIMERA CONFIGURACION
---------------------
PC1:
  1) 00_INSTALAR_Y_CONFIGURAR.bat
  2) 01_IMPORTAR_DESDE_HOSTING.bat
  3) Selecciona su carpeta ya descargada del hosting.

PC2:
  1) 00_INSTALAR_Y_CONFIGURAR.bat
  2) 08_PREPARAR_SEGUNDO_PC.bat
  3) Selecciona SU propia copia de la misma descarga del hosting.

La comprobacion inicial usa ruta+tamano para crear una huella rapida. Lee metadatos,
NO sube ni hashea los ~10 GB de contenido.

USO DIARIO
----------
En cualquiera de los dos PCs:
  02_INICIAR_COBBLEVERSE.bat

Al arrancar:
  1) Mira el flag/bloqueo pequeno de Drive.
  2) Si otro PC esta ejecutando el servidor, muestra el PC y las IP/direcciones.
  3) Si esta libre, comprueba la generacion remota.
  4) Solo descarga los ficheros que hayan cambiado desde la ultima generacion local.
  5) Lee METADATOS locales de los archivos para recordar el estado de inicio.
  6) Arranca Java/Fabric desde la carpeta CobbleverseShared configurada.

Al escribir stop:
  1) Java termina.
  2) Se vuelven a leer METADATOS locales (ruta, tamano, LastWriteTime).
  3) Se obtiene la lista exacta de archivos nuevos/modificados/borrados.
  4) rclone sube SOLO los nuevos/modificados.
  5) Se actualiza un indice JSON pequeno y la generacion.
  6) Se libera el bloqueo para el otro PC.

IMPORTANTE: recorrer ~9.000 entradas de directorio NO equivale a leer 10 GB. En un disco
normal deberia tardar segundos, no minutos. No se hace un rclone sync completo contra Drive.

COMPACTACION / ESPACIO DRIVE
----------------------------
Drive mantiene un OVERLAY con la ultima copia de cada archivo que ha cambiado desde la
ultima base comun. Si ambos PCs llegan a la misma generacion, v4.2 puede hacer una "rebase":
ambos ya tienen todos los datos, por lo que borra el overlay de Drive y declara ese estado
como nueva base. NO vuelve a subir el servidor completo.

Por esto Drive actua como BUS DE SINCRONIZACION, NO como backup completo.
Si un PC pierde totalmente su disco despues de una rebase, necesitaras el otro PC o un
backup local para reconstruirlo.

BACKUPS
-------
Los backups restic son LOCALES. No consumen Drive.
Por velocidad, AutoLocalBackupAfterSession viene desactivado por defecto.
Puedes crear uno manualmente con:
  11_CREAR_BACKUP_LOCAL_AHORA.bat
Y verlos/restaurarlos con 03/04.

RESTOS DE v4.0/v4.1
-------------------
Si empezaste la subida de ~9 GB a CobbleverseSync/state, v4.2 NO la usa.
Despues de crear correctamente la base v4.2 puedes ejecutar:
  10_LIMPIAR_ESTADO_V4_ANTIGUO_DRIVE.bat
para recuperar ese espacio.

NO BORRES EL HOSTING TODAVIA
----------------------------
Primero prueba mundo, inventarios, Pokemon, permisos y conexiones desde ambos PCs.
