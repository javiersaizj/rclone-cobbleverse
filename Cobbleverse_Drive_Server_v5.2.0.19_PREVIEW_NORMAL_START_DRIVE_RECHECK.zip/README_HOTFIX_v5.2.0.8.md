# Cobbleverse v5.2.0.8

Correcciones:
- Elimina las asignaciones locales a `$PID` en `ModTestCore.ps1`; `$PID` es una variable automática de solo lectura en Windows PowerShell.
- El selector de Modrinth pide la lista completa de versiones del proyecto y filtra localmente por Minecraft y loader, eligiendo la release compatible más reciente por `date_published`.
- Mantiene la sincronización automática de mods entre PCs y el entorno TEST aislado.
