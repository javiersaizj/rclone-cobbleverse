﻿# Hotfix v5.2.0.18

Este hotfix separa por completo el cliente TEST del perfil NORMAL.

Perfil esperado:
- CurseForge: `New Cobbleverse`
- Minecraft: `1.21.1`
- Fabric Loader: `0.19.5` o posterior

Compatibilidad aplicada al TEST:
- Cobblemon 1.8.1 se mantiene.
- Better Pokédex Scanner 1.0.0 se excluye solo del TEST.
- Reese's Sodium Options se excluye temporalmente del TEST.
- Sodium 0.6.13 se usa con Iris 1.8.8.
- Dependencias obligatorias como Lithostitched se propagan al cliente cuando el mod padre también carga en cliente.
- El servidor TEST usa Fabric Loader 0.19.5 sin cambiar el servidor NORMAL.

Cierra Minecraft y CurseForge antes de activar/sincronizar el perfil TEST.

La promoción a NORMAL se bloquea si el gestor detecta un Fabric Loader NORMAL anterior a 0.19.5.
