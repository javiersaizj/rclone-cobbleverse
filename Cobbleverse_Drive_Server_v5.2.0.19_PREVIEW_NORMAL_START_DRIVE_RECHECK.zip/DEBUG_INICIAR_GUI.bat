﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === COBBLEVERSE 5.0.2 - ARRANQUE DE DIAGNOSTICO ===
echo Si la GUI falla al abrir, deja esta ventana abierta y copia el error mostrado.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -NoExit -File "%~dp0scripts\ServerManagerGUI.ps1"
