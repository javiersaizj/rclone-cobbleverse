BOTÓN JUGAR - v5.0.6 PREVIEW

El botón Jugar busca automáticamente un acceso directo de lanzamiento de COBBLEVERSE en el Escritorio del usuario actual.

Instancia cliente por defecto:
%USERPROFILE%\curseforge\minecraft\Instances\COBBLEVERSE - Pokemon Adventure [Cobblemon]

Ejemplo:
C:\Users\javie\curseforge\minecraft\Instances\COBBLEVERSE - Pokemon Adventure [Cobblemon]

IMPORTANTE:
La carpeta de la instancia contiene mods/configuración, pero no es por sí sola un ejecutable de Minecraft.
Para lanzamiento de un clic, CurseForge debe haber creado previamente el acceso directo del perfil. Si usas "Use CurseForge launcher", el acceso directo puede lanzar el perfil sin tener que navegar manualmente por CurseForge/Minecraft Launcher.

Si el acceso directo tiene un nombre que incluye COBBLEVERSE, el manager lo detecta automáticamente.
También puede fijarse manualmente en config.json:
"MinecraftPlayShortcut": "%USERPROFILE%\\Desktop\\COBBLEVERSE.lnk"
