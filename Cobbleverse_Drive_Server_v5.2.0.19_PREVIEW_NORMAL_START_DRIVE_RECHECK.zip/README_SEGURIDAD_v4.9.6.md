﻿# v4.9.6 - Seguridad ante cortes de Internet y apagados

## Qué protege

- Los cambios de una sesión se empaquetan primero en `data\pending-sync` y quedan marcados READY localmente.
- Drive no anuncia una generación nueva hasta que `current.json` se escribe al final.
- Si la subida falla, el paquete local se conserva y se reintenta.
- Al volver a abrir la aplicación, `RetryPendingSync.ps1` recupera automáticamente paquetes pendientes o una sesión interrumpida.
- Las descargas se aplican mediante un archivo temporal en la misma carpeta y sustitución al final, evitando dejar medio archivo por una caída durante la extracción.
- Si Drive ya avanzó por otra rama, no se sobrescribe automáticamente: se detiene con conflicto seguro.
- Un lock sin heartbeat NO habilita automáticamente el otro PC; se debe confirmar/forzar de forma consciente.

## Límite importante

Esta versión protege el protocolo de sincronización. Un corte eléctrico exactamente mientras **Minecraft/Java está escribiendo físicamente un archivo del mundo** puede dañar ese propio archivo antes de que el manager pueda intervenir. Ningún sistema de Drive puede garantizar lo contrario. Los backups locales siguen siendo la capa de recuperación para ese caso.
