@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0scripts\LaunchModManager.ps1"
if errorlevel 1 (
    echo.
    echo El Gestor de Mods no pudo iniciarse. Revisa data\mod-manager-startup-error.log
    pause
)
