JUGAR EN UN CLIC - v5.0.8

1. El acceso directo del perfil COBBLEVERSE debe existir (solo hace falta crearlo una vez desde CurseForge).
2. Pulsa Jugar en Cobbleverse Server Manager.
3. El manager abre el acceso directo, espera a CurseForge, localiza COBBLEVERSE y pulsa Play automaticamente.
4. CurseForge se minimiza despues del click.

Si usas el launcher oficial de Minecraft y este te pide un segundo Play adicional, puedes activar en CurseForge Settings > Minecraft la opcion Use CurseForge launcher para omitir el launcher oficial.
