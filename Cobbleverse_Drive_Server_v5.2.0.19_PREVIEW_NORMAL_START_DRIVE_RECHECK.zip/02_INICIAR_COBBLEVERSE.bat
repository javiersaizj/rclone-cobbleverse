@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist "%~dp0Cobbleverse Server Manager.exe" (
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\BuildLauncher.ps1" >nul 2>&1
)

if exist "%~dp0Cobbleverse Server Manager.exe" (
    start "" "%~dp0Cobbleverse Server Manager.exe"
    exit /b 0
)

rem Fallback: si Windows no permite compilar el launcher, la GUI sigue funcionando como antes.
start "" powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0scripts\ServerManagerGUI.ps1"
exit /b
