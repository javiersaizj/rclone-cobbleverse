# HOTFIX v5.2.0.16

Corrige el fallo por el que Modrinth devolvía correctamente muchas versiones pero Windows PowerShell 5.1 propagaba la colección completa al planificador. Ahora el selector aplana la respuesta y entrega exactamente un objeto de versión. También evita que una respuesta sin `dependencies` aborte el TEST bajo StrictMode.

Aplicar con Minecraft, CurseForge y Server Manager cerrados. Después: Volver a NORMAL -> Crear / reconstruir TEST.
