# v4.9.2: arranque mas rapido

La v4.9.2 mueve fuera del camino critico la compactacion de Drive. El servidor aplica primero cualquier generacion pendiente y captura su manifiesto inicial. A continuacion arranca Java; un proceso de mantenimiento separado espera a que el puerto Minecraft este escuchando y solo entonces comprueba si ambos PCs estan en la misma generacion y puede limpiar bundles antiguos.

La compactacion utiliza el manifiesto previo al arranque para calcular la huella de la nueva base. No escanea el mundo mientras Minecraft lo modifica. Si el servidor se cierra mientras la compactacion esta ejecutandose, el proceso principal espera a que esa operacion termine antes de publicar la siguiente generacion.

Tambien se reutilizan `baseline.json` y `current.json` que ya se consultaron al comienzo al aplicar deltas, evitando dos lecturas remotas redundantes. La descarga sigue siendo un ZIP por generacion pendiente y la subida sigue siendo un ZIP por sesion.

Se mantienen el lock remoto, la recuperacion de sesiones, el preescaneo suave y la validacion hibrida conservadora de v4.9.1.
