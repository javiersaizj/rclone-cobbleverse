# Cobbleverse v5.2.0.9 PREVIEW

- Selector Modrinth reforzado con consulta doble y selección local por fecha.
- Cobblemon 1.8.1 Fabric para Minecraft 1.21.1 (versionId gBW3vLC7) actúa como suelo conocido, sin impedir versiones posteriores.
- Validación física SHA-1: un mod raíz actualizado nunca puede ser sustituido de nuevo por el JAR NORMAL antiguo.
- Si el JAR final no coincide exactamente con el seleccionado, la construcción TEST se cancela.
- `17_DIAGNOSTICO_COBBLEMON_TEST.bat` muestra la versión real del JAR de Cobblemon que quedó en cliente y servidor TEST.
