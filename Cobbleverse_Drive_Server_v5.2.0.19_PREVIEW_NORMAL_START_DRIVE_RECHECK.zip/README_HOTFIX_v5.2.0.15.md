# HOTFIX v5.2.0.15

Corrige el fallo visto en `worker.log` después de seleccionar correctamente Cobblemon 1.8.1:

`No existe una versión de P7dR8mSH compatible con Minecraft 1.21.1 / fabric.`

`P7dR8mSH` es Fabric API. El error estaba en cómo Windows PowerShell 5.1 entregaba la colección superior de `ConvertFrom-Json`, no en la compatibilidad real de Fabric API.

Cambios:
- captura determinista de arrays JSON con `@(...)`;
- fallback a catálogo completo si la consulta filtrada no produce candidato;
- fallback adicional por slug oficial del proyecto;
- selección de una única release más reciente compatible;
- mantiene las comprobaciones físicas y evita reconstrucciones silenciosas con JAR antiguos.
