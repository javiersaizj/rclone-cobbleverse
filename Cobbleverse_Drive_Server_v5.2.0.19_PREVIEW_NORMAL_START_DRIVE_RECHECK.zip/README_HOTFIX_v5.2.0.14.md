# HOTFIX v5.2.0.14

Corrige el fallo observado en `worker.log` donde se identificaban 136 mods en Modrinth pero el plan terminaba con `0 proyectos Modrinth, 136 mods conservados`, por lo que no se descargaba ningún JAR y se restauraban todos los mods antiguos.

Cambios:
- lectura de la lista de versiones de Modrinth como JSON de texto, compatible de forma determinista con Windows PowerShell 5.1;
- selección de una única release compatible con Minecraft/loader objetivo;
- caché por proyecto/versión/loader;
- los errores de consulta o parseo ya no se ocultan como `CONSERVADO`: abortan con el motivo real;
- si se identifican proyectos pero el plan acaba en cero, el TEST se cancela y no puede reconstruirse silenciosamente con los 136 JAR viejos;
- mantiene la validación SHA-1 física y la salvaguarda de Cobblemon 1.8.1 para 1.21.1/Fabric.
