# v4.9.1: cierre híbrido y conservador

La v4.9.1 mantiene el seguimiento de v4.9, pero ya no termina confiando únicamente en la lista de candidatos.

Al apagar:

1. Se detiene Java limpiamente.
2. El tracker recoge los últimos eventos.
3. Se validan los archivos candidatos detectados durante la partida.
4. Se revisan además las carpetas que quedaban pendientes en el ciclo de barrido suave actual.
5. Si cualquier dato de cobertura no cuadra o el tracker indica riesgo, se hace el escaneo completo de seguridad.
6. Se empaquetan únicamente los archivos realmente modificados en el ZIP de la generación y se sube a Drive.

La revisión adicional consulta metadatos (ruta, tamaño y fecha), no el contenido de los archivos. En una sesión corta puede acercarse al coste del escaneo completo anterior; en una sesión normal suele quedar bastante trabajo adelantado mientras el servidor estaba abierto.

Una creación/renombrado/borrado delicado de carpetas fuerza el fallback completo. Se prefiere fiabilidad a ahorrar uno o dos segundos.
