# Hotfix v5.2.0.17

Corrige la validación final cuando una versión nueva de Modrinth cambia de lado (client/server/both).

- Si un mod estaba en cliente y servidor en NORMAL pero la versión nueva es `server_only`, el TEST ya no intenta restaurar el JAR antiguo en cliente.
- Si la versión nueva debe estar realmente en un lado y falta, la validación sigue abortando.
- Evita el error observado con `advancementdisable` tras completar las 135 descargas.
- Mantiene la validación SHA-1 de los JAR nuevos y la protección contra reintroducir versiones antiguas.

- La activación acepta cualquier TEST construido con v5.2.0.13 o posterior (antes comparaba erróneamente solo contra 5.2.0.13 exacto).
